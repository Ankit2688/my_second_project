mServiceApp.controller('locationController', ['$rootScope', '$scope', '$compile', '$route', '$routeParams', '$location', '$translate', 'dataService', 'appDataShareService', 'commonConfig', function($rootScope, $scope, $compile, $route, $routeParams, $location, $translate, dataService, appDataShareService, commonConfig) {
    $scope.isBranches = true;
    $scope.showAlert = false;
    $scope.locationObj = "";
    $scope.routingInitiated = false;
    $scope.coordinates = "";
    $scope.selectedpage = commonConfig().PAGE_NAME.LOCATION;


    $scope.nearMeState = '';
    $scope.nearMeCity = '';
    $scope.selectedLocationType = 'OFC';
    $scope.locationRadioVal = 'OFC';
    $scope.listingDataArray = [];
    $scope.currentUserCoordinates = {'latitude':6.135397, 'longitude':100.360862};
    $scope.stateType = null;
    $scope.cityType = null;
    $scope.geocoder = null;


    $scope.loadMap = function() {
        showHideLoadingImage(true, "Loading Location Details", null, null);
        if (rootConfig.isDeviceMobile) {
            cordova.plugins.diagnostic.isLocationEnabled(function(enabled) {
                if (enabled) {
                    if (document.querySelectorAll('script')[document.querySelectorAll('script').length - 1].getAttribute('src').toString() !=
                        "https://maps.googleapis.com/maps/api/js?key=AIzaSyAyepjjj2P3K4LBBc51b8NFi00Arb-z9Es"
                    ) {
                        var script = document.createElement('script');
                        script.setAttribute('src', 'https://maps.googleapis.com/maps/api/js?key=AIzaSyAyepjjj2P3K4LBBc51b8NFi00Arb-z9Es');
                        document.body.appendChild(script);

                    }
                    setTimeout(initMap, 5000);
                } else {
                    showHideLoadingImage(false, null, null, "Loading Location Details");
                    $scope.enableGPSMessage = "enableGPSMessage";
                    $scope.showAlert = true;
                    $('#showGPSExpirymsg').modal();
                    console.log($scope.tokenAlertMessage);
                    $scope.$apply();
                }
            }, function(error) {
                console.error("The following error occurred: " + error);
            });
        } else {
            if (document.querySelectorAll('script')[document.querySelectorAll('script').length - 1].getAttribute('src').toString() !=
                "https://maps.googleapis.com/maps/api/js?key=AIzaSyAyepjjj2P3K4LBBc51b8NFi00Arb-z9Es"
            ) {
                var script = document.createElement('script');
                script.setAttribute('src', 'https://maps.googleapis.com/maps/api/js?key=AIzaSyAyepjjj2P3K4LBBc51b8NFi00Arb-z9Es');
                document.body.appendChild(script);
            }
            setTimeout(initMap, 500);
        }
    };
    $scope.goToSettings = function() {
        if ($scope.showAlert) {
            cordova.plugins.diagnostic.switchToLocationSettings();
            $scope.showAlert = false;
            $('#showGPSExpirymsg').hide();
            $scope.$apply();
        }
    };
    var resEvent = document.addEventListener("resume", function() {
        if (document.getElementById('map-section')) {
            if ($scope.routingInitiated) {
                $scope.createMap($scope.coordinates.lat, $scope.coordinates.lng, $scope.coordinates.des);
            } else {
                if(!$scope.coord){
                    $scope.loadLocations();
                } else {
                    $scope.loadMap();
                }
            }
        }
    }, false);

    $scope.$on('$destroy', function() {
        resEvent();
    });

    $scope.showPannelHospitals = function() {
        $scope.loadMap();
        $scope.isBranches = false;
        $scope.coord = $scope.locationObj.PANNEL_HOSPITALS;
        initMap();
    };
    $scope.showGeneraliBranches = function() {
        $scope.loadMap();
        $scope.isBranches = true;
        $scope.coord = $scope.locationObj.GENERALI_BRANCHES;
        initMap();
    };

    var marker = [], map, infowindow = [], lastOpenInfoWindow, markersArray = [];

    // To show the navigate option in info window
    function setContentString(locDetails) {
        $scope.locationDetails  = locDetails;
        $scope.locCoords = {'latitude': locDetails.lat, 'longitude':locDetails.lng, 'data':locDetails.data};
        var contentString = '<div id="content">' +
            '<div id="siteNotice">' +
            '</div>' + '<div id="bodyContent">' +
            '<p>' + locDetails.destination + '</p>' +
            '<span ng-click="navigate2GoogleMaps(locCoords.data)" class="navigate-pointer"></span>' +
            '</div>' +
            '</div>';
        var compiledContentString = $compile(contentString)($scope);
        infowindow = new google.maps.InfoWindow({
            content: compiledContentString[0]
        });
    }

    // To add the infor window to marker on click
    function attachInfoMessage(marker, msg) {
        marker.addListener('click', function() {
            if (lastOpenInfoWindow) {
                lastOpenInfoWindow.close();
            }
            var locDetails = {
                lat: marker.position.lat().toFixed(6),
                lng: marker.position.lng().toFixed(6),
                data: marker.data,
                destination: marker.title
            }
            setContentString(locDetails);
            infowindow.open(marker.get('map'), marker);
            lastOpenInfoWindow = infowindow;
        });
    }

    // Loads markers given the cordinates as an array of objects (must have latitude, longitude attributes to work)
    function loadMarkers(cordinateArray) {
        var pos, markerTitle, iconImage;
        for (i = 0; i < cordinateArray.length; i++) {
            markerTitle = '<span class="sub-title" style="padding-left: 0px; height: 10px;line-height: 20px;">'
                            + cordinateArray[i].Name+'</span><br>'+ cordinateArray[i].AddressLine1 
                            + (cordinateArray[i].AddressLine2 ? '<br>' + cordinateArray[i].AddressLine2 : '') 
                            + (cordinateArray[i].AddressLine3 ? '<br>' + cordinateArray[i].AddressLine3 : '' + '<br>')
                            + cordinateArray[i].PostCode + ', ' + cordinateArray[i].City + '<br>' + cordinateArray[i].State + '<br>'
                            + (cordinateArray[i].PhoneNumber ? cordinateArray[i].PhoneNumber + '<br>' : '')
                            + (cordinateArray[i].Email ? cordinateArray[i].Email + '<br>': '');
            // iconImage = (cordinateArray[i].Type.indexOf("HOS") > -1) 
            //                     ? 'css/main-theme/img/icon_loc_Black_in_Green.png'
            //                     : (cordinateArray[i].Type.indexOf("OFC") > -1)
            //                         ? 'css/main-theme/img/icon_loc_Black_in_blue.png'
            //                         : (cordinateArray[i].Type.indexOf("WOR") > -1
            //                             || cordinateArray[i].Type.indexOf("WIN") > -1)
            //                             ? 'css/main-theme/img/icon_loc_Pink_in_Whilte.png'
            //                             : '';
            if ($scope.isBranches) {
                pos = { lat: '', lng: '' };
                pos.lat = parseFloat(cordinateArray[i].Latitude);
                pos.lng = parseFloat(cordinateArray[i].Longitude);
            } 
            else {
                pos = convertToDecimal(cordinateArray[i].Latitude, cordinateArray[i].Longitude);
            }
            markersArray.push(new google.maps.Marker({ 
                position: pos,
                map: map,
                title: markerTitle,
                // icon: iconImage,
                data: cordinateArray[i]
            }));
            attachInfoMessage(markersArray[markersArray.length - 1], cordinateArray[i].marker);
        }
    }

    // Success call back of geolocation plugin
    function showPosition(position) {
        var locationType = $scope.locationRadioVal;
        $scope.currentUserCoordinates.latitude  = position.coords.latitude;
        $scope.currentUserCoordinates.longitude = position.coords.longitude;

        /* var latitude = 3.155124; var longitude = 101.699255;*/
        geocoder = new google.maps.Geocoder();

        $scope.geocoder = geocoder;

        //  To be changed for UAT 
        //  { "marker": "HEAD OFFICE", "latitude": "3.155124", "longitude": "101.699255"}
        var latlng = new google.maps.LatLng($scope.currentUserCoordinates.latitude, $scope.currentUserCoordinates.longitude);

        // Get Address from a given cordinate
        geocoder.geocode(
            { 'latLng': latlng },
            function(results, status) {
                if (status == google.maps.GeocoderStatus.OK) {
                    if (results[0]) {
                        var add = results[0].formatted_address;
                        var value = add.split(",");
                        count = value.length;
                        $scope.city = value[count - 3];
                        $scope.$apply();
                    }
                }
            }
        );

        // Center position as users current position
        var pos = {lat: $scope.currentUserCoordinates.latitude, lng:$scope.currentUserCoordinates.longitude}; // this is same as {lat:'', lng:''} es6

        // Initialize map with user's position as center position
        map = new google.maps.Map(document.getElementById('map-section'), {
            zoom: 12,
            fullscreenControl: false,
            mapTypeControl: false,
            gestureHandling: 'greedy',
            center: pos
        });

        // User's marker
        marker = new google.maps.Marker({
            position: pos,
            map: map,
            icon: 'css/main-theme/img/icon_loc_blue.png'
        });

        if(localStorage.getItem('productType')) {
            
            switch (localStorage.getItem('productType')) {

                case 'HOS': $scope.hospitalChecked = true;
                            $scope.locationRadioVal = 'HOS';
                            locationType = 'HOS';
                            break;

                case 'WOR': $scope.locationRadioVal = 'MOT';
                            $scope.motorCheck = true;
                            $scope.workshopCheck = true;
                            locationType = 'WOR';
                            break;

                case 'WIN': $scope.locationRadioVal = 'MOT';
                            $scope.motorCheck = true;
                            $scope.windscreenCheck = true;
                            locationType = 'WIN';
                            break;
            }
            localStorage.removeItem('productType');
        }

        if(localStorage.getItem('productCode')) {
            $scope.productType = localStorage.getItem('productCode');
            localStorage.removeItem('productCode');
        }

        $scope.processData(locationType);
        showHideLoadingImage(false, null, null, "Loading Location Details");
    }

    // For Handling error call back in geolocation plugin call
    function showError(error) {
        $scope.noData = true;
        $scope.validSearch = false;
        $scope.alertMessage = translateMessages($translate, "onlineAlertMessage");
        showHideLoadingImage(false, null, null, "Loading Location Details");
        switch (error.code) {
            case error.PERMISSION_DENIED:
                $scope.alertMessage = "deniedReq";
                console.log("User denied the request for Geolocation.");
                break;
            case error.POSITION_UNAVAILABLE:
                $scope.alertMessage = "noLocInfo";
                console.log("Location information is unavailable.");
                break;
            case error.TIMEOUT:
                $scope.alertMessage = "locTimeOut";
                console.log("The request to get user location timed out.");
                break;
            case error.UNKNOWN_ERROR:
                $scope.alertMessage = "locUnknwErr";
                console.log("An unknown error occurred.");
                break;
            default:
                break;
        }
        $scope.$apply();
    }

    function initMap() {
        //check if geolocation feature is enabled.
        navigator.geolocation.getCurrentPosition(showPosition, showError, {
            maximumAge: 3000,
            timeout: 20000,
            enableHighAccuracy: false
        });
    }

    //convert degrees to decimal logic
    function convertToDecimal(lat, lng) {
        var decLat = lat.replace(/[^.\w\s]/gi, '').split(" "),
            decLng = lng.replace(/[^.\w\s]/gi, '').split(" ");
        return {
            lat: Number(decLat[1]) + Number(decLat[2] / 60) + Number(decLat[3] / 3600),
            lng: Number(decLng[1]) + Number(decLng[2] / 60) + Number(decLng[3] / 3600)
        };
    }

    $scope.createMap = function(location) {
        var onSuccess = function(position) {
            //To be changed for UAT
            // position.coords.latitude = 3.155124;
            // position.coords.longitude = 101.699255;
            $scope.currentUserCoordinates.latitude = position.coords.latitude;
            $scope.currentUserCoordinates.longitude = position.coords.longitude;

            if (rootConfig.isDeviceMobile) {
                if (navigator.userAgent.indexOf("Android") > 0) {
                    window.open('geo:0,0?q=' + location.lat + ',' + location.lng + '(' + location.destination + ')', '_system');
                } else {
                    window.open('maps://?q=' + location.lat + ',' + location.lng, '_system');
                }
            } else {
                // var map = null;
                var directionsService = null;
                var directionsDisplay = null;
                document.getElementById('map-section').innerHTML = '';
                map = new google.maps.Map(document.getElementById('map-section'), {
                    zoom: 5,
                    fullscreenControl: false,
                    mapTypeControl: false,
                    center: {
                        lat: $scope.currentUserCoordinates.latitude,
                        lng: $scope.currentUserCoordinates.longitude
                    }
                });
                directionsService = new google.maps.DirectionsService;
                directionsDisplay = new google.maps.DirectionsRenderer({
                    // draggable: true,
                    map: map,
                    panel: document.getElementById('right-panel')
                });
                var origin = new google.maps.LatLng($scope.currentUserCoordinates.latitude, $scope.currentUserCoordinates.longitude);
                var destination = des;
                var waypoints = [];
                /* waypoints.push({
                    location: {lat,lng}, //I don't think I'm supposed to write this like that. But can't find the right way.
                    stopover: true
                }); */
                $scope.displayRoute(origin, destination, directionsService, directionsDisplay, waypoints);
            }
        };
        // onError Callback receives a PositionError object
        function onError(error) {
            showHideLoadingImage(false, null, null, "Loading Location Details");
            $('body').removeClass('loader');
            if (error.code == 3) {
                $scope.meassage = "Please check GPS and Net Connectivity and validity of address";
            } else {
                $scope.meassage = error.message;
            }
            $scope.showMap = false;
            $('body').addClass('map-timed-out');
            $scope.$apply();
            $rootScope.lePopupCtrl.showError(translateMessages($translate, "lifeEngage"), translateMessages($translate, "checkGPSOrNetConnection"), translateMessages($translate, "ok"), $scope.close);
        }
        if (rootConfig.isDeviceMobile) {
            cordova.plugins.diagnostic.isLocationEnabled(function(enabled) {
                if (enabled) {
                    $scope.routingInitiated = false;
                    $scope.coordinates = "";
                    navigator.geolocation.getCurrentPosition(onSuccess, onError, {
                        maximumAge: 3000,
                        timeout: 20000,
                        enableHighAccuracy: false
                    });
                } else {
                    $scope.routingInitiated = true;
                    $scope.coordinates = {
                        "lat": lat,
                        "lng": lng,
                        "des": des
                    }
                    showHideLoadingImage(false, null, null, "Loading Location Details");
                    $scope.enableGPSMessage = "enableGPSMessage";
                    $scope.showAlert = true;
                    $('#showGPSExpirymsg').modal();
                    console.log($scope.tokenAlertMessage);
                    $scope.$apply();
                }
            }, function(error) {
                console.error("The following error occurred: " + error);
            });
        } else {
            navigator.geolocation.getCurrentPosition(onSuccess, onError, {
                maximumAge: 3000,
                timeout: 20000,
                enableHighAccuracy: false
            });
        }
    };
    $scope.displayRoute = function(origin, destination, service, display, waypoints) {
        service.route({
            origin: origin,
            destination: destination,
            waypoints: waypoints,
            optimizeWaypoints: true,
            travelMode: 'DRIVING',
            avoidTolls: true
        }, function(response, status) {
            if (status === 'OK') {
                display.setDirections(response);
                $('body').removeClass('loader');
            } else {
                $scope.showMap = false;
                $('body').addClass('map-timed-out');
                $('body').removeClass('loader');
                $scope.$apply();
                console.log('Could not display directions due to: ' + status);
            }
        });
    };

    function reloadMarkers(cordinatesArray) {
        clearAllMarkers();
        loadMarkers(cordinatesArray);
    }

    function clearAllMarkers() {
        for (var i=0; i< markersArray.length; i++) {
            markersArray[i].setMap(null);
        }
        markersArray = [];
    }

    $scope.nearMe = function(geocoderObj, locationType) {
        $scope.nearMeState = 'Wilayah Persekutuan'; //Deafault State
        $scope.nearMeCity = 'Kuala Lumpur'; //Deafault City
        var pos = { lat: parseFloat($scope.currentUserCoordinates.latitude), 
                    lng: parseFloat($scope.currentUserCoordinates.longitude)};
        // var pos =  { lat: parseFloat('6.135397'), lng: parseFloat('100.360862')};
        // Reverse geocoding to get address froma  given coordinate
        geocoderObj.geocode({'location': pos}, function(results, status) {
          if (status === 'OK') {
            if (results[0]) {
              console.log(results[0]);
              for(var i=0; i < results[0].address_components.length; i++){
                  if(results[0].address_components[i].types.indexOf("administrative_area_level_1") > -1) {
                     $scope.nearMeState = results[0].address_components[i].long_name 
                            ? results[0].address_components[i].long_name
                            : results[0].address_components[i].short_name; 
                  }
                  if(results[0].address_components[i].types.indexOf("locality") > -1) {
                    $scope.nearMeCity  = results[0].address_components[i].long_name
                            ? results[0].address_components[i].long_name
                            : results[0].address_components[i].short_name; 
                  }
              }
              console.log("state " + $scope.nearMeState);
              console.log("city " + $scope.nearMeCity);
              $scope.processData(locationType);
            } else {
                window.alert('No results found');
            }
          } else {
            window.alert('Geocoder failed due to: ' + status);
          }
        });
    }

    $scope.resetToDeafaults = function(type) {
        if(type != 'HOS') { $scope.productType   = null ; }
        if(type != 'MOT') { $scope.workshopCheck = $scope.windscreenCheck = null ; }
    }

    $scope.processData = function(type) {

        $scope.resetToDeafaults($scope.locationRadioVal);

        if($scope.stateType === null && ($scope.nearMeCity === '' || $scope.nearMeState === '')) {
            $scope.nearMe($scope.geocoder, type);
            return;
        };

        var processedMarkerArray = [], nonMotorLocationTypes = [], stateVal, cityVal;
            nonMotorLocationTypes = ['OFC', 'HOS', 'MOT'];
            MotorLocationTypes = ['WIN', 'WOR'];
            // $scope.listingDataArray = [];


        processedMarkerArray = $scope.coord;

        stateVal =  ($scope.stateType === null) ? $scope.nearMeState : $scope.stateType;
        cityVal  =  ($scope.stateType === null) ? $scope.nearMeCity  : $scope.cityType;
        $scope.selectedLocationType = ($scope.locationRadioVal === 'MOT') ? type : $scope.locationRadioVal;

        if(stateVal) {
            processedMarkerArray = $scope.filterState(stateVal, processedMarkerArray);
        }
        if(cityVal) {
            processedMarkerArray = $scope.filterCity(cityVal, processedMarkerArray);
        }
        if($scope.selectedLocationType && (nonMotorLocationTypes.indexOf($scope.selectedLocationType) > -1)) {
            processedMarkerArray = $scope.filterLocations($scope.selectedLocationType, processedMarkerArray);
        }
        if($scope.selectedLocationType && (MotorLocationTypes.indexOf($scope.selectedLocationType) > -1)) {
            processedMarkerArray = $scope.filterLocationMotorSubType($scope.selectedLocationType, processedMarkerArray);
        }
        if($scope.productType && ($scope.selectedLocationType === 'HOS')) {
            processedMarkerArray = $scope.changeProducts($scope.productType, processedMarkerArray);
        }
        // As the digest cycle needs to be called again to paint the dom with fresh value
        $scope.$evalAsync(function() {$scope.listingDataArray = processedMarkerArray;});
        reloadMarkers(processedMarkerArray);
        console.log(processedMarkerArray);

    }

    $scope.changeState = function(stateName) {
        $scope.stateType = stateName;
        $scope.cityType = '';
        $scope.cityTypeList=[];
        for(var i=0;i<$scope.stateListCopy.length;i++) {
            if($scope.stateListCopy[i].name==stateName) {
                for(var j=0;j<$scope.stateListCopy[i].cities.length;j++) {
                    $scope.cityTypeList.push($scope.stateListCopy[i].cities[j]);
                }
                break;
            }
        }
        $scope.processData($scope.selectedLocationType);
        console.log("called chaneg state");
    }

    $scope.changeCity = function(cityName) {
        $scope.cityType = cityName;
        $scope.processData($scope.selectedLocationType);
        console.log("called city");
    }

    // Updates State details
    $scope.filterState=function(stateName, sourceArray) {
        // $scope.stateType = stateName;
        // $scope.cityType = '';
        
        return sourceArray.filter(function(i) { return i.State === stateName });
    };

    // Updates City Details
    $scope.filterCity=function(cityName, sourceStateArray) {
        return sourceStateArray.filter(function(i) { return i.City === cityName });
    };

     $scope.changeProducts = function(productName, sourceProductArray) {
         return sourceProductArray.filter(function(i) { return i.Product.indexOf(productName)>-1 } ) 
                ? sourceProductArray.filter(function(i) { return i.Product.indexOf(productName)>-1} )
                : [];
    };
    
    // Filters Non Motor data
    $scope.filterLocations = function(type, sourceTypeArray) {
        (type === 'HOS') ? $scope.hospitalChecked = true : $scope.hospitalChecked = false;
        (type === 'MOT') ? $scope.motorCheck = true      : $scope.motorCheck = false;
        return sourceTypeArray.filter(function(i) { return i.Type.indexOf(type)>-1 });
    };

    // Filters Motor data
    $scope.filterLocationMotorSubType = function(type, sourceMotorArray) {
        if ($scope.workshopCheck && $scope.windscreenCheck) {
            return (sourceMotorArray.filter( (function(i) { return i.Type.indexOf('WIN')>-1}) || (function(i) { return i.Type.indexOf('WOR')>-1})  ) );
        }
        else if (!$scope.workshopCheck && !$scope.windscreenCheck) {
            return [];
        }
        else {
            $scope.workshopCheck ? type = 'WOR' : type = 'WIN';
            return (sourceMotorArray.filter(function(i) { return i.Type.indexOf(type)>-1}));
        }
    }

    $scope.navigate2GoogleMaps = function(locationDetail) {
        // For Directions
        // window.open(`http://maps.google.com.?`
        // +`saddr=${$scope.currentUserCoordinates.latitude},${$scope.currentUserCoordinates.longitude}`
        // +`&daddr=${locationDetail.latitude},${locationDetail.longitude}`);

        // For location Highlight
        var concatAddress;
        concatAddress = (locationDetail.Name +" "+ locationDetail.AddressLine1 +" "+
                        locationDetail.AddressLine2 +" "+ locationDetail.AddressLine3 +" "+ 
                        locationDetail.State +" "+ locationDetail.City).replace(/ /g, "+");
        window.open('https://www.google.com/maps?q=' + concatAddress); 
    }

    // $scope.focusMarker = function (coords) {
    //     map.setCenter(new google.maps.LatLng(coords.Latitude, coords.Longitude));
    //     map.setZoom(14);
    // }

    $scope.loadLocations = function(successCallBack) {
    var stateList;
    var productList;
    $scope.stateTypeList = [];
    $scope.productTypeList =[];
        LEDynamicUI.getUIJson("hospitalLocations.json", false, function(jsonObject1) {
        $scope.locationObj = jsonObject1;
         $scope.coord = $scope.locationObj.PANEL_HOSPITAL
                            .concat($scope.locationObj.GENERALI_OFFICE)
                            .concat($scope.locationObj.MOTOR);
                $scope.loadMap();
                LEDynamicUI.getUIJson("state.json", false, function(jsonObject2) {
                   stateList=jsonObject2;
                    for(var i = 0; i< stateList.state.length; i++){
                        $scope.stateTypeList.push(stateList.state[i].name);
                    }
                    $scope.stateListCopy = stateList.state;
                    LEDynamicUI.getUIJson("productListing.json", false, function(jsonObject3) {
                       productList=jsonObject3;
                        for(var i = 0; i< productList.healthProducts.length; i++){
                            $scope.productTypeList.push(productList.healthProducts[i]);
                    }
                });
            });
        });
    };

    $scope.loadLocations();
}]);
