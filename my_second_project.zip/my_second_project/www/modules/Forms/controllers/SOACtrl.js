
mServiceApp.controller('SOACtrl',['$controller','$rootScope', '$scope',  '$compile', '$route', '$routeParams', '$location', '$translate','dataService','appDataShareService','customerServiceConfig','commonConfig', 'PersistenceMapping',function($controller ,$rootScope, $scope,  $compile, $route, $routeParams, $location, $translate,dataService,appDataShareService,customerServiceConfig,commonConfig,PersistenceMapping) {
	var mContentRoles=[];
    $scope.downloadPdf = function(fileId, fileName) {
        var downloadPdfUrl = rootConfig.serviceBaseUrl + "policyService/download/"+ $rootScope.username +"/SOA/" + fileId;
        if(rootConfig.isDeviceMobile && navigator.userAgent.includes('Android'))
        {
             downloadPdfFromRemote(downloadPdfUrl, fileName);
        }
        else {            
		    window.open(downloadPdfUrl, "_system");
        }
    };
    $scope.mapScopeToPersistance = function(type) {
        var updatedDate = new Date();
        var formattedDate = Number(updatedDate
                                   .getMonth() + 1)
        + "-"
        + updatedDate.getDate()
        + "-"
        + updatedDate.getFullYear();
        PersistenceMapping.clearTransactionKeys();
        PersistenceMapping.Key2 = $rootScope.username;
        PersistenceMapping.Key5 = "Agent";
        PersistenceMapping.Type = type;
        var transactionObj = PersistenceMapping.mapScopeToPersistence({});
        return transactionObj;
    };
    $scope.intialLoad = function() {
		if($routeParams.pageName=="Account Info"){
		    $scope.selectedpage = commonConfig().PAGE_NAME.ACCOUNT_INFO;
			$scope.agentCode = $rootScope.username;
			$scope.policySearch = {};
			$scope.policySearch.agentCode = "";
			$scope.policySearch.agentCode = $rootScope.agentId;
			$scope.activeFilter = true;
			$scope.hasRecords = true;
			var transactionObj = $scope.mapScopeToPersistance("AgentCode");
			var searchObj = {
				"agentCode" : $scope.agentCode
			};
			transactionObj.TransactionData = searchObj;
			dataService.searchTransactions(transactionObj,$scope.getAgentTransactionSuccess,$scope.getTransactionError);
			var transactionObj = $scope.mapScopeToPersistance("AgentDetails");
				var searchObj = {
				"agentCode" : $scope.policySearch.agentCode
			};
			transactionObj.TransactionData = searchObj;
				transactionObj.Key2 = $scope.agentCode;
				showHideLoadingImage(true,"Agent Information",null,null);
				dataService.searchTransactions(transactionObj,$scope.getAgentSearchTransactionSuccess,$scope.getTransactionErrorAgentInfo);
		}
		
		else{
		showHideLoadingImage(true,"SOA",null,null);
		$scope.selectedpage = commonConfig().PAGE_NAME.SOA;
        $scope.activeFilter = true;
        $scope.hasRecords = true;
        var transactionObj = $scope.mapScopeToPersistance("AgentCode");
        dataService.searchTransactions(transactionObj,$scope.getTransactionSuccess,$scope.getTransactionError);
        //For month dropdown
        $scope.monthList = [];
        var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "July", "Aug", "Sep", "Oct", "Nov", "Dec"];
        var today = new Date();
        var year = today.getFullYear();
        var month = today.getMonth();
        $scope.month =month.toString();
        if($scope.month.length == 1){
           $scope.month = '0'+$scope.month;
        }
        /*$scope.monthList.push({
               key : year+''+$scope.month+1,
               value : monthNames[month]+' '+year
         });*/
        for(var i=0;i<5;i++){
            if (month == 0) {
                month = 11;
                year--;
            } else {
                month--;
            }
            $scope.month =(month+1).toString();
            if($scope.month.length == 1){
              $scope.month = '0'+$scope.month;
            }
            $scope.monthList.push({
                   key : year+''+$scope.month,
                   value : monthNames[month]+' '+year
             });

        }
      $scope.$apply();
		}
    };
	$scope.getAgentTransactionSuccess = function(data){
        $scope.policyNumber = data[0].TransactionData.mappedIds;
        if($routeParams.pageName=="Account Info"){
        	$scope.policyNumber.push($scope.agentCode);
			var l= $scope.policyNumber.length;
        	var temp="";
        	temp = $scope.policyNumber[0];
        	$scope.policyNumber[0] = $scope.policyNumber[l-1];
        	$scope.policyNumber[l-1] = temp;
        }
        $scope.$apply();
    };
	$scope.getAgentSearchTransactionSuccess = function(data){
        showHideLoadingImage(false,"Agent Information",null,null);
        if(data[0] !== undefined)
         {
            if(data[0].TransactionData !== null) {
                $scope.isSearchInValid = false;
                if (data[0].TransactionData.length !== 0) {
                    $scope.motorDatas = [];
                    $scope.nonmotorDatas = [];
                    $scope.userDetails = [];
                    $scope.userDetails = data[0].TransactionData.userDetails;
                    if($scope.userDetails){
                       
                        $scope.hasResult = true;
                        $scope.hasRecords = true;
                        
                    }
                    else{
                        $scope.hasResult = false;
                        $scope.hasRecords = false;
                    }
                }
                else {
                    $scope.hasResult = false;
                    $scope.hasRecords = false;
                    $scope.errorMessage = [];
                    $scope.isSearchInValid = true;
                    $scope.searchFailedMessage = translateMessages($translate, "claimAlerts.searchFailedMessage");
                    $scope.errorMessage.push($scope.searchFailedMessage);
                }
            }
         }
         else {
                $scope.hasResult = false;
                $scope.hasRecords = false;
                $scope.errorMessage = [];
                $scope.isSearchInValid = true;
                $scope.searchFailedMessage = translateMessages($translate, "claimAlerts.searchFailedMessage");
                $scope.errorMessage.push($scope.searchFailedMessage);
         }
        $scope.$apply();
    };
/*	$scope.retrieveAgntCode = function(){
        if($scope.agentCode) {
            $scope.isSearchInValid=false;
            var transactionObj = $scope.mapScopeToPersistance("AgentDetails");
            var searchObj = {
			"agentCode" : $scope.policySearch.agentCode
		};
		transactionObj.TransactionData = searchObj;
            transactionObj.Key29 = $scope.agentCode;
            showHideLoadingImage(true,"Agent Information",null,null);
			dataService.searchTransactions(transactionObj,$scope.getAgentSearchTransactionSuccess,$scope.getTransactionErrorAgentInfo);
        }
        else{
            $scope.isSearchInValid=true;
            $scope.errorMessage=[];
            $scope.errorMessage.push(translateMessages($translate, "forms.agentCodeError"));
            $scope.hasResult=false;
        }        
    };  */
     $scope.getTransactionErrorAgentInfo = function(data) {
                $rootScope.serviceFailed=true;
    			if (rootConfig.isDeviceMobile && !checkConnection()) {
    				$scope.message = translateMessages($translate, "networkValidationErrorMessage");
    			}else{
    				$scope.message = translateMessages($translate, "validToken");
    			}
    			$scope.$emit('tokenEvent', { message: $scope.message });
    			showHideLoadingImage(false,"Agent Information",null,null);
    			if (data == "Error in ajax callE")
    			   {
    				   $scope.onServerError=true;
    				   $scope.serverErrorMessage= translateMessages($translate, "serverErrorMessage");
    				   showHideLoadingImage(false,"Agent Information",null,null);
    			   }
    			   else
    			   {
    				showHideLoadingImage(false,"Agent Information",null,null);
    			   }
    			$rootScope.$apply();
        };
    $scope.getTransactionSuccess = function(data){
        $scope.agentCodeDropDownList = data[0].TransactionData.mappedIds;
        showHideLoadingImage(false,"SOA",null,null);
        $rootScope.$apply();
    };
    $scope.getTransactionError = function(data) {
            $rootScope.serviceFailed=true;
			if (rootConfig.isDeviceMobile && !checkConnection()) {
				$scope.message = translateMessages($translate, "networkValidationErrorMessage");
			}else{
				$scope.message = translateMessages($translate, "validToken");
			}
			$scope.$emit('tokenEvent', { message: $scope.message });
			showHideLoadingImage(false,"SOA",null,null);
			if (data == "Error in ajax callE")
			   {
				   $scope.onServerError=true;
				   $scope.serverErrorMessage= translateMessages($translate, "serverErrorMessage");
				   showHideLoadingImage(false,"SOA",null,null);
			   }
			   else
			   {
				showHideLoadingImage(false,"SOA",null,null);
			   }
			$rootScope.$apply();
    };
    $scope.searchSOA = function(){
        if($scope.agentCode && $scope.monthSelected) {
            $scope.isSearchInValid=false;
            var transactionObj = $scope.mapScopeToPersistance("SOA");
            transactionObj.Key2 = $scope.agentCode;
            var searchObj = {
            				"SearchCriteria" : {
            					"soaMonth" : $scope.monthSelected.key
            				}
            		    };
            transactionObj.TransactionData = searchObj;
            showHideLoadingImage(true,"SOA",null,null);
			if((rootConfig.isDeviceMobile && checkConnection()) || !rootConfig.isDeviceMobile){
			    dataService.searchTransactions(transactionObj,$scope.getSearchTransactionSuccess,$scope.getTransactionError);
			}else{
			    $scope.getTransactionError();
			}
        }
        else{
            $scope.isSearchInValid=true;
            $scope.errorMessage=[];
            if(!$scope.agentCode){
                $scope.errorMessage.push(translateMessages($translate, "forms.agentCodeError"));
            }
            if(!$scope.monthSelected){
                $scope.errorMessage.push(translateMessages($translate, "forms.monthEmptyMessage"));
            }
            $scope.hasResult=false;
        }        
    };
    $scope.getSearchTransactionSuccess = function(data){
        showHideLoadingImage(false,"SOA",null,null);
        if(data[0] !== undefined)
         {
            if(data[0].TransactionData !== null) {
                $scope.isSearchInValid = false;
                if (data[0].TransactionData.length !== 0) {
                    $scope.motorDatas = [];
                    $scope.nonmotorDatas = [];
                    $scope.datas = data[0].TransactionData.SOASearchResult;
                     for(var i = 0; i < $scope.datas.length; i++){
                         if($scope.datas[i].agentIdType != "V" && $scope.datas[i].agentIdType != "N"){
                         	$scope.datas.splice(i,1);
                         	i--;
                         }
                     }
                    if($scope.datas.length > 0){
                        $scope.hasResult = true;
                        $scope.hasRecords = true;
                        for(var i = 0; i < $scope.datas.length; i++){
                            if($scope.datas[i].agentIdType === "V"){
                                $scope.motorDatas.push($scope.datas[i]);
                            }
                            if($scope.datas[i].agentIdType === "N"){
                                $scope.nonmotorDatas.push($scope.datas[i]);
                            }
                        }
                    }
                    else{
                        $scope.hasResult = false;
                        $scope.hasRecords = false;
                    }
                }
                else {
                    $scope.hasResult = false;
                    $scope.hasRecords = false;
                    $scope.errorMessage = [];
                    $scope.isSearchInValid = true;
                    $scope.searchFailedMessage = translateMessages($translate, "claimAlerts.searchFailedMessage");
                    $scope.errorMessage.push($scope.searchFailedMessage);
                }
            }
         }
         else {
                $scope.hasResult = false;
                $scope.hasRecords = false;
                $scope.errorMessage = [];
                $scope.isSearchInValid = true;
                $scope.searchFailedMessage = translateMessages($translate, "claimAlerts.searchFailedMessage");
                $scope.errorMessage.push($scope.searchFailedMessage);
         }
        $scope.$apply();
    };
    $scope.switchTab = function(tabName) {
        switch(tabName) {
            case 'guide': $scope.guideData=true;
						  $scope.claimData=false;
						  break;
            case 'claim': $scope.claimData=true;
                          $scope.guideData=false;
						  break;
			default:break;
        }
    };
    $scope.reset = function(){
        $scope.agentCode = "";
        $scope.nonmotorDatas = [];
        $scope.motorDatas = [];
        $scope.hasResult = false;
        $scope.hasRecords = true;
        $scope.isSearchInValid = false;
    };
    
    $scope.intialLoad();
}]);
