
mServiceApp.controller('GuidesCtrl',['$controller','$rootScope', '$scope','$filter', '$compile', '$route', '$routeParams', '$location', '$translate','dataService','appDataShareService','customerServiceConfig','commonConfig',function($controller ,$rootScope, $scope, $filter,  $compile,$route, $routeParams, $location, $translate,dataService,appDataShareService,customerServiceConfig,commonConfig) {
	var mContentRoles=[];
	var currentSelectedFileForSharing = '';
	$scope.syncDrive = function() {
         $scope.alertSDok= function(){
            $scope.noSDRole=false;
         };
        $scope.selectedpage =commonConfig().PAGE_NAME.CUSTOMER_SERVICE;
        $scope.subModule = customerServiceConfig().SUB_MODULE.FORMS;
	};
    $scope.downloadPdf = function(downloadUrl) {
        $scope.downloadFile = false;
        if((downloadUrl.indexOf('http') >= 0) && (downloadUrl.indexOf('pdf') >= 0) && (rootConfig.isDeviceMobile))
        { 
            navigator.userAgent.includes('Android')
            ? downloadPdfFromRemote(downloadUrl)
            : window.open(downloadUrl, '_system');
            $scope.downloadFile = true;
        }
        else if((downloadUrl.indexOf('pdf') >= 0) && (navigator.userAgent.indexOf('Android') > 0) && (rootConfig.isDeviceMobile)) {
            downloadPdfFromRemote(rootConfig.contentAdminDownLoadURL + downloadUrl);
            $scope.downloadFile = true;
        }
        else
        {

            //existing code
            if($scope.underWriting){
                for(var i = 0; i<$scope.underWriting.length; i++){
                    if($scope.underWriting[i].downloadUrl === downloadUrl){
                        if(rootConfig.isDeviceMobile) {
                            window.plugins.LEFileUtils.getApplicationPath(function (path) {
                                fileFullPath = "file://" + path + "/" + downloadUrl;
                                            // cordova.exec(function () {}, function () {}, "PdfViewer", "showPdf", [fileFullPath]);
                                            window.open(rootConfig.contentAdminDownLoadURL + downloadUrl, '_system');
                            }, function (e) {});                                  
                        }
                        else {
                            var newUrl = rootConfig.contentAdminDownLoadURL + downloadUrl;
                            window.open(newUrl, '_system');
                        }
                        $scope.downloadFile = true;
                        break;
                    }
                }
            }
            if($scope.downloadFile === false){
                downloadUrl.includes('http') 
                ? window.open(downloadUrl, '_system') 
                : window.open(rootConfig.contentAdminDownLoadURL + downloadUrl, '_system');
            }

            // // from agency portal clear duobt
            // else if(rootConfig.isDeviceMobile) {
            //      window.plugins.LEFileUtils.getApplicationPath(function (path) {
            //          fileFullPath = "file://" + path + "/" + downloadUrl;
            //          cordova.exec(function () {}, function () {}, "PdfViewer", "showPdf", [fileFullPath]);
            //      }, function (e) {});
            // }else {
            //      var newUrl = rootConfig.contentAdminDownLoadURL + downloadUrl;
            //       window.open(newUrl, '_system');
            // }
            // $scope.downloadFile = true;
        }
        // // from agency portal clear duobt
        // if($scope.downloadFile === false){
        //         window.open(downloadUrl, '_system');
        // }
    };
	$scope.showPopupShare = function(filename){
		currentSelectedFileForSharing = filename;
	};
	$scope.setShareOptions = function(option){
	 $('#sharePopupModal').modal('hide');
		var fileFullPath = '';
		if(rootConfig.isDeviceMobile){
			window.plugins.LEFileUtils.getApplicationPath(function (path) {
                fileFullPath = "file://" + path + "/"+currentSelectedFileForSharing;
                if (/webOS|iPhone|iPad/i.test(navigator.userAgent)) {
					var options = {
					  message: null, // not supported on some apps (Facebook, Instagram)
					  subject: null, // fi. for email
					  files: [fileFullPath], // an array of filenames either locally or remotely
					  url: null,
					  chooserTitle: null // Android only, you can override the default share sheet title
					}

					var onSuccess = function(result) {
					 // console.log("Share completed? " + result.completed); // On Android apps mostly return false even while it's true
					 // console.log("Shared to app: " + result.app); // On Android result.app is currently empty. On iOS it's empty when sharing is cancelled (result.completed=false)
					}

					var onError = function(msg) {
					  //console.log("Sharing failed with message: " + msg);
					}

					window.plugins.socialsharing.shareWithOptions(options, onSuccess, onError);
				}
				else{
					switch(option){
						case 'whatsapp':
							window.plugins.socialsharing.shareViaWhatsApp(null, fileFullPath /* img */, null /* url */,
							function() {console.log('share ok');},
							function(errormsg){console.log(errormsg);});
							break;
						case 'gmail':
							window.plugins.socialsharing.shareVia('com.google.android.gm', null, null, fileFullPath, null,
								function(){console.log('share ok');},
								function(msg) {console.log(msg);});
								break;
						default:break;
					}
				}
            }, function (e) {console.log(e);});


		}
	};
	
    $scope.intialLoad = function() {
        $scope.activeFilter = true;
        $scope.productData = [];
        $scope.guideData=true;
        $scope.productDescList = [];
        $scope.productTypeList = [];
        $scope.majorClassList = [];
		$scope.fromDate = "";
        $scope.toDate = "";
        var cur = new Date();
		var previousDate = new Date(cur.setDate(cur.getDate() - 364000));
		$scope.toDate = getFormattedDate();
		$scope.fromDate = getFormattedDateFromDate(previousDate);
    
        $scope.pageName=$routeParams.pageName;
       switch($scope.pageName) {
            case "guide" :  $scope.fileName = $scope.getFileName($scope.pageName) + ".json";
                            $scope.selectedpage = commonConfig().PAGE_NAME.GUIDES;
                            if(rootConfig.isDeviceMobile) {
                                LEDynamicUI.getUIJson($scope.fileName, false, function(jsonObject) {
                                    var guides = jsonObject;
                                    $scope.underWriting = guides.Underwriting;
                                    $scope.claims = guides.Claims;
									$scope.guidelines = guides.SocialMediaGuidelines;
									   $scope.tabName = "impCommunication.json";
									    LEDynamicUI.getUIJson($scope.tabName, false, function(jsonObject) {
											   var comm = jsonObject;
											  $scope.searchResultData = comm.impComm;
											 $scope.agentCircularResult = $scope.searchNewDate($scope.fromDate,$scope.toDate,$scope.searchResultData);
									   });
									//$scope.searchResult = guides.AgencyCircularCmm;
                                    $scope.$apply();
                                });
                            }
                            else {
                                $scope.getFromRemote($scope.fileName, false, function(jsonObject) {
                                   if($scope.fileName === 'guide.json') {
                                       var guides = JSON.parse(jsonObject);
                                       $scope.underWriting = guides.Underwriting;
                                       $scope.claims = guides.Claims;
									   $scope.guidelines = guides.SocialMediaGuidelines;
									   $scope.tabName = "impCommunication.json";
									    $scope.getFromRemote($scope.tabName, false, function(jsonObject) {
											   var comm = JSON.parse(jsonObject);
											  $scope.searchResultData = comm.impComm;
											 $scope.agentCircularResult = $scope.searchNewDate($scope.fromDate,$scope.toDate,$scope.searchResultData);
									   });
									   //$scope.searchResult = guides.AgencyCircularCmm;
                                   }
                               });
                            }
                            break;
							
            case "piam" :   $scope.selectedpage = commonConfig().PAGE_NAME.REPAIRERS_WORKSHOPS;
                            $scope.fileName = $scope.getFileName($scope.pageName) + ".json";
                            if(rootConfig.isDeviceMobile) {
                                LEDynamicUI.getUIJson($scope.fileName, false, function(jsonObject) {
                                        var piam = jsonObject;
                                        $scope.piam = piam.Piam;
                                        $scope.$apply();
                                });
                            }
                            else {
                                $scope.getFromRemote($scope.fileName, false, function(jsonObject) {
                                    if($scope.fileName === 'piam.json') {
                                        var piam = JSON.parse(jsonObject);
                                        $scope.piam = piam.Piam;
                                    }
                                });
                            }
                            break;
            case "hospital" :   $scope.selectedpage = commonConfig().PAGE_NAME.HOSPITALS_CLINICS;
                                $scope.fileName = $scope.getFileName($scope.pageName) + ".json";
                                if(rootConfig.isDeviceMobile) {
                                    LEDynamicUI.getUIJson($scope.fileName, false, function(jsonObject) {
                                            var hospital = jsonObject;
                                            $scope.hospital = hospital.Hospital;
                                            $scope.$apply();
                                    });
                                }
                                else {
                                    $scope.getFromRemote($scope.fileName, false, function(jsonObject) {
                                        if($scope.fileName === 'hospital.json') {
                                            var hospital = JSON.parse(jsonObject);
                                            $scope.hospital = hospital.Hospital;
                                        }
                                    });
                                }
                                break;
            case "product" :    $scope.selectedpage = commonConfig().PAGE_NAME.PRODUCTS;
                                $scope.fileName = $scope.getFileName($scope.pageName) + ".json";
                                if(rootConfig.isDeviceMobile) {
                                    LEDynamicUI.getUIJson($scope.fileName, false, function(jsonObject) {
                                            var product = jsonObject;
                                         /*    for(var i = 0; i< product.Personal.length; i++){
												for(var j=0;j<product.Personal[i].productInformation.length;j++)
												{
													$scope.productDescList.push(product.Personal[i].productInformation[j].productDesc);
												}
                                            }
                                            for(var i = 0; i< product.Commercial.length; i++)
											{
											for(var j=0;j<product.Commercial[i].productInformation.length;j++)
												{
													$scope.productDescList.push(product.Commercial[i].productInformation[j].productDesc);
												}
                                            } */
                                            $scope.personal = product.Personal;
                                            $scope.commercial = product.Commercial;
                                            $scope.productTypeList = product.ProductType;
                                            $scope.majorClassList = product.MajorClass;
                                            $scope.$apply();
                                    });
                                }
                                else {
                                    $scope.getFromRemote($scope.fileName, false, function(jsonObject) {
                                        if($scope.fileName === 'product.json') {
                                            var product = JSON.parse(jsonObject);

                                            $scope.personal = product.Personal;
                                            $scope.commercial = product.Commercial;
                                            $scope.productTypeList = product.ProductType;
                                            $scope.majorClassList = product.MajorClass;
                                        }
                                    });
                                }
                                break;
            case "form" :       $scope.selectedpage = commonConfig().PAGE_NAME.FORMS;
                                $scope.fileName = $scope.getFileName($scope.pageName) + ".json";
                                if(rootConfig.isDeviceMobile) {
                                    LEDynamicUI.getUIJson($scope.fileName, false, function(jsonObject) {
                                            var form = jsonObject;
                                            $scope.generalForm = form.generalFormDetails;
                                           // $scope.commercial = form.Commercial;
                                           // $scope.productTypeList = form.ProductType;
                                            $scope.$apply();
                                    });
                                }
                                else {
                                    $scope.getFromRemote($scope.fileName, false, function(jsonObject) {
                                        if($scope.fileName === 'form.json') {
                                            var form = JSON.parse(jsonObject);
                                            $scope.generalForm = form.generalFormDetails;
                                           // $scope.commercial = form.Commercial;
                                           // $scope.productTypeList = form.ProductType;
                                          //  $scope.majorClassList = form.MajorClass;
                                        }
                                    });
                                }
                                break;
            default:    break;
        }
		//$scope.searchDate();
    };
    $scope.getFileName = function(pageName){
        switch(pageName){
        case "guide" :      $scope.fileName = pageName;
                            break;							
        case "piam" :       $scope.fileName = pageName;
                            break;
        case "hospital" :   $scope.fileName = pageName;
                            break;
        case "product" :    $scope.fileName = pageName;
                            break;
        case "form" :    $scope.fileName = pageName;
                            break;
        default :        break;
        }
        return($scope.fileName);
    };
    $scope.getFromRemote = function(jsonFile, callmode, successCallBack,
            errorCallback) {
        var self = this;
        $.ajax({
            type : "GET",
            url : rootConfig.contentAdminDownLoadURL + jsonFile,
            dataType : "text",
            success : function(jsonObject) {
                successCallBack(jsonObject);

            },
            async : callmode,
            error : function(error) {
                console.log('Error : Failed to retrieve config JSON from remote location : ' + rootConfig.contentAdminDownLoadURL + ", "+ jsonFile + JSON.stringify(error));

            }
        });
    };
    $scope.searchProduct = function(){
        if(!$scope.productType || !$scope.productMajorClass || !$scope.productDesc) {
            $scope.errorMessage=[];
            $scope.errorMessage.push(translateMessages($translate, "feedback.allRequiredFeilds"));
            $scope.isSearchInValid=true;
            $scope.hasResult = false;
        }
        else
        {
            $scope.isSearchInValid=false;
            $scope.productData = [];
            $scope.prodData = [];
            $scope.hasResult = false;
			$scope.productHeaders=[];
            switch($scope.productType){
                case "Personal" : for(var i = 0; i < $scope.personal.length; i++){
									if($scope.personal[i].name=="productInformation")
									{
										$scope.productlabelname = $scope.personal[i].productlabelname;
										for(var k=0;k<$scope.personal[i].productheaderNames.length;k++)
									   {
									   $scope.productHeaders.push($scope.personal[i].productheaderNames[k]);
									   }
										for(var j=0;j<$scope.personal[i].value.length;j++)
										{
                                      	if($scope.productMajorClass === $scope.personal[i].value[j].majorClass && $scope.productDesc === $scope.personal[i].value[j].productDesc){
                                            $scope.prodData = $scope.personal[i].value[j].documents;
												for(var k = 0 ; k<$scope.prodData.length;k++){
												if($scope.prodData[k].Link !="")
												{
						                           $scope.productData.push({"NAME":$scope.prodData[k].name , "LINK":$scope.prodData[k].Link})
													$scope.hasResult = true;

												}
											}
                                            break;
                                        }
										}
									}
								}
                           
                                  break;
                case "Commercial" : for(var i = 0; i < $scope.commercial.length; i++){
									if($scope.commercial[i].name=="productInformation")
									{
									$scope.productlabelname = $scope.commercial[i].productlabelname;
									for(var k=0;k<$scope.commercial[i].productheaderNames.length;k++)
									   {
									   $scope.productHeaders.push($scope.commercial[i].productheaderNames[k]);
									   }
										for(var j=0;j<$scope.commercial[i].value.length;j++)
										{
											
                                      	if($scope.productMajorClass === $scope.commercial[i].value[j].majorClass && $scope.productDesc === $scope.commercial[i].value[j].productDesc){
                                            $scope.prodData = $scope.commercial[i].value[j].documents;
												for(var k = 0 ; k<$scope.prodData.length;k++){
												if($scope.prodData[k].Link !="")
												{
						                           $scope.productData.push({"NAME":$scope.prodData[k].name , "LINK":$scope.prodData[k].Link})
													$scope.hasResult = true;

												}
											}
                                            break;
                                        }
										}
									}
								}
                             
                                  break;
                default : break;
            }
        }
    };
    $scope.searchForm = function(){
		$scope.formType = $scope.productType;
		$scope.formMajorClass = $scope.productMajorClass;
       if(!$scope.productType || !$scope.productMajorClass || !$scope.productDesc) {
            $scope.errorMessage=[];
            $scope.errorMessage.push(translateMessages($translate, "feedback.allRequiredFeilds"));
            $scope.isSearchInValid=true;
            $scope.hasResultForm = false;
        }
        else
        {
            $scope.prodData = [];
			$scope.forData =[];
			$scope.formDataValue =[]; 
            $scope.hasResultForm = false;
            $scope.isSearchInValid=false;
			$scope.formHeaders=[];
            switch($scope.formType){
                case "Personal" : for(var i = 0; i < $scope.personal.length; i++){
									if($scope.personal[i].name=="Forms")
									{
									   $scope.formlabelname = $scope.personal[i].formlabelname;
									   for(var k=0;k<$scope.personal[i].formheaderNames.length;k++)
									   {
									   $scope.formHeaders.push($scope.personal[i].formheaderNames[k]);
									   }
										for(var j=0;j<$scope.personal[i].value.length;j++)
										{
                                      	if($scope.productMajorClass === $scope.personal[i].value[j].majorClass && $scope.productDesc === $scope.personal[i].value[j].productDesc){
                                            $scope.forData = $scope.personal[i].value[j].documents;
										
											for(var k = 0 ; k<$scope.forData.length;k++){
												if($scope.forData[k].Link !="")
												{
						                           $scope.formDataValue.push({"NAME":$scope.forData[k].name , "LINK":$scope.forData[k].Link})
													$scope.hasResultForm = true;

												}
											}
									      break;
                                        }
										}
									}
								}
                                 break;
                case "Commercial" : for(var i = 0; i < $scope.commercial.length; i++){
									if($scope.commercial[i].name=="Forms")
									{
										$scope.formlabelname = $scope.commercial[i].formlabelname;
										for(var k=0;k<$scope.commercial[i].formheaderNames.length;k++)
									   {
									   $scope.formHeaders.push($scope.commercial[i].formheaderNames[k]);
									   }
										for(var j=0;j<$scope.commercial[i].value.length;j++)
										{
                                      	if($scope.productMajorClass === $scope.commercial[i].value[j].majorClass && $scope.productDesc === $scope.commercial[i].value[j].productDesc){
                                            $scope.forData = $scope.commercial[i].value[j].documents;
											
											for(var k = 0 ; k<$scope.forData.length;k++){
												if($scope.forData[k].Link !="")
												{
						                           $scope.formDataValue.push({"NAME":$scope.forData[k].name , "LINK":$scope.forData[k].Link})
													$scope.hasResultForm = true;

												}
											}
                                            break;
                                        }
										}
									}
								}
                                break;
                default : break;
            }
        }
    };
    $scope.reset = function(){
        if($scope.pageName === "product"){
            $scope.productType = "";
            $scope.productMajorClass = "";
            $scope.productDesc = "";
            $scope.productData = [];
			$scope.formDataValue =[];
			$scope.hasResult = false;
			$scope.hasResultForm = false;
			$scope.majorClassList = [];
			$scope.formHeaders = [];
			$scope.productHeaders=[];
			$scope.formlabelname ="";
			$scope.productlabelname="";





        }
        if($scope.pageName === "form"){
            $scope.formType = "";
            $scope.formMajorClass = "";
            $scope.formDesc = "";
            $scope.formData = [];
			$scope.formDataValue =[]; 
			$scope.hasResultForm = false;
            $scope.majorClassList = [];
            $scope.productDescList = [];
			$scope.formDataValue =[]; 

        }
		$scope.isSearchInValid=false;
    };
     $scope.changeValue = function(field,fieldValue){
        $scope.classList = [];
        $scope.productDescList = [];
        switch(field){
            case "Type" :   $scope.majorClassList = [];
                            $scope.productMajorClass = "";
                            $scope.productDesc = "";
                            $scope.formDesc = "";
                            $scope.formMajorClass = "";
                            if(fieldValue === "Personal"){
                                for(var i = 0; i < $scope.personal.length; i++){
									for(var j=0;j<$scope.personal[i].value.length;j++)
									{
                                    $scope.classList.push($scope.personal[i].value[j].majorClass);
									}
                                }

                                $.each($scope.classList, function(i, el){
                                    if($.inArray(el, $scope.majorClassList) === -1){
										$scope.majorClassList.push(el);
									}
                                });
                            }
                            if(fieldValue === "Commercial"){
                               for(var i = 0; i < $scope.commercial.length; i++){
								   for(var j=0;j<$scope.commercial[i].value.length;j++)
									{
                                    $scope.classList.push($scope.commercial[i].value[j].majorClass);
									}
                               }
                               $.each($scope.classList, function(i, el){
									if($.inArray(el, $scope.majorClassList) === -1){
										$scope.majorClassList.push(el);
									}
                               });
                            }
                            break;
            case "Class" :  $scope.productDesc = "";
                            $scope.formDesc = "";
							$scope.uniqueList=[];
                            if($scope.productType === "Personal" || $scope.formType === "Personal"){
                                for(var i = 0; i < $scope.personal.length; i++){
									for(var j=0;j<$scope.personal[i].value.length;j++)
                                    if($scope.personal[i].value[j].majorClass === fieldValue){
                                        $scope.productDescList.push($scope.personal[i].value[j].productDesc);
                                    }
                                }
                            }
                            if($scope.productType === "Commercial" || $scope.formType === "Commercial"){
                                 for(var i = 0; i < $scope.commercial.length; i++){
									for(var j=0;j<$scope.commercial[i].value.length;j++)
                                    if($scope.commercial[i].value[j].majorClass === fieldValue){
                                        $scope.productDescList.push($scope.commercial[i].value[j].productDesc);
                                    }
                                }
                            }
							$.each($scope.productDescList, function(i, el){
									if($.inArray(el, $scope.uniqueList) === -1){
										$scope.uniqueList.push(el);
									}
                               });
							   $scope.productDescList = $scope.uniqueList;
                            break;
			default:break;
        }
    };
    $scope.switchTab = function(tabName) {
        switch(tabName) {
            case 'guide': $scope.guideData=true;
                                   $scope.claimData=false;
								   $scope.mediaGuidelines=false;
								   $scope.agency = false;
								   break;
            case 'claim': $scope.claimData=true;
                                   $scope.guideData=false;
								   $scope.mediaGuidelines=false;
								   $scope.agency = false;
								   break;
			case 'mediaGuidelines': $scope.mediaGuidelines=true;
                                   $scope.guideData=false;
								   $scope.claimData=false;
								   $scope.agency = false;
								   
								   break;
			case 'agency': $scope.agency = true; 
								   $scope.mediaGuidelines=false;
                                   $scope.guideData=false;
								   $scope.claimData=false;
								   break;
			default:break;
        }
    };
	
	 function updateDateFormat(date) {
        var newDate= date.split('/');
        return new Date(newDate[2]+'-'+newDate[1]+'-'+newDate[0]);
    }
	  $scope.searchNewDate = function(gFromDate,gToDate,searchResultData){            
    	    var filtered = [];
    	    var impCommData = searchResultData;
    	    $scope.gfromDate = gFromDate;
    	    $scope.gtoDate = gToDate;  
    	    var from_date = $filter('date')($scope.gfromDate, "dd/MM/yyyy");
            var to_date = $filter('date')($scope.gtoDate, "dd/MM/yyyy");
    	    var regExp = /(\d{1,2})\/(\d{1,2})\/(\d{2,4})/;
            for(var i=0;i<impCommData.length;i++){
              if((parseInt(impCommData[i].date.replace(regExp, "$3$2$1")) >= parseInt(from_date.replace(regExp, "$3$2$1"))) && (parseInt(impCommData[i].date.replace(regExp, "$3$2$1")) <= parseInt(to_date.replace(regExp, "$3$2$1")))){
                impCommData[i].agent_actual_date = updateDateFormat(impCommData[i].date);
                filtered.push(impCommData[i]);
              }
            }
            return filtered;
    }
	
	
	
    $scope.getFromApplicationPath = function(jsonFile, successCallBack, errorCallback) {
        	var self = this;
        	self._prepareErrorCallBack = function(errorCode, errorMessage) {
        		if(rootConfig.isDebug){
        			console.log(errorMessage);
        	    }
        	};
        	if (rootConfig && rootConfig.isOfflineDesktop) {
        		var fs = require('fs');
        		fs.readFile(jsonFile, 'utf8', function(err,data) {
        			if (err) {
        				self._prepareErrorCallBack('Error_106','Error while fetching config JSON from remote location'+ jsonFile,
        												errorCallback);
        			}
        			successCallBack(data);
        		});
        	} else {
        		url: rootConfig.contentAdminDownLoadURL + jsonFile,
        				$.getJSON(jsonFile, function(data){ //alert(data)
        				})
        				.done(function(jsonObject,textStatus) {
        			        successCallBack(jsonObject);
        		        })
        				.fail(function(jqxhr,settings,exception) {
        					self._prepareErrorCallBack('Error_106','Error while fetching config JSON from remote location . '+ JSON
        																							.stringify(error),errorCallback);
        				});

        	}
        };
    $scope.intialLoad();
}]);
