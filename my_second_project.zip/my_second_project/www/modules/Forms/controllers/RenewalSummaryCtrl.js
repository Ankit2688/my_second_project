
mServiceApp.controller('RenewalSummaryCtrl',['$controller','$rootScope', '$scope',  '$compile', '$route', '$routeParams', '$location', '$translate','dataService','appDataShareService','customerServiceConfig','commonConfig','PersistenceMapping',function($controller ,$rootScope, $scope,  $compile, $route, $routeParams, $location, $translate,dataService,appDataShareService,customerServiceConfig,commonConfig,PersistenceMapping) {
	$scope.activeFilter = true;
	$scope.noData = false;
	$scope.selectedpage = commonConfig().PAGE_NAME.RENEWAL_SUMMARY;
	$scope.mapScopeToPersistance = function (type) {
	    var newDate = new Date();
	    PersistenceMapping.clearTransactionKeys();
        PersistenceMapping.Key2 = $rootScope.username;
        PersistenceMapping.Key5 = "Agent";
        PersistenceMapping.Key10 = "FullDetails";
        PersistenceMapping.Type = type;
        var transactionObj =  PersistenceMapping.mapScopeToPersistence({});
        return transactionObj;
    };
	$scope.getAgentCodeTransactionSuccess =function(data){
		$scope.agentCodeDropDownList = data[0].TransactionData.mappedIds;
		showHideLoadingImage(false,"Loading Renewal Listing",null,null);
	};
	$scope.intialLoad = function() {
		showHideLoadingImage(true,"Loading Renewal Listing",null,null);
		$scope.isSearchInValid = false;
        $scope.pageName=$routeParams.pageName;
		var transactionObj = $scope.mapScopeToPersistance("AgentCode");
        dataService.searchTransactions(transactionObj,$scope.getAgentCodeTransactionSuccess,$scope.getTransactionError);
    };
	$scope.downloadPdf = function(fileId) {
        var downloadPdfUrl = rootConfig.serviceBaseUrl + "policyService/download/"+ $rootScope.username +"/RENEWALLISTING/" + fileId;
        if(rootConfig.isDeviceMobile && navigator.userAgent.includes('Android')) {
            downloadPdfFromRemote(downloadPdfUrl);
        }
        else {
		    window.open(downloadPdfUrl, "_system");
        }
    };
	$scope.getTransactionSuccess = function(data){
		if(data[0] !== undefined){
			if(data[0].TransactionData !== null) {
				$scope.isSearchInValid = false;
				if (data[0].TransactionData.length !== 0) {
					$scope.renewalSummaryDetails = data[0].TransactionData.RenewalListingResult;
					if($scope.renewalSummaryDetails.length === 0){
						$scope.noData = true;
						$scope.hasResult = false;
					}else{
						$scope.noData = false;
						$scope.hasResult = true;
					}
					$scope.renewalSummaryMotor = [];
					$scope.renewalSummaryNonMotor = [];
					for(var i=0;i<$scope.renewalSummaryDetails.length;i++){
						if($scope.renewalSummaryDetails[i].agentIdType == "V"){
							$scope.renewalSummaryMotor.push($scope.renewalSummaryDetails[i]);
						}else{
							$scope.renewalSummaryNonMotor.push($scope.renewalSummaryDetails[i]);
						}
					}
				}
				else {
					$scope.hasResult = false;
					$scope.errorMessage = [];
					$scope.isSearchInValid = true;
					$scope.searchFailedMessage = translateMessages($translate, "claimAlerts.searchFailedMessage");
		            $scope.errorMessage.push($scope.searchFailedMessage);
				}
			}
		 }
		 else {
				$scope.noOfPolicies = 0;
				$scope.hasResult = false;
				$scope.errorMessage = [];
				$scope.isSearchInValid = true;
				$scope.searchFailedMessage = translateMessages($translate, "claimAlerts.searchFailedMessage");
	            $scope.errorMessage.push($scope.searchFailedMessage);
	     }
		 showHideLoadingImage(false,"Loading Renewal Listing",null,null);
		 $scope.refresh();
	};
	$scope.getTransactionError = function(data){
		$rootScope.serviceFailed=true;
        if (rootConfig.isDeviceMobile && !checkConnection()) {
			$scope.message = translateMessages($translate, "networkValidationErrorMessage");
		}else{
			$scope.message = translateMessages($translate, "validToken");
		}
        $scope.$emit('tokenEvent', { message: $scope.message });
        if (data == "Error in ajax callE"){
            $scope.onServerError=true;
            $scope.serverErrorMessage= translateMessages($translate, "serverErrorMessage");
			showHideLoadingImage(false,"Loading Renewal Listing",null,null);
        }else{
            showHideLoadingImage(false,"Loading Renewal Listing",null,null);
        }
        $rootScope.$apply();
	};
    $scope.searchRenewalSummary = function(){
		if($scope.agentCode && $scope.duration){
			showHideLoadingImage(true,"Loading Renewal Listing",null,null);
			$scope.errorMessage = [];
			$scope.isSearchInValid = false;
			var transactionObj = $scope.mapScopeToPersistance("RenewalListing");
			var searchObj = {
				"SearchCriteria" : {
					"agentCode" : $scope.agentCode,
					"renewalListingPeriod" : $scope.duration
				}
			};
			transactionObj.TransactionData = searchObj;
			if((rootConfig.isDeviceMobile && checkConnection()) || !rootConfig.isDeviceMobile){
			    dataService.searchTransactions(transactionObj, $scope.getTransactionSuccess, $scope.getTransactionError);
			}else{
			    $scope.getTransactionError();
			}
		}else{
			$scope.isSearchInValid = true;
			$scope.hasResult = false;
			$scope.errorMessage = [];
			$scope.bothSearchFieldMandatoryValidationMessage = translateMessages($translate, "customerService.bothSearchFieldMandatoryValidationMessage");
            $scope.errorMessage.push($scope.bothSearchFieldMandatoryValidationMessage);
		}
    };
	$scope.reset = function(){
		$scope.duration = "";
		$scope.agentCode = "";
		$scope.hasResult = false;
		$scope.noData = false;
		$scope.errorMessage = [];
		$scope.isSearchInValid = false;
	};

    $scope.intialLoad();
}]);
