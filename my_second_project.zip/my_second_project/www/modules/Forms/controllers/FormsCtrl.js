
mServiceApp.controller('FormsCtrl',['$controller','$rootScope', '$scope',  '$compile', '$route', '$routeParams', '$location', '$translate','dataService','appDataShareService','customerServiceConfig','commonConfig',function($controller ,$rootScope, $scope,  $compile, $route, $routeParams, $location, $translate,dataService,appDataShareService,customerServiceConfig,commonConfig) {
	var mContentRoles=[];
	$scope.syncDrive = function() {
         $scope.alertSDok= function(){
            $scope.noSDRole=false;
         };
        $scope.selectedpage =commonConfig().PAGE_NAME.CUSTOMER_SERVICE;
        $scope.subModule = customerServiceConfig().SUB_MODULE.FORMS;
	};
    $scope.downloadPdf = function(downloadUrl) {
    };
    $scope.intialLoad = function() {
        $scope.guideData=true;
        $scope.pageName=$routeParams.pageName;
        switch($scope.pageName) {
            default:
                $scope.datas=[{
                    'fileName':"File 1",
                    "downloadUrl":"http://hasjkjf.cm"
                },
                             {
                    'fileName':"File 1",
                    "downloadUrl":"http://hasjkjf.cm"
                },
                             {
                    'fileName':"File 1",
                    "downloadUrl":"http://hasjkjf.cm"
                },
                             {
                    'fileName':"File 1",
                    "downloadUrl":"http://hasjkjf.cm"
                }]; break;
        }
    };
    $scope.switchTab = function(tabName) {
        switch(tabName) {
            case 'guide': $scope.guideData=true;
                                   $scope.claimData=false;
								   break;
            case 'claim': $scope.claimData=true;
                                   $scope.guideData=false;
								   break;
			default:break;
        }
    };
    $scope.intialLoad();
}]);