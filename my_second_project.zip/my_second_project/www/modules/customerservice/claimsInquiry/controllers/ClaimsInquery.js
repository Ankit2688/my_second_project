mServiceApp.controller('ClaimsInquery',['$controller','$rootScope', '$scope',  '$compile', '$route', '$routeParams', '$location', '$translate','dataService','appDataShareService','AutoSync','debounce','$timeout','$filter','PersistenceMapping', 'mServiceConstants','commonConfig','customerServiceConfig',function($controller ,$rootScope, $scope,  $compile, $route, $routeParams, $location, $translate,dataService,appDataShareService,AutoSync,debounce,$timeout,$filter,PersistenceMapping,mServiceConstants,commonConfig,customerServiceConfig) {
    var _this = this;
	angular.extend(this, $controller('BaseCtrl',{$scope:$scope, $rootScope:$rootScope, dataService:dataService, type:'clientLoggedSearch', userId:appDataShareService.selectedUser.userId}));
	$scope.noData = false;
     $scope.activeFilter = true;
	$scope.selectedpage = commonConfig().PAGE_NAME.CLAIM_INQUIRY;
	$scope.setData = function() {
		$scope.gliPolicySearch.policyNumber = "";
		$scope.gliPolicySearch.customerFirstName = "";
		$scope.gliPolicySearch.mobileNumber = "";
		$scope.gliPolicySearch.policyStartDateFrom = "";
		$scope.gliPolicySearch.policyStartDateTo = "";
		$scope.gliPolicySearch.policyEndDateFrom = "";
		$scope.gliPolicySearch.policyEndDateTo = "";
		$scope.gliPolicySearch.contractType = "";
		$scope.gliPolicySearch.claimStatus = "";
		$scope.gliPolicySearch.branch = "";
        $scope.gliPolicySearch.agentCode = "";
        $scope.gliPolicySearch.vehicleRegNumber = "";
        $scope.noDataFromServer = true;
	};
	// reset the search form fields
	$scope.reset = function() {        
		$scope.isValid = false;
		$scope.isValid2 = false;
		$scope.isSearchInValid = false;
		$scope.validSearch = false;
		$scope.errorMessage = [];
        $scope.noDataFromServer = true;
		$scope.gliPolicySearch.policyNumber = "";
		$scope.gliPolicySearch.claimNumber = "";
		$scope.gliPolicySearch.customerFirstName = "";
		$scope.gliPolicySearch.mobileNumber = "";
		$scope.gliPolicySearch.policyStartDateFrom = "";
		$scope.gliPolicySearch.policyStartDateTo = "";
		$scope.gliPolicySearch.claimIncuiredFrom = "";
		$scope.gliPolicySearch.claimIncuiredTo = "";
		$scope.gliPolicySearch.claimStatus = "";
		$scope.gliPolicySearch.branch = "";
        $scope.gliPolicySearch.agentCode = "";
        $scope.gliPolicySearch.vehicleRegNumber = "";
	};
	$scope.initialLoad = function(){
			showHideLoadingImage(true, "Loading Claims Inquiry", null,null);
    		//For policy status dropdown value
    	    var transactionObj = $scope.mapScopeToPersistance();
    		transactionObj.Type = "claimstatus";
    		dataService.searchTransactions(transactionObj,$scope.getTransactionSuccessClaimStatus,$scope.getTransactionError);
    	};
    $scope.getTransactionSuccessClaimStatus = function(data){
    	$scope.claimStatusDropDownList=[];
    	if(data[0] !== undefined && data[0].TransactionData !== null)
    	{
   			if (data[0].TransactionData.lookUps.length !== 0) {
    				$scope.claimStatusDropDownList = data[0].TransactionData.lookUps;
    				$scope.$apply();
    		}
    	}
    	else{
    		   $scope.claimStatusDropDownList=[];
    	}
    	 //For agent code dropdown values
         var transactionObj = $scope.mapScopeToPersistance();
         transactionObj.Type = "AgentCode";
         dataService.searchTransactions(transactionObj,$scope.getTransactionSuccessAgentCode,$scope.getTransactionError);
    };
    $scope.getTransactionSuccessAgentCode = function(data){
        		$scope.agentCodeDropDownList=[];
        		if(data[0] !== undefined && data[0].TransactionData !== null)
        		 {
        			if (data[0].TransactionData.mappedIds.length !== 0) {
        				$scope.agentCodeDropDownList = data[0].TransactionData.mappedIds;
        				$scope.$apply();
        			}
        		 }
        		else{
        			   $scope.agentCodeDropDownList=[];
        		}
        		 //For branch drop down values
                var transactionObj = $scope.mapScopeToPersistance();
                transactionObj.Type = "BranchCode";
                dataService.searchTransactions(transactionObj,$scope.getTransactionSuccessBranch,$scope.getTransactionError);
                showHideLoadingImage(false);
        	};
       $scope.getTransactionSuccessBranch = function(data){
        		$scope.branchDropDownList=[];
        		if(data[0] !== undefined && data[0].TransactionData !== null)
        		 {
        			if (data[0].TransactionData.branches.length !== 0) {
        				$scope.branchDropDownList = data[0].TransactionData.branches;
        				$scope.$apply();
        			}
        		 }
        		else{
        			   $scope.branchDropDownList=[];
        		}
        		showHideLoadingImage(false);
       };
	$scope.mapScopeToPersistance = function () {
	    var newDate = new Date();
	    PersistenceMapping.clearTransactionKeys();
        PersistenceMapping.Key1 = "";
        PersistenceMapping.Key2 = $rootScope.username;
        PersistenceMapping.Key5 = "Agent";
        PersistenceMapping.Key10 = "";
        PersistenceMapping.Type = _this.Type;
        var transactionObj =  PersistenceMapping.mapScopeToPersistence({});
        return transactionObj;
    };
	$scope.searchPolicyDetails = function(gliPolicySearch, fromSearchButton){
		$scope.policySearch = gliPolicySearch;
		var transactionObj = $scope.mapScopeToPersistance();
		transactionObj.type = "clientLoggedSearch";
		//Date format conversion to dd/MM/yyyy for request json
		if($scope.policySearch.policyStartDateFrom && $scope.policySearch.policyStartDateTo){
			$scope.policyStartDateFrom = $scope.policySearch.policyStartDateFrom;
	    	$scope.policyStartDateTo = $scope.policySearch.policyStartDateTo;
		}
		else{
			$scope.policyStartDateFrom = "";
			$scope.policyStartDateTo = "";
		}
		if($scope.policySearch.claimIncuiredFrom && $scope.policySearch.claimIncuiredTo){
			$scope.claimIncuiredFrom = $scope.policySearch.claimIncuiredFrom;
	    	$scope.claimIncuiredTo = $scope.policySearch.claimIncuiredTo;
		}
		else{
			$scope.claimIncuiredFrom = "";
			$scope.claimIncuiredTo = "";
		}
		 if($scope.policySearch.branch){
               $scope.branch = $scope.policySearch.branch.code;
          }
         else{
              $scope.branch = "";
         }

		if(!$scope.policySearch.claimStatus)
         {
            $scope.policySearch.claimStatus=[{
                "code":""
            }];
         }
         var searchObj = {
				"SearchCriteria" : {
					"policyNumber" : $scope.policySearch.policyNumber,
					"claimNumber" : $scope.policySearch.claimNumber,
					"policyHolderName": $scope.policySearch.customerFirstName,
					"mobileNumber" : $scope.policySearch.mobileNumber,
					"incurredDateFrom" : $scope.claimIncuiredFrom,
					"incurredDateTo" : $scope.claimIncuiredTo,
					"claimStatus" : $scope.policySearch.claimStatus.code,
					"policyFromDate" : $scope.policyStartDateFrom,
					"policyEndDate" : $scope.policyStartDateTo,
					"vehicleRegNumber" : $scope.policySearch.vehicleRegNumber,
					"agentCode": $scope.policySearch.agentCode,
                    "branchCode" : $scope.branch
				}
			};
		$scope.searchFieldCount = 0;
		$scope.searchFieldEmptyCount = 0;
		Object.keys(searchObj.SearchCriteria).forEach(function(key) {
			  if (searchObj.SearchCriteria[key] == undefined) {
				  searchObj.SearchCriteria[key] = "";
			  }
		});
		Object.keys(searchObj.SearchCriteria).forEach(function(key) {
			  if (searchObj.SearchCriteria[key] == "") {
				  $scope.searchFieldEmptyCount++;
			  }
		});
		//To get count of searchObj
		Object.keys(searchObj.SearchCriteria).forEach(function(key) {
			  if (searchObj.SearchCriteria) {
				  $scope.searchFieldCount++;
			  }
		});
		if($scope.searchFieldEmptyCount == $scope.searchFieldCount){
			$scope.isSearchInValid = true;
			$scope.validSearch = false;
			$scope.errorMessage = [];
			$scope.minOneSearchFieldValidationMessage = translateMessages($translate, "policySearch.minOneSearchFieldValidationMessage");
            $scope.errorMessage.push($scope.minOneSearchFieldValidationMessage);
		}
		else{
			$scope.errorMessage = [];
			$scope.isSearchInValid = false;
            searchObj.SearchCriteria.pageNo = $scope.pageNumber;
            searchObj.SearchCriteria.pageSize = rootConfig.resultPerPage;
			transactionObj.TransactionData = searchObj;
            if(fromSearchButton)
			     showHideLoadingImage(true, "Loading Claim Inquiry", $translate);
				 
			if((rootConfig.isDeviceMobile && checkConnection()) || !rootConfig.isDeviceMobile){
			    dataService.searchTransactions(transactionObj, $scope.getTransactionSuccess, $scope.getTransactionError);
			}else{
			    $scope.getTransactionError();
			}
		}
	};
	$scope.validateFields = function(policySearch){
	    $scope.noDataFromServer = true;
        $scope.errorMessage = [];
		$scope.noData = false;
		if(policySearch){
			$scope.policySearch = policySearch;
		} else {
			$scope.policySearch = [];
		}
		//Date validation for Policy Start Date
		 if($scope.policySearch.policyStartDateFrom && $scope.policySearch.policyStartDateTo){
			if($scope.policySearch.policyStartDateTo < $scope.policySearch.policyStartDateFrom){
            	$scope.errorMessage = [];
            	$scope.isValid = true;
				$scope.dateRangeSixtyValidationMessage = translateMessages($translate, "policySearch.fromGreaterthanToValidationMessage");// have'nt got the error message
                $scope.errorMessage.push($scope.dateRangeSixtyValidationMessage);
            }
            else{
            	$scope.isValid = false;
            }
		}
		else if(($scope.policySearch.policyStartDateFrom && !$scope.policySearch.policyStartDateTo) || (!$scope.policySearch.policyStartDateFrom && $scope.policySearch.policyStartDateTo)){
				$scope.fromTodateValidationErrorMessage = translateMessages($translate, "policySearch.fromTodateValidationErrorMessage");
				$scope.errorMessage.push($scope.fromTodateValidationErrorMessage);
				$scope.isValid = true;
		}
		else{
        	$scope.isValid = false;
		}
		//Date validation for Policy Expiry Date
		if($scope.policySearch.claimIncuiredFrom && $scope.policySearch.claimIncuiredTo){
        			if(isFutureDate($scope.policySearch.claimIncuiredFrom) || isFutureDate($scope.policySearch.claimIncuiredTo)){
        				$scope.errorMessage = [];
        				$scope.isValid2 = true;
        				$scope.futureDateValidationMessage = translateMessages($translate, "claimAlerts.futureDateValidationMessage");
                        $scope.errorMessage.push($scope.futureDateValidationMessage);
                    } else if($scope.policySearch.claimIncuiredTo < $scope.policySearch.claimIncuiredFrom){
                    	$scope.errorMessage = [];
                    	$scope.isValid2 = true;
        				$scope.dateRangeSixtyValidationMessage = translateMessages($translate, "claimAlerts.fromGreaterthanToValidationMessage");// have'nt got the error message
                        $scope.errorMessage.push($scope.dateRangeSixtyValidationMessage);
                    }
                    else{
                    	$scope.isValid2 = false;
                    }
        		}
        		else if(($scope.policySearch.claimIncuiredFrom && !$scope.policySearch.claimIncuiredTo) || (!$scope.policySearch.claimIncuiredFrom && $scope.policySearch.claimIncuiredTo)){
        				$scope.errorMessage = [];
        				$scope.fromTodateValidationErrorMessage = translateMessages($translate, "claimAlerts.fromTodateValidationErrorMessage");
        				$scope.errorMessage.push($scope.fromTodateValidationErrorMessage);
        				$scope.isValid2 = true;
        		}
        		else{
                	$scope.isValid2 = false;
        		}
		if($scope.isValid || $scope.isValid2){
			//errror message
			$scope.isSearchInValid = true;
			$scope.validSearch = false;
		}
		else{
			$scope.isSearchInValid = false;
			$scope.errorMessage = [];
            $scope.pageNumber = 1; // for lazy loading
            $scope.searchData=JSON.parse(JSON.stringify($scope.policySearch));
			$scope.searchPolicyDetails($scope.policySearch, true);
		}
	};
	$scope.getTransactionSuccess = function(data) {
		showHideLoadingImage(false);
        $scope.activeFilter = false;
		var policySearchDetails = [];
        if($scope.pageNumber==1) {
			$scope.clientDetails = [];
            $scope.policySearchResultFullData=[]
        }
		 if(data[0])
		 {
		  if (data[0].TransactionData !== null) {
				$scope.validSearch = true;
				if (data[0].TransactionData.ClaimsLoggedSearchResult.length !== 0) {
					$scope.noData = false;
					policySearchDetails = data[0].TransactionData.ClaimsLoggedSearchResult;
					var formattedDate;
					$scope.noOfPolicies = data[0].Key25;
                    if(policySearchDetails.length < rootConfig.resultPerPage) {
                            $scope.noDataFromServer=true;
                     } else {
                         $scope.noDataFromServer=false;
                     }
					for ( var i = 0; i < policySearchDetails.length; i++) {
                        $scope.policySearchResultFullData.push(policySearchDetails[i]);
						var policyStatus;
						var policyIcon;
						policySearchDetails[i].agentCode = policySearchDetails[i].branchCode+' '+policySearchDetails[i].agentCode;
						$scope.clientDetailsTemp = [];
						$scope.clientDetailsTemp.push({
                           	key : translateMessages($translate, "claimInquiry.branchOffice"),
                           	value : policySearchDetails[i].branchName
                        });
                        $scope.clientDetailsTemp.push({
                           	key : translateMessages($translate, "claimInquiry.accountCode"),
                           	value : policySearchDetails[i].agentCode
                        });
                        $scope.clientDetailsTemp.push({
                        	key : translateMessages($translate, "policySearch.productName"),
                        	value : policySearchDetails[i].productName
                        });
                        $scope.clientDetailsTemp.push({
                            key : translateMessages($translate, "claimInquiry.claimantName2"),
                            value : policySearchDetails[i].policyholderName
                         });
                        $scope.clientDetailsTemp.push({
                        	key : translateMessages($translate, "claimInquiry.dateOfLoss"),
                        	value : policySearchDetails[i].claimIncurredDate,
                        	isRupeeShow : true
                        });
                        $scope.clientDetailsTemp.push({
                        	key : translateMessages($translate, "claimInquiry.claimLossDescription"),
                        	value : policySearchDetails[i].claimLossDescription
                        });
                        var claimAmount = parseInt(policySearchDetails[i].paid)+parseInt(policySearchDetails[i].balanceOutstanding);
                        claimAmount = claimAmount.toString();
                        $scope.clientDetailsTemp.push({
                        	key : translateMessages($translate, "claimInquiry.claimPaid"),
                        	value : policySearchDetails[i].paid
                        });
                        policyStatus = policySearchDetails[i].claimStatusCode;
                        switch (policyStatus) {
                        case '2':
                        	policyIcon = mServiceConstants.PolicyLapsedIcon;
                        	break;
                        default:
                        	policyIcon = mServiceConstants.PolicyActiveIcon;
                            break;
                        }
                        formattedDate1=LEDate(policySearchDetails[i].claimLastUpdatedDate);
                        formattedDate=$filter('date')(formattedDate1, "dd-MM-yyyy h:mm a");
						$scope.clientDetails
								.push({
									"header" : policySearchDetails[i].claimNumber,
                                    "lastUpdatedDate": formattedDate,
									"data" : $scope.clientDetailsTemp,
									"statusIcon" : policyIcon
								});
					}
                    appDataShareService.claimInquiryjson = {
				        'policySearch' : $scope.policySearchResultFullData
				    };
                    $scope.pageNumber++;
                    $scope.noData = false;
                    $scope.validSearch = true;
				} else if($scope.clientDetails.length ==0) {
					$scope.noData = true;
					$scope.noOfPolicies = 0;
					$scope.validSearch = false;
				    $scope.alertMessage = translateMessages($translate, "onlineAlertMessage");
				}
			}
			}else {
			$scope.noData = true;
			$scope.noOfPolicies = 0;
			$scope.validSearch = false;
			$scope.alertMessage = translateMessages($translate, "onlineAlertMessage");
		}
		showHideLoadingImage(false);
        $scope.loadingMoreData=false;
        $scope.$apply();
	};
	$scope.getTransationError = function(data) {
    	 $rootScope.serviceFailed=true;
            	if (rootConfig.isDeviceMobile && !checkConnection()) {
					$scope.message = translateMessages($translate, "networkValidationErrorMessage");
				}else{
					$scope.message = translateMessages($translate, "validToken");
				}
            	$scope.$emit('tokenEvent', { message: $scope.message });
            	if (data == "Error in ajax callE")
                   {
                       $scope.onServerError=true;
                       $scope.serverErrorMessage= translateMessages($translate, "serverErrorMessage");
                      showHideLoadingImage(false);
                   }
                   else
                   {
            		showHideLoadingImage(false);
                   }
        $scope.loadingMoreData=false;
            	$rootScope.$apply();
    };
	 $scope.getPolicyInfo = function(policyNumber,id) {
     			$scope.policyNumber = policyNumber;
     			var policySearchData = appDataShareService.claimInquiryjson.policySearch;
     			var formattedDate1="";
     			var formattedDate="";
     			var issueDate1="";
     			var issueDate="";
     			var policyStartDate1="";
     			var policyStartDate="";
     			var policyExpiryDate1="";
     			var policyExpiryDate="";
     			for ( var i = 0; i < policySearchData.length; i++) {
     				if (policySearchData[i].claimNumber === ($scope.policyNumber) && policySearchData[i].id == id) {
     					$scope.policyDetails = [];
     					if (policySearchData[i].dateOfBirth!=="")
     					{
     						 formattedDate1=new Date(policySearchData[i].dateOfBirth);
     						 formattedDate=$filter('date')(formattedDate1, "dd-MM-yyyy");
     					}
     					else
     					{
     						 formattedDate=policySearchData[i].dateOfBirth;
     					}
     					if (policySearchData[i].issueDate!=="")
     					{
     						issueDate1 = new Date(policySearchData[i].issueDate);
     						issueDate=$filter('date')(issueDate1, "dd-MM-yyyy");
     					}
     					else
     					{
     						issueDate=policySearchData[i].issueDate;

     					}
     					if (policySearchData[i].policyStartDate!=="")
     					{
     						policyStartDate1 = new Date(policySearchData[i].policyStartDate);
     						policyStartDate =$filter('date')(policyStartDate1, "dd-MM-yyyy");
     					}
     					else
     					{
     						policyStartDate=policySearchData[i].policyStartDate;

     					}
     					if (policySearchData[i].policyExpiryDate!=="")
     					{
     						policyExpiryDate1 = new Date(policySearchData[i].policyExpiryDate);
     						policyExpiryDate=$filter('date')(policyExpiryDate1, "dd-MM-yyyy");
     					}
     					else
     					{
     						policyExpiryDate=policySearchData[i].policyExpiryDate;
     					}
     					$scope.policyDetails.push({
     						key : translateMessages($translate, "policySearch.dateOfBirthText"),
     						value : formattedDate
     						});
     					$scope.policyDetails
     							.push({
     								key : translateMessages($translate, "policySearch.insuredName"),
     								value : policySearchData[i].policyholderName
     							});
     					$scope.policyDetails.push({
     						key : translateMessages($translate, "policySearch.issueDate"),
     						value : issueDate
     						});
     					$scope.policyDetails.push({
     						key : translateMessages($translate, "policySearch.policyStartDate"),
     						value : policyStartDate
     						});
     					$scope.policyDetails.push({
     						key : translateMessages($translate, "policySearch.policyEndDate"),
     						value : policyExpiryDate
     					});
     				}
     			}
     		};
	  $scope.getTransactionError = function(data) {
			if (rootConfig.isDeviceMobile && !checkConnection()) {
				$scope.message = translateMessages($translate, "networkValidationErrorMessage");
			}else{
				$scope.message = translateMessages($translate, "validToken");
			}
			$rootScope.serviceFailed=true;
     		$scope.$emit('tokenEvent', { message: $scope.message });
     		if (data == "Error in ajax callE"){
     			$scope.onServerError=true;
     			$scope.serverErrorMessage= translateMessages($translate, "serverErrorMessage");
     			showHideLoadingImage(false);
     		}else{
     			showHideLoadingImage(false);
     		}
     		$rootScope.$apply();
     	};
	 $scope.getContactInfo = function(policyNumber,id) {
     			$scope.policyNumber = policyNumber;
     			var policySearchData = appDataShareService.claimInquiryjson.policySearch;
     			for ( var i = 0; i < policySearchData.length; i++) {
     				if (policySearchData[i].claimNumber === ($scope.policyNumber) && policySearchData[i].id == id) {
     					$scope.contactInfoDetails = [];
     					$scope.contactInfoMobileNumber =   policySearchData[i].mobileNumber;
     					$scope.contactInfoPhoneNumber =  [policySearchData[i].telephoneHome, policySearchData[i].telephoneOffice];
     					$scope.mailingAddress = policySearchData[i].mailingAddress[0].addressLine1+','+policySearchData[i].mailingAddress[0].addressLine2+','+policySearchData[i].mailingAddress[0].addressLine3+','+policySearchData[i].mailingAddress[0].addressLine4;
     					$scope.contactInfoDetails
     							.push({
     								key : translateMessages($translate, "policySearch.nameText"),
     								value :[policySearchData[i].policyholderName]
     							});
     					$scope.contactInfoDetails.push({
     						key : translateMessages($translate, "policySearch.mobileText"),
     						value :[$scope.contactInfoMobileNumber]
     					});
     					$scope.contactInfoDetails.push({
     						key : translateMessages($translate, "policySearch.emailText"),
     						value : [ policySearchData[i].emailId ]
     					});
     					$scope.contactInfoDetails.push({
     						key : translateMessages($translate, "policySearch.phoneText"),
     						value : $scope.contactInfoPhoneNumber
     					});
     					$scope.contactInfoDetails.push({
     						key : translateMessages($translate, "policySearch.mailingText"),
     						value : [$scope.mailingAddress]
     					});
     				}
     			}
     		};
    
    $scope.$on('requestDataSet', function(e, args) {
        if(!$scope.noDataFromServer) {
            $scope.loadingMoreData=true;
            $scope.searchPolicyDetails($scope.searchData, false);
        }
        else {
        	$scope.loadingMoreData=false;
        }
        $scope.$apply();
    });
    
    $scope.initialLoad();
}]);
