mServiceApp.controller('GLI_PolicySearchCtrl',['$controller','$rootScope', '$scope',  '$compile', '$route', '$routeParams', '$location', '$translate','dataService',
'appDataShareService','UserDetailsService','AutoSync','debounce','$timeout','$filter','commonConfig','mServiceConstants','customerServiceConfig','gli_dataservice','PersistenceMapping',function GLI_PolicySearchCtrl($controller ,$rootScope, $scope,
$compile, $route, $routeParams, $location, $translate,dataService,appDataShareService,UserDetailsService,AutoSync,debounce,$timeout,$filter,commonConfig,mServiceConstants,customerServiceConfig,gli_dataservice,PersistenceMapping) {
    $controller('PolicySearchCtrl',{
        $rootScope:$rootScope,
        $scope:$scope,
        $compile:$compile,
        $route:$route,
        $routeParams:$routeParams,
        $location:$location,
        $translate:$translate,
        dataService:gli_dataservice,
        appDataShareService:appDataShareService,
		UserDetailsService:UserDetailsService,
        AutoSync:AutoSync,
        debounce:debounce,
        $timeout:$timeout,
        $filter:$filter,
        commonConfig:commonConfig,
        mServiceConstants:mServiceConstants,
        customerServiceConfig:customerServiceConfig});
    $scope.authorizationToken = appDataShareService.authorizationToken;
	var _this = this;
	$scope.isValid = false;
	$scope.isValid2 = false;
	$scope.isSearchInValid = false;
	$scope.gliPolicySearch = {};
	$scope.validSearch = false;
	$scope.selectedpage = commonConfig().PAGE_NAME.POLICY_SEARCH;
	$scope.gliPolicySearch.clientNumber = "";
	$scope.hideSearch = true;
	$scope.activeFilter = true;
	$scope.noData = false;
	$scope.noDataFromServer = true;
	angular.extend(this, $controller('BaseCtrl',{$scope:$scope, $rootScope:$rootScope, dataService:dataService, type:'policySearch', userId:appDataShareService.selectedUser.userId}));
	$scope.setData = function() {
		$scope.gliPolicySearch.policyNumber = "";
		$scope.gliPolicySearch.customerFirstName = "";
		$scope.gliPolicySearch.mobileNumber = "";
		$scope.gliPolicySearch.policyStartDateFrom = "";
		$scope.gliPolicySearch.policyStartDateTo = "";
		$scope.gliPolicySearch.policyEndDateFrom = "";
		$scope.gliPolicySearch.policyEndDateTo = "";
		$scope.gliPolicySearch.contractType = "";
		$scope.gliPolicySearch.policyStatus = "";
		$scope.gliPolicySearch.branch = "";
        $scope.gliPolicySearch.agentCode = "";		$scope.gliPolicySearch.vehicleRegNumber = "";	};
	// reset the search form fields
	$scope.reset = function() {
		$scope.gliPolicySearch.policyNumber = "";
		$scope.gliPolicySearch.customerFirstName = "";
		$scope.gliPolicySearch.mobileNumber = "";
		$scope.gliPolicySearch.policyStartDateFrom = "";
		$scope.gliPolicySearch.policyStartDateTo = "";
		$scope.gliPolicySearch.policyEndDateFrom = "";
		$scope.gliPolicySearch.policyEndDateTo = "";
		$scope.gliPolicySearch.contractType = "";
		$scope.gliPolicySearch.policyStatus = "";
		$scope.gliPolicySearch.branch = "";
        $scope.gliPolicySearch.agentCode = "";		$scope.gliPolicySearch.vehicleRegNumber = "";		$scope.isValid = false;
		$scope.isValid2 = false;
		$scope.isSearchInValid = false;
		$scope.validSearch = false;
		$scope.errorMessage = [];
		$scope.noData = false;
        $scope.noDataFromServer = true;
	};
	$scope.rerouteLink = function(){
		if($location.path().indexOf('Customer Contact') > 0){
            $rootScope.backToCustomerContact = true;
			$location.path('/customerService/customerContact');
        }else{
			$location.path('/dashboard');
		}
	}
	$scope.initialLoad = function(){
	if(!(rootConfig.isDeviceMobile) && !(UserDetailsService.userDetilsModel)){
		var userDetilsModel = JSON.parse(sessionStorage.userDetails);
		var userDetailData = JSON.parse(sessionStorage.loginData);
		$rootScope.isLoggedOut = false;
		$rootScope.username = userDetilsModel.user.userId;
		$rootScope.agentId = userDetilsModel.user.rexitLoginId;
		$rootScope.isAuthenticated = true;
		$rootScope.username = userDetilsModel.user.userId;
		$rootScope.authenticationStatus = "SUCCESS";
		$rootScope.firstTimeLogin = userDetailData.firstTimeLogin;
		$rootScope.isTemporaryPassword = userDetailData.isTemporaryPassword;
		$rootScope.role = userDetailData.roles[0];
		UserDetailsService.setUserDetailsModel(userDetilsModel);
	}
		if($routeParams.pageName === "Customer Contact"){
			$scope.hideSearch = false;
			$scope.gliPolicySearch.clientNumber = $rootScope.clientNo;
            $scope.pageNumber = 1; // for lazy loading            
            $scope.searchData=JSON.parse(JSON.stringify($scope.gliPolicySearch));
			$scope.searchPolicyDetails($scope.gliPolicySearch, true);
						   showHideLoadingImage(true,"Policy Search",null,null);
			
			$scope.$apply();
		}
            showHideLoadingImage(true,"Policy Search",null,null);
			//For contract type dropdown value
		       var transactionObj = $scope.mapScopeToPersistance();
			   transactionObj.Type = "contracttype"; dataService.searchTransactions(transactionObj,$scope.getTransactionSuccessContractType,$scope.getTransactionError);
		
        $scope.productList =[];
        LEDynamicUI.getUIJson("productListing.json", false, function(jsonObject3) {
           $scope.productList=jsonObject3;  
        });
	};
    $scope.findHealthProduct = function(prodCode) {
        var productCode = prodCode;
        for(var i=0;i<$scope.productList.healthProducts.length;i++) {
            if($scope.productList.healthProducts[i].code === productCode) {
                return i;
            }
        }
    }
    $scope.findMotorProduct = function(prodCode) {  
         var productCode = prodCode;
        for(var i=0;i<$scope.productList.motorProducts.length;i++) {
            if($scope.productList.motorProducts[i].code === productCode) {
                return i;
            }
        }
        
    }
	$scope.getTransactionSuccessContractType = function(data){
		$scope.contractTypeDropDownList = [];
		if(data[0] !== undefined && data[0].TransactionData !== null)
		 {
			if (data[0].TransactionData.lookUps.length !== 0) {
				$scope.contractTypeDropDownList = data[0].TransactionData.lookUps;
				$scope.$apply();
			}
		 }
		else{
			$scope.contractTypeDropDownList = [];
		}
		//For policy status dropdown value
        var transactionObj = $scope.mapScopeToPersistance();
        transactionObj.Type = "transactiontype";
        dataService.searchTransactions(transactionObj,$scope.getTransactionSuccessPolicyStatus,$scope.getTransactionError);
	};
	$scope.getTransactionSuccessPolicyStatus = function(data){
		$scope.policyStatusDropDownList=[];
		if(data[0] !== undefined && data[0].TransactionData !== null)
		 {
			if (data[0].TransactionData.lookUps.length !== 0) {
				$scope.policyStatusDropDownList = data[0].TransactionData.lookUps;
				$scope.$apply();
			}
		 }
		else{
			   $scope.policyStatusDropDownList=[];
		}
		//For agent code dropdown values
        var transactionObj = $scope.mapScopeToPersistance();
        transactionObj.Type = "AgentCode";
        dataService.searchTransactions(transactionObj,$scope.getTransactionSuccessAgentCode,$scope.getTransactionError);
	};
	$scope.getTransactionSuccessAgentCode = function(data){
    		$scope.agentCodeDropDownList=[];
    		if(data[0] !== undefined && data[0].TransactionData !== null)
    		 {
    			if (data[0].TransactionData.mappedIds.length !== 0) {
    				$scope.agentCodeDropDownList = data[0].TransactionData.mappedIds;
    				$scope.$apply();
    			}
    		 }
    		else{
    			   $scope.agentCodeDropDownList=[];
    		}
    		//For branch drop down values
            var transactionObj = $scope.mapScopeToPersistance();
            transactionObj.Type = "BranchCode";
            dataService.searchTransactions(transactionObj,$scope.getTransactionSuccessBranch,$scope.getTransactionError);
    	};
    $scope.getTransactionSuccessBranch = function(data){
    		$scope.branchDropDownList=[];
    		if(data[0] !== undefined && data[0].TransactionData !== null)
    		 {
    			if (data[0].TransactionData.branches.length !== 0) {
    				$scope.branchDropDownList = data[0].TransactionData.branches;
    				$scope.$apply();
    			}
    		 }
    		else{
    			   $scope.branchDropDownList=[];
    		}
    		showHideLoadingImage(false,"Policy Search",null,null);
    	};
	$scope.mapScopeToPersistance = function () {
	    var newDate = new Date();
	    PersistenceMapping.clearTransactionKeys();
        PersistenceMapping.Key2 = $rootScope.username;
        PersistenceMapping.Key5 = "Agent";
        PersistenceMapping.Type = _this.Type;
        var transactionObj =  PersistenceMapping.mapScopeToPersistence({});
        return transactionObj;
    };
    $scope.downloadPdf = function(type, fileId, fileName) {
		var isAndroid = navigator.userAgent.indexOf("Android") > 0 ? true : false;
        switch(type) {
            case 'insured': 
                var downloadPdfUrl = rootConfig.serviceBaseUrl + "policyService/download/"+ $rootScope.username +"/POLICYINSUREDCOPY/" + fileId;
                if(rootConfig.isDeviceMobile && isAndroid) {
                    downloadPdfFromRemote(downloadPdfUrl, fileName);
				}
                else {
                    window.open(downloadPdfUrl, "_system");
                } 
		break;
            case 'agent': 
				var downloadPdfUrl = rootConfig.serviceBaseUrl + "policyService/download/"+ $rootScope.username +"/POLICYAGENTCOPY/" + fileId;
                if(rootConfig.isDeviceMobile && isAndroid) {
                    downloadPdfFromRemote(downloadPdfUrl, fileName);
                }
                else {
                    window.open(downloadPdfUrl,"_system");
                } break;    
        }
    }
	$scope.searchPolicyDetails = function(gliPolicySearch, fromSearchButton){
		$scope.policySearch = gliPolicySearch;
		var transactionObj = $scope.mapScopeToPersistance();
		//Date format conversion to dd/MM/yyyy for request json
		if($scope.policySearch.policyStartDateFrom && $scope.policySearch.policyStartDateTo){
			$scope.policyStartDateFrom = $filter('date')($scope.policySearch.policyStartDateFrom, "yyyy-MM-dd");
	    	$scope.policyStartDateTo = $filter('date')($scope.policySearch.policyStartDateTo, "yyyy-MM-dd");
		}
		else{
			$scope.policyStartDateFrom = $scope.policySearch.policyStartDateFrom;
			$scope.policyStartDateTo = $scope.policySearch.policyStartDateTo;
		}
		if($scope.policySearch.policyEndDateFrom && $scope.policySearch.policyEndDateTo){
			$scope.policyEndDateFrom = $filter('date')($scope.policySearch.policyEndDateFrom, "yyyy-MM-dd");
	    	$scope.policyEndDateTo = $filter('date')($scope.policySearch.policyEndDateTo, "yyyy-MM-dd");

		}
		else{
			$scope.policyEndDateFrom = $scope.policySearch.policyEndDateFrom;
			$scope.policyEndDateTo = $scope.policySearch.policyEndDateTo;
		}
		if($scope.policySearch.contractType){
        	$scope.contractType = $scope.policySearch.contractType.code;
        }
        else{
        	$scope.contractType = "";
        }
		if($scope.policySearch.policyStatus){
        	$scope.policyStatus = $scope.policySearch.policyStatus.code;
        }
        else{
        	$scope.policyStatus = "";
        }
        if($scope.policySearch.branch){
                	$scope.branch = $scope.policySearch.branch.code;
         }
         else{
               $scope.branch = "";
         }
		var searchObj = {
				"SearchCriteria": {
					"policyNumber": $scope.policySearch.policyNumber,
                	"policyHolderName": $scope.policySearch.customerFirstName,
                	"policyHolderMobileNo": $scope.policySearch.mobileNumber,
                	"contractType": $scope.contractType,
                	"customPolicyStatus": $scope.policyStatus,
                	"policyDateFrom": $scope.policyEndDateFrom,
                	"policyDateTo": $scope.policyEndDateTo,
                	"policyIssueDateFrom": $scope.policyStartDateFrom,
                	"policyIssueDateTo": $scope.policyStartDateTo,
                	"clientCode": $scope.policySearch.clientNumber,
                    "vehicleRegNumber" : $scope.policySearch.vehicleRegNumber,
                    "agentCode": $scope.policySearch.agentCode,
                    "branchCode" : $scope.branch

                }
			};
		$scope.searchFieldCount = 0;
		$scope.searchFieldEmptyCount = 0;
		Object.keys(searchObj.SearchCriteria).forEach(function(key) {
			  if (searchObj.SearchCriteria[key] == undefined) {
				  searchObj.SearchCriteria[key] = "";
			  }
		});
		Object.keys(searchObj.SearchCriteria).forEach(function(key) {
			  if (searchObj.SearchCriteria[key] == "") {
				  $scope.searchFieldEmptyCount++;
			  }
		});
		//To get count of searchObj
		Object.keys(searchObj.SearchCriteria).forEach(function(key) {
			  if (searchObj.SearchCriteria) {
				  $scope.searchFieldCount++;
			  }
		});
        
		if($scope.searchFieldEmptyCount == $scope.searchFieldCount){
			$scope.isSearchInValid = true;
			$scope.validSearch = false;
			$scope.errorMessage = [];
			$scope.minOneSearchFieldValidationMessage = translateMessages($translate, "policySearch.minOneSearchFieldValidationMessage");
            $scope.errorMessage.push($scope.minOneSearchFieldValidationMessage);

		}
		else{
			$scope.errorMessage = [];
			$scope.isSearchInValid = false;
            searchObj.SearchCriteria.pageNo = $scope.pageNumber;
            searchObj.SearchCriteria.pageSize = rootConfig.resultPerPage;
			transactionObj.TransactionData = searchObj;
            if(fromSearchButton)
			     showHideLoadingImage(true,"Policy Search",null,null);
			     if((rootConfig.isDeviceMobile && checkConnection()) || !rootConfig.isDeviceMobile){
			        dataService.searchTransactions(transactionObj, $scope.getTransactionSuccess, $scope.getTransactionError);
			     }else{
			        $scope.getTransactionError();
			     }

		}
	};
	$scope.validateFields = function(policySearch){
	    $scope.noDataFromServer = true;
		$scope.noData = false;
		$scope.errorMessage = [];
		$scope.policySearch = policySearch;
		//Date validation for Policy Start Date
		 if($scope.policySearch.policyStartDateFrom && $scope.policySearch.policyStartDateTo){
			if(!validateDateRange($scope.policySearch.policyStartDateFrom, 365) || !validateDateRange($scope.policySearch.policyStartDateTo, 365)){
            	$scope.errorMessage = [];
            	$scope.isValid = true;
				$scope.dateRangeSixtyValidationMessage = translateMessages($translate, "policySearch.dateRangeOneYearValidationMessage");
                $scope.errorMessage.push($scope.dateRangeSixtyValidationMessage);
            } else if($scope.policySearch.policyStartDateTo < $scope.policySearch.policyStartDateFrom){
            	$scope.errorMessage = [];
            	$scope.isValid = true;
				$scope.dateRangeSixtyValidationMessage = translateMessages($translate, "policySearch.fromGreaterthanToValidationMessage");// have'nt got the error message
                $scope.errorMessage.push($scope.dateRangeSixtyValidationMessage);
            }
            else{
            	$scope.isValid = false;
            }
		}
		else if(($scope.policySearch.policyStartDateFrom && !$scope.policySearch.policyStartDateTo) || (!$scope.policySearch.policyStartDateFrom && $scope.policySearch.policyStartDateTo)){
				$scope.errorMessage = [];
				$scope.fromTodateValidationErrorMessage = translateMessages($translate, "policySearch.fromTodateValidationErrorMessage");
				$scope.errorMessage.push($scope.fromTodateValidationErrorMessage);
				$scope.isValid = true;
		}
		else{
        	$scope.isValid = false;
		}
		//Date validation for Policy Expiry Date
		if($scope.policySearch.policyEndDateFrom && $scope.policySearch.policyEndDateTo){
				if(!validateDateRange($scope.policySearch.policyEndDateFrom, 365) || !validateDateRange($scope.policySearch.policyEndDateTo, 365)){
	                $scope.isValid2 = true;
	                $scope.dateRangeSixtyValidationMessage = translateMessages($translate, "policySearch.dateRangeOneYearValidationMessage");
	                $scope.errorMessage.push($scope.dateRangeSixtyValidationMessage);
	            }
	            else if($scope.policySearch.policyEndDateTo < $scope.policySearch.policyEndDateFrom){
	                $scope.isValid2 = true;
	                $scope.dateRangeSixtyValidationMessage = translateMessages($translate, "policySearch.fromGreaterthanToValidationMessage");
	                $scope.errorMessage.push($scope.dateRangeSixtyValidationMessage);
	            }
	            else{
	            	$scope.isValid2 = false;
	            }
	    }
		else if(($scope.policySearch.policyEndDateFrom && !$scope.policySearch.policyEndDateTo) || (!$scope.policySearch.policyEndDateFrom && $scope.policySearch.policyEndDateTo)){
			    $scope.errorMessage = [];
			    $scope.fromTodateValidationErrorMessage = translateMessages($translate, "policySearch.fromTodateValidationErrorMessage");
				$scope.errorMessage.push($scope.fromTodateValidationErrorMessage);
				$scope.isValid2 = true;
		}
		else{
        	$scope.isValid2 = false;
		}
		if($scope.isValid || $scope.isValid2){
			//errror message
			$scope.isSearchInValid = true;
			$scope.validSearch = false;

		}
		else{
			$scope.isSearchInValid = false;
			$scope.errorMessage = [];            
            $scope.pageNumber = 1; // for lazy loading
            $scope.searchData=JSON.parse(JSON.stringify($scope.policySearch));
			$scope.searchPolicyDetails($scope.policySearch, true);
		}
	};
	$scope.getTransactionSuccess = function(data){
		var policySearchDetails = [];
        $scope.activeFilter = false;
        if($scope.pageNumber==1) {
			$scope.clientDetails = [];
            $scope.policySearchResultFullData=[]
        }
		 if(data[0] !== undefined)
		 {
		  if (data[0].TransactionData !== null) {
				$scope.validSearch = true;
				if (data[0].TransactionData.length !== 0) {
					policySearchDetails = data[0].TransactionData.policySearchResult;
					var formattedDate;
					$scope.noOfPolicies = data[0].Key25;
                    if(policySearchDetails.length < rootConfig.resultPerPage) {
                            $scope.noDataFromServer=true;
                     } else {
                         $scope.noDataFromServer=false;
                     }
					for ( var i = 0; i < policySearchDetails.length; i++) {
                        $scope.policySearchResultFullData.push(policySearchDetails[i]);
						var policyStatus;
						var policyIcon;
						policySearchDetails[i].agentCode = policySearchDetails[i].branchCode+' '+policySearchDetails[i].agentCode;
						$scope.clientDetailsTemp = [];
						$scope.clientDetailsTemp
                        		.push({
                        		    key : translateMessages($translate, "policySearch.branchAgent"),
                        			value : policySearchDetails[i].agentCode
                        });
						$scope.clientDetailsTemp
								.push({
									key : translateMessages($translate, "policySearch.nameText"),
									value : policySearchDetails[i].customerName
						});
						$scope.clientDetailsTemp.push({
							key : translateMessages($translate, "policySearch.mobileNumber"),
							value : policySearchDetails[i].contactNumber
						});
						$scope.clientDetailsTemp.push({
							key : translateMessages($translate, "policySearch.emailText"),
							value : policySearchDetails[i].emailId
						});
						$scope.clientDetailsTemp.push({
							key : translateMessages($translate, "policySearch.premiumAmount"),
							value : $filter('number')(policySearchDetails[i].premium,2),
							isRupeeShow : true
						});
						$scope.clientDetailsTemp.push({
							key : translateMessages($translate, "policySearch.productName"),
							value : policySearchDetails[i].productName
						});
                        $scope.clientDetailsTemp.push({
							key : translateMessages($translate, "policySearch.productCode"),
							value : policySearchDetails[i].productCode
						});
                        // Changed to policy expiry Date
                        if(policySearchDetails[i].expiryDate < getFormattedDate()) {
                            policyIcon = mServiceConstants.PolicyLapsedIcon;
                        }
                        else {
                            policyIcon = mServiceConstants.PolicyActiveIcon;
                        }
						/*policyStatus = policySearchDetails[i].policyStatus;
						switch (policyStatus) {
						case mServiceConstants.PolicyActiveStatus:
							policyIcon = mServiceConstants.PolicyActiveIcon;
							break;
						case mServiceConstants.PolicyLapsedStatus:
							policyIcon = mServiceConstants.PolicyLapsedIcon;
							break;
						case mServiceConstants.PolicyOtherStatus:
							policyIcon = "";
							break;
						default:break;
						}*/
                        var policyNumber=policySearchDetails[i].policyNumber;
                        if(policySearchDetails[i].policyStatusCode=='T413') {
                            policyNumber=policySearchDetails[i].policyNumber+ 'E' + policySearchDetails[i].transactionNumber;
                        }
						$scope.clientDetails
								.push({
									"header" : policyNumber,
									"data" : $scope.clientDetailsTemp,
                                    "statusCode" : policySearchDetails[i].policyStatusCode,
									"statusIcon" : policyIcon,
                                    "pdfInsuredCopy": policySearchDetails[i].pdfReady,
                                    "pdfAgentCopy" : policySearchDetails[i].pdfReadyAgentCpy,
                                    "fileName_insuredCopy" : policySearchDetails[i].fileName_insuredCopy,
                                    "fileName_agentCopy" : policySearchDetails[i].fileName_agentCopy,
                                    "id": policySearchDetails[i].id
								});
					}                    
                    appDataShareService.policysearchjson = {
				        'policySearch' : $scope.policySearchResultFullData
				    };
					if($scope.clientDetails.length === 0){
						$scope.noData = true;
						$scope.validSearch = false;
					}else{
						$scope.noData = false;
						$scope.validSearch = true;
                        $scope.pageNumber++;
					}					
				}else if($scope.clientDetails.length ==0) {
					$scope.noOfPolicies = 0;
					$scope.validSearch = false;
				    $scope.alertMessage = translateMessages($translate, "onlineAlertMessage");
				}
			}
			}else {
			$scope.noOfPolicies = 0;
			$scope.validSearch = false;
			$scope.alertMessage = translateMessages($translate, "onlineAlertMessage");
		}
		showHideLoadingImage(false,"Policy Search",null,null);
        $scope.loadingMoreData=false;
        $scope.$apply();
	};
	 $scope.getTransactionError = function(data) {
			$rootScope.serviceFailed=true;
			if (rootConfig.isDeviceMobile && !checkConnection()) {
				$scope.message = translateMessages($translate, "networkValidationErrorMessage");
			}else{
				$scope.message = translateMessages($translate, "validToken");
			}
			$scope.$emit('tokenEvent', { message: $scope.message });
			if (data == "Error in ajax callE")
			   {
				   $scope.onServerError=true;
				   $scope.serverErrorMessage= translateMessages($translate, "serverErrorMessage");
			   }
			showHideLoadingImage(false,"Policy Search",null,null);
            $scope.loadingMoreData=false;
			$rootScope.$apply();
	};
	 $scope.getPolicyInfo = function(policyNumber,id) {
     			$scope.policyNumber = policyNumber;
     			var policySearchData = appDataShareService.policysearchjson.policySearch;
     			var formattedDate1="";
     			var formattedDate="";
     			var issueDate1="";
     			var issueDate="";
     			var policyStartDate1="";
     			var policyStartDate="";
     			var policyExpiryDate1="";
     			var policyExpiryDate="";
     			var additionalData="";
     			for ( var i = 0; i < policySearchData.length; i++) {
     				if (($scope.policyNumber.includes(policySearchData[i].policyNumber)) && policySearchData[i].id == id) {
     					$scope.policyDetails = [];
     					if (policySearchData[i].dateOfBirth!=="")
     					{
     						 formattedDate=$filter('date')(policySearchData[i].dateOfBirth, "dd-MM-yyyy");
     					}
     					else
     					{
     						 formattedDate=policySearchData[i].dateOfBirth;
     					}
     					if (policySearchData[i].issueDate!=="")
     					{
     						issueDate=$filter('date')(policySearchData[i].issueDate, "dd-MM-yyyy");
     					}
     					else
     					{
     						issueDate=policySearchData[i].issueDate;
     					}
     					if (policySearchData[i].startDate!=="")
     					{
     						policyStartDate =$filter('date')(policySearchData[i].startDate, "dd-MM-yyyy");
     					}
     					else
     					{
     						policyStartDate=policySearchData[i].startDate;
     					}
     					if (policySearchData[i].expiryDate!=="")
     					{
     						policyExpiryDate=$filter('date')(policySearchData[i].expiryDate, "dd-MM-yyyy");
     					}
     					else
     					{
     						policyExpiryDate=policySearchData[i].expiryDate;
     					}
     					if(policySearchData[i].typeOfBusiness === 'N'){
     						if(policySearchData[i].riskOfLocation !== ""){

     							additionalData = "RM"+$filter('number')(policySearchData[i].totalSumAssured,2)+'['+policySearchData[i].riskOfLocation+']';
     						}
     						else{
     							additionalData = "RM"+$filter('number')(policySearchData[i].totalSumAssured,2);
     						}
     					}
     					else if(policySearchData[i].typeOfBusiness === 'M'){
     						if(policySearchData[i].vehicleNumber !== ""){
     							additionalData = "RM"+$filter('number')(policySearchData[i].totalSumAssured,2)+'['+policySearchData[i].vehicleNumber+']';
     						}
     						else{
     							additionalData = "RM"+$filter('number')(policySearchData[i].totalSumAssured,2);
     						}
                             additionalData = additionalData + "[ " + Math.round(policySearchData[i].ncdPercentage * 100) /100 + "% ]";
     					}
     					else{
     						additionalData = "";
     					}
     					$scope.policyDetails.push({
     						key : translateMessages($translate, "policySearch.dateOfBirthText"),
     						value : formattedDate
     						});
     					$scope.policyDetails
     							.push({
     								key : translateMessages($translate, "policySearch.insuredName"),
     								value : policySearchData[i].customerName
     							});
     					$scope.policyDetails.push({
     						key : translateMessages($translate, "policySearch.issueDate"),
     						value : issueDate
     						});
     					$scope.policyDetails.push({
     						key : translateMessages($translate, "policySearch.policyStartDate"),
     						value : policyStartDate
     						});
     					$scope.policyDetails.push({
     						key : translateMessages($translate, "policySearch.policyEndDate"),
     						value : policyExpiryDate
     					});
     					$scope.policyDetails.push({
     						key : translateMessages($translate, "policySearch.sumInsuredLbl"),
     						value : additionalData
     					});
     				}
     			}
     		};
	 $scope.getContactInfo = function(policyNumber,id) {
    			$scope.policyNumber = policyNumber;
    			var policySearchData = appDataShareService.policysearchjson.policySearch;
    			for ( var i = 0; i < policySearchData.length; i++) {
    				if (($scope.policyNumber.includes(policySearchData[i].policyNumber)) && policySearchData[i].id == id) {
    					$scope.contactInfoDetails = [];
    					$scope.contactInfoMobileNumber =   policySearchData[i].contactNumber;
    					$scope.contactInfoPhoneNumber =  [policySearchData[i].telephoneHome, policySearchData[i].telephoneOffice];
    					$scope.mailingAddress = [policySearchData[i].address.addressLine1, policySearchData[i].address.addressLine2, policySearchData[i].address.addressLine3, policySearchData[i].address.addressLine4,policySearchData[i].address.postcode,policySearchData[i].address.country].filter(function (val) {return val;}).join(', ');
    					$scope.contactInfoDetails
    							.push({
    								key : translateMessages($translate, "policySearch.nameText"),
    								value :[policySearchData[i].customerName]
    							});
    					$scope.contactInfoDetails.push({
    						key : translateMessages($translate, "policySearch.mobileText"),
    						value :$scope.contactInfoMobileNumber.split(",")
    					});
    					$scope.contactInfoDetails.push({
    						key : translateMessages($translate, "policySearch.emailText"),
    						value : [ policySearchData[i].emailId ]
    					});
    					$scope.contactInfoDetails.push({
    						key : translateMessages($translate, "policySearch.phoneText"),
    						value : $scope.contactInfoPhoneNumber
    					});
    					$scope.contactInfoDetails.push({
    						key : translateMessages($translate, "policySearch.mailingText"),
    						value : [ $scope.mailingAddress ]
    					});
    				}
    			}
    		};
    $scope.setParameters = function(type, productCode) {
        var Type = type;
        var prodCode = productCode;
        if(localStorage.getItem("productType")) {
            localStorage.removeItem("productType");
        }
        if(localStorage.getItem("productCode")) {
            localStorage.removeItem("productCode");
        }
        localStorage.setItem("productType",Type);
        localStorage.setItem("productCode",prodCode);
        $location.path('/location');
    }
    $scope.$on('requestDataSet', function(e, args) {
        if(!$scope.noDataFromServer) {
            $scope.loadingMoreData=true;
            $scope.searchPolicyDetails($scope.searchData, false);
        }
        else {
        	$scope.loadingMoreData=false;
        }
        $scope.$apply();
    });
}]);
