mServiceApp.controller('ClaimsLoggedCtrl',['$controller','$rootScope', '$scope',  '$compile', '$route', '$routeParams', '$location', '$translate','dataService',
'appDataShareService','AutoSync','debounce','$timeout','$filter','mServiceConstants','commonConfig','customerServiceConfig','gli_dataservice','PersistenceMapping',function($controller ,$rootScope, $scope,
$compile, $route, $routeParams, $location, $translate,dataService,appDataShareService,AutoSync,debounce,$timeout,$filter,mServiceConstants,commonConfig,customerServiceConfig,gli_dataservice,PersistenceMapping) {
	$scope.authorizationToken = appDataShareService.authorizationToken;
    var _this = this;
    $scope.isValid = false;
    $scope.activeFilter = true;
    $scope.isSearchInValid = false;
    $scope.claimsLogged = {};
    $scope.selectedpage = commonConfig().PAGE_NAME.CLAIM_RECORDS;
	$scope.noData = false;
    angular.extend(this, $controller('BaseCtrl',{$scope:$scope, $rootScope:$rootScope, dataService:dataService, type:'clientLoggedSearch', userId:appDataShareService.selectedUser.userId}));
	$scope.setData = function() {
		$scope.claimsLogged.policyHolderName = "";
		$scope.claimsLogged.claimNumber = "";
		$scope.claimsLogged.policyNumber = "";
		$scope.claimsLogged.claimsIncurredDateFrom = "";
		$scope.claimsLogged.claimsIncurredDateTo = "";
		$scope.claimsLogged.vehicleRegNo = "";
		$scope.noData = false;
	};
	// reset the search form fields
	$scope.reset = function() {
		$scope.claimsLogged.policyHolderName = "";
		$scope.claimsLogged.claimNumber = "";
		$scope.claimsLogged.policyNumber = "";
		$scope.claimsLogged.claimsIncurredDateFrom = "";
		$scope.claimsLogged.claimsIncurredDateTo = "";
		$scope.claimsLogged.vehicleRegNo = "";
		$scope.claimsLoggedDetails = [];
		$scope.errorMessage = [];
		$scope.isValid = false;
		$scope.isSearchInValid = false;
		$scope.noData = false;
	    $scope.$apply();

	};
	$scope.mapScopeToPersistance = function () {
	    var newDate = new Date();
	    PersistenceMapping.clearTransactionKeys();
        PersistenceMapping.Key2 = $rootScope.username;
        PersistenceMapping.Key5 = "Agent";
        PersistenceMapping.Type = _this.Type;
        var transactionObj =  PersistenceMapping.mapScopeToPersistence({});
        return transactionObj;
    };
	$scope.initialLoad = function(){
        var curDate = new Date();
		var past7days = new Date(curDate.setDate(curDate.getDate() - rootConfig.defaultDayCountRelationship));
		$scope.claimsLogged.claimsIncurredDateFrom = getFormattedDateFromDate(past7days);
		$scope.claimsLogged.claimsIncurredDateTo = getFormattedDate();
        $scope.searchClaimsLogged($scope.claimsLogged, true);
		$scope.$apply();
	};
	
    $scope.paintUISuccess = function (callbackId, data) {
	    if (!showActivityFlag)
	    {
		showHideLoadingImage(false,"Loading Claims Records",null,null);
	    }
	   $scope.isPainted = true;
    };
    LEDynamicUI.paintUI(rootConfig.template, "claimslogged-ui-json.json", "claimLogged", "#dvPolicyRenewal", true, $scope.paintUISuccess, $scope, $compile);
    
	$scope.searchClaimsLogged = function(claimsLogged, fromSearchButton){
		$scope.claimsLogged = claimsLogged;
		var transactionObj = $scope.mapScopeToPersistance();
    	if($scope.claimsLogged.claimsIncurredDateFrom && $scope.claimsLogged.claimsIncurredDateTo){
    		$scope.claimsIncurredDateFrom = $filter('date')($scope.claimsLogged.claimsIncurredDateFrom, "yyyy-MM-dd");
        	$scope.claimsIncurredDateTo = $filter('date')($scope.claimsLogged.claimsIncurredDateTo, "yyyy-MM-dd");
    	}
    	else{
    		$scope.claimsIncurredDateFrom = $scope.claimsLogged.claimsIncurredDateFrom;
    		$scope.claimsIncurredDateTo = $scope.claimsLogged.claimsIncurredDateTo;
    	}
		var searchObj = {
				"SearchCriteria" : {
					"policyHolderName" : $scope.claimsLogged.policyHolderName,
					"vehicleRegNumber": $scope.claimsLogged.vehicleRegNo,
					"claimNumber" : $scope.claimsLogged.claimNumber,
					"policyNumber" : $scope.claimsLogged.policyNumber,
					"incurredDateFrom" : $scope.claimsIncurredDateFrom,
					"incurredDateTo" : $scope.claimsIncurredDateTo
				 }
		    };
		$scope.searchFieldCount = 0;
		$scope.searchFieldEmptyCount = 0;
		Object.keys(searchObj.SearchCriteria).forEach(function(key) {
			  if (searchObj.SearchCriteria[key] == undefined) {
				  searchObj.SearchCriteria[key] = "";
			  }
		});
		Object.keys(searchObj.SearchCriteria).forEach(function(key) {
			  if (searchObj.SearchCriteria[key] == "") {
				  $scope.searchFieldEmptyCount++;
			  }
		});
		//To get count of searchObj
		Object.keys(searchObj.SearchCriteria).forEach(function(key) {
			  if (searchObj.SearchCriteria) {
				  $scope.searchFieldCount++;
			  }
		});
		if($scope.searchFieldEmptyCount == $scope.searchFieldCount){
			$scope.isSearchInValid = true;
			$scope.validSearch = false;
			$scope.errorMessage = [];
			$scope.claimsLoggedDetails = [];
			$scope.minOneSearchFieldValidationMessage = translateMessages($translate, "claimLogged.minOneSearchFieldValidationMessage");
            $scope.errorMessage.push($scope.minOneSearchFieldValidationMessage);
		}
		else{
			$scope.errorMessage = [];
			$scope.isSearchInValid = false;
            $scope.noData = false;
		    $scope.noDataFromServer = true;
            $scope.searchData = JSON.parse(JSON.stringify(claimsLogged));
            if(fromSearchButton) {
			     showHideLoadingImage(true,"Loading Claims Records",null,null);
                 $scope.pageNumber = 1;
            }
            searchObj.SearchCriteria.pageNo = $scope.pageNumber;
            searchObj.SearchCriteria.pageSize = rootConfig.resultPerPage;
			transactionObj.TransactionData = searchObj;
			if((rootConfig.isDeviceMobile && checkConnection()) || !rootConfig.isDeviceMobile){
			    dataService.searchTransactions(transactionObj, $scope.getTransactionSuccess, $scope.getTransactionError);
			}else{
			    $scope.getTransactionError();
			}
		}
	};
	$scope.getTransactionSuccess = function(data) {
        if($scope.pageNumber==1) {
		      $scope.claimsLoggedDetails = [];
		      $scope.claimsLoggedFullData = [];
		}
		var claimsLoggedSearchDetails = [];
		var formattedDate1="";
		var formattedDate="";
		 if(data[0] !== undefined)
		 {
		   if(data[0].TransactionData !== null) {
				$scope.validSearch = true;
				if (data[0].TransactionData.ClaimsLoggedSearchResult.length !== 0) {
                    $scope.policyCount = data[0].Key25;
					claimsLoggedSearchDetails = data[0].TransactionData.ClaimsLoggedSearchResult;
                    if(rootConfig.resultPerPage > claimsLoggedSearchDetails.length) {
                       $scope.noDataFromServer = true;
                    }
                    else {
                        $scope.noDataFromServer = false;
                    }
					/* for(var i=0;i<data[0].TransactionData.ClaimsLoggedSearchResult.length;i++){
					  $scope.claimsLoggedDetails[i].policyNumber = $scope.claimsLoggedDetails[i].policyNumber+'/'+$scope.claimsLoggedDetails[i].claimNumber;
					  $scope.claimsLoggedDetails[i].agentCode = $scope.claimsLoggedDetails[i].branchName+' '+$scope.claimsLoggedDetails[i].agentCode;
                    } */
					
					for ( var i = 0; i < claimsLoggedSearchDetails.length; i++) {
					    $scope.claimsLoggedFullData.push(claimsLoggedSearchDetails[i]);
						var policyStatus;
						var policyIcon;
						claimsLoggedSearchDetails[i].agentCode = claimsLoggedSearchDetails[i].branchCode+' '+claimsLoggedSearchDetails[i].agentCode;
						$scope.clientDetailsTemp = [];
						$scope.clientDetailsTemp.push({
                           	key : translateMessages($translate, "claimInquiry.branchOffice"),
                           	value : claimsLoggedSearchDetails[i].branchName
                        });
                        $scope.clientDetailsTemp.push({
                           	key : translateMessages($translate, "claimInquiry.accountCode"),
                           	value : claimsLoggedSearchDetails[i].agentCode
                        });
                        $scope.clientDetailsTemp.push({
                        	key : translateMessages($translate, "policySearch.productName"),
                        	value : claimsLoggedSearchDetails[i].productName
                        });
                        $scope.clientDetailsTemp.push({
                            key : translateMessages($translate, "claimInquiry.claimantName2"),
                            value : claimsLoggedSearchDetails[i].policyholderName
                         });
                        $scope.clientDetailsTemp.push({
                        	key : translateMessages($translate, "claimInquiry.dateOfLoss"),
                        	value : claimsLoggedSearchDetails[i].claimIncurredDate,
                        	isRupeeShow : true
                        });
                        $scope.clientDetailsTemp.push({
                        	key : translateMessages($translate, "claimInquiry.claimLossDescription"),
                        	value : claimsLoggedSearchDetails[i].claimLossDescription
                        });
                        var claimAmount = parseInt(claimsLoggedSearchDetails[i].paid)+parseInt(claimsLoggedSearchDetails[i].balanceOutstanding);
                        claimAmount = claimAmount.toString();
                        $scope.clientDetailsTemp.push({
                        	key : translateMessages($translate, "claimInquiry.claimPaid"),
                        	value : claimsLoggedSearchDetails[i].paid
                        });
                        policyStatus = claimsLoggedSearchDetails[i].claimStatusCode;
                        switch (policyStatus) {
                        case '2':
                        	policyIcon = mServiceConstants.PolicyLapsedIcon;
                        	break;
                        default:
                        	policyIcon = mServiceConstants.PolicyActiveIcon;
                            break;
                        }
                        formattedDate1=LEDate(claimsLoggedSearchDetails[i].claimLastUpdatedDate);
                        formattedDate=$filter('date')(formattedDate1, "dd-MM-yyyy h:mm a");
						$scope.claimsLoggedDetails
								.push({
									"header" : claimsLoggedSearchDetails[i].claimNumber,
                                    "lastUpdatedDate": formattedDate,
									"data" : $scope.clientDetailsTemp,
									"statusIcon" : policyIcon
								});
					}
					
					appDataShareService.claimLoggedjson = {
				        'policySearch' : claimsLoggedSearchDetails
				    };
					$scope.noData = false;
                    $scope.pageNumber++;
					$scope.$apply();
				}
				else if($scope.claimsLoggedFullData == 0) {
					$scope.noData = true;
					$scope.validSearch = false;
					$scope.errorMessage = [];
		            $scope.$apply();
		        }
			}
		 }
		 else {
				$scope.noData = true;
				$scope.validSearch = false;
				$scope.errorMessage = [];
				$scope.isSearchInValid = true;
				$scope.searchFailedMessage = translateMessages($translate, "policySearch.searchFailedMessage");
	            $scope.errorMessage.push($scope.searchFailedMessage);
	            $scope.$apply();
	     }
	     $scope.activeFilter=false;
         $scope.loadingMoreData=false;
		 showHideLoadingImage(false,"Loading Claims Records",null,null);
		 $scope.refresh();
	};
	$scope.getTransactionError = function(data) {
		$rootScope.serviceFailed=true;
        if (rootConfig.isDeviceMobile && !checkConnection()) {
			$scope.message = translateMessages($translate, "networkValidationErrorMessage");
		}else{
			$scope.message = translateMessages($translate, "validToken");
		}
        $scope.$emit('tokenEvent', { message: $scope.message });
        if (data == "Error in ajax callE"){
            $scope.onServerError=true;
            $scope.serverErrorMessage= translateMessages($translate, "serverErrorMessage");
			showHideLoadingImage(false,"Loading Claims Records",null,null);
        }else{
            showHideLoadingImage(false,"Loading Claims Records",null,null);
        }
        $rootScope.$apply();
    };
	
	/* Modal Field values */
		 $scope.getPolicyInfo = function(policyNumber) {
			$scope.policyNumber = policyNumber;
			var policySearchData = $scope.claimsLoggedFullData;
			var formattedDate1="";
			var formattedDate="";
			var issueDate1="";
			var issueDate="";
			var policyStartDate1="";
			var policyStartDate="";
			var policyExpiryDate1="";
			var policyExpiryDate="";
			for ( var i = 0; i < policySearchData.length; i++) {
				if (policySearchData[i].claimNumber === ($scope.policyNumber)) {
					$scope.policyDetails = [];
					if (policySearchData[i].dateOfBirth!=="")
					{
						 formattedDate1=new Date(policySearchData[i].dateOfBirth);
						 formattedDate=$filter('date')(formattedDate1, "dd-MM-yyyy");
					}
					else
					{
						 formattedDate=policySearchData[i].dateOfBirth;
					}
					if (policySearchData[i].issueDate!=="")
					{
						issueDate1 = new Date(policySearchData[i].issueDate);
						issueDate=$filter('date')(issueDate1, "dd-MM-yyyy");
					}
					else
					{
						issueDate=policySearchData[i].issueDate;

					}
					if (policySearchData[i].policyStartDate!=="")
					{
						policyStartDate1 = new Date(policySearchData[i].policyStartDate);
						policyStartDate =$filter('date')(policyStartDate1, "dd-MM-yyyy");
					}
					else
					{
						policyStartDate=policySearchData[i].policyStartDate;

					}
					if (policySearchData[i].policyExpiryDate!=="")
					{
						policyExpiryDate1 = new Date(policySearchData[i].policyExpiryDate);
						policyExpiryDate=$filter('date')(policyExpiryDate1, "dd-MM-yyyy");
					}
					else
					{
						policyExpiryDate=policySearchData[i].policyExpiryDate;
					}
					$scope.policyDetails.push({
						key : translateMessages($translate, "policySearch.dateOfBirthText"),
						value : formattedDate
						});
					$scope.policyDetails
							.push({
								key : translateMessages($translate, "policySearch.insuredName"),
								value : policySearchData[i].policyholderName
							});
					$scope.policyDetails.push({
						key : translateMessages($translate, "policySearch.issueDate"),
						value : issueDate
						});
					$scope.policyDetails.push({
						key : translateMessages($translate, "policySearch.policyStartDate"),
						value : policyStartDate
						});
					$scope.policyDetails.push({
						key : translateMessages($translate, "policySearch.policyEndDate"),
						value : policyExpiryDate
					});
                    if(policySearchData[i].vehicleNumber!="") {
                        $scope.policyDetails.push({
                            key : translateMessages($translate, "policyRenewal.vehicleNumber"),
                            value : policySearchData[i].vehicleNumber
                        });
                    }
				}
			}
		};
		
			 $scope.getContactInfo = function(policyNumber) {
			$scope.policyNumber = policyNumber;
			var policySearchData = $scope.claimsLoggedFullData;
			for ( var i = 0; i < policySearchData.length; i++) {
				if (policySearchData[i].claimNumber === ($scope.policyNumber)) {
					$scope.contactInfoDetails = [];
					$scope.contactInfoMobileNumber =   policySearchData[i].mobileNumber;
					$scope.contactInfoPhoneNumber =  [policySearchData[i].telephoneHome, policySearchData[i].telephoneOffice];
					$scope.mailingAddress = policySearchData[i].mailingAddress[0].addressLine1+','+policySearchData[i].mailingAddress[0].addressLine2+','+policySearchData[i].mailingAddress[0].addressLine3+','+policySearchData[i].mailingAddress[0].addressLine4;
					$scope.contactInfoDetails
							.push({
								key : translateMessages($translate, "policySearch.nameText"),
								value :[policySearchData[i].policyholderName]
							});
					$scope.contactInfoDetails.push({
						key : translateMessages($translate, "policySearch.mobileText"),
						value :[$scope.contactInfoMobileNumber]
					});
					$scope.contactInfoDetails.push({
						key : translateMessages($translate, "policySearch.emailText"),
						value : [ policySearchData[i].emailId ]
					});
					$scope.contactInfoDetails.push({
						key : translateMessages($translate, "policySearch.phoneText"),
						value : $scope.contactInfoPhoneNumber
					});
					$scope.contactInfoDetails.push({
						key : translateMessages($translate, "policySearch.mailingText"),
						value : [$scope.mailingAddress]
					});
				}
			}
		};
		
	$scope.validateFields = function(claimsLogged){
		$scope.noData = false;
		$scope.claimsLoggedDetails = [];
		$scope.claimsLogged = claimsLogged;
		//Date validation for claim incurred date
		 if($scope.claimsLogged.claimsIncurredDateFrom && $scope.claimsLogged.claimsIncurredDateTo){
			if($scope.claimsLogged.claimsIncurredDateTo < $scope.claimsLogged.claimsIncurredDateFrom){
            	$scope.errorMessage = [];
            	$scope.isValid = true;
				$scope.dateRangeSixtyValidationMessage = translateMessages($translate, "policySearch.fromGreaterthanToValidationMessage");// have'nt got the error message
                $scope.errorMessage.push($scope.dateRangeSixtyValidationMessage);
            }
            else{
            	$scope.isValid = false;
            }
		}
		else if(($scope.claimsLogged.claimsIncurredDateFrom && !$scope.claimsLogged.claimsIncurredDateTo) || (!$scope.claimsLogged.claimsIncurredDateFrom && $scope.claimsLogged.claimsIncurredDateTo)){
				$scope.errorMessage = [];
				$scope.fromTodateValidationErrorMessage = translateMessages($translate, "policySearch.fromTodateValidationErrorMessage");
				$scope.errorMessage.push($scope.fromTodateValidationErrorMessage);
				$scope.isValid = true;
		}
		else{
        	$scope.isValid = false;
		}
		//To call claims Logged search
	    if($scope.isValid){
		  //errror message
		     $scope.isSearchInValid = true;
		}
		else{
		     $scope.isSearchInValid = false;
			 $scope.errorMessage = [];
			 $scope.searchClaimsLogged($scope.claimsLogged, true);
			}
	 };
    $scope.$on('requestDataSet', function(e, args) {
        if(!$scope.noDataFromServer) {
            $scope.loadingMoreData=true;
            $scope.searchClaimsLogged($scope.searchData, false);
        }
        else {
        	$scope.loadingMoreData=false;
        }
        $scope.$apply();
    });
    $scope.initialLoad();
}]);
