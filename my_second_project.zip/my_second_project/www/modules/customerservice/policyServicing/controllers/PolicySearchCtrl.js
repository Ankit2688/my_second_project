mServiceApp.controller('PolicySearchCtrl',['$controller','$rootScope', '$scope',  '$compile', '$route', '$routeParams', '$location', '$translate','dataService','appDataShareService','AutoSync','debounce','$timeout','$filter','mServiceConstants','commonConfig','customerServiceConfig',function($controller ,$rootScope, $scope,  $compile, $route, $routeParams, $location, $translate,dataService,appDataShareService,AutoSync,debounce,$timeout,$filter,mServiceConstants,commonConfig,customerServiceConfig) {   	

	var userDetails={};
	userDetails.currentUrl=$location.path();
	userDetails.userId=appDataShareService.selectedUser.userId;
	userDetails.userName=appDataShareService.selectedUser.name;
	var logedin = [];
	
	$rootScope.serviceFailed=false;
	
	logedin.push(userDetails);
	sessionStorage.setItem('currentUser',JSON.stringify(logedin));
	$scope.selectedpage = commonConfig().PAGE_NAME.CUSTOMER_SERVICE;
	$scope.subModule = customerServiceConfig().SUB_MODULE.POLICY_SEARCH;
	
	if (rootConfig.autoSync && ($rootScope.isAutoSyncCompleted)) {
		   
	   	AutoSync.SyncData(dataService,$rootScope,appDataShareService,debounce,$scope,$timeout);
	}	

	$scope.policySearch = {};
	$scope.setData = function() {
		
		$scope.policySearch.policyNumber = "";
		$scope.policySearch.mobileNumber = "";
		$scope.policySearch.premiumFrequency = "";
		$scope.policySearch.customerFirstName = "";
		$scope.policySearch.customerLastName = "";
		$scope.policySearch.clientId = "";
		$scope.policySearch.premiumIssueDateFrom = "";
		$scope.policySearch.premiumIssueDateTo = "";
		$scope.policySearch.premiumDueDateFrom = "";
		$scope.policySearch.premiumDueDateTo = "";
		$scope.policySearch.productName = "";
		$scope.policySearch.policyStatus = "";
		$scope.policySearch.premiumAmount = "";
		$scope.isPremiumFrequency =  false;
		$scope.isProductName =  false;
		$scope.isPolicyStatus =  false;
		var policyNumberPattern = "^(\\d{9})$";
		if ($routeParams.pid) {
		    
			if(!$rootScope.isSwitchUser){
			  	var tempPID = parseInt($routeParams.pid);
				var pattern = new RegExp(policyNumberPattern);
	                if(rootConfig.isDeviceMobile){
					
	                	//var userAgent = navigator.userAgent.toLowerCase();
	                	if (rootConfig.isDevicePhone){
	                	
	                		$scope.policySearch.searchOptions = commonConfig().SEARCH_OPTION.POLICY_NUMBER;
	                		$scope.policySearch.inputSearchValue = tempPID;
	                		if (!pattern.test($scope.policySearch.inputSearchValue)) {
	            				$scope.policyNumberValidationMessage = translateMessages($translate, "policyNumberValidationErrorMessage");
	            			} else {
	            				$scope.policyNumberValidationMessage = "";
	            			}
	            			   
	                	}

	                	else {
	                		
	                		$scope.policySearch.policyNumber = tempPID; 
	                		if (!pattern.test($scope.policySearch.policyNumber)) {
	            				$scope.policyNumberValidationMessage = translateMessages($translate, "policyNumberValidationErrorMessage");
	            			} else {
	            				$scope.policyNumberValidationMessage = "";
	            			}
	            			   
	                	}
	                }else{
	                	$scope.policySearch.policyNumber = tempPID; 
	                	if (!pattern.test($scope.policySearch.policyNumber)) {
	        				$scope.policyNumberValidationMessage = translateMessages($translate, "policyNumberValidationErrorMessage");
	        			} else {
	        				$scope.policyNumberValidationMessage = "";
	        			}
	        			   
	                }
				/*$scope.policySearch.policyNumber = tempPID; 
				$scope.policySearch.searchOptions = "Policy Number";
				$scope.policySearch.inputSearchValue = tempPID;*/
			
				 
					
					$scope.searchPolicyDetails($scope.policySearch);
			}
	
			else{
				$rootScope.isSwitchUser =  false;
			}
                
		}
		
	}
	var _this = this;
	$scope.errorMessage=[];
	$scope.isValid = false;
	$scope.noOfPolicies = 0;
	$scope.productLists = [];
	$scope.freqLists = [];
	$scope.statusLists = [];
	$scope.validSearch = true;
	$scope.dataEmpty = false;
	$scope.alertMessage;
	$scope.isDateField = false;
	$scope.validationMessage=[];
	$scope.policyNumberValidationMessage = "";
	$scope.mobileNumberValidationMessage = "";
	$scope.nameValidationMessage  = "";
	$scope.lastNameValidationMessage="";
	$scope.cilentIdValidationMessage = "";
	$scope.premiumAmountValidationMessage = "";
	
	if(appDataShareService.productNameJson.productName != undefined){
		for ( var i = 0; i < appDataShareService.productNameJson.productName.length; i++)
			{
			$scope.productLists.push(appDataShareService.productNameJson.productName[i].value);
			}
			
	}
	if( appDataShareService.premiumFrequencyJson.premiumFrequency != undefined){
		for ( var i = 0; i < appDataShareService.premiumFrequencyJson.premiumFrequency.length; i++){
			$scope.freqLists.push(appDataShareService.premiumFrequencyJson.premiumFrequency[i].value);
		}
}
	
	if( appDataShareService.policyStatusJson.policyStatus != undefined){
		for ( var i = 0; i < appDataShareService.policyStatusJson.policyStatus.length; i++){
			$scope.statusLists.push(appDataShareService.policyStatusJson.policyStatus[i].value);
		}
}
	
	$scope.searchLists = [ "Policy Number", "Name", "Client ID",
			"Mobile Number", "Policy Issue Date", "Premium Due Date",
			"Premium Amount", "Premium Frequency", "Product Name",
			"Policy Status" ]
	//angular.extend(this, new BaseCtrl($scope, $rootScope, dataService,
			//'PolicySearch', appDataShareService.selectedUser.userId));
angular.extend(this, $controller('BaseCtrl',{$scope:$scope, $rootScope:$rootScope, dataService:dataService, type:'PolicySearch', userId:appDataShareService.selectedUser.userId}));
	$scope.emptySearchDataMessage;
	$scope.getTransationSuccessProductName = function(data) {
		
	$scope.isProductName =  true;
      if (data[0].TransactionData != null) {
    	  var data = data[0].TransactionData;
    		var obj = {
					'productName': ""
			};
			obj.productName = data;
			appDataShareService.productNameJson = obj;
			if($scope.productLists.length == 0 ){
				for ( var i = 0; i < appDataShareService.productNameJson.productName.length; i++)
					$scope.productLists.push(appDataShareService.productNameJson.productName[i].value);
			}
			
		}
      if(!rootConfig.isDeviceMobile){
    	 
    	  if($scope.isPremiumFrequency && $scope.isPolicyStatus){
  			showHideLoadingImage(false);
  		}  
      }
     
		
		$scope.refresh();

	}
	


	$scope.getTransationSuccessPremiumFrequency = function(data) {
		 
		$scope.isPremiumFrequency =  true;
		if (data[0].TransactionData != null) {
			  var data = data[0].TransactionData;
	    		var obj = {
						'premiumFrequency': ""
				};
				obj.premiumFrequency = data;
				appDataShareService.premiumFrequencyJson = obj;
				if($scope.freqLists.length == 0){
					for ( var i = 0; i < appDataShareService.premiumFrequencyJson.premiumFrequency.length; i++)
						$scope.freqLists.push(appDataShareService.premiumFrequencyJson.premiumFrequency[i].value);
				}
			
		}
	      if(!rootConfig.isDeviceMobile){
	    	 
	    	  if($scope.isProductName && $scope.isPolicyStatus){
	  			showHideLoadingImage(false);
	  		}
	      }
		
		$scope.refresh();

	}
	
	$scope.getTransationSuccessPolicyStatus = function(data) {
	
		$scope.isPolicyStatus =  true;
		if (data[0].TransactionData != null) {
			  var data = data[0].TransactionData;
	    		var obj = {
						'policyStatus': ""
				};
				obj.policyStatus = data;
				appDataShareService.policyStatusJson = obj;
				if($scope.statusLists.length == 0){
					for ( var i = 0; i < appDataShareService.policyStatusJson.policyStatus.length; i++)
						$scope.statusLists.push(appDataShareService.policyStatusJson.policyStatus[i].value);
				}
			
		}
		if(rootConfig.isDeviceMobile){
			
			showHideLoadingImage(false);
		}
		else{
			
			if($scope.isProductName &&  $scope.isPremiumFrequency){
				showHideLoadingImage(false);
			}
		}
		
		$scope.refresh();

	}
	
	
	$scope.getTransationError = function(data) {
		showHideLoadingImage(false);
		$rootScope.serviceFailed=true;		
		if (rootConfig.isDeviceMobile && !checkConnection()) {
			$scope.message = translateMessages($translate, "networkValidationErrorMessage");
		}else{
			$scope.message = translateMessages($translate, "validToken");
		}	
		$scope.$emit('tokenEvent', { message: $scope.message });	
	}

	
	
	$scope.getTransationSuccess = function(data) {
        $scope.showResultPage=true;
        if($scope.$parent.isDevicePhone) {
            $scope.hideSearch=true;
        }
		appDataShareService.policysearchjson = {};
		var policySearchDetails = [];
		 if(data[0] != undefined)
			{	
		if (data[0].TransactionData != null) {
			
			$scope.validSearch = true;
			if (data[0].TransactionData.length != 0) {
				policySearchDetails = data[0].TransactionData;
				appDataShareService.policysearchjson = {
					'policySearch' : policySearchDetails
				};
				
				var policySearchData = appDataShareService.policysearchjson.policySearch;
				$scope.clientDetails = [];
				var formattedDate;
				$scope.noOfPolicies = policySearchData.length;
				for ( var i = 0; i < policySearchData.length; i++) {
					var policyStatus;
					var policyIcon;
					if(policySearchData[i].clientDetails.dueDate != ""){
						
						formattedDate = convertDateFromISO(policySearchData[i].clientDetails.dueDate);
						formattedDate=$scope.getFormattedDate(formattedDate.getDate()+"/"+(formattedDate.getMonth()+1)+"/"+formattedDate.getFullYear());
						
					}
					else{
						formattedDate = policySearchData[i].clientDetails.dueDate;
					}
					$scope.clientDetailsTemp = [];
					$scope.mobileNumber =  (policySearchData[i].clientDetails.mobNo.toString()).replace(/","/g , ",");
					
					$scope.clientDetailsTemp
							.push({
								key : translateMessages($translate, "policySearch.nameText"),
								value : (policySearchData[i].clientDetails.clientFirstName)
										.concat("  ")
										.concat(policySearchData[i].clientDetails.clientLastName)
					});
					$scope.clientDetailsTemp.push({
						key : translateMessages($translate, "policySearch.mobileNumber"),
						value : $scope.mobileNumber
					});
					$scope.clientDetailsTemp.push({
						key : translateMessages($translate, "policySearch.emailText"),
						value : policySearchData[i].clientDetails.emailId
					});
					$scope.clientDetailsTemp.push({
						key : translateMessages($translate, "policySearch.premiumAmount"),
						value : policySearchData[i].clientDetails.premiumAmount,
						isRupeeShow : true
					});
					$scope.clientDetailsTemp.push({
						key : translateMessages($translate, "policySearch.productName"),
						value : policySearchData[i].clientDetails.productName
					});
					$scope.clientDetailsTemp.push({
						key : translateMessages($translate, "policySearch.dueDateText"),
						value : formattedDate
					});
					policyStatus = policySearchData[i].policyDetails.summaryStatus;

					switch (policyStatus) {
					case mServiceConstants.PolicyActiveStatus:
						policyIcon = mServiceConstants.PolicyActiveIcon;
						break;
					case mServiceConstants.PolicyGracedStatus:
						policyIcon = mServiceConstants.PolicyGracedIcon;
						break;
					case mServiceConstants.PolicyLapsedStatus:
						policyIcon = mServiceConstants.PolicyLapsedIcon;
						break;
					case mServiceConstants.PolicyOtherStatus:
						policyIcon = "";
						break;
					}
					$scope.clientDetails
							.push({
								"header" : policySearchData[i].clientDetails.policyNumber,
								"data" : $scope.clientDetailsTemp,
								"statusIcon" : policyIcon
							});
					
					
				}
			} else {
				$scope.noOfPolicies = 0;
				$scope.validSearch = false;
				
					$scope.alertMessage = translateMessages($translate, "onlineAlertMessage");
			}
			
			delete $routeParams.pid;

			
			
		} 
			}else {
			$scope.noOfPolicies = 0;
			$scope.validSearch = false;
			
				$scope.alertMessage = translateMessages($translate, "onlineAlertMessage");
			

		}
		$scope.transactionSuccess = true;
		showHideLoadingImage(false); 
		$scope.refresh();
		

	}

	
	$scope.getTransationError = function(data) {
		showHideLoadingImage(false);
		$rootScope.serviceFailed=true;
		$scope.message = translateMessages($translate, "validToken");		
		$scope.$emit('tokenEvent', { message: $scope.message });	
	}

	
		$scope.validDate = function(policySearch) {

		if (policySearch.dateType) {

			if (policySearch.dateType && policySearch.dateFrom
					&& policySearch.dateTo) {
				return true;
			} else if (!policySearch.dateType && !policySearch.dateFrom
					&& !policySearch.dateTo) {
				return true;
			} else {
				return false;
			}

		} else {
			if (policySearch.dateFrom && policySearch.dateTo) {
				return true;
			} else if (!policySearch.dateFrom && !policySearch.dateTo) {
				return true;
			} else {
				return false;
			}
		}

	}

	// reset the search form fields
	$scope.reset = function() {
		$scope.isValid = false;
		$scope.clientDetails = {};
		$scope.policySearch.policyNumber = "";
		$scope.policySearch.mobileNumber = "";
		$scope.policySearch.premiumFrequency = "";
		$scope.policySearch.customerFirstName = "";
		$scope.policySearch.customerLastName = "";
		$scope.policySearch.clientId = "";
		$scope.policySearch.premiumIssueDateFrom = "";
		$scope.policySearch.premiumIssueDateTo = "";
		$scope.policySearch.premiumDueDateFrom = "";
		$scope.policySearch.premiumDueDateTo = "";
		$scope.policySearch.productName = "";
		$scope.policySearch.policyStatus = "";
		$scope.policySearch.premiumAmount = "";
		$scope.policySearch.searchOptions = "";
		$scope.policySearch.inputSearchValue = "";
		$scope.policySearch.dateType = "";
		$scope.networkValdiationMessage="";
		$scope.policySearch.dateFrom = "";
		$scope.policySearch.dateTo = "";
		$scope.noOfPolicies = 0;
		$scope.sortExpression = commonConfig().SEARCH_OPTION.POLICY_NUMBER;
		$scope.errorMessage=[];
		$scope.alertMessage="";
		$scope.policyNumberValidationMessage = "";
	$scope.mobileNumberValidationMessage = "";
	$scope.nameValidationMessage  = "";
	$scope.lastNameValidationMessage="";
	$scope.cilentIdValidationMessage = "";
	$scope.premiumAmountValidationMessage = "";
	$location.url("/customerService/policySearch");
	}

	$scope.resetInputSearchValue = function(policySearch) {
		
		policySearch.inputSearchValue = "";
		policySearch.dateFrom = "";
		policySearch.dateTo = "";
	}

	$scope.validSearchFields = function(policySearch) {

		if (policySearch.searchOptions) {
		
			if (policySearch.inputSearchValue || policySearch.dateFrom
					|| policySearch.dateTo) {
				return true;
			} else {
				return false;
			}
		}

		else {
			
			if (policySearch.policyNumber || policySearch.customerFirstName
					|| policySearch.dateType || policySearch.premiumFrequency
					|| policySearch.customerLastName || policySearch.clientId
					|| policySearch.mobileNumber || policySearch.premiumAmount
					|| policySearch.productName || policySearch.policyStatus) {

				return true;
			} else {
				return false;
			}
		}
	}
	$scope.searchPolicyDetails = function(policySearch) {
		var dateFrom = "";
		var dateTo = "";
		$scope.networkValdiationMessage="";
		$scope.noOfPolicies = 0;
		var polDateFrom=$scope.policySearch.dateFrom;
		var polDateTo=$scope.policySearch.dateTo;
		$scope.policySearch.dateFrom = $filter('date')($scope.policySearch.dateFrom, "dd-MM-yyyy");
		$scope.policySearch.dateTo = $filter('date')($scope.policySearch.dateTo, "dd-MM-yyyy");
		var dateFlag = $scope.validDate(policySearch);
	
		if (!($scope.validSearchFields(policySearch)) || !dateFlag) {
			if (!dateFlag) {
				$scope.errorMessage = [];
				$scope.errorMessage.push(translateMessages($translate, "policySearch.dateValidationErrorMessage"));
			} else {
				$scope.errorMessage = [];
				$scope.errorMessage.push(translateMessages($translate, "policySearch.mandatoryFieldsValidationErrorMessgae"));
			}
			$scope.noOfPolicies = 0;
			$scope.clientDetails = {};
			$scope.isValid = true;
			$scope.validSearch = false;

		} else {
			$scope.errorMessage = [];
			dateFrom = changeStringToDate($scope.policySearch.dateFrom,"dd-MM-yyyy");
			dateTo=changeStringToDate($scope.policySearch.dateTo,"dd-MM-yyyy");
			   if (dateFrom > dateTo) {
				$scope.isValid = true;
				$scope.errorMessage.push(translateMessages($translate, "policySearch.FromDateValidationErrorMessage"));
				$scope.validSearch = false;
			   }
			  
			else if (
					$scope.policyNumberValidationMessage == "" && 
					$scope.mobileNumberValidationMessage == "" &&
					$scope.nameValidationMessage == "" && 
					$scope.lastNameValidationMessage == "" &&
					$scope.cilentIdValidationMessage == "" &&
					$scope.premiumAmountValidationMessage == ""
					)
			{
				$scope.errorMessage = [];
				$scope.isValid = false;
				var transObj = _this.mapScopeToPersistance();
				var searchObj = {
					"searchCriteria" : {
						"policyNumber" : "",
						"mobileNumber" : "",
						"premiumFrequency" : "",
						"customerFirstName" : "",
						"customerLastName" : "",
						"clientId" : "",
						"policyIssueDateFrom" : "",
						"policyIssueDateTo" : "",
						"premiumDueDateFrom" : "",
						"premiumDueDateTo" : "",
						"productName" : "",
						"policyStatus" : "",
						"premiumAmount" : ""
					}
				}
				//searchObj.searchCriteria.type = "PolicyDetails";
				
				if(rootConfig.isDeviceMobile){
					
					if(policySearch.searchOptions){
						
						switch(policySearch.searchOptions){					
						case commonConfig().SEARCH_OPTION.POLICY_NUMBER:
							searchObj.searchCriteria.policyNumber = ($scope.policySearch.inputSearchValue).toString();
							break;
						case commonConfig().SEARCH_OPTION.NAME:
					
							searchObj.searchCriteria.customerFirstName = $scope.policySearch.inputSearchValue;
						    break;
						    
						case commonConfig().SEARCH_OPTION.CLIENT_ID:
							searchObj.searchCriteria.clientId = $scope.policySearch.inputSearchValue;
							break;
							
						case commonConfig().SEARCH_OPTION.MOBILE_NUMBER:
							searchObj.searchCriteria.mobileNumber = $scope.policySearch.inputSearchValue;
							break;
							
						case commonConfig().SEARCH_OPTION.POLICY_ISSUE_DATE:
						{
							searchObj.searchCriteria.policyIssueDateFrom = $scope.policySearch.dateFrom;
							searchObj.searchCriteria.policyIssueDateTo = $scope.policySearch.dateTo;
	                                             break;
						}
						
							
						case commonConfig().SEARCH_OPTION.PREMIUM_DUE_DATE :
						{
							searchObj.searchCriteria.premiumDueDateFrom = $scope.policySearch.dateFrom;
							searchObj.searchCriteria.premiumDueDateTo = $scope.policySearch.dateTo;
							break;
						}
							
						case commonConfig().SEARCH_OPTION.PREMIUM_AMOUNT:
							searchObj.searchCriteria.premiumAmount =  $scope.policySearch.inputSearchValue;
							break;
							
						case commonConfig().SEARCH_OPTION.PREMIUM_FREQUENCY:
							searchObj.searchCriteria.premiumFrequency = $scope.policySearch.inputSearchValue;
							break;
							
						case commonConfig().SEARCH_OPTION.PRODUCT_NAME:
							searchObj.searchCriteria.productName = $scope.policySearch.inputSearchValue;
							break;
							
						case commonConfig().SEARCH_OPTION.POLICY_STATUS:
							searchObj.searchCriteria.policyStatus = $scope.policySearch.inputSearchValue;
							break;
						}

						
						}
					else{
						if ($scope.policySearch.productName == null) {
							$scope.policySearch.productName="";
						}
						if ($scope.policySearch.policyStatus == null) {
							$scope.policySearch.policyStatus="";
						}
						if ($scope.policySearch.premiumFrequency==null) {
							$scope.policySearch.premiumFrequency="";
						}
						searchObj.searchCriteria.policyNumber = ($scope.policySearch.policyNumber).toString();
						searchObj.searchCriteria.mobileNumber = $scope.policySearch.mobileNumber;
						searchObj.searchCriteria.premiumFrequency = $scope.policySearch.premiumFrequency;
						searchObj.searchCriteria.customerFirstName = $scope.policySearch.customerFirstName;
						searchObj.searchCriteria.customerLastName = $scope.policySearch.customerLastName;
						searchObj.searchCriteria.clientId = $scope.policySearch.clientId;
						if($scope.policySearch.dateType){
							if(policySearch.dateType == commonConfig().DATE_TYPE.ISSUE_DATE)
							{
								searchObj.searchCriteria.policyIssueDateFrom = $scope.policySearch.dateFrom;
								searchObj.searchCriteria.policyIssueDateTo = $scope.policySearch.dateTo;
							}
							else if(policySearch.dateType == commonConfig().DATE_TYPE.DUE_DATE)
							{
								searchObj.searchCriteria.premiumDueDateFrom = $scope.policySearch.dateFrom;
								searchObj.searchCriteria.premiumDueDateTo = $scope.policySearch.dateTo;
							}
						}
						
						searchObj.searchCriteria.productName = $scope.policySearch.productName;
						searchObj.searchCriteria.policyStatus = $scope.policySearch.policyStatus;
						searchObj.searchCriteria.premiumAmount = $scope.policySearch.premiumAmount;
						
						
					}
				}
				
				else
				{
					if ($scope.policySearch.productName == null) {
							$scope.policySearch.productName="";
						}
						if ($scope.policySearch.policyStatus == null) {
							$scope.policySearch.policyStatus="";
						}
						if ($scope.policySearch.premiumFrequency==null) {
							$scope.policySearch.premiumFrequency="";
						}
					searchObj.searchCriteria.policyNumber = ($scope.policySearch.policyNumber).toString();
					searchObj.searchCriteria.mobileNumber = $scope.policySearch.mobileNumber;
					searchObj.searchCriteria.premiumFrequency = $scope.policySearch.premiumFrequency;
					searchObj.searchCriteria.customerFirstName = $scope.policySearch.customerFirstName;
					searchObj.searchCriteria.customerLastName = $scope.policySearch.customerLastName;
					searchObj.searchCriteria.clientId = $scope.policySearch.clientId;
					if($scope.policySearch.dateType){
						if(policySearch.dateType == "issuedate")
						{
							searchObj.searchCriteria.policyIssueDateFrom = $scope.policySearch.dateFrom;
							searchObj.searchCriteria.policyIssueDateTo = $scope.policySearch.dateTo;
						}
						else if(policySearch.dateType == "duedate")
						{
							searchObj.searchCriteria.premiumDueDateFrom = $scope.policySearch.dateFrom;
							searchObj.searchCriteria.premiumDueDateTo = $scope.policySearch.dateTo;
						}
					}
					
					searchObj.searchCriteria.productName = $scope.policySearch.productName;
					searchObj.searchCriteria.policyStatus = $scope.policySearch.policyStatus;
					searchObj.searchCriteria.premiumAmount = $scope.policySearch.premiumAmount;
					
					
					 
				}
				transObj.TransactionData = searchObj;
				if (navigator.userAgent.search(commonConfig().SEARCH_OPTION.MSIE) >= 0)
                                {
                                showHideLoadingImage(true, "Loading Policy Search Details"); 
                                 }
                                else
                                {
				showHideLoadingImage(true, "loadingPolicySearch", $translate);
				}
				
				if (rootConfig.isDeviceMobile){
					if(navigator.network.connection.type == Connection.NONE) {
					showHideLoadingImage(false);
					$scope.validSearch = false;
					$scope.networkValdiationMessage = translateMessages($translate, "networkValidationErrorMessage");
					$scope.showNetworkMessage = true;
				}
					else
					{
						
						dataService.searchTransactions(transObj,$scope.getTransationSuccess,$scope.getTransationError);
						$scope.showNetworkMessage = false;
					}
			}else {
				dataService.searchTransactions(transObj,$scope.getTransationSuccess,$scope.getTransationError);
				$scope.showNetworkMessage = false;
				}
			}

			else {
         		$scope.errorMessage .push($scope.policyNumberValidationMessage);
				$scope.errorMessage .push($scope.mobileNumberValidationMessage);
				$scope.errorMessage .push($scope.nameValidationMessage);
				$scope.errorMessage .push($scope.lastNameValidationMessage);
				$scope.errorMessage .push($scope.cilentIdValidationMessage);
				$scope.errorMessage .push($scope.premiumAmountValidationMessage);		
				$scope.clientDetails = {};
				$scope.isValid = true;
			}
		}
		
		$scope.policySearch.dateFrom=polDateFrom;
		$scope.policySearch.dateTo=polDateTo;
	}

	
	
	$scope.mySortFunction = function(item) {
		if ($scope.sortExpression == mServiceConstants.PolicyNumber) {
			return ($scope.getSortedData(item.header, $scope.sortExpression));

		} else if ($scope.sortExpression == mServiceConstants.DueDate) {
			return ($scope.getSortedData(item.data[5], $scope.sortExpression));

		} else if ($scope.sortExpression == mServiceConstants.PremiumAmount) {
			return ($scope.getSortedData(item.data[3], $scope.sortExpression));
		}

	}

	$scope.getSortedData = function(data, sortExpression) {
		
		if (sortExpression == translateMessages($translate, "policySearch.dueDateText")) {
			if(data.value != ""){
				
				return new Date(data.value);
			}
			else{
				
				return data.value;
			}
		}
		else if (isNaN(data))
		{
			if(sortExpression == translateMessages($translate, "policySearch.premiumAmount"))
			{
				if(data.value != ""){
					return parseFloat((data.value) ? (data.value).replace(/,/g, ""):(data.value))
				}
				else{
					return data.value;
				}
			}
			else
			{
				return data
			}
		}
		else 
		{
			return parseInt(data)
		}
	}
	$scope.getFormattedDate = function(inputDate) {
		var dateFormatted;
		var months = [ 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug',
				'Sep', 'Oct', 'Nov', 'Dec' ];
		var pattern = /(.*?)\/(.*?)\/(.*?)$/;
		var result = inputDate.replace(pattern, function(match, p1, p2, p3) {
			dateFormatted = (p1 < 10 ? "0" + p1 : p1) + " " + months[(p2 - 1)]
					+ " " + p3;
		});
		return dateFormatted;
	}
	$scope.getPaymentHistory = function(policyNumber) {
		var policySearchData = appDataShareService.policysearchjson.policySearch;
		$scope.policyNumber = policyNumber;
		$scope.paymentHistoryDetails = [];
		$scope.paymentDetails = [];
		$scope.policyDetails = [];

		for ( var i = 0; i < policySearchData.length; i++) {

			if (policySearchData[i].policyDetails.policyNumber == policyNumber) {
				
				$scope.paymentHistoryDetails = angular.copy(policySearchData[i].policyDetails.paymentHistory);
				
				for(var j = 0  ; j < $scope.paymentHistoryDetails.length; j++){
					
					if ($scope.paymentHistoryDetails[j].amount)
					{
						$scope.paymentHistoryDetails[j].amount = getIntegerFromString($scope.paymentHistoryDetails[j].amount);
					}
					if ($scope.paymentHistoryDetails[j].instrumentNumber)
					{
						$scope.paymentHistoryDetails[j].instrumentNumber = getIntegerFromString($scope.paymentHistoryDetails[j].instrumentNumber);
					}
					if ($scope.paymentHistoryDetails[j].policyAmount)
					{
						$scope.paymentHistoryDetails[j].policyAmount = getIntegerFromString($scope.paymentHistoryDetails[j].policyAmount);
					}
					if ($scope.paymentHistoryDetails[j].receiptDate)
					{
						$scope.paymentHistoryDetails[j].receiptDate = convertDateFromISO($scope.paymentHistoryDetails[j].receiptDate);
					}
					if ($scope.paymentHistoryDetails[j].bounceDate)
					{
						
						$scope.paymentHistoryDetails[j].bounceDate = convertDateFromISO($scope.paymentHistoryDetails[j].bounceDate);
						
					}
					if ($scope.paymentHistoryDetails[j].clearanceDate)
					{
						$scope.paymentHistoryDetails[j].clearanceDate = convertDateFromISO($scope.paymentHistoryDetails[j].clearanceDate);
						
					}
					
				}
				
				$scope.paymentDetails.push({payment:$scope.paymentHistoryDetails});
				$scope.$apply();
							}
			
		}
		

	
	}

	
	$scope.paintUISuccess = function(callbackId, data) {
		// call this getTransaction after paintUI complete
		
		$scope.isPainted = true;
	}
	$scope.onPartialLoaded = function(element, scope) {
		// call the paint UI with "scope.item.subType" as view name and define
		// this view in alerts-ui-json
		
		LEDynamicUI.paintUI(rootConfig.template, "policysearch-ui-json.json",
				"paymentHistory", element, true, $scope.paintUISuccess,
				scope, $compile);
	}
	
	$scope.getPolicyInfo = function(policyNumber) {
		$scope.policyNumber = policyNumber;
		var policySearchData = appDataShareService.policysearchjson.policySearch;
		var formattedDate1="";
		var formattedDate="";
		var bdayDate1="";
		var bdayDate="";
		
		for ( var i = 0; i < policySearchData.length; i++) {
			if (policySearchData[i].policyDetails.policyNumber == ($scope.policyNumber)) {

				$scope.policyDetails = [];
				
				$scope.riderDetails = (policySearchData[i].policyDetails.rider.toString()).replace(/","/g , ",");
				if (policySearchData[i].policyDetails.issueDate!="")
				{
					 formattedDate1 = convertDateFromISO(policySearchData[i].policyDetails.issueDate);
					 formattedDate=$filter('date')(formattedDate1, "dd-MM-yyyy");
				}
				else
				{
					 formattedDate=policySearchData[i].policyDetails.issueDate;
				}
				
				if (policySearchData[i].policyDetails.dob!="")
				{
					bdayDate1 = convertDateFromISO(policySearchData[i].policyDetails.dob);
					bdayDate=$filter('date')(bdayDate1, "dd-MM-yyyy");
				}
				else
				{
					bdayDate=policySearchData[i].policyDetails.dob;
					
				}
				
				
				$scope.policyDetails.push({
					key : translateMessages($translate, "policySearch.dateOfBirthText"),
					value : bdayDate
					});
				$scope.policyDetails
						.push({
							key : translateMessages($translate, "policySearch.lifeAssuredName"),
							value : policySearchData[i].policyDetails.lifeAssuredName
						});
				$scope.policyDetails.push({
					key : translateMessages($translate, "policySearch.issueDate"),
					value : formattedDate
					});
				$scope.policyDetails.push({
					key : translateMessages($translate, "policySearch.basePlan"),
					value : policySearchData[i].policyDetails.basePlan
					});
				$scope.policyDetails.push({
					key : translateMessages($translate, "policySearch.riderName"),
					value : $scope.riderDetails
				});
				$scope.policyDetails.push({
					key : translateMessages($translate, "policySearch.sumAssured"),
					value : policySearchData[i].policyDetails.sumAssured,
					isRupeeShow : true
				});
				$scope.policyDetails.push({
					key : translateMessages($translate, "policySearch.grossAmount"),
					value : policySearchData[i].policyDetails.grossAmount,
					isRupeeShow : true
				});
				$scope.policyDetails.push({
					key : translateMessages($translate, "policySearch.ctpText"),
					value : policySearchData[i].policyDetails.ctp,
					isRupeeShow : true
				});
				$scope.policyDetails.push({
					key : translateMessages($translate, "policySearch.modalPremium"),
					value : policySearchData[i].policyDetails.modalPremium,
					isRupeeShow : true
				});
				$scope.policyDetails.push({
					key : translateMessages($translate, "policySearch.paymentMode"),
					value : policySearchData[i].policyDetails.paymentMode
				});
				$scope.policyDetails.push({
					key : translateMessages($translate, "policySearch.policyStatus"),
					value : policySearchData[i].policyDetails.policyStatus
				});
				$scope.policyDetails.push({
					key : translateMessages($translate, "policySearch.billingType"),
					value : policySearchData[i].policyDetails.billingType
				});
				$scope.policyDetails.push({
					key : translateMessages($translate, "policySearch.ECSRegistration"),
					value : policySearchData[i].policyDetails.ecsStatus
				});
				$scope.policyDetails.push({
					key : translateMessages($translate, "policySearch.billingDrawDate"),
					value : policySearchData[i].policyDetails.billingDrawDate
				});

			}
		}
		
	}

	$scope.getContactInfo = function(policyNumber) {
		$scope.policyNumber = policyNumber;
		var policySearchData = appDataShareService.policysearchjson.policySearch;
		for ( var i = 0; i < policySearchData.length; i++) {
			if (policySearchData[i].clientDetails.policyNumber == ($scope.policyNumber)) {
				$scope.contactInfoDetails = [];
				$scope.contactInfoMobileNumber =  (policySearchData[i].clientDetails.mobNo.toString()).replace(/","/g , ",");
				$scope.contactInfoPhoneNumber =  (policySearchData[i].clientDetails.phoneNo.toString()).replace(/","/g , ",");
				
				$scope.contactInfoDetails
						.push({
							key : translateMessages($translate, "policySearch.nameText"),
							value : [ (policySearchData[i].clientDetails.clientFirstName)
									.concat("  ")
									.concat(policySearchData[i].clientDetails.clientLastName) ]
						});
				$scope.contactInfoDetails.push({
					key : translateMessages($translate, "policySearch.mobileText"),
					value :$scope.contactInfoMobileNumber.split(",")
				});
				$scope.contactInfoDetails.push({
					key : translateMessages($translate, "policySearch.emailText"),
					value : [ policySearchData[i].clientDetails.emailId ]
				});
				$scope.contactInfoDetails.push({
					key : translateMessages($translate, "policySearch.phoneText"),
					value : $scope.contactInfoPhoneNumber.split(",")
				});
				$scope.contactInfoDetails.push({
					key : translateMessages($translate, "policySearch.mailingText"),
					value : policySearchData[i].clientDetails.postalAddress
							.split(",")
				});
				var postalAddress = policySearchData[i].clientDetails.postalAddress
						.split(",");

			}
		}
	}
	
	
	$scope.initialLoad = function(){
		if (appDataShareService.refreshApp || (!(appDataShareService.productNameJson.hasOwnProperty('productName')))  || (!(appDataShareService.premiumFrequencyJson.hasOwnProperty('premiumFrequency')))
				|| (!(appDataShareService.policyStatusJson.hasOwnProperty('policyStatus')))) {

			appDataShareService.productNameJson = {};
			appDataShareService.premiumFrequencyJson = {};
			appDataShareService.policyStatusJson = {};
			//call get transaction and reload data
			var transactionObj = _this.mapScopeToPersistance();
			transactionObj.Type = "Product Name";
			transactionObj.Key1 = appDataShareService.selectedUser.userId;
			_this.getTransactions($scope.getTransationSuccessProductName,
					$scope.getTransationError, transactionObj);
			
			var transactionObj = _this.mapScopeToPersistance();
			transactionObj.Type = "Premium Frequency";
			transactionObj.Key1 = appDataShareService.selectedUser.userId;
			_this.getTransactions($scope.getTransationSuccessPremiumFrequency,
					$scope.getTransationError, transactionObj);
			
			var transactionObj = _this.mapScopeToPersistance();
			transactionObj.Type = "Policy Status";
			transactionObj.Key1 = appDataShareService.selectedUser.userId;
			_this.getTransactions($scope.getTransationSuccessPolicyStatus,
					$scope.getTransationError, transactionObj);

	       
	        if(!rootConfig.isDeviceMobile){
	        	if (navigator.userAgent.search(commonConfig().SEARCH_OPTION.MSIE) >= 0)
	    	    {
	    	     showHideLoadingImage(true, "Loading Policy Search"); 
	    	     }
	    	    else
	    	    {
	    	    showHideLoadingImage(true, "loadingPolicySearchPage", $translate);
	    	    }
	        }
			
				
			appDataShareService.refreshApp = false;

		}
	}

	$scope.$on('$viewContentLoaded', function(){
		$scope.initialLoad();
	  });
	
	

}]);