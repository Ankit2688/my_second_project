mServiceApp.controller('ProposalSearchCtrl',['$controller','$rootScope', '$scope',  '$compile', '$route', '$routeParams', '$location', '$translate','dataService','appDataShareService','AutoSync','debounce','$timeout','$filter','mServiceConstants','commonConfig','customerServiceConfig',function($controller ,$rootScope, $scope,  $compile, $route, $routeParams, $location, $translate,dataService,appDataShareService,AutoSync,debounce,$timeout,$filter,mServiceConstants,commonConfig,customerServiceConfig) {   	

	
	$rootScope.serviceFailed=false;
	var userDetails={};
	userDetails.currentUrl=$location.path();
	userDetails.userId=appDataShareService.selectedUser.userId;
	userDetails.userName=appDataShareService.selectedUser.name;
	var logedin = [];
	logedin.push(userDetails);
	sessionStorage.setItem('currentUser',JSON.stringify(logedin));
        // For sync
	if (rootConfig.autoSync && ($rootScope.isAutoSyncCompleted)) {

		AutoSync.SyncData(dataService, $rootScope, appDataShareService,
				debounce, $scope, $timeout);
	}
	
	$scope.selectedpage = commonConfig().PAGE_NAME.CUSTOMER_SERVICE;
	$scope.subModule = customerServiceConfig().SUB_MODULE.PROPOSAL_SEARCH;

	$scope.proposalSearch = {};
	var _this = this;
	$scope.isValid = false;
	$scope.noOfProposals = 0;
	$scope.planLists = [];
	$scope.statusLists = [];
	$scope.validSearch = true;
	$scope.proposalNumberValidationMessage = "";
	$scope.mobileNumberValidationMessage = "";
	$scope.isPlanType = false;
	$scope.isProposalStatus = false;
	$scope.alertMessage;
	$scope.validationMessage;

        // For mobile view of search criteria
	$scope.searchLists = [ "Proposal Number", "Proposal Received Date",
                                    "Plan Type", "Status", "Mobile Number" ];

	//angular.extend(this, new BaseCtrl($scope, $rootScope, dataService,
			//'ProposalSearch', appDataShareService.selectedUser.userId));
			angular.extend(this, $controller('BaseCtrl',{$scope:$scope, $rootScope:$rootScope, dataService:dataService, type:'ProposalSearch', userId:appDataShareService.selectedUser.userId}));
        // For proposal number link clicked from Alerts tab, details to display
	$scope.setData = function()
        {
		$scope.proposalSearch.proposalNumber = "";
		$scope.proposalSearch.planType = "";
		$scope.proposalSearch.mobNumber = "";
		$scope.proposalSearch.proposalReceivedDate = "";
		$scope.proposalSearch.status = "";
		var proposalNumberPattern = "^(\\d{9})$";
		if ($routeParams.proposalid) {
			
			if(!$rootScope.isSwitchUser){
				var tempPID = parseInt($routeParams.proposalid);
				var pattern = new RegExp(proposalNumberPattern);
				if(rootConfig.isDeviceMobile){
					
	            	// var userAgent = navigator.userAgent.toLowerCase();
					if (rootConfig.isDevicePhone){
	            		
	            		$scope.proposalSearch.searchOptions = commonConfig().SEARCH_OPTION.PROPOSAL_NUMBER;
	        			$scope.proposalSearch.inputSearchValue = tempPID;
	        			if (!pattern.test($scope.proposalSearch.inputSearchValue)) {
	        				$scope.proposalNumberValidationMessage = translateMessages($translate, "proposalNumberValidationErrorMessage");
	        			} else {
	        				$scope.proposalNumberValidationMessage = "";
	        			}
	            	}

	            	else {
	            		
	            		$scope.proposalSearch.proposalNumber = tempPID;
	            		if (!pattern.test($scope.proposalSearch.proposalNumber)) {
	        				$scope.proposalNumberValidationMessage = translateMessages($translate, "proposalNumberValidationErrorMessage");
	        			} else {
	        				$scope.proposalNumberValidationMessage = "";
	        			}
	            	}
	            }else{
	            	$scope.proposalSearch.proposalNumber = tempPID;
	            	if (!pattern.test($scope.proposalSearch.proposalNumber)) {
	    				$scope.proposalNumberValidationMessage = translateMessages($translate, "proposalNumberValidationErrorMessage");
	    			} else {
	    				$scope.proposalNumberValidationMessage = "";
	    			}
	            }
				
				
				$scope.searchProposalDetails($scope.proposalSearch);
			}
		

		}

	}
        // Plan type master Data
	if (appDataShareService.planTypeJson.planType != undefined) {
		for ( var i = 0; i < appDataShareService.planTypeJson.planType.length; i++) {
			$scope.planLists.push(appDataShareService.planTypeJson.planType[i].value);
		}

	}
	
	


        $scope.getTransationSuccessPlanType = function(data) {

		$scope.isPlanType = true;
		if (data[0].TransactionData != null) {
			var data = data[0].TransactionData;
			var obj = {
				'planType' : ""
			};
			obj.planType = data;
			appDataShareService.planTypeJson = obj;
			if ($scope.planLists.length == 0) {
				for ( var i = 0; i < appDataShareService.planTypeJson.planType.length; i++)
					$scope.planLists
							.push(appDataShareService.planTypeJson.planType[i].value);
			}

		}
		if(!rootConfig.isDeviceMobile){
			if ($scope.isProposalStatus) {
				showHideLoadingImage(false);
			}
		}
		
		$scope.refresh();

	}
        
        // Proposal type master data
	if (appDataShareService.proposalStatusJson.proposalStatus != undefined) {
		for ( var i = 0; i < appDataShareService.proposalStatusJson.proposalStatus.length; i++) {
			$scope.statusLists.push(appDataShareService.proposalStatusJson.proposalStatus[i].value);
		}

	}
	
	
        
	$scope.getTransationSuccessProposalStatus = function(data) {

		$scope.isProposalStatus = true;
		if (data[0].TransactionData != null) {
			var data = data[0].TransactionData;
			var obj = {
				'proposalStatus' : ""
			};
			obj.proposalStatus = data;
			appDataShareService.proposalStatusJson = obj;
			if ($scope.statusLists.length == 0) {
				for ( var i = 0; i < appDataShareService.proposalStatusJson.proposalStatus.length; i++)
					$scope.statusLists.push(appDataShareService.proposalStatusJson.proposalStatus[i].value);
			}

		}
		if(rootConfig.isDeviceMobile){
			showHideLoadingImage(false);
		}
		else{
			if ($scope.isPlanType) {
				showHideLoadingImage(false);
			}
		}
		
		$scope.refresh();
	}

	$scope.getTransationError = function(data) {
		showHideLoadingImage(false);
		$scope.proposalDetails=[];
		$scope.validSearch = false;		
		$rootScope.serviceFailed=true;
		if (rootConfig.isDeviceMobile && !checkConnection()) {
			$scope.message = translateMessages($translate, "networkValidationErrorMessage");
		}else{
			$scope.message = translateMessages($translate, "validToken");
		}	
		$scope.$emit('tokenEvent', { message: $scope.message });	
	}

        // Fetching data for proposal search
	$scope.getTransationSuccess = function(data) {
		appDataShareService.json = {};
		var proposalSearchDetails = [];
		if (data[0] != undefined) {
			if (data[0].TransactionData.length != 0 )
                                {
                                        proposalSearchDetails = data[0].TransactionData;
					appDataShareService.json = {
						'ProposalSearch' : proposalSearchDetails
					};
					var proposalSearchData = appDataShareService.json.ProposalSearch;
					$scope.proposalDetails = [];

					$scope.noOfProposals = proposalSearchData.length;
					for ( var i = 0; i < proposalSearchData.length; i++)
                                        {
						var proposalStatus;
						var proposalIcon;
						$scope.proposalDetailsTemp = [];
						if (proposalSearchData[i].proposalDetails.proposalReceivedDate != "")
                                                {
								var proposalReceivedformattedDate = convertDateFromISO(proposalSearchData[i].proposalDetails.proposalReceivedDate);
								if (proposalReceivedformattedDate!=0) {
									proposalReceivedformattedDate = $scope.getFormattedDate(proposalReceivedformattedDate.getDate()+"/"+(proposalReceivedformattedDate.getMonth()+1)+"/"+proposalReceivedformattedDate.getFullYear());
								}
								else
								{
									proposalReceivedformattedDate = proposalSearchData[i].proposalDetails.proposalReceivedDate;
								}
								
						}

						else
                                                {
							var proposalReceivedformattedDate = proposalSearchData[i].proposalDetails.proposalReceivedDate;
						}

						if (proposalSearchData[i].proposalDetails.lastUpdateDate != "")
                                                {
							var lastUpdateformattedDate = convertDateFromISO(proposalSearchData[i].proposalDetails.lastUpdateDate);
							if (lastUpdateformattedDate!=0) {
								lastUpdateformattedDate=$scope.getFormattedDate(lastUpdateformattedDate.getDate()+"/"+(lastUpdateformattedDate.getMonth()+1)+"/"+lastUpdateformattedDate.getFullYear());
							}
							else
							{
								lastUpdateformattedDate = proposalSearchData[i].proposalDetails.lastUpdateDate;
							}
							

						}
                                                else
                                                {
							var lastUpdateformattedDate = proposalSearchData[i].proposalDetails.lastUpdateDate;

						}

						if (proposalSearchData[i].proposalDetails.policyIssuedDate != "") {
							
							var policyIssuedformattedDate = convertDateFromISO(proposalSearchData[i].proposalDetails.policyIssuedDate);
							if (policyIssuedformattedDate!=0) {
								policyIssuedformattedDate=$scope.getFormattedDate(policyIssuedformattedDate.getDate()+"/"+(policyIssuedformattedDate.getMonth()+1)+"/"+policyIssuedformattedDate.getFullYear());
							}
							else
							{
								policyIssuedformattedDate = proposalSearchData[i].proposalDetails.policyIssuedDate;
							}
							
						}

						else {
							var policyIssuedformattedDate = proposalSearchData[i].proposalDetails.policyIssuedDate;
						}
						$scope.proposalDetailsTemp
								.push({
									key : translateMessages($translate, "proposalSearch.proposarNameText"),
									value : proposalSearchData[i].proposalDetails.proposerName});
						$scope.proposalDetailsTemp
								.push({
									key : translateMessages($translate, "proposalSearch.planNameText"),
									value : proposalSearchData[i].proposalDetails.planName});
						$scope.proposalDetailsTemp
								.push({
									key : translateMessages($translate, "proposalSearch.premiumAmount"),
									value : proposalSearchData[i].proposalDetails.premiumAmount,
									isRupeeShow : true
								});
						$scope.proposalDetailsTemp
								.push({
									key : translateMessages($translate, "proposalSearch.grossAmountText"),
									value : proposalSearchData[i].proposalDetails.grossAmount,
									isRupeeShow : true
								});
						$scope.proposalDetailsTemp.push({
							key : translateMessages($translate, "proposalSearch.proposalReceivedDate"),
							value : proposalReceivedformattedDate
						});
						$scope.proposalDetailsTemp.push({
							key : translateMessages($translate, "proposalSearch.lastUpdateDateText"),
							value : lastUpdateformattedDate
						});
						$scope.proposalDetailsTemp
								.push({
									key : translateMessages($translate, "proposalSearch.status"),
									value : proposalSearchData[i].proposalDetails.status});
						$scope.proposalDetailsTemp.push({
							key : translateMessages($translate, "proposalSearch.policyIssueDate"),
							value : policyIssuedformattedDate});

						proposalStatus = proposalSearchData[i].proposalDetails.summarystatus;

						switch (proposalStatus) {
						case mServiceConstants.PolicyActiveStatus:
							proposalIcon = "st-completed-large";
							break;
						case mServiceConstants.PolicyGracedStatus:
							proposalIcon = "st-progress-large";
							break;

						}

						$scope.proposalDetails
								.push({
									"header" : proposalSearchData[i].proposalDetails.proposalNumber,
									"data" : $scope.proposalDetailsTemp,
									"statusIcon" : proposalIcon
								});
					}

				}
                                
                                
                                else if (data[0].TransactionData.length == 0)
                                {
                                    $scope.proposalDetails=[];
                                    $scope.validSearch = false;
                                    $scope.alertMessage = translateMessages($translate, "onlineAlertMessage");
                                 }
                                 delete $routeParams.proposalid;
			
		}
                // when data is not defined
               
                else 
                {
                        $scope.proposalDetails=[];
			$scope.validSearch = false;
                        $scope.alertMessage = translateMessages($translate, "onlineAlertMessage");
                }
                
		$scope.transactionSuccess = true;
		showHideLoadingImage(false);
		$scope.refresh();

	}
        
        // display the date in proposal summary with format eg: 28 Aug 2014
	$scope.getFormattedDate = function(inputDate) {
		var dateFormatted;
		var months = [ 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug',
				'Sep', 'Oct', 'Nov', 'Dec' ];
		var pattern = /(.*?)\/(.*?)\/(.*?)$/;
		var result = inputDate.replace(pattern, function(match, p1, p2, p3) {
			dateFormatted = (p1 < 10 ? "0" + p1 : p1) + " " + months[(p2 - 1)]
					+ " " + p3;
		});
		return dateFormatted;
	}

	// reset the search form fields
	$scope.reset = function(proposalSearch) {
		$scope.proposalDetails = [];
		$scope.noOfProposals = 0;
		$scope.errorMessage = [];
                $scope.validSearch = false;
                $scope.isValid = false;
		proposalSearch.proposalNumber = "";
		proposalSearch.planType = "";
		proposalSearch.mobNumber = "";
		proposalSearch.proposalReceivedDate = "";
		$scope.proposalNumberValidationMessage = "";
		$scope.mobileNumberValidationMessage = "";
		$scope.networkValdiationMessage = "";
		proposalSearch.status = "";
		$scope.sortExpression = "Proposal Number";
		$scope.alertMessage="";
		proposalSearch.searchOptions="";
		proposalSearch.inputSearchValue = "";
		proposalSearch.proposalReceivedDate = "";
		$location.url("/customerService/proposalSearch");
	}
        
        // reset search criterias in mobile view
	$scope.resetInputSearchValue = function(proposalSearch) {
		proposalSearch.inputSearchValue = "";
		proposalSearch.proposalReceivedDate = "";
	}
        
        // checking the validations in search criteria
	$scope.validSearchFields = function(proposalSearch) {

		if (proposalSearch.searchOptions) {

			if (proposalSearch.inputSearchValue
					|| proposalSearch.proposalReceivedDate) {
				return true;
			} else {
				return false;
			}
		} else {
			if (proposalSearch.proposalNumber
					|| proposalSearch.proposalReceivedDate
					|| proposalSearch.planType || proposalSearch.status
					|| proposalSearch.mobNumber) {
				return true;
			} else {
				return false;
			}

		}

	}

            // For getting the search results
	$scope.searchProposalDetails = function(proposalSearch)
        {
		var propDate = $scope.proposalSearch.proposalReceivedDate; 
                $scope.noOfProposals = 0;
		$scope.validSearch = false;
		$scope.networkValdiationMessage = "";
                // checking if any of the fields filled as search criteria
		if (!$scope.validSearchFields(proposalSearch))
                {
			$scope.errorMessage = [];
			$scope.errorMessage.push(translateMessages($translate, "proposalSearch.mandatoryFieldsValidationErrorMessgae"));
			$scope.proposalDetails = [];
			$scope.isValid = true;
            	}
                // checking whether the search criteria entered is valid or not
                else
                {
                	if($scope.proposalSearch.proposalReceivedDate){
                		var dateReceived= new Date(changeStringToDate($scope.proposalSearch.proposalReceivedDate,"dd-MM-yyyy"));
                        if ((dateReceived == "Invalid Date") || (dateReceived == "NaN"))
                        {
                        $scope.errorMessage.push(translateMessages($translate, "proposalSearch.receivedDateValidationErrorMessage"));
                        $scope.proposalDetails = [];
                        $scope.isValid = true;
                        }
                        else{
                    		$scope.errorMessage = [];
                            // if no validation error's then proceeding with
							// search response
    			if ($scope.proposalNumberValidationMessage == ""&& $scope.mobileNumberValidationMessage == "")
                            {
                                        $scope.isValid = false;
                                       $scope.validSearch=true;
                                       // taking the date from date picker and
										// making it into dd-MM-yyyy format to
										// give as service request
                     $scope.proposalSearch.proposalReceivedDate = $filter('date')(
    						$scope.proposalSearch.proposalReceivedDate,
    						"dd-MM-yyyy");
    				
    				
    				var transObj = _this.mapScopeToPersistance();

    				var searchObj = {
    					"searchCriteria" : {
    						"proposalNumber" : "",
    						"planType" : "",
    						"mobNumber" : "",
    						"proposalReceivedDate" : "",
    						"status" : ""
    					}
    				}
                                    // setting service search request in mobile
									// view
                                    if(rootConfig.isDeviceMobile){
    				if (proposalSearch.searchOptions) {
    					
    					switch (proposalSearch.searchOptions) {

    					case commonConfig().SEARCH_OPTION.PROPOSAL_NUMBER:
    						searchObj.searchCriteria.proposalNumber = ($scope.proposalSearch.inputSearchValue)
    								.toString();
    						break;
    					case commonConfig().SEARCH_OPTION.PLAN_TYPE:

    						searchObj.searchCriteria.planType = $scope.proposalSearch.inputSearchValue;
    						break;

    					case commonConfig().SEARCH_OPTION.MOBILE_NUMBER:
    						searchObj.searchCriteria.mobNumber = $scope.proposalSearch.inputSearchValue;
    						break;

    					case commonConfig().SEARCH_OPTION.PROPOSAL_RECEIVED_DATE: {
    						searchObj.searchCriteria.proposalReceivedDate = proposalSearch.proposalReceivedDate;
    					}
    						break;

    					case commonConfig().SEARCH_OPTION.STATUS:
    						searchObj.searchCriteria.status = $scope.proposalSearch.inputSearchValue;
    						break;
    					}
    					
    					                 

    				}else{
    					if ($scope.proposalSearch.status == null) {
    						$scope.proposalSearch.status="";
    					}
    					if ($scope.proposalSearch.planType == null) {
    						$scope.proposalSearch.planType="";
    					}
    					searchObj.searchCriteria.proposalNumber = ($scope.proposalSearch.proposalNumber).toString();
    					searchObj.searchCriteria.planType = $scope.proposalSearch.planType;
    					searchObj.searchCriteria.mobNumber = $scope.proposalSearch.mobNumber;
    					searchObj.searchCriteria.proposalReceivedDate = $scope.proposalSearch.proposalReceivedDate;
    					searchObj.searchCriteria.status = $scope.proposalSearch.status;
                                            
    				
    				}
                                    }
                                    // setting service search request in desktop
									// and tab views
                                    else
                                    {
    					if ($scope.proposalSearch.status == null) {
    						$scope.proposalSearch.status="";
    					}
    					if ($scope.proposalSearch.planType == null) {
    						$scope.proposalSearch.planType="";
    					}
    					searchObj.searchCriteria.proposalNumber = ($scope.proposalSearch.proposalNumber).toString();
    					searchObj.searchCriteria.planType = $scope.proposalSearch.planType;
    					searchObj.searchCriteria.mobNumber = $scope.proposalSearch.mobNumber;
    					searchObj.searchCriteria.proposalReceivedDate = $scope.proposalSearch.proposalReceivedDate;
    					searchObj.searchCriteria.status = $scope.proposalSearch.status;
    					 
                                            
    				}

    				transObj.TransactionData = searchObj;
    				// setting loading image according to the browser
    				if (navigator.userAgent.search(commonConfig().SEARCH_OPTION.MSIE) >= 0)
                                    {
    					showHideLoadingImage(true,
    							"Loading Proposal Search Details");
    				}
                                    else
                                    {
    					showHideLoadingImage(true, "loadingProposalSearch",
    							$translate);
    				}
                                    
                                    // checking whether the device in which app
									// running is mobile/Tab and checking
									// network connection
    				if (rootConfig.isDeviceMobile)
                                    {
    					if (navigator.network.connection.type == Connection.NONE)
                                            {
    						showHideLoadingImage(false);
    						$scope.validSearch = false;
    						$scope.networkValdiationMessage = translateMessages($translate, "networkValidationErrorMessage");
    						$scope.showNetworkMessage = true;
    					}
                                            else
                                            {
                                                    $scope.validSearch = true;
    						dataService.searchTransactions(transObj,$scope.getTransationSuccess,$scope.getTransationError);
    						$scope.showNetworkMessage = false;
    					}
    				}
                                    // calling the service if device is not
									// mobile
                                    else
                                    {
                                            $scope.validSearch = true;
    					dataService.searchTransactions(transObj,$scope.getTransationSuccess,$scope.getTransationError);
    					$scope.showNetworkMessage = false;
                                    }
                            }
                            // if any validation error is found
                            else
                            {
                                    $scope.errorMessage.push($scope.proposalNumberValidationMessage);
    				$scope.errorMessage.push($scope.mobileNumberValidationMessage);
    				$scope.proposalDetails = [];
    				$scope.isValid = true;
                                    $scope.validSearch = false;
    			}

    		}
                        }
                	else{
                		$scope.errorMessage = [];
                        // if no validation error's then proceeding with search
						// response
			if ($scope.proposalNumberValidationMessage == ""&& $scope.mobileNumberValidationMessage == "")
                        {
                                    $scope.isValid = false;
                                   $scope.validSearch=true;
                                   // taking the date from date picker and
									// making it into dd-MM-yyyy format to give
									// as service request
                 $scope.proposalSearch.proposalReceivedDate = $filter('date')(
						$scope.proposalSearch.proposalReceivedDate,
						"dd-MM-yyyy");
				
				
				var transObj = _this.mapScopeToPersistance();

				var searchObj = {
					"searchCriteria" : {
						"proposalNumber" : "",
						"planType" : "",
						"mobNumber" : "",
						"proposalReceivedDate" : "",
						"status" : ""
					}
				}
                                // setting service search request in mobile view
                                if(rootConfig.isDeviceMobile){
				if (proposalSearch.searchOptions) {
					
					switch (proposalSearch.searchOptions) {

					case "Proposal Number":
						searchObj.searchCriteria.proposalNumber = ($scope.proposalSearch.inputSearchValue)
								.toString();
						break;
					case "Plan Type":

						searchObj.searchCriteria.planType = $scope.proposalSearch.inputSearchValue;
						break;

					case "Mobile Number":
						searchObj.searchCriteria.mobNumber = $scope.proposalSearch.inputSearchValue;
						break;

					case "Proposal Received Date": {
						searchObj.searchCriteria.proposalReceivedDate = proposalSearch.proposalReceivedDate;
					}
						break;

					case "Status":
						searchObj.searchCriteria.status = $scope.proposalSearch.inputSearchValue;
						break;
					}
					
					                 

				}else{
					if ($scope.proposalSearch.status == null) {
						$scope.proposalSearch.status="";
					}
					if ($scope.proposalSearch.planType == null) {
						$scope.proposalSearch.planType="";
					}
					searchObj.searchCriteria.proposalNumber = ($scope.proposalSearch.proposalNumber).toString();
					searchObj.searchCriteria.planType = $scope.proposalSearch.planType;
					searchObj.searchCriteria.mobNumber = $scope.proposalSearch.mobNumber;
					searchObj.searchCriteria.proposalReceivedDate = $scope.proposalSearch.proposalReceivedDate;
					searchObj.searchCriteria.status = $scope.proposalSearch.status;
                                        
				
				}
                                }
                                // setting service search request in desktop and
								// tab views
                                else
                                {
					if ($scope.proposalSearch.status == null) {
						$scope.proposalSearch.status="";
					}
					if ($scope.proposalSearch.planType == null) {
						$scope.proposalSearch.planType="";
					}
					searchObj.searchCriteria.proposalNumber = ($scope.proposalSearch.proposalNumber).toString();
					searchObj.searchCriteria.planType = $scope.proposalSearch.planType;
					searchObj.searchCriteria.mobNumber = $scope.proposalSearch.mobNumber;
					searchObj.searchCriteria.proposalReceivedDate = $scope.proposalSearch.proposalReceivedDate;
					searchObj.searchCriteria.status = $scope.proposalSearch.status;
					 
                                        
				}

				transObj.TransactionData = searchObj;
				// setting loading image according to the browser
				if (navigator.userAgent.search(commonConfig().SEARCH_OPTION.MSIE) >= 0)
                                {
					showHideLoadingImage(true,
							"Loading Proposal Search Details");
				}
                                else
                                {
					showHideLoadingImage(true, "loadingProposalSearch",
							$translate);
				}
                                
                                // checking whether the device in which app
								// running is mobile/Tab and checking network
								// connection
				if (rootConfig.isDeviceMobile)
                                {
					if (navigator.network.connection.type == Connection.NONE)
                                        {
						showHideLoadingImage(false);
						$scope.validSearch = false;
						$scope.networkValdiationMessage = translateMessages($translate, "networkValidationErrorMessage");
						$scope.showNetworkMessage = true;
					}
                                        else
                                        {
                                                $scope.validSearch = true;
						dataService.searchTransactions(transObj,$scope.getTransationSuccess,$scope.getTransationError);
						$scope.showNetworkMessage = false;
					}
				}
                                // calling the service if device is not mobile
                                else
                                {
                                        $scope.validSearch = true;
					dataService.searchTransactions(transObj,$scope.getTransationSuccess,$scope.getTransationError);
					$scope.showNetworkMessage = false;
                                }
                        }
                        // if any validation error is found
                        else
                        {
                                $scope.errorMessage.push($scope.proposalNumberValidationMessage);
				$scope.errorMessage.push($scope.mobileNumberValidationMessage);
				$scope.proposalDetails = [];
				$scope.isValid = true;
                                $scope.validSearch = false;
			}

		}
                	}
                
                	
	
                	
	
                // setting the date into date picker format
		
		$scope.proposalSearch.proposalReceivedDate = propDate;
	}
        // sorting the search service response according to sort field selected
	$scope.mySortFunction = function(item) {
		if ($scope.sortExpression == translateMessages($translate, "proposalSearch.proposalNumberHeader")) {
			return ($scope.getSortedData(item.header, $scope.sortExpression));

		} else if ($scope.sortExpression == translateMessages($translate, "proposalSearch.premiumAmount")) {
			return ($scope.getSortedData(item.data[2], $scope.sortExpression));

		} else if ($scope.sortExpression == translateMessages($translate, "proposalSearch.proposalReceivedDate")) {
			return ($scope.getSortedData(item.data[4], $scope.sortExpression));
		} else if ($scope.sortExpression == translateMessages($translate, "proposalSearch.policyIssueDate")) {
			return ($scope.getSortedData(item.data[7], $scope.sortExpression));
		}

	}

	$scope.getSortedData = function(data, sortExpression) {
		if (sortExpression == translateMessages($translate, "proposalSearch.proposalReceivedDate")) {
			
			if(data.value != ""){
				return new Date(data.value);
			}
			else{
				return data.value;
			}
		} else if (sortExpression == translateMessages($translate, "proposalSearch.policyIssueDate")) {
			
			if(data.value != ""){
				return new Date(data.value);
			}
			else{
				return data.value;
			}
		} else if (isNaN(data)) {
			if (sortExpression == translateMessages($translate, "proposalSearch.premiumAmount")) {
				if(data.value != ""){
					return parseFloat((data.value) ? (data.value).replace(/,/g, ""):(data.value))
				}
				else{
					return data.value;
				}
			} else {
				return data
			}

		} else {
			return parseInt(data)
		}
	}

            // Getting the details for pending requirement icon
	$scope.getPendingRequirements = function(proposalNumber) {
		
		var proposalSearchData = appDataShareService.json.ProposalSearch;
		$scope.proposalNumber = proposalNumber;
		$scope.pendingRequirementsDetails = [];
		$scope.pendingDetails = [];
		for ( var i = 0; i < proposalSearchData.length; i++) {
			if (proposalSearchData[i].proposalDetails.proposalNumber == proposalNumber) {
				$scope.pendingRequirementsDetails = angular.copy(proposalSearchData[i].proposalInfo.pendingRequirements);
		            
				for(var j = 0  ; j < $scope.pendingRequirementsDetails.length; j++){
					
					if ($scope.pendingRequirementsDetails[j].orderedDate)
					{
						$scope.pendingRequirementsDetails[j].orderedDate = convertDateFromISO($scope.pendingRequirementsDetails[j].orderedDate);
					}
					
				}
				$scope.pendingDetails.push({
					requirements : $scope.pendingRequirementsDetails
				});
				$scope.$apply();
			}
		}
		$scope.pendingRequirementsHeaders = [ "Requirement Name",
				"Requirement Status", "Ordered Date" ];
	}
	
	$scope.paintUISuccess = function(callbackId, data) {
		// call this getTransaction after paintUI complete
		
		$scope.isPainted = true;
	}
	$scope.onPartialLoaded = function(element, scope) {
		// call the paint UI with "scope.item.subType" as view name and define
		// this view in alerts-ui-json
		
		LEDynamicUI.paintUI(rootConfig.template, "proposalsearch-ui-json.json",
				"pendingRequirements", element, true, $scope.paintUISuccess,
				scope, $compile);
	}
            // Getting the details for proposal info icon
	$scope.getProposalInfo = function(proposalNumber) {
		$scope.proposalNumber = proposalNumber;
		var proposalSearchData = appDataShareService.json.ProposalSearch;
		for ( var i = 0; i < proposalSearchData.length; i++) {
			if (proposalSearchData[i].proposalDetails.proposalNumber == proposalNumber) {
				$scope.proposalInfoTemp = [];
				$scope.proposalInfoTemp.push({
					key : translateMessages($translate, "proposalSearch.riderDetailsText"),
					value : proposalSearchData[i].proposalInfo.riderDetails
				});
				$scope.proposalInfoTemp.push({
					key : translateMessages($translate, "proposalSearch.sumAssured"),
					value : proposalSearchData[i].proposalInfo.sumAssured,
					isRupeeShow : true
				});
				$scope.proposalInfoTemp.push({
					key : translateMessages($translate, "proposalSearch.modalPremium"),
					value : proposalSearchData[i].proposalInfo.modalPremium,
					isRupeeShow : true
				});
				$scope.proposalInfoTemp.push({
					key : translateMessages($translate, "proposalSearch.lifeInsuredNameText"),
					value : proposalSearchData[i].proposalInfo.lifeInsuredName
				});
				$scope.proposalInfoTemp.push({
					key : translateMessages($translate, "proposalSearch.caseStatusText"),
					value : proposalSearchData[i].proposalInfo.caseStatus
				});
				$scope.proposalInfoTemp.push({
					key : translateMessages($translate, "proposalSearch.workItemText"),
					value : proposalSearchData[i].proposalInfo.workItem
				});
				$scope.proposalInfoTemp.push({
					key : translateMessages($translate, "proposalSearch.actionableText"),
					value : proposalSearchData[i].proposalInfo.actionable
				});

			}
		}

	}
            // Getting the details for contact info icon
	$scope.getContactInfo = function(proposalNumber) {
		$scope.proposalNumber = proposalNumber;
		var proposalSearchData = appDataShareService.json.ProposalSearch;
		for ( var i = 0; i < proposalSearchData.length; i++) {
			if (proposalSearchData[i].proposalDetails.proposalNumber == proposalNumber) {
				$scope.contactInfoTemp = [];
				
				$scope.contactInfoMobileNumber =  (proposalSearchData[i].proposalDetails.mobNo.toString()).replace(/","/g , ",");
				$scope.contactInfoPhoneNumber =  (proposalSearchData[i].proposalDetails.phoneNo.toString()).replace(/","/g , ",");
				
				$scope.contactInfoTemp
						.push({
							key : translateMessages($translate, "proposalSearch.nameText"),
							value : [ proposalSearchData[i].proposalDetails.proposerName ]
						});
				$scope.contactInfoTemp.push({
					key : translateMessages($translate, "proposalSearch.mobileText"),
					value : $scope.contactInfoMobileNumber.split(",")
				});
				$scope.contactInfoTemp.push({
					key : translateMessages($translate, "proposalSearch.emailText"),
					value : [ proposalSearchData[i].proposalDetails.emailID ]
				});
				$scope.contactInfoTemp.push({
					key : translateMessages($translate, "proposalSearch.phoneText"),
					value : $scope.contactInfoPhoneNumber.split(",")
				});
				$scope.contactInfoTemp
						.push({
							key : translateMessages($translate, "proposalSearch.mailingText"),
							value : proposalSearchData[i].proposalDetails.preferredMailingAddress
									.split(",")
						});
			}
		}

	}

            // refresh app for master datas used-Plan type and Proposal status
	if (appDataShareService.refreshApp
			|| (!(appDataShareService.proposalStatusJson
					.hasOwnProperty('proposalStatus')))
			|| (!(appDataShareService.planTypeJson.hasOwnProperty('planType'))))
            {

		appDataShareService.proposalSearchJson = {};
		// call get transaction and reload data
		var transactionObj = _this.mapScopeToPersistance();
		transactionObj.Type = commonConfig().TRANSACTION_TYPE.PLAN_TYPE;
		transactionObj.Key1 =  appDataShareService.selectedUser.userId;
		_this.getTransactions($scope.getTransationSuccessPlanType,
				$scope.getTransationError, transactionObj);

		var transactionObj = _this.mapScopeToPersistance();
		transactionObj.Type = commonConfig().TRANSACTION_TYPE.PROPOSAL_STATUS;
		transactionObj.Key1 =  appDataShareService.selectedUser.userId;
		_this.getTransactions($scope.getTransationSuccessProposalStatus,
				$scope.getTransationError, transactionObj);	

		 if(!rootConfig.isDeviceMobile){
			 if (navigator.userAgent.search(commonConfig().SEARCH_OPTION.MSIE) >= 0) {
					showHideLoadingImage(true, "Loading Proposal Search");
				} else {
					showHideLoadingImage(true, "loadingProposalSearchPage", $translate);
				} 
		 }
		
		appDataShareService.refreshApp = false;

	}
}]);