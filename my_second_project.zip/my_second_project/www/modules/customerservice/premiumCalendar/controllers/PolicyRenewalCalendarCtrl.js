mServiceApp.controller('PolicyRenewalCalendarCtrl',['$controller','$rootScope', '$scope',  '$compile', '$route', '$routeParams', '$location', '$translate','dataService','appDataShareService','AutoSync','debounce','$timeout','$filter','commonConfig','customerServiceConfig',function($controller ,$rootScope, $scope,  $compile, $route, $routeParams, $location, $translate,dataService,appDataShareService,AutoSync,debounce,$timeout,$filter,commonConfig,customerServiceConfig) {   	
	
	
	$rootScope.serviceFailed=false;
	var userDetails={};
	userDetails.currentUrl=$location.path();
	userDetails.userId=appDataShareService.selectedUser.userId;
	userDetails.userName=appDataShareService.selectedUser.name;
	var logedin = [];
	logedin.push(userDetails);
	sessionStorage.setItem('currentUser',JSON.stringify(logedin));
	if (rootConfig.autoSync && ($rootScope.isAutoSyncCompleted)) {
		   
	   	AutoSync.SyncData(dataService,$rootScope,appDataShareService,debounce,$scope,$timeout);
	}   
	
	$scope.selectedpage = commonConfig().PAGE_NAME.CUSTOMER_SERVICE;
	$scope.subModule = customerServiceConfig().SUB_MODULE.PREMIUM_CALENDER;
           
        if (navigator.userAgent.search(commonConfig().SEARCH_OPTION.MSIE) >= 0)
                {
                showHideLoadingImage(true, "Refreshing Premium Calender"); 
                }
                else
                {
        showHideLoadingImage(true, "loadingPremiumCalendar", $translate);
                }
                
	$scope.globalConfig = {
	           isPaginationEnabled: true,         
	           itemsByPage: 10
	   };
           $scope.premiumExcelTempData= [];
           //$scope.premiumExcelData= [];
        $scope.calendarData=[];
	$scope.calendarDisplayData=[];
	$scope.displayData=[];
	var today=new Date();
	var monthIndex=0;
	var monthArrayIndex=0;
	var yearIndex=0;
	$scope.month=[];
	var flag=0;
	$scope.alertMessage;
	$scope.dataEmpty = false;
	$scope.currDate=new Date();
	var displayMonths=[];
	$scope.pos=0;
	var tempMonthIndex;
	var monthArray = [ "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul",
				"Aug", "Sep", "Oct", "Nov", "Dec" ];
	
	//$scope.monthShown=getMonthName($scope.currDate.getMonth());
	//$scope.monthNum=getMonthNumber($scope.monthShown);
	$scope.year=$scope.currDate.getFullYear();
        var yearArray=[$scope.year,$scope.year+1,$scope.year+2];
	for (var i=0;i<monthArray.length;i++) {
		if (getMonthName($scope.currDate.getMonth())==monthArray[i]) {
			monthIndex=i;
			monthArrayIndex=i;
			tempMonthIndex =i;
			break;
		}
	}
	
	if (tempMonthIndex==0) {
	    displayMonths.push(($scope.year-1).toString()+"_"+"Dec");	
	}
	else{
	    displayMonths.push(($scope.year).toString()+"_"+(monthArray[tempMonthIndex-1]).toString());	
	}
	
	var tempYear=$scope.year;
	for (var i=0;i<=10;i++) {
	    displayMonths.push(tempYear.toString()+"_"+(monthArray[tempMonthIndex]).toString());
	    tempMonthIndex++;
	    if (tempMonthIndex>11) {
		tempMonthIndex=0;
		tempYear = $scope.year+1;
	    }
	}

	for (var i=0;i<yearArray.length;i++) {
		if ($scope.year==yearArray[i]) {
			yearIndex=i;
		}
	}
	$scope.pos=0;

        $scope.getTransationSuccess = function(data) {

        	 if(data[0] != undefined)
 			{
		appDataShareService.json = {};
		var premiumCalendarDetails = [];
		premiumCalendarDetails = data[0].TransactionData;
		appDataShareService.json = {
			'premiumCalendar' : premiumCalendarDetails
		};
		$scope.transactionSuccess = true;
		$scope.setCalData();
		$scope.refresh();
                showHideLoadingImage(false);
 			}
        	 else{
        		 showHideLoadingImage(false);
        		 if(appDataShareService.selectedUser.userId != $rootScope.IntialloggedInUser){			  
 					if (rootConfig.isDeviceMobile){
 						
 						if (navigator.network.connection.type == Connection.NONE) {
 							$scope.dataEmpty = true;
 							$scope.alertMessage = translateMessages($translate, "alerts.offlineAlertMessage");
 						}
 						else{
 							$rootScope.$broadcast(commonConfig().STATUS.IS_DEVICE_ONLINE);
 						}
 						
 						
 					}
 						
 					else{
 						$scope.dataEmpty = true;
 						$scope.alertMessage = translateMessages($translate, "alerts.onlineAlertMessage");
 					}
 		  }	
   			   } 
        	 
	}
        
        $scope.downLoad =  function(data,filename)
    {
        
        if(/iPhone|iPad|iPod/i.test(navigator.userAgent))
        {
            var formattedData = $scope.formatDataForExcelDownload(data);
            var downloadIdentify = filename;
            var downloadData = [];
            downloadData.push(downloadIdentify, formattedData);
            dataService.exportDataToExcel(downloadData, $scope.getTransationDownloadSuccess, $scope.getTransationError);
            
        }
        else if(/Android/i.test(navigator.userAgent))
        {
            $scope.premiumExcelTempData = data;
            var header=[];
            $scope.premiumExcelData= [];
            header = $scope.getHeader($scope.premiumExcelTempData[0]);
            var premiumValues = $scope.getValues($scope.premiumExcelTempData);
            $scope.premiumExcelData.push({key:filename,value:premiumValues,header:header,module:'Premium Calendar'});
            dataService.exportDataToExcel($scope.premiumExcelData,$scope.getTransationDownloadSuccess,$scope.getTransationError);
            
        }
        
        
    }
    $scope.formatDataForExcelDownload = function(inputData)
    {
        var keyArray = [];
        var flag=0;
        
        
        for (var index in inputData[0]) {
            delete inputData[0].$$hashKey;
            keyArray.push(index);
        }
        
        
        for (var i = 0; i < inputData.length; i++)
        {
            
            flag=1;
            for (var index in inputData[i])
            {
                
                if(flag==1)
                {
                    var str = "\n"+inputData[i].policyNumber;
                    flag=0;
                    keyArray.push(str);
                }
                else{
                    if((inputData[i][index].toString()).indexOf(',') )
                    {
                        if (index==commonConfig().DATE_TYPE.LAST_PAYMENT_DATE) {
                            inputData[i][index] = ' '+$filter('date')(inputData[i][index], "dd-MM-yyyy");
                        }
                        
                        keyArray.push((inputData[i][index].toString()).replace(/,/g," "));
                    }
                    else
                    {
                        keyArray.push(inputData[i][index]);
                    }
                }
                
            }
           // console.log("keyArray=="+angular.toJson(keyArray));
        }
        return keyArray;
        
    }
    
	$scope.getTransationDownloadSuccess =  function(message){
        if(/iPhone|iPad|iPod/i.test(navigator.userAgent))
        {
            var messageTemp = message.split(" ");
            if(messageTemp[0] == "SUCCESS"){
                $('#alertDownloadModel').modal('show');
            }
            
            $scope.downloadMessage = translateMessages($translate, "excelDownloadSuccessfullMessage");
            $scope.filePath = translateMessages($translate, "fileDownloadSuccessfullMessage");//"Path"+" : "+messageTemp[1];
            
            $scope.refresh();
        }
        else if(/Android/i.test(navigator.userAgent))
        {
            var messageTemp = message.split("%");
            if(messageTemp[0] == "SUCCESS"){
                $scope.downloadMessage = translateMessages($translate, "excelDownloadSuccessfullMessage");
                $scope.filePath = "Path"+" : "+messageTemp[1];
				      $scope.refresh();
                $('#alertDownloadModel').modal('show');
            }
        }
	}
        $scope.paintUISuccess = function(callbackId, data) {
		$scope.isPainted = true;
	}
	
        $scope.onPartialLoaded = function(element, scope,viewID) {
		// call the paint UI with "scope.item.subType" as view name and define
		// this view in alerts-ui-json
		LEDynamicUI.paintUI(rootConfig.template, "premiumcalendar-ui-json.json",
				viewID, element, true, $scope.paintUISuccess,
				scope, $compile);	
	}
        $scope.getTransationError = function(data) {
      $rootScope.serviceFailed=true;
		if (rootConfig.isDeviceMobile && !checkConnection()) {
			$scope.message = translateMessages($translate, "networkValidationErrorMessage");
		}else{
			$scope.message = translateMessages($translate, "validToken");
		}	
	  $scope.$emit('tokenEvent', { message: $scope.message });	
	  
		if (data == "Error in ajax callE")
                                      {
                                          
                                          $scope.onServerError=true;
                                          $scope.serverErrorMessage= translateMessages($translate, "serverErrorMessage");
                                         showHideLoadingImage(false);
                                      }
                                      else
                                      {
					showHideLoadingImage(false);
                                      }
		$rootScope.$apply();							  
	}
        
        
    	$scope.setCalData=function(){
		if(typeof(appDataShareService.json.premiumCalendar) != 'undefined')
		{
			var today=new Date();
			$scope.calendarData=setCalendarData(appDataShareService.json.premiumCalendar.premiumCalendar);

			$scope.ytd=appDataShareService.json.premiumCalendar.premiumCalendar[0].ytd;
			if($scope.calendarData.length==0)
			{
				$scope.backDisable=true;
				$scope.frontDisable=true;
			}
			else {
			$scope.displayPos = $scope.calendarData.length-1;
			}
			
			loopYear: for (var j=0;j<yearArray.length;j++) {
				loopMonth: for (var k=monthIndex;k<monthArray.length;k++)
				{
					loopData: for(var i=0;i<$scope.calendarData.length;i++)
					{
						$scope.calendarData[i].month=capitaliseFirstLetter($scope.calendarData[i].month);
						if($scope.calendarData[i].month==monthArray[k]&&yearArray[j]==$scope.calendarData[i].year)
						{
							//$scope.calendarDisplayData.push($scope.calendarData[i]);
							$scope.year=$scope.calendarData[i].year;
							$scope.monthShown=$scope.calendarData[i].month;
							$scope.monthNum=getMonthNumber($scope.monthShown);
							$scope.mtd=$scope.calendarData[i].mtd;
							$scope.pos=i;
							$scope.activeDue=$scope.calendarData[i].activeDue;
							$scope.graceDue=$scope.calendarData[i].graceDue;
							$scope.premiumDue=$scope.calendarData[i].premiumDue;
							$scope.lapsedDue=$scope.calendarData[i].lapsedDue;
							$scope.lapsedDueAfter=$scope.calendarData[i].lapsedDueAfter;
							$scope.setDaysData($scope.pos);
							break loopYear;
						}
					}
				}
				monthIndex=0;
			}
			
			if (monthArrayIndex==0) {
				monthArrayIndex=12;
				yearArray[yearIndex]=yearArray[yearIndex]-1;
			}
			if ($scope.calendarData[$scope.pos-1] && $scope.calendarData[$scope.pos-1].month==monthArray[monthArrayIndex-1]&&$scope.calendarData[$scope.pos-1].year==yearArray[yearIndex]) {
				
				$scope.calendarDisplayData.push($scope.calendarData[$scope.pos-1]);
				$scope.displayPos = 1;
			}
			$scope.calendarDisplayData.push($scope.calendarData[$scope.pos]);
			for (var i=1;i<11;i++) {
				if($scope.calendarData[$scope.pos+i]!=undefined){
				var displayIndex=$scope.calendarData[$scope.pos+i].year.toString()+"_"+$scope.calendarData[$scope.pos+i].month;
				for (var j=0;j<displayMonths.length;j++) {
					if (displayIndex==displayMonths[j]) {
						$scope.calendarDisplayData.push($scope.calendarData[$scope.pos+i]);	
					}
				}
			}
			}
			
			if($scope.pos==0)
			{
				$scope.pos=$scope.calendarData.length-1;
				$scope.monthShown=$scope.calendarData[$scope.pos].month;
				$scope.activeDue=$scope.calendarData[$scope.pos].activeDue;
				$scope.graceDue=$scope.calendarData[$scope.pos].graceDue;
				$scope.premiumDue=$scope.calendarData[$scope.pos].premiumDue;
				$scope.lapsedDue=$scope.calendarData[$scope.pos].lapsedDue;
				$scope.lapsedDueAfter=$scope.calendarData[$scope.pos].lapsedDueAfter;
				$scope.setDaysData($scope.pos);
			}
			
			

		}
        }
	
	$scope.setDaysData=function(index){
		
		if($scope.calendarData[index].days != undefined){
			for(var l=0;l<$scope.calendarData[index].days.length;l++){   				
				if ($scope.calendarData[index].days[l].dayNumber==today.getDate()){
					$scope.displayData.push({month:$scope.calendarData[index].month,year:$scope.calendarData[index].year,acc:$scope.calendarData[index].days[l].active.length,lcc:$scope.calendarData[index].days[l].lapsed.length,gcc:$scope.calendarData[index].days[l].grace.length,day:$scope.calendarData[index].days[l].dayName,date:$scope.calendarData[index].days[l].dayNumber,activeData:$scope.calendarData[index].days[l].active,graceData:$scope.calendarData[index].days[l].grace,lapsedData:$scope.calendarData[index].days[l].lapsed})
				}
				else{
					$scope.displayData.push({month:$scope.calendarData[index].month,year:$scope.calendarData[index].year,acc:$scope.calendarData[index].days[l].active.length,lcc:$scope.calendarData[index].days[l].lapsed.length,gcc:'',day:$scope.calendarData[index].days[l].dayName,date:$scope.calendarData[index].days[l].dayNumber,activeData:$scope.calendarData[index].days[l].active,graceData:$scope.calendarData[index].days[l].grace,lapsedData:$scope.calendarData[index].days[l].lapsed})
				}
				 
			}
		}
		
		if ($scope.pos==$scope.calendarData.length-1)
		{
			$scope.frontDisable=true;
		}
		else if ($scope.pos==0 ||$scope.displayData.length==0 )
		{
			$scope.backDisable=true;
		}
		
		
	}

	$scope.initialize = function(){

	// angular.extend(this, new BaseCtrl($scope, $rootScope, dataService,
    		//	'PremiumCalendar', appDataShareService.selectedUser.userId));
          	angular.extend(this, $controller('BaseCtrl',{$scope:$scope, $rootScope:$rootScope, dataService:dataService, type:'PremiumCalendar', userId:appDataShareService.selectedUser.userId}));

		  if (appDataShareService.refreshApp || (!(appDataShareService.json.hasOwnProperty('PremiumCalendar')))) {
        		appDataShareService.json = {};
        		// call get transaction and reload data
        		this.getTransactions($scope.getTransationSuccess, $scope.getTransationError);
        		appDataShareService.refreshApp = false;
        	} else {
        		//showHideLoadingImage(false);
        	}
	}
	$scope.$on('$viewContentLoaded', function(){
			//$scope.initialize();
          });
        


	
	$scope.front=function(){
		if ($scope.displayPos<$scope.calendarData.length-1) {
			$scope.displayPos=$scope.displayPos+1;
			$scope.monthShown=capitaliseFirstLetter($scope.calendarData[$scope.displayPos].month);
			$scope.monthNum=getMonthNumber($scope.calendarData[$scope.displayPos].month);
			$scope.year=$scope.calendarData[$scope.displayPos].year;
			$scope.activeDue=$scope.calendarData[$scope.displayPos].activeDue;
			$scope.graceDue=$scope.calendarData[$scope.displayPos].graceDue;
			$scope.premiumDue=$scope.calendarData[$scope.displayPos].premiumDue;
			$scope.lapsedDue=$scope.calendarData[$scope.displayPos].lapsedDue;
			$scope.lapsedDueAfter=$scope.calendarData[$scope.displayPos].lapsedDueAfter;
			$scope.displayData=[];
			$scope.setDaysData($scope.displayPos);
			$scope.backDisable=false;
			if ($scope.displayPos==$scope.calendarData.length-1) {
				$scope.frontDisable=true;
			}
		}	
	}
	
        $scope.back=function(){
		if ($scope.displayPos>0) {
			$scope.displayPos=$scope.displayPos-1;	      
			$scope.monthNum=getMonthNumber($scope.calendarData[$scope.displayPos].month);
			$scope.monthShown=capitaliseFirstLetter(getMonthName($scope.monthNum));
			$scope.activeDue=$scope.calendarData[$scope.displayPos].activeDue;
			$scope.year=$scope.calendarData[$scope.displayPos].year;
			$scope.graceDue=$scope.calendarData[$scope.displayPos].graceDue;
			$scope.premiumDue=$scope.calendarData[$scope.displayPos].premiumDue;
			$scope.lapsedDue=$scope.calendarData[$scope.displayPos].lapsedDue;
			$scope.lapsedDueAfter=$scope.calendarData[$scope.displayPos].lapsedDueAfter;
			$scope.displayData=[];
			$scope.setDaysData($scope.displayPos);
			$scope.frontDisable=false;
		}	
		if ($scope.displayPos==0) {
				$scope.backDisable=true;
			}
        }
	
           $scope.getStatusDetails=function(data,filter){
		var today=new Date();
		$scope.showDate=true;
		$scope.selectedFilter=filter;
		$scope.activeData=[];
		$scope.graceData=[];
		$scope.lapsedData=[];
		$scope.date=data.date;
		var monthNum=getMonthNumber(data.month);
		if ($scope.date==today.getDate()) {
			$scope.showTabGrace=true;

		}
		else{
			$scope.showTabGrace=false;
			$scope.showTabLapsed=false
		}
		$scope.year=data.year;
		
		
		$scope.activeDataTemp=angular.copy(data.activeData);
		for (var f=0;f<$scope.activeDataTemp.length;f++)
		{
			if ($scope.activeDataTemp[f].ctpAmount) {
				$scope.activeDataTemp[f].ctpAmount=getIntegerFromString($scope.activeDataTemp[f].ctpAmount);
			}
			if ($scope.activeDataTemp[f].grossAmount) {
				$scope.activeDataTemp[f].grossAmount=getIntegerFromString($scope.activeDataTemp[f].grossAmount);
			}
			if ($scope.activeDataTemp[f].lastPaymentDate) {
				$scope.activeDataTemp[f].lastPaymentDate=convertDateFromISO($scope.activeDataTemp[f].lastPaymentDate);
			}
			/*if ($scope.activeDataTemp[f].lastPaymentInstrument) {
				$scope.activeDataTemp[f].lastPaymentInstrument=getIntegerFromString($scope.activeDataTemp[f].lastPaymentInstrument);
			}*/
		}
		$scope.graceDataTemp=angular.copy(data.graceData);
		for (var f=0;f<$scope.graceDataTemp.length;f++)
		{
			if ($scope.graceDataTemp[f].ctpAmount) {
				$scope.graceDataTemp[f].ctpAmount=getIntegerFromString($scope.graceDataTemp[f].ctpAmount);
			}
			if ($scope.graceDataTemp[f].grossAmount) {
				$scope.graceDataTemp[f].grossAmount=getIntegerFromString($scope.graceDataTemp[f].grossAmount);
			}
			if ($scope.graceDataTemp[f].lastPaymentDate) {
				$scope.graceDataTemp[f].lastPaymentDate=convertDateFromISO($scope.graceDataTemp[f].lastPaymentDate);
			}
			/*if ($scope.graceDataTemp[f].lastPaymentInstrument) {
				$scope.graceDataTemp[f].lastPaymentInstrument=getIntegerFromString($scope.graceDataTemp[f].lastPaymentInstrument);
			}*/
		}
		$scope.lapsedDataTemp=angular.copy(data.lapsedData);
		for (var f=0;f<$scope.lapsedDataTemp.length;f++)
		{
			if ($scope.lapsedDataTemp[f].ctpAmount) {
				$scope.lapsedDataTemp[f].ctpAmount=getIntegerFromString($scope.lapsedDataTemp[f].ctpAmount);
			}
			if ($scope.lapsedDataTemp[f].grossAmount) {
				$scope.lapsedDataTemp[f].grossAmount=getIntegerFromString($scope.lapsedDataTemp[f].grossAmount);
			}
			if ($scope.lapsedDataTemp[f].lastPaymentDate) {
				$scope.lapsedDataTemp[f].lastPaymentDate=convertDateFromISO($scope.lapsedDataTemp[f].lastPaymentDate);
			}
			/*if ($scope.lapsedDataTemp[f].lastPaymentInstrument) {
				$scope.lapsedDataTemp[f].lastPaymentInstrument=getIntegerFromString($scope.lapsedDataTemp[f].lastPaymentInstrument);
			}*/
		}
		
		
		for (var i=0;i<$scope.activeDataTemp.length;i++) {
			
			delete $scope.activeDataTemp[i].email;
			delete $scope.activeDataTemp[i].lastName;
			delete $scope.activeDataTemp[i].premiumAmount;
			delete $scope.activeDataTemp[i].productName;
			delete $scope.activeDataTemp[i].premiumDueDate;
		}
                //$scope.activeDataTemp=angular.copy(data.activeData);
		for (var i=0;i<$scope.graceDataTemp.length;i++) {
			
			delete $scope.graceDataTemp[i].email;
			delete $scope.graceDataTemp[i].lastName;
			delete $scope.graceDataTemp[i].premiumAmount;
			delete $scope.graceDataTemp[i].productName;
			delete $scope.graceDataTemp[i].premiumDueDate;
		}
                //$scope.graceDataTemp=angular.copy(data.graceData);
		for (var i=0;i<data.lapsedData.length;i++) {
			
			delete $scope.lapsedDataTemp[i].email;
			delete $scope.lapsedDataTemp[i].lastName;
			delete $scope.lapsedDataTemp[i].premiumAmount;
			delete $scope.lapsedDataTemp[i].productName;
			delete $scope.lapsedDataTemp[i].premiumDueDate;
		}
                //$scope.lapsedDataTemp=angular.copy(data.lapsedData);
		
                
		$scope.activeData.push($scope.activeDataTemp);
		$scope.graceData.push($scope.graceDataTemp);
		$scope.lapsedData.push($scope.lapsedDataTemp);
		
		$scope.$apply();
           }
           
           $scope.getPremiumDetails=function(tab)
           {
                      
           
           $scope.selectedTab=tab;
           $scope.activeDataDetailsPremium=[];
	   $scope.graceDataDetailsPremium=[];
	   $scope.lapsedDataDetailsPremium=[];
           $scope.activeDataPremium=[];
	   $scope.graceDataPremium=[];
	   $scope.lapsedDataPremium=[];
           $scope.premiumDueDataPremium=[];
           $scope.tempCalendarPremiumData=[];
	   
           $scope.premiumDueData=[];
            angular.copy($scope.calendarData, $scope.tempCalendarPremiumData);
           for(var i=0;i<$scope.tempCalendarPremiumData.length;i++){
                      
                      
                      if($scope.tempCalendarPremiumData[i].month==$scope.monthShown)
                      {
                    	  
                    	  if($scope.tempCalendarPremiumData[i].days != undefined){
                    		  for(var j=0;j<$scope.tempCalendarPremiumData[i].days.length;j++)
                              {
                                    for(var k=0;k<$scope.tempCalendarPremiumData[i].days[j].active.length;k++)
                                           {
                                               delete $scope.tempCalendarPremiumData[i].days[j].active[k].lastName;
                                              delete $scope.tempCalendarPremiumData[i].days[j].active[k].email;
					       delete $scope.tempCalendarPremiumData[i].days[j].active[k].premiumAmount;
					       delete $scope.tempCalendarPremiumData[i].days[j].active[k].productName;
					       delete $scope.tempCalendarPremiumData[i].days[j].active[k].premiumDueDate;
                                           }
                                    $scope.activeDataDetailsPremium = $scope.activeDataDetailsPremium.concat($scope.tempCalendarPremiumData[i].days[j].active);
                                    for(var l=0;l<$scope.tempCalendarPremiumData[i].days[j].grace.length;l++)
                                           {
                                              
                                               delete $scope.tempCalendarPremiumData[i].days[j].grace[l].lastName;
                                               delete $scope.tempCalendarPremiumData[i].days[j].grace[l].email;
					       delete $scope.tempCalendarPremiumData[i].days[j].grace[l].premiumAmount;
					       delete $scope.tempCalendarPremiumData[i].days[j].grace[l].productName;
					       delete $scope.tempCalendarPremiumData[i].days[j].grace[l].premiumDueDate;
                                           }
                                    $scope.graceDataDetailsPremium = $scope.graceDataDetailsPremium.concat($scope.tempCalendarPremiumData[i].days[j].grace);
                                    for(var m=0;m<$scope.tempCalendarPremiumData[i].days[j].lapsed.length;m++)
                                           {
                                               delete $scope.tempCalendarPremiumData[i].days[j].lapsed[m].reinstatementAmount;
                                               delete $scope.tempCalendarPremiumData[i].days[j].lapsed[m].lastName;
                                               delete $scope.tempCalendarPremiumData[i].days[j].lapsed[m].additionalInformation;
					       delete $scope.tempCalendarPremiumData[i].days[j].lapsed[m].premiumAmount;
					       delete $scope.tempCalendarPremiumData[i].days[j].lapsed[m].productName;
					       delete $scope.tempCalendarPremiumData[i].days[j].lapsed[m].premiumDueDate;
					       delete $scope.tempCalendarPremiumData[i].days[j].lapsed[m].email;
                                           }
                                    $scope.lapsedDataDetailsPremium=$scope.lapsedDataDetailsPremium.concat($scope.tempCalendarPremiumData[i].days[j].lapsed);
                              } 
                    	  }
                          
                      }
                      }
            $scope.activeDataPremium.push($scope.activeDataDetailsPremium);
	   $scope.lapsedDataPremium.push($scope.lapsedDataDetailsPremium);
	   $scope.graceDataPremium.push($scope.graceDataDetailsPremium);
           $scope.temporaryPremiumDueData=$scope.activeDataDetailsPremium.concat($scope.graceDataDetailsPremium);
	   $scope.premiumDueTemporaryData=$scope.temporaryPremiumDueData.concat($scope.lapsedDataDetailsPremium);
	   
	   for (var f=0;f<$scope.premiumDueTemporaryData.length;f++)
		{
			if ($scope.premiumDueTemporaryData[f].ctpAmount) {
				$scope.premiumDueTemporaryData[f].ctpAmount=getIntegerFromString($scope.premiumDueTemporaryData[f].ctpAmount);
			}
			if ($scope.premiumDueTemporaryData[f].grossAmount) {
				$scope.premiumDueTemporaryData[f].grossAmount=getIntegerFromString($scope.premiumDueTemporaryData[f].grossAmount);
			}
			if ($scope.premiumDueTemporaryData[f].lastPaymentDate) {
				$scope.premiumDueTemporaryData[f].lastPaymentDate=convertDateFromISO($scope.premiumDueTemporaryData[f].lastPaymentDate);
			}
			/*if ($scope.premiumDueTemporaryData[f].lastPaymentInstrument) {
				$scope.premiumDueTemporaryData[f].lastPaymentInstrument=getIntegerFromString($scope.premiumDueTemporaryData[f].lastPaymentInstrument);
			}*/
			
		}
		    
           
	   $scope.premiumDueData.push($scope.premiumDueTemporaryData);
           $scope.$apply();
                      
           }
           
           $scope.getMonthlyDetails=function(filter,tab){
                      
		$scope.selectedTab=tab;
		$scope.showDate=false;
		$scope.selectedFilter=filter;
		$scope.activeData=[];
		$scope.graceData=[];
		$scope.lapsedData=[];
		$scope.activeDataDetails =[];
		$scope.graceDataDetails =[];
		$scope.lapsedDataDetails=[];
                $scope.activeDataDetailsPremium =[];
		$scope.graceDataDetailsPremium =[];
		$scope.lapsedDataDetailsPremium=[];
		$scope.premiumDueData=[];
                $scope.tempCalendarData=[];
                angular.copy($scope.calendarData, $scope.tempCalendarData);
                
		$scope.tempCalendarData=angular.copy($scope.tempCalendarData);
		for(var i=0;i<$scope.tempCalendarData.length;i++){
			
			
			if($scope.tempCalendarData[i].month==$scope.monthShown)
			{
				for(var j=0;j<$scope.tempCalendarData[i].days.length;j++)
				{
                                        for(var k=0;k<$scope.tempCalendarData[i].days[j].active.length;k++)
                                        {
                                            delete $scope.tempCalendarData[i].days[j].active[k].email;
                                            delete $scope.tempCalendarData[i].days[j].active[k].lastName;
                                            delete $scope.tempCalendarData[i].days[j].active[k].premiumAmount;
                                            delete $scope.tempCalendarData[i].days[j].active[k].productName;
                                            delete $scope.tempCalendarData[i].days[j].active[k].premiumDueDate;
                                        }
					$scope.activeDataDetails = $scope.activeDataDetails.concat($scope.tempCalendarData[i].days[j].active);
                                        for(var l=0;l<$scope.tempCalendarData[i].days[j].grace.length;l++)
                                        {
                                            delete $scope.tempCalendarData[i].days[j].grace[l].email;
                                            delete $scope.tempCalendarData[i].days[j].grace[l].lastName;
                                            delete $scope.tempCalendarData[i].days[j].grace[l].premiumAmount;
                                            delete $scope.tempCalendarData[i].days[j].grace[l].productName;
                                            delete $scope.tempCalendarData[i].days[j].grace[l].premiumDueDate;
                                        }
					$scope.graceDataDetails = $scope.graceDataDetails.concat($scope.tempCalendarData[i].days[j].grace);
                                        for(var m=0;m<$scope.tempCalendarData[i].days[j].lapsed.length;m++)
                                        {
                                            delete $scope.tempCalendarData[i].days[j].lapsed[m].email;
                                            delete $scope.tempCalendarData[i].days[j].lapsed[m].lastName;
                                            delete $scope.tempCalendarData[i].days[j].lapsed[m].premiumAmount;
                                            delete $scope.tempCalendarData[i].days[j].lapsed[m].productName;
                                            delete $scope.tempCalendarData[i].days[j].lapsed[m].premiumDueDate;
                                            delete $scope.tempCalendarData[i].days[j].lapsed[m].additionalInformation;
                                        }
					$scope.lapsedDataDetails =$scope.lapsedDataDetails.concat($scope.tempCalendarData[i].days[j].lapsed);
				}
			}
			
		}
               
		$scope.activeDataDetails=angular.copy($scope.activeDataDetails);
		for (var f=0;f<$scope.activeDataDetails.length;f++)
		{
			if ($scope.activeDataDetails[f].ctpAmount) {
				$scope.activeDataDetails[f].ctpAmount=getIntegerFromString($scope.activeDataDetails[f].ctpAmount);
			}
			if ($scope.activeDataDetails[f].grossAmount) {
				$scope.activeDataDetails[f].grossAmount=getIntegerFromString($scope.activeDataDetails[f].grossAmount);
			}
			if ($scope.activeDataDetails[f].lastPaymentDate) {
				$scope.activeDataDetails[f].lastPaymentDate=convertDateFromISO($scope.activeDataDetails[f].lastPaymentDate);
			}
			/*if ($scope.activeDataDetails[f].lastPaymentInstrument) {
				$scope.activeDataDetails[f].lastPaymentInstrument=getIntegerFromString($scope.activeDataDetails[f].lastPaymentInstrument);
			}*/
		}
		$scope.lapsedDataDetails=angular.copy($scope.lapsedDataDetails);
		for (var f=0;f<$scope.lapsedDataDetails.length;f++)
		{
			if ($scope.lapsedDataDetails[f].ctpAmount) {
				$scope.lapsedDataDetails[f].ctpAmount=getIntegerFromString($scope.lapsedDataDetails[f].ctpAmount);
			}
			if ($scope.lapsedDataDetails[f].grossAmount) {
				$scope.lapsedDataDetails[f].grossAmount=getIntegerFromString($scope.lapsedDataDetails[f].grossAmount);
			}
			if ($scope.lapsedDataDetails[f].lastPaymentDate) {
				$scope.lapsedDataDetails[f].lastPaymentDate=convertDateFromISO($scope.lapsedDataDetails[f].lastPaymentDate);
			}
			/*if ($scope.lapsedDataDetails[f].lastPaymentInstrument) {
				$scope.lapsedDataDetails[f].lastPaymentInstrument=getIntegerFromString($scope.lapsedDataDetails[f].lastPaymentInstrument);
			}*/
		}
		$scope.graceDataDetails=angular.copy($scope.graceDataDetails);
		
		for (var f=0;f<$scope.graceDataDetails.length;f++)
		{
			if ($scope.graceDataDetails[f].ctpAmount) {
				$scope.graceDataDetails[f].ctpAmount=getIntegerFromString($scope.graceDataDetails[f].ctpAmount);
			}
			if ($scope.graceDataDetails[f].grossAmount) {
				$scope.graceDataDetails[f].grossAmount=getIntegerFromString($scope.graceDataDetails[f].grossAmount);
			}
			if ($scope.graceDataDetails[f].lastPaymentDate) {
				$scope.graceDataDetails[f].lastPaymentDate=convertDateFromISO($scope.graceDataDetails[f].lastPaymentDate);
			}
			/*if ($scope.graceDataDetails[f].lastPaymentInstrument) {
				$scope.graceDataDetails[f].lastPaymentInstrument=getIntegerFromString($scope.graceDataDetails[f].lastPaymentInstrument);
			}*/
		}
		$scope.activeData.push($scope.activeDataDetails);
		$scope.lapsedData.push($scope.lapsedDataDetails);
		$scope.graceData.push($scope.graceDataDetails);
		$scope.$apply();
		
	}
	
           $scope.getLapsedData=function(lapsedTab)
           {
		$scope.lapsedPeriodData=[];
		$scope.selectedTab=lapsedTab;
		var Header=[];
		var i=0;
           if (lapsedTab== translateMessages($translate, "premiumCalender.dueFromLapsedBucket(<180 Days)")) {
			
			$scope.lapsedPeriodTempData=angular.copy(appDataShareService.json.premiumCalendar.premiumCalendar[0].lapsedLessThan180);
			
			for (i=0;i<$scope.lapsedPeriodTempData.length;i++) {
				if ($scope.lapsedPeriodTempData[i].grossAmount) {
					$scope.lapsedPeriodTempData[i].grossAmount=getIntegerFromString($scope.lapsedPeriodTempData[i].grossAmount);
				}
				if ($scope.lapsedPeriodTempData[i].lastPaymentDate) {
					$scope.lapsedPeriodTempData[i].lastPaymentDate=convertDateFromISO($scope.lapsedPeriodTempData[i].lastPaymentDate);
				}
				if ($scope.lapsedPeriodTempData[i].premiumAmount) {
					$scope.lapsedPeriodTempData[i].premiumAmount=getIntegerFromString($scope.lapsedPeriodTempData[i].premiumAmount);
				}
				if ($scope.lapsedPeriodTempData[i].premiumDueDate) {
					$scope.lapsedPeriodTempData[i].premiumDueDate=convertDateFromISO($scope.lapsedPeriodTempData[i].premiumDueDate);
				}
				if ($scope.lapsedPeriodTempData[i].reinstatementAmount) {
					$scope.lapsedPeriodTempData[i].reinstatementAmount=getIntegerFromString($scope.lapsedPeriodTempData[i].reinstatementAmount);
				}
				/*if ($scope.lapsedPeriodTempData[i].lastPaymentInstrument) {
					$scope.lapsedPeriodTempData[i].lastPaymentInstrument=getIntegerFromString($scope.lapsedPeriodTempData[i].lastPaymentInstrument);
				}*/
				delete $scope.lapsedPeriodTempData[i].premiumDueDate;
				delete $scope.lapsedPeriodTempData[i].additionalInformation;
				delete $scope.lapsedPeriodTempData[i].email;
				delete $scope.lapsedPeriodTempData[i].lastName;
				delete $scope.lapsedPeriodTempData[i].premiumAmount;
				delete $scope.lapsedPeriodTempData[i].productName;
			}
			
			
		      $scope.lapsedPeriodData.push($scope.lapsedPeriodTempData);
	   }
	   else if (lapsedTab=translateMessages($translate, "premiumCalender.dueFromLapsedBucket(>180 Days)")) {
			
			$scope.lapsedPeriodTempData=angular.copy(appDataShareService.json.premiumCalendar.premiumCalendar[0].lapsedGreaterThan180);
			
			for (i=0;i<$scope.lapsedPeriodTempData.length;i++) {
				if ($scope.lapsedPeriodTempData[i].grossAmount) {
					$scope.lapsedPeriodTempData[i].grossAmount=getIntegerFromString($scope.lapsedPeriodTempData[i].grossAmount);
				}
				if ($scope.lapsedPeriodTempData[i].lastPaymentDate) {
					$scope.lapsedPeriodTempData[i].lastPaymentDate=convertDateFromISO($scope.lapsedPeriodTempData[i].lastPaymentDate);
				}
				if ($scope.lapsedPeriodTempData[i].premiumAmount) {
					$scope.lapsedPeriodTempData[i].premiumAmount=getIntegerFromString($scope.lapsedPeriodTempData[i].premiumAmount);
				}
				if ($scope.lapsedPeriodTempData[i].premiumDueDate) {
					$scope.lapsedPeriodTempData[i].premiumDueDate=convertDateFromISO($scope.lapsedPeriodTempData[i].premiumDueDate);
				}
				if ($scope.lapsedPeriodTempData[i].reinstatementAmount) {
					$scope.lapsedPeriodTempData[i].reinstatementAmount=getIntegerFromString($scope.lapsedPeriodTempData[i].reinstatementAmount);
				}
				/*if ($scope.lapsedPeriodTempData[i].lastPaymentInstrument) {
					$scope.lapsedPeriodTempData[i].lastPaymentInstrument=getIntegerFromString($scope.lapsedPeriodTempData[i].lastPaymentInstrument);
				}*/
				delete $scope.lapsedPeriodTempData[i].premiumDueDate;
				delete $scope.lapsedPeriodTempData[i].additionalInformation;
				delete $scope.lapsedPeriodTempData[i].email;
				delete $scope.lapsedPeriodTempData[i].lastName;
				delete $scope.lapsedPeriodTempData[i].premiumAmount;
				delete $scope.lapsedPeriodTempData[i].productName;
			}
			$scope.lapsedPeriodData.push($scope.lapsedPeriodTempData);
			
                      }
		$scope.$apply();
           }
           
           $scope.JSONToCSVConvertor=function(JSONData, ReportTitle, ShowLabel) {
           
           var arrData = typeof JSONData != 'object' ? JSON.parse(JSONData) : JSONData;
           var timeStamp=new Date().getTime();
           
            if (navigator.userAgent.search(commonConfig().SEARCH_OPTION.MSIE) >= 0)  {
            	
            	if(arrData[0].status==commonConfig().STATUS.LAPSED)
                {
                ReportTitle="Due From Lapsed ";
               var fileName = "";
             fileName += ReportTitle.replace(/ /g,"_");
             fileName +=timeStamp+".xls";
             
                }
             else
             {
                    var fileName = "";
          fileName += ReportTitle.replace(/ /g,"_");
         fileName +=timeStamp+".xls";   
             }

            	
             var CSV = '';    
           CSV += "<table style='border: 1px solid black'>";
           if (ShowLabel) {
                      
                      var row = "<tr style='border: 1px solid black'>";
		     /* if (arrData[0]==undefined)
		      {
			row += 'Policy Number,Insured,Plan,Mode,Issued Date,Benefit Split(%),Allocation Date,FYC/RYC,Premium(Rs.),Rate(%),Gross Amount(Rs.),Reason,Disbursement Date,';
		      }*/
		     
                      for (var index in arrData[0]) {
			
                                            delete arrData[0].$$hashKey;
                                            row += "<td style='border: 1px solid black'>"+index + '</td> ';
                                 }  
                      //row = row.slice(0, -1);
                      row +="</tr>";
           CSV += row + '\r\n';
           }
           
           for (var i = 0; i < arrData.length; i++) {
                      row = "<tr style='border: 1px solid black'>";
           for (var index in arrData[i]) {
        	   if (index==commonConfig().DATE_TYPE.LAST_PAYMENT_DATE) {
       			arrData[i][index] = ' '+$filter('date')(arrData[i][index], "dd-MM-yyyy");
       			}
                         delete arrData[i].$$hashKey;
                          row +=  "<td style='border: 1px solid black'>" + arrData[i][index] + '</td>';
           }
           
           //row.slice(0, row.length - 1);
           row +='</tr>'
           CSV += row + '\r\n';
           }
           
           CSV +='</table>'
           
           if (CSV == '') {        
               
               return;
           }                       
           
	   
	   
           var fileName = "";
           fileName += ReportTitle.replace(/ /g,"_");
	   fileName +=timeStamp+".xls";
           var txt = document.getElementById('txtArea1').contentWindow;
           txt.document.open("txt/html","replace");
           txt.document.write(CSV);
           txt.document.close();
           txt.focus();
           tb = txt.document.execCommand("SaveAs",true,fileName);
           return (tb);  
           
            
           }
           else
           {          
           var CSV = '';    
           CSV += ReportTitle + '\r\n\n';
	 
           if (ShowLabel) {
                      
                      var row = "";
                      for (var index in arrData[0]) {
                                            delete arrData[0].$$hashKey;
                                            row += index + ',';
                                 }  
                      row = row.slice(0, -1);
           CSV += row + '\r\n';
           }
           for (var i = 0; i < arrData.length; i++) {
                      var row = "";
           for (var index in arrData[i]) {
        	  // console.log("arrData[i].."+angular.toJson(arrData[i]));
		if (index==commonConfig().DATE_TYPE.LAST_PAYMENT_DATE) {
			arrData[i][index] = ' '+$filter('date')(arrData[i][index], "dd-MM-yyyy");
		}
                         delete arrData[i].$$hashKey;
                          row += '"' + arrData[i][index] + '",';
           }
           row.slice(0, row.length - 1);
           CSV += row + '\r\n';
           }
        
          // console.log("CSV.."+CSV);
           
           if (CSV == '') {        
               //alert("Invalid data");
               return;
           }
           
           var fileName = "MyReport_";
           fileName += ReportTitle.replace(/ /g,"_");
	   fileName +=timeStamp;
           // to support csv file download in safari and edge browsers.
		   fileName += ".csv";							 
		   var blob = new Blob([CSV], {'type':'text/csv'});
	       saveAs(new Blob([blob], {type: "application/octet-stream;charset=UTF-8"}), fileName);
		   /*var uri = 'data:text/csv;charset=utf-8,' + escape(CSV);
           
           // Now the little tricky part.
           // you can use either>> window.open(uri);
           // but this will not work in some browsers
           // or you will not get the correct file extension    
           
           //this trick will generate a temp <a /> tag
                                 var link = document.createElement("a");    
                                 link.href = uri;
           
           //set the visibility hidden so it will not effect on your web-layout
                                 link.style = "visibility:hidden";
                                 link.download = fileName + ".csv";
           
           //this part will append the anchor tag and remove it after automatic click
                                 document.body.appendChild(link);
                                 link.click();
                                 document.body.removeChild(link);*/
           }
           }

        $scope.getHeader=function(data){
		var header=[];
		var i =0;
		for (var index in data) {
                                            delete data.$$hashKey;
					    header[i]=index;
                                            i=i+1;
					    //row += ''+index + '';
                                }  
		return header;
		
	}
	
	$scope.getValues=function(data)
	{
              
              
              var values = [];           
              for (var i = 0; i < data.length; i++)
              {
                     var row=[];
                     var j=0;
                     for (var index in data[i])
                     {
                    	 if (index==commonConfig().DATE_TYPE.LAST_PAYMENT_DATE) {
                    		 data[i][index] = ' '+$filter('date')(data[i][index], "dd-MM-yyyy");
                 			}
			delete data[i].$$hashKey;
                           row[j]=(data[i][index].toString()).replace(/,/g, "");
                           j=j+1;
                     }
              
                     values.push(row);
                }
              
              return values;
       }



function setCalendarData(data) {
	
	var d=[];
	d=(data[0].byPeriod);
	return d
}
function getMonthName(MonthNumber) {
		var monthArray = [ "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul",
				"Aug", "Sep", "Oct", "Nov", "Dec" ];
		return monthArray[parseInt(MonthNumber)];
	}
function getMonthNumber(MonthName) {
		var monthArray = [ "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul",
				"Aug", "Sep", "Oct", "Nov", "Dec" ];
		for (var i=0;i<monthArray.length;i++) {
			if (MonthName==monthArray[i]) {
				return i;
			}
		}
	}
function capitaliseFirstLetter(string)
{
    return string.charAt(0).toUpperCase() + string.slice(1);
}

}]);
