mServiceApp.controller('GLI_PolicyRenewalCalendarCtrl',['$controller','$rootScope', '$scope',  '$compile', '$route', '$routeParams', '$location', '$translate','dataService',
'appDataShareService','UserDetailsService','AutoSync','debounce','$timeout','$filter','commonConfig','PersistenceMapping','customerServiceConfig','gli_dataservice',function GLI_PolicyRenewalCalendarCtrl($controller ,$rootScope, $scope,
$compile, $route, $routeParams, $location, $translate,dataService,appDataShareService,UserDetailsService,AutoSync,debounce,$timeout,$filter,commonConfig,PersistenceMapping,customerServiceConfig,gli_dataservice) {
    $controller('PolicyRenewalCalendarCtrl',{
        $rootScope:$rootScope,
        $scope:$scope,
        $compile:$compile,
        $route:$route,
        $routeParams:$routeParams,
        $location:$location,
        $translate:$translate,
        dataService:gli_dataservice,
        appDataShareService:appDataShareService,
		UserDetailsService:UserDetailsService,
        AutoSync:AutoSync,
        debounce:debounce,
        $timeout:$timeout,
        $filter:$filter,
        commonConfig:commonConfig,
        customerServiceConfig:customerServiceConfig});
        angular.extend(this, $controller('BaseCtrl',{$scope:$scope, $rootScope:$rootScope, dataService:dataService, type:'premiumCalendar', userId:appDataShareService.selectedUser.userId}));
        var _this = this;
        $scope.isResultEmpty = true;
        $scope.selectedpage = commonConfig().PAGE_NAME.PREMIUM_CALENDAR;
        $scope.mapScopeToPersistance = function () {
            var newDate = new Date();
            PersistenceMapping.clearTransactionKeys();
            PersistenceMapping.Key1 = "";
            PersistenceMapping.Key2 = $rootScope.username;
            PersistenceMapping.Key5 = "Agent";
            PersistenceMapping.Key10 = "";
            PersistenceMapping.Type = _this.Type;
            var transactionObj =  PersistenceMapping.mapScopeToPersistence({});
            return transactionObj;
        };
        $scope.validateDates = function(){
            $scope.errorMessage = [];
            if(!$scope.dateFrom || !$scope.dateTo){
              $scope.errorFlag = true;
              $scope.errorMessage.push("Both From and To date are Mandatory");
            } else {
                if($scope.dateTo < $scope.dateFrom){
                  $scope.errorFlag = true;
                  $scope.errorMessage.push("To date should be greater than or equal to From date");
              }
            }
            if($scope.errorFlag){
                $scope.isResultEmpty = true;
                $scope.displayData = "";
                $scope.errorFlag = false;
                return false;
            } else {
                return true;
            }
        };
         $scope.getTransactionError = function(data) {
        			showHideLoadingImage(false,'');
        			$rootScope.serviceFailed=true;
        			$rootScope.$apply();
        	};
        $scope.getPremiumCalendar = function(){
            $scope.errorMessage = [];
			$scope.validSearch = false;
            if($scope.validateDates()){
                showHideLoadingImage(true, "Refreshing Premium Calender..");
                $scope.searchData = JSON.parse(JSON.stringify({
                        		"premiumStartDate" : $scope.dateFrom,
                        		"premiumEndDate": $scope.dateTo
                    }));
                appDataShareService.premiumCalendarSearchData = $scope.searchData;
                var transactionObj = $scope.mapScopeToPersistance();
                transactionObj.Type = "premiumCalendar";
                var searchObj = {
                    "SearchCriteria" : {
                        		"premiumStartDate" : $scope.dateFrom,
                        		"premiumEndDate": $scope.dateTo
                    }
                };
                transactionObj.TransactionData = searchObj;
                //To be changed once service is completed
				if((rootConfig.isDeviceMobile && checkConnection()) || !rootConfig.isDeviceMobile){
			        $scope.validSearch = true; dataService.searchTransactions(transactionObj,$scope.getTransationSuccess,$scope.getTransationError);
			     }else{
			        $scope.getTransationError();
			     }
                
            }
        };
        $scope.initialize = function(){
		if(!(rootConfig.isDeviceMobile) && !(UserDetailsService.userDetilsModel)){
			var userDetilsModel = JSON.parse(sessionStorage.userDetails);
			var userDetailData = JSON.parse(sessionStorage.loginData);
			$rootScope.isLoggedOut = false;
			$rootScope.username = userDetilsModel.user.userId;
			$rootScope.agentId = userDetilsModel.user.rexitLoginId;
			$rootScope.isAuthenticated = true;
			$rootScope.username = userDetilsModel.user.userId;
			$rootScope.authenticationStatus = "SUCCESS";
			$rootScope.firstTimeLogin = userDetailData.firstTimeLogin;
			$rootScope.isTemporaryPassword = userDetailData.isTemporaryPassword;
			$rootScope.role = userDetailData.roles[0];
			UserDetailsService.setUserDetailsModel(userDetilsModel);
		}
            $scope.authorizationToken = "";
            $scope.errorFlag = false;
            showHideLoadingImage(false);
            if($rootScope.backToPremiumCalendar) {
                var premiumCalendar = appDataShareService.premiumCalendarSearchData;
                $rootScope.backToPremiumCalendar = false;
                $scope.dateFrom=premiumCalendar.premiumStartDate;
                $scope.dateTo=premiumCalendar.premiumEndDate;
                $scope.getPremiumCalendar();
            }
        };
         $scope.getTransactionError = function(data) {
         		showHideLoadingImage(false);
         		$rootScope.serviceFailed=true;
         		$rootScope.$apply();
         };
    
    $scope.$on('backToPremiumCalendar',function(){
		var premiumCalendar = appDataShareService.premiumCalendarSearchData;
        $rootScope.backToPremiumCalendar = false;
        $scope.dateFrom=premiumCalendar.premiumStartDate;
        $scope.dateTo=premiumCalendar.premiumEndDate;
        $scope.getPremiumCalendar();
	});
    
        $scope.getTransationSuccess = function(data) {
            $scope.displayData = [];
            if(data[0]){
                var transaction = data[0];
                var premiumCalendar =   transaction.TransactionData.PremiumCalendarResult.PremiumCalendarArray;
                $scope.ytd = transaction.TransactionData.PremiumCalendarResult.renewalTotalPolicyCount;
                $scope.premiumDue = transaction.TransactionData.PremiumCalendarResult.renewalTotalPremiumAmount;
                if(premiumCalendar.length >0){
                    $scope.isResultEmpty  = false;
                }
                for(var i=0; i<premiumCalendar.length; i++){
                    var displayObj = {
                                        "day":"",
                                        "date":"",
                                        "count":"",
                                        "premium":"",
										"month":""

                                    };
                    $scope.displayData.push(displayObj);
                    $scope.displayData[i].day = getDay(premiumCalendar[i].renewalPolicyDate);
                    $scope.displayData[i].date = new Date(premiumCalendar[i].renewalPolicyDate).getDate();
                    $scope.displayData[i].month = getMonthFromDate(premiumCalendar[i].renewalPolicyDate);
                    $scope.displayData[i].count = premiumCalendar[i].renewalPolicyCount;
                    $scope.displayData[i].premium = premiumCalendar[i].renewalPolicyPremium;
                    $scope.displayData[i].renewalPolicyDate = premiumCalendar[i].renewalPolicyDate;
                }
            } else{
                $scope.isResultEmpty  = true;
            }
            var premiumCalendar = appDataShareService.premiumCalendarSearchData;
            $scope.dateFrom=premiumCalendar.premiumStartDate;
            $scope.dateTo=premiumCalendar.premiumEndDate;            
            showHideLoadingImage(false);
			$scope.refresh();
        };
    $scope.loadPolicies = function(renewalPolicyDate) {        
		$rootScope.policyRenewalDate = renewalPolicyDate;
		$location.path('/policyDueForRenewal/premiumCalendar');
    }
    $scope.initialize();
}])