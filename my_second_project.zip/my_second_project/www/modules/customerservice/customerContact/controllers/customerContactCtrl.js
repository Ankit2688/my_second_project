
mServiceApp.controller('customerContactCtrl',['$controller','$rootScope', '$scope',  '$compile', '$route', '$routeParams', '$location', '$translate','dataService','appDataShareService','customerServiceConfig','commonConfig','PersistenceMapping','gli_dataservice', '$timeout',function($controller ,$rootScope, $scope,  $compile, $route, $routeParams, $location, $translate,dataService,appDataShareService,customerServiceConfig,commonConfig,PersistenceMapping,gli_dataservice, $timeout) {
	var _this = this;
	$scope.isValid = false;
	$scope.isValid2 = false;
	$scope.isSearchInValid = false;
	$scope.gliPolicySearch = {};
	$scope.validSearch = false;
	$scope.pageName = "Customer Contact";
	$rootScope.clientNo = "";
	$scope.noData = false;
	$scope.catchEventFromBackBtn = true;
	$scope.noDataFromServer = true;
	$scope.selectedpage = commonConfig().PAGE_NAME.CUSTOMER_CONTACT;
	$scope.customerStatus= ['Active','Inactive'];
	angular.extend(this, $controller('BaseCtrl',{$scope:$scope, $rootScope:$rootScope, dataService:dataService, type:'customerStatus', userId:appDataShareService.selectedUser.userId}));
	$scope.setData = function() {
		$scope.customerContact = {};
		$scope.customerContact.idNumber = "";
		$scope.customerContact.customerFirstName = "";
		$scope.customerContact.mobileNumber = "";
		$scope.noData = false;
	};
	$scope.mapScopeToPersistance = function () {
	    var newDate = new Date();
	    PersistenceMapping.clearTransactionKeys();
        PersistenceMapping.Key2 = $rootScope.username;
        PersistenceMapping.Key5 = "Agent";
        PersistenceMapping.Type = _this.Type;
        var transactionObj =  PersistenceMapping.mapScopeToPersistence({});
        return transactionObj;
    };
	$scope.searchCustomerContact = function(customerContact, fromSearchButton){
		if(fromSearchButton)
		{
			$scope.intialLoadingData = false;
		}
		$scope.noData = false;
		$scope.noDataFromServer = true;
		$scope.customerContact = customerContact;
        $scope.searchData=JSON.parse(JSON.stringify($scope.customerContact));
		var transactionObj = $scope.mapScopeToPersistance();
		appDataShareService.customerContactjson = $scope.customerContact;
		var searchObj = {
				"SearchCriteria" : {
					"customerName" : $scope.customerContact.customerFirstName,
					"contactNumber": $scope.customerContact.mobileNumber,
					"identityNumber" : $scope.customerContact.idNumber,
					"customerStatus" : $scope.customerContact.customerStatus
				}
			};
		$scope.searchFieldCount = 0;
		$scope.searchFieldEmptyCount = 0;
		Object.keys(searchObj.SearchCriteria).forEach(function(key) {
			  if (searchObj.SearchCriteria[key] == undefined) {
				  searchObj.SearchCriteria[key] = "";
			  }
		});
		Object.keys(searchObj.SearchCriteria).forEach(function(key) {
			  if (searchObj.SearchCriteria[key] == "") {
				  $scope.searchFieldEmptyCount++;
			  }
		});
		//To get count of searchObj
		Object.keys(searchObj.SearchCriteria).forEach(function(key) {
			  if (searchObj.SearchCriteria) {
				  $scope.searchFieldCount++;
			  }
		});
		if($scope.intialLoadingData == false)
		{
			if($scope.searchFieldEmptyCount == $scope.searchFieldCount){
				$scope.isSearchInValid = true;
				$scope.validSearch = false;
				$scope.errorMessage = [];
				$scope.minOneSearchFieldValidationMessage = translateMessages($translate, "policySearch.minOneSearchFieldValidationMessage");
				$scope.errorMessage.push($scope.minOneSearchFieldValidationMessage);
			}
			else{
				$scope.errorMessage = [];
				$scope.isSearchInValid = false;
				if(fromSearchButton) {
					 showHideLoadingImage(true,"Customer Contact",null,null);
					 $scope.pageNumber = 1;
				}
				searchObj.SearchCriteria.pageNo = $scope.pageNumber;
				searchObj.SearchCriteria.pageSize = rootConfig.resultPerPage;
				searchObj.SearchCriteria.customerStatus = $scope.customerContact.customerStatus;
				transactionObj.TransactionData = searchObj;   
				if((rootConfig.isDeviceMobile && checkConnection()) || !rootConfig.isDeviceMobile){
					dataService.searchTransactions(transactionObj, $scope.getTransactionSuccess, $scope.getTransactionError);
				}else{
					$scope.getTransactionError();
				}	
			}
		}
		else
		{			
				$scope.errorMessage = [];
				$scope.isSearchInValid = false;
				if($scope.intialLoadingDataFirstPage == true) {
					 showHideLoadingImage(true,"Customer Contact",null,null);
					 $scope.pageNumber = 1;
					 $scope.intialLoadingDataFirstPage = false;
				}
				searchObj.SearchCriteria.pageNo = $scope.pageNumber;
				searchObj.SearchCriteria.pageSize = rootConfig.resultPerPage;
				searchObj.SearchCriteria.customerStatus = $scope.customerContact.customerStatus;
				transactionObj.TransactionData = searchObj;   
				if((rootConfig.isDeviceMobile && checkConnection()) || !rootConfig.isDeviceMobile){
					dataService.searchTransactions(transactionObj, $scope.getTransactionSuccess, $scope.getTransactionError);
				}else{
					$scope.getTransactionError();
				}	
		}
	};

	$scope.$on('backToCustomerContact',function(){
        var customerContactSearchData = appDataShareService.customerContactSearchCriteria;
        $rootScope.backToCustomerContact = false;
        $scope.searchCustomerContact(customerContactSearchData, true);
	});

	$scope.getTransactionSuccess = function(data) {
		showHideLoadingImage(false,"Customer Contact",null,null);
        if($scope.pageNumber==1)
			$scope.clientDetails = [];
		
		 if(data[0] !== undefined)
		 {
		  if (data[0].TransactionData != null) {
				$scope.validSearch = true;
				if (data[0].TransactionData.length !== 0) {
					$scope.customerContactDetails = data[0].TransactionData.customerStatusResult;
                    if($scope.customerContactDetails.length != null && $scope.customerContactDetails.length == 0 &&$scope.customerContactDetails.length !='') {
                       $scope.noDataFromServer = true;
                    }
                    else {
                        $scope.noDataFromServer = false;
                    }
					$scope.noOfPolicies = data[0].Key25;
					for ( var i = 0; i < $scope.customerContactDetails.length; i++) {
						$scope.clientDetailsTemp = [];
						$scope.clientNo = $scope.customerContactDetails[i].clientNumber;
						$scope.policyStatus  =$scope.customerContactDetails[i].clientStatus;
						$scope.clientDetailsTemp
								.push({
									key : translateMessages($translate, "customerService.customerNameLabel"),
									value : $scope.customerContactDetails[i].customerName

						});
						$scope.clientDetailsTemp.push({
							key : translateMessages($translate, "customerService.contactNumberLabel"),
							value : $scope.customerContactDetails[i].contactNumber
						});
						$scope.clientDetailsTemp.push({
							key : translateMessages($translate, "customerService.emailLabel"),
							value : $scope.customerContactDetails[i].email
						});
						$scope.clientDetailsTemp.push({
							key : translateMessages($translate, "customerService.addressLabel"),
							value : $scope.customerContactDetails[i].address.addressLine1+','+$scope.customerContactDetails[i].address.addressLine2+','+$scope.customerContactDetails[i].address.addressLine3+','+$scope.customerContactDetails[i].address.addressLine4
						});
						$scope.clientDetails
								.push({
									"data" : $scope.clientDetailsTemp,
									"clientNo" : $scope.clientNo
								});
					}
					if($scope.clientDetails.length === 0){
						$scope.noData = true;
					}else{
						$scope.noData = false;
                        $scope.pageNumber++;
					}					
				}
				else {
					$scope.validSearch = false;
				    $scope.alertMessage = translateMessages($translate, "onlineAlertMessage");
				}
			}
			}else {
			$scope.noOfPolicies = 0;
			$scope.validSearch = false;
			$scope.alertMessage = translateMessages($translate, "onlineAlertMessage");
		}
		showHideLoadingImage(false,"Policy Search",null,null);
        $scope.loadingMoreData=false;
        $scope.customerContact = $scope.searchData;
        $scope.$apply();
	};
	$scope.getTransactionError = function(data) {
        $rootScope.serviceFailed=true;
        $scope.loadingMoreData=false;
		if (rootConfig.isDeviceMobile && !checkConnection()) {
			$scope.message = translateMessages($translate, "networkValidationErrorMessage");
		}else{
			$scope.message = translateMessages($translate, "validToken");
		}
            	$scope.$emit('tokenEvent', { message: $scope.message });
            	if (data == "Error in ajax callE")
                   {
                       $scope.onServerError=true;
                       $scope.serverErrorMessage= translateMessages($translate, "serverErrorMessage");
					   showHideLoadingImage(false,"Customer Contact",null,null);
                   }
                   else
                   {
            		showHideLoadingImage(false,"Customer Contact",null,null);
                   }
            	$rootScope.$apply();
    };
	$scope.callPolicySearch = function(clientNo) {
        appDataShareService.customerContactSearchCriteria = $scope.searchData;
		$rootScope.clientNo = clientNo[0][0];
		$rootScope.customerStatus = $scope.searchData.customerStatus;
		$location.path('/customerService/policySearch/Customer Contact');
	};
    $scope.downloadPdf = function(downloadUrl) {
    };
	$scope.reset = function(){
	    $scope.customerContact = {};
		$scope.customerContact.customerStatus = 'Active';
		$scope.validSearch = false;
		$scope.errorMessage = [];
        $scope.noDataFromServer = true;
        $scope.isSearchInValid = false;	
	};
    $scope.intialLoad = function() {
        $scope.guideData=true;
        $scope.pageName=$routeParams.pageName;
		//Change for Data Onload
		$scope.intialLoadingData = true;
        if($rootScope.backToCustomerContact) {
			$scope.intialLoadingData = true;
            var customerContactSearchData = appDataShareService.customerContactSearchCriteria;
            $rootScope.backToCustomerContact = false;
			$scope.intialLoadingDataFirstPage = true;
            $scope.searchCustomerContact(customerContactSearchData, false);
        }else
		{
			$scope.intialLoadingDataFirstPage = true;
			$scope.customerContact = {};
			$scope.customerContact.idNumber = "";
			$scope.customerContact.customerFirstName = "";
			$scope.customerContact.mobileNumber = "";
			$scope.customerContact.customerStatus='Active';
			$scope.searchCustomerContact($scope.customerContact, false);
		}
    };
    $scope.$on('requestDataSet', function(e, args) {
        if(!$scope.noDataFromServer) {
            $scope.loadingMoreData=true;
            $scope.searchCustomerContact($scope.searchData, false);
        }
        else {
        	$scope.loadingMoreData=false;
        }
        $scope.$apply();
    });
    $scope.intialLoad();
	
	
	$scope.disablePolicy = function(policyValue){
		$scope.clientDetails.customerStatus;
		
		if (policyValue =='InActive'){
			return true;
		}
		else
			return false;
	}
}]);