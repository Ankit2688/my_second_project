mServiceApp.constant('customerServiceConfig',function(){return {
	"SUB_MODULE" : {
					"FORMS" : "Forms",
					"POLICY_SEARCH" : "Policy Search",
					"PROPOSAL_SEARCH" : "Proposal Search",
					"PREMIUM_CALENDER" : "Premium Calender"
					}
}});  