
mServiceApp.controller('KnowledgecenterCtrl',['$controller','$rootScope', '$scope',  '$compile', '$route', '$routeParams', '$location', '$translate','dataService','appDataShareService','authService','commonConfig','UserDetailsService',function($controller ,$rootScope, $scope,  $compile, $route, $routeParams, $location, $translate,dataService,appDataShareService,authService,commonConfig,UserDetailsService) {   
   var mContentRoles =null;
   $scope.isDeviceMobile = rootConfig.isDeviceMobile;
  mContentRoles= ["mServiceRole","mRecRole"];
   $scope.alertSDok= function(){
   	$scope.noSDRole=false;
   }

	$scope.selectedpage = commonConfig().PAGE_NAME.KNOWLEDGE_CENTER;
	$scope.subModule = "";
/* 	$scope.navigatetoSalesApp = function()
 	{
		localStorage.usr_Det = JSON.stringify(UserDetailsService.getUserDetailsModel());
		sessionStorage.fromApp = "AgencyPortal";
		sessionStorage.role = angular.copy($rootScope.role);
		window.location.href = rootConfig.salesAppLink;
	}  */
	
	$scope.syncDrive = function() {
       // showSyncDriveContent(rootConfig.knowledgeCenterSDPath ,"111441" ,mContentRoles,location.href);
			/*	 if(localStorage.mContentRoles!=undefined && localStorage.mContentRoles.length!=0) 
					 mContentRoles =localStorage.mContentRoles.split(',');
		
		if(mContentRoles=='null'){
			$scope.noSDRole=true;
			$rootScope.alertMessageSD="You don't have the permission to access this content.";
                $('#dvShowDecisionBoxSD').modal('show');
                $scope.refresh();
		}else if(mContentRoles=="not authenticated"){
		
		//$scope.getSDRoles();
		
              
		}
		else{
		
		showSyncDriveContent(rootConfig.knowledgeCenterSDPath ,appDataShareService.selectedUser.userId ,mContentRoles,location.href);
        }*/

	}
	
	
	//$rootScope.alertSDok= function(){
	//$scope.getSDRoles();
	
	//}
	
	$scope.getSDRoles= function(){
	
		if (navigator.userAgent.search(commonConfig().SEARCH_OPTION.MSIE) >= 0) {
			showHideLoadingImage(true, "Loading User Details", null,"SyncDriveAppRoles");
		} else {
			showHideLoadingImage(true, "Loading User Details", $translate,"SyncDriveAppRoles");
		}
		
		var retrievedObject = JSON.parse(localStorage.getItem(getUniqueAppNamePattern(commonConfig().PAGE_DETAILS.LOGIN)));
		$scope.username = retrievedObject.uname;
		
		var password = Decrypt_text(retrievedObject.pwd);
		
        authService
.getSyncDriveAppRole(
		{
			username : $scope.username,
			password : password

		},
		function(res) {
			
			var data = angular
					.toJson(res);
			appDataShareService.mContentRoles = res.mContentRoles;
			mContentRoles = res.mContentRoles;
			
			

				localStorage
						.setItem(
								getUniqueAppNamePattern(commonConfig().PAGE_DETAILS.MCONTENTROLES),
								mContentRoles);
								

			
			//$scope.syncDrive();
showSyncDriveContent(rootConfig.knowledgeCenterSDPath ,appDataShareService.selectedUser.userId ,mContentRoles,location.href);
showHideLoadingImage(
					false, null,
					null,
					"SyncDriveAppRoles");
		},
		function() {
		
			showHideLoadingImage(
					false, null,
					null,
					"SyncDriveAppRoles");
			//appDataShareService.mContentRoles = "not authenticated";
			  $scope.noSDRole=true;
			$rootScope.alertMessageSD="Error while accessing service. Please try again later.";
                $('#dvShowDecisionBoxSD').modal('show');
                $scope.refresh();
			//console.log("--error");
		});	

	}
	
	
}]);
