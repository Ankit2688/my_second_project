mServiceApp.constant('knowledgeCenterConfig', {
 
		
});  