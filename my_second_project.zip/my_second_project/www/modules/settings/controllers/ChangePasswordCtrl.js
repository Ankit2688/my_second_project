mServiceApp.controller('ChangePasswordCtrl',['$controller','$rootScope', '$scope',  '$compile', '$route', '$routeParams', '$location', '$translate','dataService','appDataShareService','authService','UserDetailsService','LoginService','debounce','commonConfig','$timeout','$window','PersistenceMapping','$filter',function($controller ,$rootScope, $scope,  $compile, $route, $routeParams, $location, $translate,dataService,appDataShareService,authService,UserDetailsService,LoginService,debounce,commonConfig,$timeout,$window,PersistenceMapping,$filter) {

    $scope.validSearch = false;
    $scope.dvPassword = true;
    $scope.selectedpage = commonConfig().PAGE_NAME.CHANGE_PASSWORD;
    $scope.resetPasswordQuestArray = ["M1","M2" ,"M3" ,"M4" ,"M5" ,"M6" ,"N1" ,"N2" ,"N3" ,"N4","N5",
									"N6","N7","N8","P1","P2","P3","P4","P5" ,"P6" ,"P7" ,"P8" ,"P9"];
    $scope.passwordPattern = rootConfig.passwordRegexPattern;
    $scope.error = false;
    $scope.passwordError = false;
    $scope.mapScopeToPersistance = function () {
	    var newDate = new Date();
	    PersistenceMapping.clearTransactionKeys();
        PersistenceMapping.Key2 = $rootScope.username;
        PersistenceMapping.Key5 = "Agent";
        PersistenceMapping.Type = "Change Password";
        var transactionObj =  PersistenceMapping.mapScopeToPersistence({});
        return transactionObj;
    };
    
    $scope.reset = function() {
        $scope.validSearch = false;
        $scope.isSearchInValid = false;
        $scope.questionValidSearch = false;
        $scope.questionErrorMessage=[];
        $scope.passwordError = false;
        $scope.error = false; 
        $scope.securityQuestion='';
        $scope.changePassword.newPassword="";
        $scope.changePassword.confirmPassword="";
        $scope.changePassword.currentPassword="";
        
    }
    $scope.validateFields = function(changePassword) {
        $scope.errorMessage = [];
        $scope.error = false; 
        $scope.isSearchInValid = false;
        $scope.validSearch = false;
        if(!changePassword)
         {
            $scope.errorMessage.push(translateMessages($translate, "settings.mandatoryFieldsMessage"));
            $scope.isSearchInValid = true;
         }
        else {
            var i;
            if(Object.keys(changePassword).length==3) {
                for(i=0; i < Object.keys(changePassword).length; i++) {
                    if(!changePassword[Object.keys(changePassword)[i]]) {
                        $scope.error = true;
                        $scope.errorMessage.push(translateMessages($translate, "settings.mandatoryFieldsMessage"));
                        $scope.isSearchInValid = true;
                        break;
                    }
                }
            }
            else {
                $scope.error = true;
                $scope.errorMessage.push(translateMessages($translate, "settings.mandatoryFieldsMessage"));
                $scope.isSearchInValid = true;
            }
            if(!$scope.error) {
                if(changePassword.newPassword== changePassword.confirmPassword) {
					$scope.validatePasswordPattern(changePassword.newPassword);
					if($scope.errorMessage.length == 0){
                        $scope.updatePassword(changePassword);
					} else{
						$scope.isSearchInValid = true;
					}
                }
                else {
                    $scope.errorMessage.push(translateMessages($translate, "settings.passwordMismatch"));
                    $scope.isSearchInValid = true;
                }
            }
        }
    }
     $scope.validatePasswordPattern = function(newPassword){
        $scope.errorMessage = [];
        var userID = $rootScope.username.toLowerCase();
        var password = newPassword.toLowerCase();
        var agentCode = userID.split('');
        var count = [];
       /* var len = 0;
        for(var i=0; i<agentCode.length; i++){
            len = password.split(agentCode[i]).length - 1
            if( len > 0){
                count.push(len);
            }
        }*/
     	if(newPassword && !$scope.passwordPattern.test(newPassword)){
              $scope.passwordError = true;
              $scope.errorMessage.push(translateMessages($translate, "settings.passwordValidationMsg"));
              $scope.isSearchInValid = true;
     	} else {
             $scope.passwordError = false;
         }
     }
    $scope.updatePassword = function(changePassword) {
        var transactionObj = $scope.mapScopeToPersistance();
        transactionObj.TransactionData = {
            "password": CryptoJS.SHA512(changePassword.newPassword).toString(CryptoJS.enc.Hex),
            "oldPassword": CryptoJS.SHA512(changePassword.currentPassword).toString(CryptoJS.enc.Hex)
        }
        showHideLoadingImage(true, "Loading..");
		if((rootConfig.isDeviceMobile && checkConnection()) || !rootConfig.isDeviceMobile){
			dataService.searchTransactions(transactionObj, $scope.getTransactionSuccess, $scope.getTransactionError);
		}else{
			$scope.getTransactionError();
		}  
    }
    
    $scope.redirectLogin = function() {
        $rootScope.completeLogOut();
    }
    
    $scope.getTransactionSuccess = function(data) {
        var status = data[0].TransactionData.StatusData;
        $scope.validSearch = true;
        if(status.Status==='SUCCESS') {
            $scope.successfullPasswordChange = true;
        }
        else {
            switch(status.StatusCode) {
                case "100":
                    $scope.successfullPasswordChange = true;
                    break;
                case "503": 
                    $scope.updateResult= translateMessages($translate, "settings.incorrectPassword");
                    break;
                case "502": 
                    $scope.updateResult= translateMessages($translate, "settings.invalidUser"); 
                    break;
                case "504":
                    $scope.updateResult= translateMessages($translate, "settings.resetPasswordError"); break;
				case "404":
				case "300":
					$scope.errorPasswordChange = true;
					$scope.updateResult=settings.passwordChangeEmailErrorMessage;
					break;
				case "500":
					$scope.errorPasswordChange = true;
					$scope.updateResult=settings.passwordChangeUnsuccess;
					break;
				case "501":
					$scope.errorPasswordChange = true;
					$scope.updateResult=settings.passwordChangeError;
					break;
                default: $scope.validSearch = false;
            }
        }
        showHideLoadingImage(false, "Loading..");
        $scope.$apply();
    }
    
    $scope.getTransactionError = function(data) {
        $rootScope.serviceFailed=true;
        showHideLoadingImage(false);
        if (rootConfig.isDeviceMobile && !checkConnection()) {
			$scope.message = translateMessages($translate, "networkValidationErrorMessage");
		}else{
			$scope.message = translateMessages($translate, "validToken");
		}
        $scope.$emit('tokenEvent', { message: $scope.message });
        if (data == "Error in ajax callE")
            {
                 $scope.onServerError=true;
                 $scope.serverErrorMessage= translateMessages($translate, "serverErrorMessage");
				 showHideLoadingImage(false,"Customer Contact",null,null);
             }
             else {
                 showHideLoadingImage(false,"Customer Contact",null,null);
             }
         $rootScope.$apply();
    };
    
    $scope.switchTab = function(tabName) {
        switch(tabName) {
            case 'password': $scope.dvPassword=true;
                                   $scope.dvSecurityQuestion=false;
								   break;
            case 'question': $scope.dvSecurityQuestion=true;
                                   $scope.dvPassword=false;
								   break;
			default:break;
        }
    };
    
    $scope.updateSecretQues = function() {
        $scope.questionValidSearch = false;
        $scope.questionErrorMessage=[];
        if(!$scope.securityQuestion || !$scope.secretAnswer) {
            $scope.questionErrorMessage.push(translateMessages($translate, "settings.mandatoryFieldsMessage"))
        }
        else {
            var transObj = $scope.mapScopeToPersistance();
            var securityOptions = {
                 "securityOptions": {
                      "questionCode": $scope.securityQuestion,
                      "answer": $scope.secretAnswer
                  }
            };
            transObj.TransactionData = securityOptions;
            transObj.Type = "CreateSecurityQuestion";
            showHideLoadingImage(true, "Loading..");   
			if((rootConfig.isDeviceMobile && checkConnection()) || !rootConfig.isDeviceMobile){
				dataService.searchTransactions(transObj,$scope.saveSecretQuesSuccess,$scope.getTransactionError);
			}else{
				$scope.getTransactionError();
			}  	
        }
    }
    
    $scope.saveSecretQuesSuccess = function(data){
        	if(data[0] && data[0].TransactionData !== null){
                var statusCode = data[0].TransactionData.StatusData.StatusCode;
                showHideLoadingImage(false);
                if(statusCode === "200"){
                    $scope.questionValidSearch = true;
                    $scope.updateQuestionResult = translateMessages($translate, "settings.secretQuestionSuccessMessage");
                }
                 else {
					$scope.questionValidSearch = true;
					switch(status.StatusCode) {
					case "502": 
                    $scope.updateQuestionResult= translateMessages($translate, "settings.invalidUser"); 
                    break;
					case "404":
					case "300":
					$scope.updateQuestionResult=translateMessages($translate, "settings.secretQuestionChangeEmailErrorMessage");
					break;
					case "500":
					$scope.updateQuestionResult=translateMessages($translate, "settings.secretQuestionChangeError");
					break;
				}
			
            }
             $scope.$apply();
        	}
        };
	
}]);







