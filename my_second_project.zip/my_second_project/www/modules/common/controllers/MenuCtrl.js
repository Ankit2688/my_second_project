mServiceApp
		.controller(
				'MenuCtrl',
				[
						'$controller',
						'$rootScope',
						'$scope',
						'$compile',
						'$route',
						'$routeParams',
						'$location',
						'$translate',
						'dataService',
						'appDataShareService',
						'authService',
						'AutoSync',
						'debounce',
						'$timeout',
						'$filter',
						'ngTableParams','commonConfig','loginConfig','UtilityService',
						function($controller, $rootScope, $scope, $compile,
								$route, $routeParams, $location, $translate,
								dataService, appDataShareService, authService,
								AutoSync, debounce, $timeout, $filter,
								ngTableParams,commonConfig,loginConfig,UtilityService) {

							$rootScope.selectedUser = translateMessages($translate, "myTeam");
							$scope.selectedTheme = "MainTheme";
							$scope.themes = [ {
								"key" : "MainTheme",
								"value" : "Theme 1"
							}, {
								"key" : "ABCTHEME",
								"value" : "Theme 2"
							} ];
							$scope.showPopup = false;
							$rootScope.isSwitchUser = false;
							$rootScope.isBackButtonDisbaled = true;
							$rootScope.majorVersion = rootConfig.majorVersion;
							$rootScope.minorVersion = rootConfig.minorVersion;
							$rootScope.appDownloadURLAndroid = rootConfig.appDownloadURLAndroid;
							$scope.totalPNcount = function() {
								return pushArray.length;
							};
							$scope.showAlertTab = function() {
								showActivityFlag = true;
								showAlertClickedFlag = true;

								if (navigator.network.connection.type == Connection.NONE)// offline
								{
									$('#networkConnectionChkId').modal('show');
									showAlertClickedFlag = false;
								} else {
									$location.path("/alerts");
									$route.reload();
								}
							}
							$scope.onNotificationAPN1 = function() {
								// alert("onNotificationAPN1 reached");
								onNotificationAPN2();
							}

							Object.getPrototypeOf($rootScope).refresh = function(delay,callback) {
                                var time;
                                if (!delay) {
                                    time = 0;
                                }
                                $timeout(function(){
                                    if(callback){
                                        callback();
                                    }
                                },time);
                            };
                            Object.getPrototypeOf($scope).refresh = function(delay,callback) {
                                var time;
                                if (!delay) {
                                    time = 0;
                                }
                                $timeout(function(){
                                    if(callback){
                                        callback();
                                    }
                                },time);
                            };


							$scope.$watch('isBackButtonDisbaled', function(
									value) {
								if (!value) {
									$rootScope.isBackButtonDisbaled = true;
									$('#dvShowBackButtonAlertBox')
											.modal('show');
									$scope.refresh();
								}

							});

							

							$scope.routeIs = function(routeName) {
								var s = $location.path();
								if (s.indexOf(routeName) >= 0) {
									return true;
								} else {
									return false;
								}
							};
							
							$scope.navigateToURL= function(path){
								 window.open(path, '_system');
							}
							$scope.$on('$routeChangeStart', function(next,
									current) {
								hidePopUps();

							});

							$scope.initiateSync = function() {
								pushArray = [];
								$rootScope.$broadcast(commonConfig().STATUS.IS_DEVICE_ONLINE,["true"]);
							}

							$scope.clearFilteredData = function() {

								$scope.$broadcast(commonConfig().STATUS.CLEAR_FILTER);

							}
							$scope.showBreadCrump = true;
							$scope.getBreadcrump = function() {
								$scope.mainHeader = translateMessages($translate, "appHeader");
								// return $location.path();
								var str = $location.path();
								var strTemp;
								str = str.substr(1);
								strTemp = str;
								var strTemp1 = str;

								if (str.indexOf('/') != -1) {
									str = str.substr(0, str.indexOf('/'));
								}
								if (strTemp.lastIndexOf('/') != -1) {
									strTemp = strTemp.substr(0, strTemp
											.lastIndexOf('/'));
								}
								var message;

								if (strTemp1.indexOf('/') != -1) {

									strTemp1 = strTemp1.substr(strTemp1
											.lastIndexOf("/") + 1);

								}
								switch (str) {

								case commonConfig().LOCATION.DASHBOARD:
									if (navigator.userAgent.search(commonConfig().SEARCH_OPTION.MSIE) >= 0) {
										message = ",";
									} else {
										message = translateMessages($translate,
												"", "");
									}
									$scope.showBreadCrump = false;
									$scope.mainHeader = translateMessages($translate, "dashboardHeader");

									break;

								case commonConfig().LOCATION.ALERTS:
									if (navigator.userAgent.search(commonConfig().SEARCH_OPTION.MSIE) >= 0) {
										message = commonConfig().MESSAGE.ALERTS;
									} else {
										message = translateMessages($translate,
												"AlertHeader", "");
									}
									$scope.showBreadCrump = true;
									break;

								case commonConfig().LOCATION.SELF_SERVICE:
									if (navigator.userAgent.search(commonConfig().SEARCH_OPTION.MSIE) >= 0) {
										message = commonConfig().MESSAGE.SELF_SERVICE;
									} else {
										message = translateMessages($translate,
												"selfserviceHeader", "");
									}
									$scope.showBreadCrump = true;
									break;

								case commonConfig().LOCATION.CUSTOMER_SERVICE:
									if (navigator.userAgent.search(commonConfig().SEARCH_OPTION.MSIE) >= 0) {
										message = commonConfig().MESSAGE.CUSTOMER_SERVICE;
									} else {
										message = translateMessages($translate,
												"mycustomerHeader", "");

									}
									$scope.showBreadCrump = true;
									break;

								}
								return message;
							}

							$scope.logout = function() {

								/*if (rootConfig.isDeviceMobile) {
									if (PushMsgRegisteredID) {
										if (navigator.network.connection.type == Connection.NONE) {
											$('#dvShowDecisionBox').modal(
													'show');
											$scope.refresh();
										} else {
											showHideLoadingImage(true,
													"loggingout", $translate);
											unRegisterPushnotification();
										}
									} else {
										$rootScope.completeLogOut();
									}

								} else {
									$rootScope.completeLogOut();
								}*/
								$rootScope.completeLogOut();
							}

							$rootScope.completeLogOut = function() {

								if (!rootConfig.isDebug) {
									for (key in localStorage) {

										if (key != getUniqueAppNamePattern(commonConfig().PAGE_DETAILS.LOGIN)
												&& key != getUniqueAppNamePattern(commonConfig().PAGE_DETAILS.INITIAL_LOGIN)
												&& key != getUniqueAppNamePattern(commonConfig().PAGE_DETAILS.LAST_SYNCED)
												&& key != getUniqueAppNamePattern(commonConfig().PAGE_DETAILS.MCONTENTROLES)
												&& key != getUniqueAppNamePattern(commonConfig().PAGE_DETAILS.AA)
												&& key != getUniqueAppNamePattern(commonConfig().PAGE_DETAILS.AGENT)
												&& key != getUniqueAppNamePattern(commonConfig().PAGE_DETAILS.VERSION)) {

											delete localStorage[key];
										}
									}
								}

								// PushMsgRegisteredID=null;

								if (!(rootConfig.isDeviceMobile)) {
									localStorage
											.removeItem(getUniqueAppNamePattern(commonConfig().PAGE_DETAILS.INITIAL_LOGIN));
									localStorage.setItem(getUniqueAppNamePattern(commonConfig().PAGE_DETAILS.MCONTENTROLES),
											commonConfig().STATUS.NOT_AUTHENTICATED);
								}
								appDataShareService.alert.selectedFilter = commonConfig().FILTER.TODAY;
								appDataShareService.dashboard.selectedFilter = commonConfig().FILTER.MEETING;
								appDataShareService.alertBusinessOverview.selectedFilter = commonConfig().FILTER.YTD;
								appDataShareService.user.reporties = [];
								appDataShareService.mybusinessjson = {};
										appDataShareService.alertjson = {},
										appDataShareService.policysearchjson = {},
										appDataShareService.proposalsearchjson = {},
										appDataShareService.premiumcalenderjson = {},
										appDataShareService.myearningsjson = {},
										appDataShareService.mypotentialtoearnjson = {},
										appDataShareService.myrrjson = {},
										appDataShareService.recruitmentdashboardjson = {},
										appDataShareService.admDashboardjson = {},
										appDataShareService.salesleadjson = {},
										appDataShareService.isSwitchEnabled = false;
								appDataShareService.performanceJson = {};
								appDataShareService.pottentialJson = {};
								appDataShareService.refreshApp = true;
								$rootScope.isAuthenticated = false;
								$rootScope.isRelationshipManagement = "";
								$rootScope.isEarningOpportunity = "";
								sessionStorage.removeItem("currentUser");
								$rootScope.username = "";
								$rootScope.agentId = "";
								$rootScope.authenticationStatus = "";
								$rootScope.loggedInUser = "";
								$rootScope.IntialloggedInUser = "";
								$rootScope.syncProgress = 0;
								$rootScope.lastSuccessSyncDate = "";
								$rootScope.syncMessage = "";
								$rootScope.isAGT = false;
								$rootScope.isAA = false;
								$rootScope.isShowADM = false;
								DeviceUserID = "";
								sessionStorage.fromApp = '';
								$rootScope.lastSyncedDate = "";
								$rootScope.syncLabel = "";
								$rootScope.selectedUser = translateMessages($translate,"myTeamHeader");
								$rootScope.selectedAlertFilter = "";
								$rootScope.transactionId = "";
								$rootScope.showChart = "";
								$rootScope.selectedRecruitmentFilter = "";
								$rootScope.selectedLeadSourceFilter = "";
								$rootScope.selectedLeadSourceFilter = "";
								$rootScope.selectedDashboardFilter = "";
								$location.path('/login');
								showHideLoadingImage(false);
								$scope.showPopup = false;
								$rootScope.isSessionExpired = false;
								$scope.$apply();
								$scope.refresh();
							}

							/*
							 * $scope.showDecisionPopup = function(index) {
							 * $('#dvShowLeadDetails').modal('show'); }
							 */

							$scope.hideDecisionBox = function() {
								$('#dvShowDecisionBox').modal('hide');
								showHideLoadingImage(false);
							}

							$scope.userLogOut = function() {
								$('#dvShowDecisionBox').modal('hide');
								$rootScope.completeLogOut();
							}
							var unRegisterPushnotification = function() {
								pushArray = [];
								var successHandleriOS = function(res) {

									unRegisterPushnotificationToServer(
											PushMsgRegisteredID, loginConfig().DEVICE_TYPE.IOS,
											rootConfig.iOSAppBundleIdentifier);
								}
								var errorHandleriOS = function(error) {

								}

								var successHandler = function(res) {

									unRegisterPushnotificationToServer(
											PushMsgRegisteredID, loginConfig().DEVICE_TYPE.ANDROID,
											rootConfig.AndroidPackageName);
								}
								var errorHandler = function(error) {

								}

								var pushNotification = window.plugins.pushNotification;

								if (/Android/i.test(navigator.userAgent)) {// do
									// it
									// with
									// agent
									// id
									// and
									// reg
									// id
									pushNotification.unregister(successHandler,
											errorHandler);

								} else if (/iPhone|iPad|iPod/i
										.test(navigator.userAgent)) {
									pushNotification.unregister(
											successHandleriOS, errorHandleriOS);
								}

							}

							var unRegisterPushnotificationToServer = function(
									token, deviceType, appId) {
								var requestInfo = PushNotificationRequest();
								requestInfo.MobileAppBundleID = appId;
								requestInfo.DeviceType = deviceType;
								requestInfo.PushMsgRegisteredID = token;
								requestInfo.DeviceUserID = DeviceUserID;
								requestInfo.TruJunctionAPPName = "eServe"

								var successcallback = function(res) {
									PushMsgRegisteredID = null;
									$rootScope.completeLogOut();
								}

								var errorcallback = function(error) {
									$rootScope.completeLogOut();
								}
								PushNotificationService.unRegisterdevice(
										requestInfo, successcallback,
										errorcallback); // register with the
								// service

							}

							$scope.selectedUserObj;
							$rootScope.loggedInUser = appDataShareService.selectedUser.name;

							$scope.filterChange = function(value) {
								
								$scope.showPopup = false;
								$scope.selectedUserObj = value;
								$rootScope.selectedUser = $scope.selectedUserObj.reporteeId;
								///appDataShareService.selectedUser.userName = $scope.selectedUserObj.reporteeName;
								//appDataShareService.selectedUser.userId = $scope.selectedUserObj.reporteeId;
								$rootScope.loggedInUser = $scope.selectedUserObj.reporteeName;

								//appDataShareService.reporties = value;
								appDataShareService.mybusinessjson = {};
								appDataShareService.alertjson = {};
								appDataShareService.policysearchjson = {};
								appDataShareService.proposalsearchjson = {};
								appDataShareService.premiumcalenderjson = {};
								appDataShareService.myearningsjson = {};
								appDataShareService.mypotentialtoearnjson = {};
								appDataShareService.myrrjson = {};
								appDataShareService.recruitmentdashboardjson = {};
								appDataShareService.salesleadjson = {};
								appDataShareService.isSwitchEnabled = true;
								appDataShareService.performanceJson = {};
								appDataShareService.pottentialJson = {};
								appDataShareService.admDashboardjson = {};
								if (rootConfig.isDeviceMobile){
								$scope.initiateSync();
								}
								
							/*	appDataShareService.refreshApp = true;
								appDataShareService.mybusinessjson = {};
								appDataShareService.alertjson = {};
								appDataShareService.policysearchjson = {};
								appDataShareService.proposalsearchjson = {};
								appDataShareService.premiumcalenderjson = {};
								appDataShareService.myearningsjson = {};
								appDataShareService.mypotentialtoearnjson = {};
								appDataShareService.myrrjson = {};
								appDataShareService.recruitmentdashboardjson = {};
								appDataShareService.salesleadjson = {};
								appDataShareService.isSwitchEnabled = true;
								appDataShareService.performanceJson = {};
								appDataShareService.pottentialJson = {};
								appDataShareService.admDashboardjson = {};
								showActivityFlag = false;
								globalPushReceived = true;
								appDataShareService.alert.selectedFilter = "today";
								$scope.$broadcast('clearFilter');

								if (navigator.userAgent.search(commonConfig().SEARCH_OPTION.MSIE) >= 0) {
									showHideLoadingImage(true,
											"Loading User Details", null,
											"MenuCtrl");
								} else {
									showHideLoadingImage(true,
											"Loading User Details", $translate,
											"MenuCtrl");
								}
								authService
										.getUserDetails(
												{
													username : $rootScope.selectedUser
												},
												function(res) {
													if (res.information != undefined) {
														if (res.information.designation == "AGT") {
															$rootScope.isAGT = true;
															sessionStorage.isAGT = true;
														} else {
															$rootScope.isAGT = false;
															sessionStorage.isAGT = false;
														}

														if (res.information.designation == "AA") {

															$rootScope.isAA = false;
															sessionStorage.isAA = false;
														} else {
															$rootScope.isAA = true;
															sessionStorage.isAA = true;
														}
														if (res.information.designation == "PSA"
																|| res.information.designation == "SAD"
																|| res.information.designation == "AAM"
																|| res.information.designation == "SAP"
																|| res.information.designation == "APA"
																|| res.information.designation == "ADM") {

															$rootScope.isShowADM = true;
															sessionStorage.isShowADM = true;
														} else {
															$rootScope.isShowADM = false;
															sessionStorage.isShowADM = false;
														}
													} else {
														$rootScope.isShowADM = false;
														sessionStorage.isShowADM = false;
														$rootScope.isAGT = true;
														sessionStorage.isAGT = true;
														$rootScope.isAA = true;
														sessionStorage.isAA = true;
													}

													if ($location.path() == "/customerService/policySearch"
															|| $location.path() == "/customerService/proposalSearch") {
														$rootScope.isSwitchUser = true;
													}

													if ($location.path() == "/selfService/myBusiness/performance-dashboard"
															&& $rootScope.isAA) {

														$location
																.path("/selfService/myBusiness");
													}

													if ($location
															.path()
															.search(
																	"adm-Dashboard") != -1
															&& !($rootScope.isShowADM)) {

														$location
																.path("/dashboard");

													}
													
													if ($location
															.path()
															.search(
																	"recruitmentDashboard") != -1
															&& ($rootScope.isAGT)) {

														$location
																.path("/dashboard");

													}
													
													$route.reload();
													$scope.$apply();
													showHideLoadingImage(false,
															null, null,
															"MenuCtrl");

												},
												function(err) {
													showHideLoadingImage(false,
															null, null,
															"MenuCtrl");
													
												});*/
								if ($rootScope.selectedUser == $rootScope.IntialloggedInUser) {
									$rootScope.selectedUser = translateMessages($translate,"myTeamHeader");
								}

							}

							$scope.loadSelfData = function() {

								$rootScope.selectedUser = translateMessages($translate,"myTeamHeader");
								appDataShareService.selectedUser.userName = appDataShareService.selectedUser.name;
								if ($rootScope.IntialloggedInUser != undefined) {
									appDataShareService.selectedUser.userId = $rootScope.IntialloggedInUser;
								}
								$rootScope.loggedInUser = appDataShareService.selectedUser.userName;
								appDataShareService.refreshApp = true;
								$route.reload();
							}
							
							
							 $rootScope.$on('tokenEvent', function (event, args) {
								 $scope.tokenAlertMessage = args.message;
								 /* $scope.showExpiryAlert = true; */
								 $('#showExpirymsg').modal();
								 console.log($scope.tokenAlertMessage);
							});
							
							$scope.hideExpiryMessagePopup = function() {
								  $scope.showExpiryAlert = false;
								 // sessionStorage.removeItem("currentUser");
								 // $location.path('/login');
								  $rootScope.completeLogOut();
								  $scope.$apply();
							
							}
							
							$scope.onThemeChange = function(themeName) {
								if (!(angular.isDefined(themeName))) {
									themeName = $scope.selectedTheme;
								}
								UtilityService.initiateThemeChange(themeName);
								//$scope.hideThemePopup();
							};

							if (rootConfig.isDeviceMobile){
                                document.addEventListener("backbutton", function(e){
                                e.preventDefault();
                                if($('.modal.share-popup').hasClass('in')) {
                                	$('.modal.share-popup').removeClass('in');
                                	$('.modal-backdrop.fade').removeClass('in');
                                }
                                else {
                                    if($location.path()=="/dashboard") {
                                        if(confirm('Do you want to logout?')) {
                                            $rootScope.completeLogOut();
                                        }
                                    }
                                    else if($location.path()=="/login") {
                                        if(confirm('Do you want to exit?')) {
                                            navigator.app.exitApp();
                                        }
                                    }
                                    else
                                        window.history.back();
                                    }
                                }, false);

                                var logoutInactive;
                                function onAppPause() {
                                    if($rootScope.isAuthenticated) {
                                        logoutInactive = $timeout(function() {
                                            $rootScope.isSessionExpired = true;
                                            $timeout.cancel(logoutInactive);
                                        }, rootConfig.autoSignOff);
                                    }
                                }
                                function onAppResume() {
                                    if($rootScope.isAuthenticated) {
                                        $timeout.cancel(logoutInactive);
                                    }
                                }
                                /*function onAppResume() {
                                    if($rootScope.isAuthenticated && !$rootScope.isSessionExpired) {
                                        $timeout.cancel(logoutInactive);
                                        logoutInactive = $timeout(function() {
                                            $rootScope.isSessionExpired = true;
                                            $timeout.cancel(logoutInactive);
                                        }, 15000);
                                    }
                                }
                                document.addEventListener("touchstart", onAppResume);
                                */
                                document.addEventListener("resume", onAppResume);
                                document.addEventListener("pause", onAppPause);
                            }
						} ]);
