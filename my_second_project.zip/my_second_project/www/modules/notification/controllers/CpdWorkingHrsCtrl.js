mServiceApp.controller('CpdWorkingHrsCtrl',['$controller','$rootScope', '$scope',  '$compile', '$route', '$routeParams', '$location', '$translate','dataService',
'appDataShareService','AutoSync','debounce','$timeout','$filter','mServiceConstants','commonConfig','customerServiceConfig','gli_dataservice','PersistenceMapping',function($controller ,$rootScope, $scope,
$compile, $route, $routeParams, $location, $translate,dataService,appDataShareService,AutoSync,debounce,$timeout,$filter,mServiceConstants,commonConfig,customerServiceConfig,gli_dataservice,PersistenceMapping) {
	$scope.isFromFooter = "false";
	$scope.isValid = false;
    $scope.isSearchInValid = false;
	$scope.initialData = {};
	$scope.selectedpage = commonConfig().PAGE_NAME.CPD_HOURS_TRACKING;
	$scope.noData = true;
	$scope.paintUISuccess = function (callbackId, data) {
		//showHideLoadingImage(false);
		$scope.isPainted = true;
    };
	
	$scope.reset = function() {
		$scope.cpdTraining.branch = "";
		$scope.cpdTraining.dateFrom = "";
		$scope.cpdTraining.dateTo = "";
		$scope.CPDTrainingCalendar = [];
		$scope.errorMessage = [];
		$scope.NoDataRes = false;
		$scope.$apply();
	}
	
	
	$scope.mapScopeToPersistance = function(type) {
	    var newDate = new Date();
	    PersistenceMapping.clearTransactionKeys();
        PersistenceMapping.Key2 = $rootScope.username;
        PersistenceMapping.Key5 = "Agent";
        PersistenceMapping.Type = type;
        var transactionObj =  PersistenceMapping.mapScopeToPersistence({});
        return transactionObj;
    };
	$scope.initialLoad = function(){
		$scope.errorMessage = [];
		if($route.current.loadedTemplateUrl.lastIndexOf('notification.htm') !== -1){
			$scope.isFromFooter = "true";
		}
		else{
			$scope.isFromFooter = "false";
		}
		//For agent code dropdown values
		var transactionObj = $scope.mapScopeToPersistance();
        transactionObj.Type = "AgentCode";
        dataService.searchTransactions(transactionObj,$scope.getTransactionSuccessAgentCode,$scope.getTransactionError);
		 //For branch drop down values
        var transactionObj = $scope.mapScopeToPersistance();
        transactionObj.Type = "retrieveCpdBranchList";
        dataService.searchTransactions(transactionObj,$scope.getTransactionSuccessBranch,$scope.getTransactionError);
   		$scope.cpdTraining = {};
    	$scope.cpdTraining.agentNo = "";
    	$scope.cpdTraining.agentNo = $rootScope.username;
		$scope.retrieveCPDHours($rootScope.username);
		var cur = new Date();
		var after30days = new Date(cur.setDate(cur.getDate() + 30));
		$scope.initialData.dateFrom = getFormattedDate();
		$scope.initialData.dateTo = getFormattedDateFromDate(after30days);
		$scope.cpdTraining.dateFrom = $scope.initialData.dateFrom;
		$scope.cpdTraining.dateTo = $scope.initialData.dateTo;
		$scope.searchCpdTraining($scope.initialData);
	};
	
	$scope.getTransactionSuccessAgentCode = function(data){
		$scope.agentCodeDropDownList=[];
		if(data[0] !== undefined && data[0].TransactionData !== null)
		 {
			if (data[0].TransactionData.mappedIds.length !== 0) {
				$scope.agentCodeDropDownList = data[0].TransactionData.mappedIds;
				if($scope.agentCodeDropDownList.indexOf($scope.cpdTraining.agentNo) < 0)
				$scope.agentCodeDropDownList.push($scope.cpdTraining.agentNo);
				$scope.agentCodeDropDownList.reverse();
				$scope.$apply();
			}
		 }
		else{
			   $scope.agentCodeDropDownList=[];
		}
	};
	
	$scope.getTransactionSuccessBranch = function(data){
		$scope.branchDropDownList=[];
		if(data[0] !== undefined && data[0].TransactionData !== null)
		 {
			if (data[0].TransactionData.branchOffices.length !== 0) {
				$scope.branchDropDownList = data[0].TransactionData.branchOffices;
				$scope.$apply();
			}
		 }
		else{
			   $scope.branchDropDownList=[];
		}
	};
	
	
	$scope.retrieveCPDHours = function(userName){
		$scope.noData = true;
        $scope.CPDHours = [];
		$scope.agentNo = userName;
		var transactionObj = $scope.mapScopeToPersistance("CPDHoursTracking");
		var searchObj = {
				"SearchCriteria": {
					"agentNumber": $scope.agentNo
                }
			};
		transactionObj.TransactionData = searchObj;
		showHideLoadingImage(true, "Loading CPD hours", $translate);
		 if((rootConfig.isDeviceMobile && checkConnection()) || !rootConfig.isDeviceMobile){
			gli_dataservice.searchTransactions(transactionObj, $scope.getTransactionSuccess, $scope.getTransactionError);
			//$scope.getTransactionSuccess($scope.CPDHours);
		}else{
			$scope.getTransactionError();
		}
	};
	$scope.getTransactionSuccess = function(data) {
		$scope.cpdYear1 = "";
        $scope.cpdCount1 = "";
        $scope.cpdYear2 = "";
        $scope.cpdCount2 = "";
		showHideLoadingImage(false,null,null,"CPD hours");
		$scope.CPDHours = [];
		$scope.errorMessage = [];
		var d = new Date();
		var n = d.getFullYear();
		$scope.year = n.toString();
		$scope.noData = false;
		 if(data[0] !== undefined){
			if(data[0].TransactionData !== null) {
				if (data[0].TransactionData.length !== 0) {
					if(data[0].TransactionData.CdpHoursSummary.length !== 0){
						$scope.noData = false;
						$scope.CPDHours = data[0].TransactionData.CdpHoursSummary;
						for(var i=0;i<$scope.CPDHours.length;i++){
							if($scope.CPDHours[i].cdpYear == $scope.year){
								$scope.cpdYear1 = $scope.CPDHours[i].cdpYear;
								$scope.cpdCount1 = $scope.CPDHours[i].totalCpdHours;
							}
							else{
								$scope.cpdYear2 = $scope.CPDHours[i].cdpYear;
								$scope.cpdCount2 = $scope.CPDHours[i].totalCpdHours;
							}
						}
						
					}else{
						$scope.noData = true;
						$scope.errorMessage = [];
						$scope.searchFailedMessage = translateMessages($translate, "policySearch.noDataMessage");
    		            $scope.errorMessage.push($scope.searchFailedMessage);
    		            $scope.$apply();
					}
				}else {
					$scope.errorMessage = [];
					$scope.searchFailedMessage = translateMessages($translate, "claimAlerts.searchFailedMessage");
		            $scope.errorMessage.push($scope.searchFailedMessage);
		            $scope.$apply();
				}
			}
		 }else {
				$scope.errorMessage = [];
				$scope.searchFailedMessage = translateMessages($translate, "claimAlerts.searchFailedMessage");
	            $scope.errorMessage.push($scope.searchFailedMessage);
	            $scope.$apply();
	     }
		 showHideLoadingImage(false);
		 $scope.refresh();
	};
	
	$scope.validateFields = function(cpdTraining){
		$scope.NoDataRes = true;
        $scope.CPDTrainingCalendar = [];
		$scope.cpdTraining = cpdTraining;
		if($scope.cpdTraining.dateFrom && $scope.cpdTraining.dateTo){
			if(!isDateWithinSixtyPastFuture($scope.cpdTraining.dateFrom) || !isDateWithinSixtyPastFuture($scope.cpdTraining.dateTo)){
	        	$scope.errorMessage = [];
	        	$scope.searchResult = [];
	        	$scope.isSearchInValid = true;
	        	$scope.isValid = true;
				$scope.dateRangeSixtyValidationMessage = translateMessages($translate, "policySearch.dateRangeSixtyValidationMessage");
	            $scope.errorMessage.push($scope.dateRangeSixtyValidationMessage);
	        } else if($scope.cpdTraining.dateTo < $scope.cpdTraining.dateFrom){
	        	$scope.errorMessage = [];
	        	$scope.searchResult = [];
	        	$scope.isSearchInValid = true;
	        	$scope.isValid = true;
				$scope.dateRangeSixtyValidationMessage = translateMessages($translate, "policySearch.fromGreaterthanToValidationMessage");// have'nt got the error message
	            $scope.errorMessage.push($scope.dateRangeSixtyValidationMessage);
	        }
	        else{
	        	$scope.isSearchInValid = false;
	        	$scope.isValid = false;
	        }
		}else if(($scope.cpdTraining.dateFrom && !$scope.cpdTraining.dateTo) || (!$scope.cpdTraining.dateFrom && $scope.cpdTraining.dateTo)){
			$scope.isSearchInValid = true;
        	$scope.isValid = true;
        	$scope.errorMessage = [];
			$scope.fromTodateValidationErrorMessage = translateMessages($translate, "policySearch.fromTodateValidationErrorMessage");
			$scope.errorMessage.push($scope.fromTodateValidationErrorMessage);
		}
		else{
        	$scope.isSearchInValid = false;
        	$scope.isValid = false;
        }
	
		
	       if($scope.isValid){
		  //errror message
		     $scope.isSearchInValid = true;
		   }
		   else{
		     $scope.isSearchInValid = false;
			 $scope.searchCpdTraining($scope.cpdTraining);
		   }
	}
	
	
	$scope.searchCpdTraining = function(cpdTraining){

		   $scope.cpdTraining1 = cpdTraining;
		   var transactionObj = $scope.mapScopeToPersistance("CPDTrainingCalendar");
		   if($scope.cpdTraining1.dateFrom && $scope.cpdTraining1.dateTo){
			   $scope.cpdDateFrom = $filter('date')($scope.cpdTraining1.dateFrom, "yyyy-MM-dd");
		       $scope.cpdDateTo = $filter('date')($scope.cpdTraining1.dateTo, "yyyy-MM-dd");
		   }
		   else{
			   $scope.cpdDateFrom = "";
			   $scope.cpdDateTo = "";
		   }
			if($scope.cpdTraining1.branch){
				$scope.branch = $scope.cpdTraining1.branch;
			}
			else{
				$scope.branch = "";
			}
			var searchObj = {
					"SearchCriteria": {
						"branchOffice": $scope.branch,
	                    "trainingDateFrom": $scope.cpdDateFrom,
	                    "trainingDateTo": $scope.cpdDateTo
	                }
			};
			$scope.searchFieldCount = 0;
			$scope.searchFieldEmptyCount = 0;
			Object.keys(searchObj.SearchCriteria).forEach(function(key) {
				  if (searchObj.SearchCriteria[key] == "") {
					  $scope.searchFieldEmptyCount++;
				  }
			});
			//To get count of searchObj
			Object.keys(searchObj.SearchCriteria).forEach(function(key) {
				  if (searchObj.SearchCriteria) {
					  $scope.searchFieldCount++;
				  }
			});
	        
			if($scope.searchFieldEmptyCount == $scope.searchFieldCount){
				$scope.isSearchInValid = true;
				$scope.NoDataRes = false;
				$scope.validSearch = false;
				$scope.errorMessage = [];
				$scope.minOneSearchFieldValidationMessage = translateMessages($translate, "policySearch.minOneSearchFieldValidationMessage");
	            $scope.errorMessage.push($scope.minOneSearchFieldValidationMessage);

			}
			else{
				$scope.errorMessage = [];
				$scope.isSearchInValid = false;
				transactionObj.TransactionData = searchObj;
				showHideLoadingImage(true,"CPD Training Calendar",null,null);
				if((rootConfig.isDeviceMobile && checkConnection()) || !rootConfig.isDeviceMobile){
					gli_dataservice.searchTransactions(transactionObj, $scope.getCpdTrainingSuccess, $scope.getTransactionError);
					//$scope.getCpdTrainingSuccess($scope.CPDTrainingCaledar);
				}else{
				   $scope.getTransactionError();
				}
			}
		
		
	}
	
	$scope.getCpdTrainingSuccess = function(data) {
		showHideLoadingImage(false,null,null,"CPD Training Calendar");
		$scope.CPDTrainingCalendar = [];
		$scope.errorMessage = [];
		$scope.NoDataRes = false;
		 if(data[0] !== undefined){
			if(data[0].TransactionData !== null) {
				if (data[0].TransactionData.length !== 0) {
					if(data[0].TransactionData.customerStatusResult.length !== 0){
						$scope.NoDataRes = false;
						$scope.CPDTrainingCalendar = data[0].TransactionData.customerStatusResult;
						for(var i=0;i<$scope.CPDTrainingCalendar.length;i++){
							$scope.CPDTrainingCalendar[i].dateTime = $scope.CPDTrainingCalendar[i].trainingDate+' '+$scope.CPDTrainingCalendar[i].trainingTimeFrom+'-'+$scope.CPDTrainingCalendar[i].trainingTimeTo;
						}
					}else{
						$scope.NoDataRes = true;
						$scope.errorMessage = [];
						$scope.searchFailedMessage = translateMessages($translate, "policySearch.noDataMessage");
    		            $scope.errorMessage.push($scope.searchFailedMessage);
    		            $scope.$apply();
					}
				}else {
					$scope.errorMessage = [];
					$scope.searchFailedMessage = translateMessages($translate, "claimAlerts.searchFailedMessage");
		            $scope.errorMessage.push($scope.searchFailedMessage);
		            $scope.$apply();
				}
			}
		 }else {
				$scope.errorMessage = [];
				$scope.searchFailedMessage = translateMessages($translate, "claimAlerts.searchFailedMessage");
	            $scope.errorMessage.push($scope.searchFailedMessage);
	            $scope.$apply();
	     }
		 showHideLoadingImage(false);
		 $scope.refresh();
	};
	
	$scope.getTransactionError = function(data){
		$rootScope.serviceFailed=true;
        if (rootConfig.isDeviceMobile && !checkConnection()) {
			$scope.message = translateMessages($translate, "networkValidationErrorMessage");
		}else{
			$scope.message = translateMessages($translate, "validToken");
		}
        $scope.$emit('tokenEvent', { message: $scope.message });
        if (data == "Error in ajax callE"){
            $scope.onServerError=true;
            $scope.serverErrorMessage= translateMessages($translate, "serverErrorMessage");
            showHideLoadingImage(false,"Loading Claims Alerts",null,null);
        }else{
            showHideLoadingImage(false,"Loading Claims Alerts",null,null);
        }
        $rootScope.$apply();
	};
	$scope.CPDHours=[{
		"TransTrackingID": "",
		"Key30": "",
		"Key10": "",
		"Key11": "",
		"Key23": "",
		"Key24": "",
		"Key25": "",
		"Key26": "",
		"Key27": "",
		"Key28": "",
		"Key29": "",
		"TransactionData": {
			"CdpHoursSummary": [{
				"visible": "N",
				"dateModified": "Oct 10, 2016 12:00:00 AM",
				"agentNumber": "BWN01067",
				"cdpYear": "2015",
				"totalCpdHours": "100"
			}, {
				"visible": "Y",
				"dateModified": "Dec 12, 2017 12:00:00 AM",
				"agentNumber": "BWV01067",
				"cdpYear": "2016",
				"totalCpdHours": "50"
			}]
		},
		"Key20": "",
		"Key21": "",
		"Key22": "",
		"Key2": "BWM01067",
		"Key12": "",
		"Key1": "",
		"Key13": "",
		"Key14": "",
		"Type": "ClaimsLoggedSearch",
		"Key15": "",
		"Key6": "",
		"Key16": "",
		"Key5": "Agent",
		"Key17": "",
		"Key4": "",
		"Key18": "",
		"Key3": "",
		"Key19": "",
		"Key9": "",
		"Key8": "",
		"Id": "resultObject",
		"Key7": ""
	}];
	
	
	$scope.CPDTrainingCaledar = [{
		"TransTrackingID": "",
		"Key30": "",
		"Key10": "",
		"Key11": "",
		"Key23": "",
		"Key24": "",
		"Key25": "1",
		"Key26": "",
		"Key27": "",
		"Key28": "",
		"Key29": "",
		"TransactionData": {
			"cpdTrainingCalResult": [{
				"branchOffice": "",
				"trainingDate": "",
				"trainingTimeFrom": "",
				"trainingTimeTo": "",
				"trainingSubject": "",
				"trainingSpeaker": "",
				"trainingVenue": "",
				"trainingCpdHours": "",
				"visible": ""
			}]
		},
		"Key20": "",
		"Key21": "",
		"Key22": "",
		"Key2": "ACM02804",
		"Key12": "",
		"Key1": "",
		"Key13": "",
		"Key14": "",
		"Type": "PolicyDetails",
		"Key15": "",
		"Key6": "",
		"Key16": "",
		"Key5": "Agent",
		"Key17": "",
		"Key4": "",
		"Key18": "",
		"Key3": "",
		"Key19": "",
		"Key9": "",
		"Key8": "",
		"Id": "resultObject",
		"Key7": ""
	}];
	                 
    $scope.onPartialLoaded=function(element,scope)
	{
		LEDynamicUI.paintUI(rootConfig.template, "cpdhours-ui-json.json", "CPDHours", element, true, $scope.paintUISuccess, $scope, $compile);
	};
	$scope.initialLoad();
}]);
