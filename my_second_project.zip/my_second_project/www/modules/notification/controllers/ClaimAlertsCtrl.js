mServiceApp.controller('ClaimAlertsCtrl',['$controller','$rootScope', '$scope',  '$compile', '$route', '$routeParams', '$location', '$translate','dataService',
'appDataShareService','AutoSync','debounce','$timeout','$filter','mServiceConstants','commonConfig','customerServiceConfig','gli_dataservice','PersistenceMapping',function($controller ,$rootScope, $scope,
$compile, $route, $routeParams, $location, $translate,dataService,appDataShareService,AutoSync,debounce,$timeout,$filter,mServiceConstants,commonConfig,customerServiceConfig,gli_dataservice,PersistenceMapping) {
	$scope.authorizationToken = appDataShareService.authorizationToken;
    var _this = this;
    $scope.isValid = false;
    $scope.isSearchInValid = false;
	$scope.validSearch = false;
	$scope.activeFilter = false;
    $scope.claimAlerts = {};
    $scope.claimAlertDetails = {};
	$scope.noData = false;
    angular.extend(this, $controller('BaseCtrl',{$scope:$scope, $rootScope:$rootScope, dataService:dataService, type:'ClaimsAlert', userId:appDataShareService.selectedUser.userId}));
	$scope.setData = function() {
		$scope.claimAlerts.policyHolderName = "";
		$scope.claimAlerts.claimNumber = "";
		$scope.claimAlerts.policyNumber = "";
		$scope.claimAlerts.claimIncurredDateFrom = "";
		$scope.claimAlerts.claimIncurredDateTo = "";
		$scope.claimAlerts.vehicleRegNo = "";
	};
	// reset the search form fields
	$scope.reset = function() {
		$scope.claimAlerts.policyHolderName = "";
		$scope.claimAlerts.claimNumber = "";
		$scope.claimAlerts.policyNumber = "";
		$scope.claimAlerts.claimIncurredDateFrom = "";
		$scope.claimAlerts.claimIncurredDateTo = "";
		$scope.claimAlerts.vehicleRegNo = "";
		$scope.errorMessage = [];
		$scope.isValid = false;
		$scope.validSearch = false;
		$scope.isSearchInValid = false;
		$scope.noData = false;
	};
	$scope.mapScopeToPersistance = function () {
	    var newDate = new Date();
	    PersistenceMapping.clearTransactionKeys();
        PersistenceMapping.Key1 = this.UserId != null ? this.UserId : "1";
        PersistenceMapping.Key2 = $rootScope.username;
        PersistenceMapping.Key5 = "Agent";
        PersistenceMapping.Key10 = "FullDetails";
        PersistenceMapping.Type = _this.Type;
        var transactionObj =  PersistenceMapping.mapScopeToPersistence({});
        return transactionObj;
    };
	//to retrieve claim alerts with respect to any status change for the past 7 days
	$scope.retrieveClaimAlerts = function(){
		var transactionObj = $scope.mapScopeToPersistance();
		var searchObj = {
				"SearchCriteria" : {
					"policyHolderName" : "",
					"vehicleRegNumber": "",
					"claimNumber" : "",
					"policyNumber" : "",
					"incurredDateFrom" : "",
					"incurredDateTo" : "",
					"days":rootConfig.defaultDayCountAlerts
				 }
		    };
		transactionObj.TransactionData = searchObj;
		showHideLoadingImage(true,"Loading Claims Alerts",null,null);
		if((rootConfig.isDeviceMobile && checkConnection()) || !rootConfig.isDeviceMobile){
			gli_dataservice.searchTransactions(transactionObj, $scope.getTransactionSuccess, $scope.getTransactionError);
		}else{
			$scope.getTransactionError();
		}
	};
	$scope.initialLoad = function(){
		if($route.current.loadedTemplateUrl.lastIndexOf('notification.htm') !== -1){
			$scope.isFromFooter = "true";
		}
		else{
			$scope.isFromFooter = "false";
		}
		var curDate = new Date();
		var past30days = new Date(curDate.setDate(curDate.getDate() - rootConfig.default30DayCount));
		$scope.claimAlerts.claimIncurredDateFrom = getFormattedDateFromDate(past30days);
		$scope.claimAlerts.claimIncurredDateTo = getFormattedDate();
		$scope.retrieveClaimAlerts();
	};
	//To search claim alerts based on various search options for the past 60 days
	$scope.searchClaimAlerts = function(claimAlerts){
		$scope.claimAlerts = claimAlerts;
		var transactionObj = $scope.mapScopeToPersistance();
    	if($scope.claimAlerts.claimIncurredDateFrom && $scope.claimAlerts.claimIncurredDateTo){
    		$scope.claimIncurredDateFrom = $filter('date')($scope.claimAlerts.claimIncurredDateFrom, "yyyy-MM-dd");
        	$scope.claimIncurredDateTo = $filter('date')($scope.claimAlerts.claimIncurredDateTo, "yyyy-MM-dd");

    	}else{
    		$scope.claimIncurredDateFrom = $scope.claimAlerts.claimIncurredDateFrom;
    		$scope.claimIncurredDateTo = $scope.claimAlerts.claimIncurredDateTo;
    	}
		var searchObj = {
				"SearchCriteria" : {
					"policyHolderName" : $scope.claimAlerts.policyHolderName,
					"vehicleRegNumber": $scope.claimAlerts.vehicleRegNo,
					"claimNumber" : $scope.claimAlerts.claimNumber,
					"policyNumber" : $scope.claimAlerts.policyNumber,
					"incurredDateFrom" : $scope.claimIncurredDateFrom,
					"incurredDateTo" : $scope.claimIncurredDateTo
				 }
		    };
		$scope.searchFieldCount = 0;
		$scope.searchFieldEmptyCount = 0;
		Object.keys(searchObj.SearchCriteria).forEach(function(key) {
			  if (searchObj.SearchCriteria[key] == undefined) {
				  searchObj.SearchCriteria[key] = "";
			  }
		});
		Object.keys(searchObj.SearchCriteria).forEach(function(key) {
			  if (searchObj.SearchCriteria[key] == "") {
				  $scope.searchFieldEmptyCount++;
			  }
		});
		//To get count of searchObj
		Object.keys(searchObj.SearchCriteria).forEach(function(key) {
			  if (searchObj.SearchCriteria) {
				  $scope.searchFieldCount++;
			  }
		});
		searchObj.SearchCriteria.days = "";
		if($scope.searchFieldEmptyCount == $scope.searchFieldCount){
			$scope.isSearchInValid = true;
			$scope.validSearch = false;
			$scope.errorMessage = [];
			$scope.claimAlertDetails = [];
			$scope.minOneSearchFieldValidationMessage = translateMessages($translate, "claimAlerts.minOneSearchFieldValidationMessage");
            $scope.errorMessage.push($scope.minOneSearchFieldValidationMessage);

		}else{
			$scope.errorMessage = [];
			$scope.isSearchInValid = false;
			transactionObj.TransactionData = searchObj;
			showHideLoadingImage(true,"Loading Claims Alerts",null,null);
			if((rootConfig.isDeviceMobile && checkConnection()) || !rootConfig.isDeviceMobile){
			    gli_dataservice.searchTransactions(transactionObj, $scope.getTransactionSuccess, $scope.getTransactionError);
			}else{
			    $scope.getTransactionError();
			}
		}
	};
	$scope.getTransactionSuccess = function(data) {
		$scope.claimAlertDetails = [];
		var formattedDate1="";
		var formattedDate="";
		 if(data[0] !== undefined){
			if(data[0].TransactionData !== null) {
				$scope.isSearchInValid = false;
				if (data[0].TransactionData.length !== 0) {
					$scope.claimAlertDetails = data[0].TransactionData.ClaimsAlertResult;
					for ( var i = 0; i < $scope.claimAlertDetails.length; i++) {
                    	$scope.claimAlertDetails[i].agentCode = $scope.claimAlertDetails[i].branchCode+' '+$scope.claimAlertDetails[i].agentCode;
                    }
					if($scope.claimAlertDetails.length === 0){
						$scope.noData = true;
						$scope.validSearch = false;
					}else{
						$scope.validSearch = true;
						$scope.noData = false;
						$scope.activeFilter = false;
					}
					$scope.$apply();
				}else{
					$scope.noData = true;
					$scope.validSearch = false;
					$scope.errorMessage = [];
					$scope.isSearchInValid = true;
					$scope.searchFailedMessage = translateMessages($translate, "claimAlerts.searchFailedMessage");
		            $scope.errorMessage.push($scope.searchFailedMessage);
				}
			}
		 }else{
				$scope.noData = true;
				$scope.validSearch = false;
				$scope.errorMessage = [];
				$scope.isSearchInValid = true;
				$scope.searchFailedMessage = translateMessages($translate, "claimAlerts.searchFailedMessage");
	            $scope.errorMessage.push($scope.searchFailedMessage);
	     }
		 showHideLoadingImage(false,"Loading Claims Alerts",null,null);
		 $scope.refresh();
	};
	$scope.getTransactionError = function(data){
		$rootScope.serviceFailed=true;
        if (rootConfig.isDeviceMobile && !checkConnection()) {
			$scope.message = translateMessages($translate, "networkValidationErrorMessage");
		}else{
			$scope.message = translateMessages($translate, "validToken");
		}
        $scope.$emit('tokenEvent', { message: $scope.message });
        if (data == "Error in ajax callE"){
            $scope.onServerError=true;
            $scope.serverErrorMessage= translateMessages($translate, "serverErrorMessage");
            showHideLoadingImage(false,"Loading Claims Alerts",null,null);
        }else{
            showHideLoadingImage(false,"Loading Claims Alerts",null,null);
        }
        $rootScope.$apply();
	};
	$scope.validateFields = function(claimAlerts){
		$scope.validSearch = false;
		$scope.noData = false;
		$scope.claimAlerts = claimAlerts;
		//Date validation for claim incurred date
		 if($scope.claimAlerts.claimIncurredDateFrom && $scope.claimAlerts.claimIncurredDateTo){
			if(isFutureDate($scope.claimAlerts.claimIncurredDateFrom) || isFutureDate($scope.claimAlerts.claimIncurredDateTo)){
				$scope.errorMessage = [];
				$scope.isValid = true;
				$scope.futureDateValidationMessage = translateMessages($translate, "claimAlerts.futureDateValidationMessage");
                $scope.errorMessage.push($scope.futureDateValidationMessage);
            }else if(!isDateWithinSixty($scope.claimAlerts.claimIncurredDateFrom) || !isDateWithinSixty($scope.claimAlerts.claimIncurredDateTo)){
            	$scope.errorMessage = [];
            	$scope.isValid = true;
				$scope.dateRangeSixtyValidationMessage = translateMessages($translate, "claimAlerts.dateRangeSixtyValidationMessage");
                $scope.errorMessage.push($scope.dateRangeSixtyValidationMessage);
            }else if($scope.claimAlerts.claimIncurredDateTo < $scope.claimAlerts.claimIncurredDateFrom){
            	$scope.errorMessage = [];
            	$scope.isValid = true;
				$scope.dateRangeSixtyValidationMessage = translateMessages($translate, "claimAlerts.fromGreaterthanToValidationMessage");// have'nt got the error message
                $scope.errorMessage.push($scope.dateRangeSixtyValidationMessage);
            }else{
            	$scope.isValid = false;
            }
		}else if(($scope.claimAlerts.claimIncurredDateFrom && !$scope.claimAlerts.claimIncurredDateTo) || (!$scope.claimAlerts.claimIncurredDateFrom && $scope.claimAlerts.claimIncurredDateTo)){
				$scope.errorMessage = [];
				$scope.fromTodateValidationErrorMessage = translateMessages($translate, "claimAlerts.fromTodateValidationErrorMessage");
				$scope.errorMessage.push($scope.fromTodateValidationErrorMessage);
				$scope.isValid = true;
		}else{
        	$scope.isValid = false;
		}
	    if($scope.isValid){
		     $scope.isSearchInValid = true;
		}else{
		     $scope.isSearchInValid = false;
			 $scope.errorMessage = [];
			 $scope.searchClaimAlerts($scope.claimAlerts);
		}
	 };
	$scope.initialLoad();
}]);