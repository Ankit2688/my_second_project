mServiceApp.controller('RelationshipManagementCtrl',['$controller','$rootScope', '$scope',  '$compile', '$route', '$routeParams', '$location', '$translate','dataService','appDataShareService','AutoSync','debounce','$timeout','commonConfig','PersistenceMapping','$filter','gli_dataservice',function($controller,$rootScope, $scope,  $compile, $route, $routeParams, $location, $translate,dataService,appDataShareService,AutoSync,debounce,$timeout,commonConfig,PersistenceMapping,$filter,gli_dataservice) {
  angular.extend(this, $controller('BaseCtrl',{$scope:$scope, $rootScope:$rootScope, dataService:dataService, type:'clientBirthdayInformations', userId:appDataShareService.selectedUser.userId}));
  var _this = this;
  $scope.isSearchInValid = false;
  $scope.errorMessage = [];
  $scope.initialDate = {};
  $scope.isFromFooter = "false";
  $scope.relationshipMngmnt = {};
  $scope.selectedpage = commonConfig().PAGE_NAME.RELATIONSHIP_MANAGEMENT;
  $scope.noData = false;
	$scope.paintUISuccess = function (callbackId, data) {
	     $scope.isPainted = true;
         if (!showActivityFlag)
	     {
	       showHideLoadingImage(false);
	     }
    };
	$scope.onPartialLoaded=function(element,scope)
	{
		LEDynamicUI.paintUI(rootConfig.template, "alerts-ui-json.json", scope.item.subType , element , true, $scope.paintUISuccess, scope, $compile);
	};
	$scope.initialLoad = function(){
			if($route.current.loadedTemplateUrl.lastIndexOf('notification.htm') !== -1){
				$scope.isFromFooter = "true";
			}
			else{
				$scope.isFromFooter = "false";
			}
	       //For policy details within 7days
	       var cur = new Date();
	       var noOfDays = rootConfig.defaultDayCountRelationship;
		   var after7days = new Date(cur.setDate(cur.getDate() + noOfDays));
		   $scope.initialDate.dateFrom = getFormattedDate();
		   $scope.initialDate.dateTo = getFormattedDateFromDate(after7days);        
	       showHideLoadingImage(false);
		   $scope.searchBirthdays($scope.initialDate);
		   $scope.$apply();
	};
   $scope.validateFields = function(relationshipMngmnt){
		 $scope.noData = false;
		 $scope.validSearch = false;
		 $scope.relationshipMngmnt = relationshipMngmnt;
		 //Date validation for claim incurred date
		 if(!$scope.relationshipMngmnt.dateFrom || !$scope.relationshipMngmnt.dateTo){
			    $scope.errorMessage = [];
				$scope.dateMandatoryErrorMessage = translateMessages($translate, "policySearch.dateMandatoryErrorMessage");
				$scope.errorMessage.push($scope.dateMandatoryErrorMessage);
				$scope.isValid = true;
		 }
		 else if(!isFtureDate($scope.relationshipMngmnt.dateFrom) || !isFtureDate($scope.relationshipMngmnt.dateTo)){
				 $scope.errorMessage = [];
	         	 $scope.isValid = true;
				 $scope.pastDateValidationMessage = translateMessages($translate, "policySearch.pastDateValidationMessage");
	             $scope.errorMessage.push($scope.pastDateValidationMessage);
		 }
		 else if($scope.relationshipMngmnt.dateTo < $scope.relationshipMngmnt.dateFrom){
	         	$scope.errorMessage = [];
	         	$scope.isValid = true;
				$scope.fromGreaterthanToValidationMessage = translateMessages($translate, "policySearch.fromGreaterthanToValidationMessage");// To got the error message
	            $scope.errorMessage.push($scope.fromGreaterthanToValidationMessage);
	     }
		 else if(!isDateWithinSixtyFuture($scope.relationshipMngmnt.dateFrom) || !isDateWithinSixtyFuture($scope.relationshipMngmnt.dateTo)){
			    $scope.errorMessage = [];
	         	$scope.isValid = true;
				$scope.dateRangeSixtyValidationMessage = translateMessages($translate, "policySearch.dateRangeSixtyValidationMessage");// To got the error message
	            $scope.errorMessage.push($scope.dateRangeSixtyValidationMessage);
		 }
		 else{
         	    $scope.isValid = false;
         }
	    if($scope.isValid){
		  //errror message
		     $scope.isSearchInValid = true;
		     $scope.policyRenewalDetails = [];
		}
		else{
		     $scope.isSearchInValid = false;
			 $scope.errorMessage = [];
			 $scope.searchBirthdays($scope.relationshipMngmnt);
		}
	 };
	$scope.mapScopeToPersistance = function () {
		var newDate = new Date();
		PersistenceMapping.clearTransactionKeys();
	    PersistenceMapping.Key2 = $rootScope.username;
	    PersistenceMapping.Key5 = "Agent";
	    PersistenceMapping.Type = _this.Type;
	    var transactionObj =  PersistenceMapping.mapScopeToPersistence({});
	    return transactionObj;
	};
	$scope.searchBirthdays = function(relationshipMngmnt){
        showHideLoadingImage(true,"Loading Relationship Management", null, null);
		$scope.relationshipMngmnt = relationshipMngmnt;
		$scope.errorMessage = [];
		$scope.isSearchInValid = false;
		var transactionObj = $scope.mapScopeToPersistance();
    	$scope.relationshipMngmntDateFrom = $filter('date')($scope.relationshipMngmnt.dateFrom, "yyyy-MM-dd");
        $scope.relationshipMngmntDateTo = $filter('date')($scope.relationshipMngmnt.dateTo, "yyyy-MM-dd");
		var searchObj = {
				"SearchCriteria" : {
					"fromDate" : $scope.relationshipMngmntDateFrom,
					"toDate" : $scope.relationshipMngmntDateTo
				}
		    };
		transactionObj.TransactionData = searchObj;
		transactionObj.Type = "relationshipSearch";
		if((rootConfig.isDeviceMobile && checkConnection()) || !rootConfig.isDeviceMobile){
			dataService.searchTransactions(transactionObj, $scope.getTransactionSuccess, $scope.getTransactionError);
		}else{
			$scope.getTransactionError();
		}
		};
	$scope.getTransactionSuccess = function(data) {
		var bithdayResults = [];
		 if(data[0] !== undefined && data[0].TransactionData !== null){
				$scope.validSearch = true;
				if (data[0].TransactionData.birthdayUserList.length !== 0) {
					bithdayResults = data[0].TransactionData.birthdayUserList;
					$scope.noOfPolicies = bithdayResults.length;
				    $scope.clientDetails = [];
					for ( var i = 0; i < bithdayResults.length; i++) {
					    bithdayResults[i].agentCode = bithdayResults[i].branchCode+' '+bithdayResults[i].agentCode;
						$scope.clientDetailsTemp = [];
						if (bithdayResults[i].dateOfBirth!="")
						{
							dob=$filter('date')(bithdayResults[i].dateOfBirth, "dd-MM-yyyy");
						}
						else
						{
							dob=bithdayResults[i].dateOfBirth;
						}
						$scope.clientDetailsTemp.push({
                        	key : '',
                        	value : bithdayResults[i].customerName
                        });
						$scope.clientDetailsTemp.push({
							key : translateMessages($translate, "alerts.dobLabel"),
							value : dob
						});
						$scope.clientDetailsTemp.push({
							key : translateMessages($translate, "alerts.policyNoLabel"),
							value : bithdayResults[i].policyNumber
						});
						$scope.clientDetailsTemp.push({
							key : translateMessages($translate, "alerts.productNameLabel"),
							value : bithdayResults[i].productName
						});
						$scope.clientDetailsTemp.push({
							key : translateMessages($translate, "alerts.occupationLabel"),
							value : bithdayResults[i].occupation
						});
						$scope.clientDetailsTemp.push({
							key : translateMessages($translate, "alerts.emailLabel"),
							value : bithdayResults[i].email
						});
						$scope.clientDetailsTemp.push({
							key : translateMessages($translate, "alerts.contactLabel"),
							value : bithdayResults[i].mobileNumber
						});
						$scope.clientDetailsTemp.push({
							key : translateMessages($translate, "alerts.addressLabel"),
							value : [bithdayResults[i].address.addressLine1, bithdayResults[i].address.addressLine2, bithdayResults[i].address.addressLine3, bithdayResults[i].address.addressLine4,bithdayResults[i].address.postalCode,bithdayResults[i].address.country].filter(function (val) {return val;}).join(', ')
						});
						$scope.clientDetails
								.push({
									"header" : bithdayResults[i].agentCode,
									"data" : $scope.clientDetailsTemp
								});
					}
					if(bithdayResults.length===0){
						$scope.noData = true;
					}else{
						$scope.noData = false;
					}
					$scope.$apply();
				}
				else {
					$scope.noData = true;
					$scope.noOfPolicies = 0;
					$scope.validSearch = false;
					$scope.errorMessage = [];
					$scope.searchFailedMessage = translateMessages($translate, "policySearch.noDataMessage");
		            $scope.errorMessage.push($scope.searchFailedMessage);
		            $scope.$apply();
		   }
		}else {
		 		$scope.noData = true;
				$scope.noOfPolicies = 0;
				$scope.validSearch = false;
				$scope.errorMessage = [];
				$scope.searchFailedMessage = translateMessages($translate, "policySearch.noDataMessage");
	            $scope.errorMessage.push($scope.searchFailedMessage);
	            $scope.$apply();
	    }
		showHideLoadingImage(false);
	};
	$scope.getTransactionError = function(data) {
		$rootScope.serviceFailed=true;
		if (rootConfig.isDeviceMobile && !checkConnection()) {
			$scope.message = translateMessages($translate, "networkValidationErrorMessage");
		}else{
			$scope.message = translateMessages($translate, "validToken");
		}
		$scope.$emit('tokenEvent', { message: $scope.message });
		if (data == "Error in ajax callE")
		   {
			   $scope.onServerError=true;
			   $scope.serverErrorMessage= translateMessages($translate, "serverErrorMessage");
		   }
		showHideLoadingImage(false);
		$rootScope.$apply();
	};
	$scope.initialLoad();
}]);
