mServiceApp.controller('NotificationCtrl',['$controller','$rootScope', '$scope',  '$compile', '$route', '$routeParams', '$location', '$translate','dataService',
'appDataShareService','AutoSync','debounce','$timeout','$filter','mServiceConstants','commonConfig','customerServiceConfig','gli_dataservice',function($controller ,$rootScope, $scope,
$compile, $route, $routeParams, $location, $translate,dataService,appDataShareService,AutoSync,debounce,$timeout,$filter,mServiceConstants,commonConfig,customerServiceConfig,gli_dataservice) {
	var renderAction = $route.current.action;
	var renderPath = renderAction.split(".");
	$scope.renderPath = renderPath;
	$scope.dataEmpty = false;
	// booleans used to set the selected class
 	$scope.isClaimAlerts = (renderPath[1] === 'claimAlerts');
 	$scope.isImpCommunication = (renderPath[1] === 'impCommunication');
  	$scope.isCPDWorkingHours = (renderPath[1] === 'cpdHrsTracking');
 	$scope.isRelationshipManagement = (renderPath[1] === 'relationship');
	$scope.$on('$viewContentLoaded', function(){
		$scope.initialLoad();
	});
}]);