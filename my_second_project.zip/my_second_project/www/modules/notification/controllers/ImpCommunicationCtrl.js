mServiceApp.controller('ImpCommunicationCtrl',['$controller','$rootScope', '$scope', '$filter',  '$compile', '$route', '$routeParams', '$location', '$translate','dataService','appDataShareService','customerServiceConfig','commonConfig',function($controller ,$rootScope, $scope,  $filter, $compile, $route, $routeParams, $location, $translate,dataService,appDataShareService,customerServiceConfig,commonConfig) {
 
	$scope.impComm = {};
	$scope.isFromFooter = "false";
	var impCommunicationData = [];
	$scope.selectedpage = commonConfig().PAGE_NAME.IMP_COMMUNICATIONS;
	$scope.afterDateSearch = [];
	$scope.intialLoad = function() {
		if($route.current.loadedTemplateUrl.lastIndexOf('notification.htm') !== -1){
			$scope.isFromFooter = "true";
		}
		else{
			$scope.isFromFooter = "false";
		}        $scope.impComm.fromDate = "";
        $scope.impComm.toDate = "";
        $scope.impComm.subject = "";
        $scope.fileName = "impCommunication.json";
        var cur = new Date();
		var previousdays = new Date(cur.setDate(cur.getDate() - 30));
		$scope.toDate = getFormattedDate();
		$scope.fromDate = getFormattedDateFromDate(previousdays);
    	$scope.impComm.fromDate = $scope.fromDate;
    	$scope.impComm.toDate = $scope.toDate;
        if(rootConfig.isDeviceMobile) {
            LEDynamicUI.getUIJson($scope.fileName, false, function(jsonObject) {
            impCommunicationData = jsonObject;
            $scope.impCommData = impCommunicationData.impComm;
            $scope.searchResult = $scope.searchDate($scope.fromDate,$scope.toDate,$scope.impCommData);
            $scope.$apply();
           });
        }
        else {
          $scope.getFromRemote($scope.fileName, false, function(jsonObject) {
            if($scope.fileName === 'impCommunication.json') {
               impCommunicationData = JSON.parse(jsonObject);
               $scope.impCommData = impCommunicationData.impComm;
               $scope.searchResult = $scope.searchDate($scope.fromDate,$scope.toDate,$scope.impCommData);
               $scope.$apply();
            }
          });
          
       }
        
    };
        
    $scope.showFullText = function(event){
		$scope.$broadcast('dibari:refresh-ellipsis');
	}
	
    $scope.getFromRemote = function(jsonFile, callmode, successCallBack,
            errorCallback) {
        var self = this;
        $.ajax({
            type : "GET",
            url : rootConfig.contentAdminDownLoadURL + jsonFile,
            dataType : "text",
            success : function(jsonObject) {
                successCallBack(jsonObject);

            },
            async : callmode,
            error : function(error) {
                console.log('Error : Failed to retrieve config JSON from remote location : ' + rootConfig.contentAdminDownLoadURL + ", "+ jsonFile + JSON.stringify(error));

            }
        });
    };
    
    $scope.reset = function(){
    	$scope.impComm.fromDate = "";
    	$scope.impComm.toDate = "";
    	$scope.impComm.subject = "";
    	$scope.searchResult = [];
		$scope.errorMessage = [];
		$scope.isSearchInValid=false;
    	$scope.$apply();
    }
    
   $scope.searchImpCommunication = function(impComm){
	    $scope.impComm = impComm;
	    showHideLoadingImage(false,"Loading Important Communication",null,null);
        if((!$scope.impComm.fromDate && !$scope.impComm.toDate) && (!$scope.impComm.subject)) {
            $scope.errorMessage=[];
            $scope.errorMessage.push(translateMessages($translate, "policySearch.minOneSearchFieldValidationMessage"));
            $scope.isSearchInValid=true;
            $scope.searchResult = [];
        }
        else
        {
            if($scope.impComm.fromDate && $scope.impComm.toDate){
            	if(isFutureDate($scope.impComm.fromDate) || isFutureDate($scope.impComm.toDate)){
            		  $scope.isSearchInValid=true;
            		  $scope.searchResult = [];
            		  $scope.errorMessage = [];
                      $scope.futureDateValidationMessage = translateMessages($translate, "policySearch.futureDateValidationMessage");
                      $scope.errorMessage.push($scope.futureDateValidationMessage);
            	}
				/* else if(!isDateWithinSixty($scope.impComm.fromDate) || !isDateWithinSixty($scope.impComm.toDate)){
                	$scope.errorMessage = [];
                	$scope.searchResult = [];
                	$scope.isSearchInValid = true;
    				$scope.dateRangeSixtyValidationMessage = translateMessages($translate, "policySearch.dateRangeSixtyValidationMessage");
                    $scope.errorMessage.push($scope.dateRangeSixtyValidationMessage);
                } */
				else if($scope.impComm.toDate < $scope.impComm.fromDate){
                	$scope.errorMessage = [];
                	$scope.searchResult = [];
                	$scope.isSearchInValid = true;
    				$scope.dateRangeValidationMessage = translateMessages($translate, "policySearch.fromGreaterthanToValidationMessage");// have'nt got the error message
                    $scope.errorMessage.push($scope.dateRangeValidationMessage);
                }
                else{
                	$scope.isSearchInValid = false;
                	var result = [];
                	$scope.afterDateSearch = $scope.searchDate($scope.impComm.fromDate,$scope.impComm.toDate,$scope.impCommData);
                	if($scope.impComm.subject){
                		var subject = $scope.impComm.subject;
                		for (var i = 0; i < $scope.afterDateSearch.length; i++) {
                		      var str = $scope.afterDateSearch[i].subject;
                		      var regex = new RegExp(subject, 'g' );
                		      var str1 = str.toLowerCase();
                		      var regex1 = subject.toLowerCase();
                              if(str1.match(regex1)){
                            	  result.push($scope.afterDateSearch[i]);                              
                              }
                		 }
                		if(result.length !== 0){
                   	       $scope.searchResult = result;
                   	       $scope.isSearchInValid = false;
                		}
                		else{
                			//no data message
                			$scope.searchResult = [];
                			$scope.errorMessage = [];
                			$scope.searchFailedMessage = translateMessages($translate, "policySearch.noDataMessage");
        		            $scope.errorMessage.push($scope.searchFailedMessage);
        		            $scope.isSearchInValid = true;
                		}
                	}
                	else{
                		if($scope.afterDateSearch.length !== 0){
                    		$scope.searchResult = $scope.afterDateSearch;
                    		$scope.isSearchInValid = false;
                		}
                		else{
                			$scope.searchResult = [];
                			$scope.errorMessage = [];
                			$scope.searchFailedMessage = translateMessages($translate, "policySearch.noDataMessage");
        		            $scope.errorMessage.push($scope.searchFailedMessage);
        		            $scope.isSearchInValid = true;
                		}
                	}
                }
            }
            else if(($scope.impComm.fromDate && !$scope.impComm.toDate) || (!$scope.impComm.fromDate && $scope.impComm.toDate)){
            	$scope.searchResult = [];
            	$scope.errorMessage = [];
				$scope.fromTodateValidationErrorMessage = translateMessages($translate, "policySearch.fromTodateValidationErrorMessage");
				$scope.errorMessage.push($scope.fromTodateValidationErrorMessage);
	            $scope.isSearchInValid = true;
            }
            else{
            	var result = [];
            	if($scope.impComm.subject){
            		var subject = $scope.impComm.subject;
            		for (var i = 0; i < $scope.impCommData.length; i++) {
            		      var str = $scope.impCommData[i].subject;
            		      var regex = new RegExp(subject, 'g' );
            		      var str1 = str.toLowerCase();
            		      var regex1 = subject.toLowerCase();
                          if(str1.match(regex1)){
                        	  result.push($scope.impCommData[i]);                              
                          }                          
            		 }
            		 if(result.length !== 0){
                	       $scope.searchResult = result;
                	       $scope.isSearchInValid = false;
             		 }
             		 else{
             			//no data message
             			$scope.searchResult = [];
             			$scope.errorMessage = [];
            			$scope.searchFailedMessage = translateMessages($translate, "policySearch.noDataMessage");
    		            $scope.errorMessage.push($scope.searchFailedMessage);
    		            $scope.isSearchInValid = true;
             		 }
            	     
            	}
            	else{
                	$scope.isSearchInValid = true;
            	}
            }
        }
    };
    
    $scope.onClickUrl = function(url){
    	window.open(url, '_system');
    }
    function changeDateFormat(date) {
        var newDate= date.split('/');
        return new Date(newDate[2]+'-'+newDate[1]+'-'+newDate[0]);
    }
    
    $scope.searchDate = function(fromDate,toDate,impCommData){            
    	    var filtered = [];
    	    var impCommData = impCommData;
    	    $scope.fromDate = fromDate;
    	    $scope.toDate = toDate;  
    	    var from_date = $filter('date')($scope.fromDate, "dd/MM/yyyy");
            var to_date = $filter('date')($scope.toDate, "dd/MM/yyyy");
    	    var regExp = /(\d{1,2})\/(\d{1,2})\/(\d{2,4})/;
            for(var i=0;i<impCommData.length;i++){
              if((parseInt(impCommData[i].date.replace(regExp, "$3$2$1")) >= parseInt(from_date.replace(regExp, "$3$2$1"))) && (parseInt(impCommData[i].date.replace(regExp, "$3$2$1")) <= parseInt(to_date.replace(regExp, "$3$2$1")))){
                impCommData[i].actual_date = changeDateFormat(impCommData[i].date);
                filtered.push(impCommData[i]);
              }
            }
            return filtered;
    }
    
    $scope.getFromRemote = function(jsonFile, callmode, successCallBack,
            errorCallback) {
        var self = this;
        $.ajax({
            type : "GET",
            url : rootConfig.contentAdminDownLoadURL + jsonFile,
            dataType : "text",
            success : function(jsonObject) {
                successCallBack(jsonObject);

            },
            async : callmode,
            error : function(error) {
                console.log('Error : Failed to retrieve config JSON from remote location : ' + rootConfig.contentAdminDownLoadURL + ", "+ jsonFile + JSON.stringify(error));

            }
        });
    };

    $scope.downloadPdf = function(downloadUrl) {
		var isAndroid = navigator.userAgent.indexOf("Android") > 0 ? true : false;
        if((downloadUrl.indexOf('http') >= 0) && (downloadUrl.indexOf('pdf') >= 0) 
			&& (rootConfig.isDeviceMobile) && (isAndroid))
        {
            downloadPdfFromRemote(downloadUrl);
        } else{
                window.open(downloadUrl, '_system');
        }
   };
	
    $scope.intialLoad();
	
}]);
