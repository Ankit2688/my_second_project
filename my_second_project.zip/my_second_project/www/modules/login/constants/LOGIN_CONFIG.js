mServiceApp.constant('loginConfig',function(){return {
	"DESIGNATION" : {
					"PSA" : "PSA",
					"SAD" : "SAD",
					"AAM" : "AAM",
					"SAP" : "SAP",
					"APA" : "APA",
					"ADM" : "ADM",
					"AA" :  "AA",
					"AGT" : "AGT"
					},	
	"DEVICE_TYPE" : {
						"ANDROID" : "Android",
						"IOS" : "iOS"
						}
	
}});