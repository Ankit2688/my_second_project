mServiceApp.controller('ForgotPasswordCtrl',['$controller', '$rootScope', '$scope', '$http', '$compile', '$route', '$routeParams', '$location', '$translate','dataService','appDataShareService','AutoSync', 'gli_dataservice', 'debounce', '$timeout','mServiceConstants','commonConfig', 'PersistenceMapping','customerServiceConfig','$filter',function($controller ,$rootScope, $scope, $http, $compile, $route, $routeParams, $location, $translate,dataService,appDataShareService,AutoSync,gli_dataservice,debounce,$timeout,mServiceConstants,commonConfig,PersistenceMapping,customerServiceConfig,$filter) {
	$scope.username = $rootScope.username;
	$scope.authorizationToken = appDataShareService.authorizationToken;
	$scope.invalidPwd = true;
	$scope.pwdMismatch = false;
	$scope.disableSubmitPwd = true;
	$scope.showInd=true;
	$scope.isValidUserName = false;
	$scope.agentCode = "";
	$rootScope.fromForgotPasswordPage = false;
	$scope.secretAns = "";
	$scope.passwordUpdated  = false;
	$scope.securityQues = "";
	$scope.newPassword = "";
	$scope.confirmPassword = "";
	$scope.isFirstLogin = $rootScope.firstTimeLogin;
	$scope.showPopUpMsg = false;
	$scope.secQuestArray = [];
	if($route.current.loadedTemplateUrl.indexOf("forgotpassword") > -1){
		$scope.selectedpage = commonConfig().PAGE_NAME.RESET_PASSWORD;
	} else if($route.current.loadedTemplateUrl.indexOf("resetPassword") > -1){
		$scope.selectedpage = commonConfig().PAGE_NAME.CHANGE_TEMPORARY_PASSWORD;
	} else if($route.current.loadedTemplateUrl.indexOf("secret-qn-answer") > -1){
		$scope.selectedpage = commonConfig().PAGE_NAME.SET_SECRET_QUESTION;
	} else {
		$scope.selectedpage = "";
	}
	$scope.resetPasswordQuestArray = ["secQues1","secQues2" ,"secQues3" ,"secQues4" ,"secQues5" ,"secQues6" ,"secQues7" ,"secQues8" ,"secQues9" ,"secQues10","secQues11",
									"secQues12","secQues13","secQues14","secQues15","secQues16","secQues17"];
	$scope.questionCode = "";
	$scope.successFlag = false;
	$scope.successFlagCorp = false;
	$scope.passwordPattern = rootConfig.passwordRegexPattern;
	angular.extend(this, $controller('BaseCtrl',{$scope:$scope, $rootScope:$rootScope, dataService:dataService, type:'ForgotPassword', userId:appDataShareService.selectedUser.userId, userCode:appDataShareService.userCode,loggedInUserType:$rootScope.moduleVariable}));
	var _this = this;
	$scope.getTransactionSuccess = function(data){
		$scope.errorMessage = [];
		showHideLoadingImage(false);
		if(data[0] !== undefined){
        	if (data[0].TransactionData && data[0].TransactionData.StatusData.StatusCode === "200") {
         		$scope.showPopUpMsg = true;
            	$scope.popUpMsg = "passwordUpdatedMsg";
         		$scope.passwordUpdated  = true;
           } else if(data[0].TransactionData && data[0].TransactionData.StatusData.StatusCode === "500") {
        		$scope.passwordUpdated  = false;
        		$scope.errorMessage.push("secretAnsErrorMsg");
        	} else{
        		$scope.passwordUpdated  = false;
        		$scope.getTransactionError();
        	}
        	$scope.$apply();
        }  else {
			$scope.passwordUpdated  = false;
        	$scope.getTransactionError();
		}
	};
	  $scope.getTransactionError = function(data) {
          $rootScope.serviceFailed=true;
    	  if (rootConfig.isDeviceMobile && !checkConnection()) {
				$scope.message = translateMessages($translate, "networkValidationErrorMessage");
		  }else{
				$scope.message = translateMessages($translate, "validToken");
		  }
    	  $scope.$emit('tokenEvent', { message: $scope.message });
    		if (data == "Error in ajax callE")
            {
                $scope.onServerError=true;
                $scope.serverErrorMessage= translateMessages($translate, "serverErrorMessage");
                showHideLoadingImage(false);
            }
            else
            {
    			showHideLoadingImage(false);
            }
    		$rootScope.$apply();
    	};
	$scope.retrieveSecretQues = function(){
		$scope.secQuestArray = [];
		$scope.showPopUpMsg = false;
		$scope.securityQues = "";
		$scope.isValidUserName = false;
		var transObj = $scope.mapScopeToPersistance();
		var userDetails = {
			"userDetails": {
	                        	"agentCode": $scope.agentCode
	                        }
		};
	    transObj.TransactionData = userDetails;
	    transObj.Type = "RetrieveSecretQuestion";
	    transObj.Key14 = "";
	    transObj.Key2 = $scope.agentCode;
	    showHideLoadingImage(true, "Loading..");
		if((rootConfig.isDeviceMobile && checkConnection()) || !rootConfig.isDeviceMobile){
			gli_dataservice.getTransactions(transObj,$scope.retrieveSecretQuesSucc,$scope.getTransactionError);
		}else{
			$scope.getTransactionError();
		}
	};
	$scope.retrieveSecretQuesSucc = function(data){
		$scope.errorMessage = [];
		showHideLoadingImage(false);
		if(data[0] !== undefined){
		     if (data[0].TransactionData && data[0].TransactionData.StatusData.StatusCode === "200") {
					$scope.isValidUserName = true;
					$scope.securityQues  = data[0].TransactionData.securityOptions.questionCode;
					$scope.secQuestArray.push($scope.securityQues);
		       }  else if(data[0].TransactionData && data[0].TransactionData.StatusData.StatusCode === "500") {
               		$scope.errorMessage.push("invalidUserNameErr");
               } else {
		       		$scope.getTransactionError();
		       }
		       $scope.$apply();
			}
	};
	$scope.validateSecretQues = function(){
	if($scope.secretAns){
		$scope.passwordUpdated  = false;
		var transObj = $scope.mapScopeToPersistance();
		var userDetails = {
				"securityOptions": {
                              		"questionCode": $scope.securityQues,
                              		"answer": $scope.secretAns
                                   }
		};
		transObj.TransactionData = userDetails;
		transObj.Type = "ValidateSecretQuestion";
		transObj.Key2 = $scope.agentCode;
		showHideLoadingImage(true, "Loading..");
		if((rootConfig.isDeviceMobile && checkConnection()) || !rootConfig.isDeviceMobile){
			gli_dataservice.getTransactions(transObj,$scope.getTransactionSuccess,$scope.getTransactionError);
		}else{
			$scope.getTransactionError();
		}
		}
	};
	$scope.updatePassword = function(){
			if($scope.validatePassword()){
    		$scope.passwordUpdated  = false;
    		var transObj = $scope.mapScopeToPersistance();
    		var userDetails = {
    				"password": CryptoJS.SHA512($scope.newPassword).toString(CryptoJS.enc.Hex),
    				"oldPassword": CryptoJS.SHA512($scope.currentPassword).toString(CryptoJS.enc.Hex)
    		};
    		transObj.TransactionData = userDetails;
    		transObj.Type = "Change Password";
    		showHideLoadingImage(true, "Loading..");
			if((rootConfig.isDeviceMobile && checkConnection()) || !rootConfig.isDeviceMobile){
			    dataService.searchTransactions(transObj,$scope.onUpdatePasswordSucc,$scope.getTransactionError);
			}else{
			    $scope.getTransactionError();
			}
    	}
    };
    $scope.onUpdatePasswordSucc = function(data){
    	$scope.errorMessage = [];
    	if(data[0] && data[0].TransactionData !== null){
                 var statusCode = data[0].TransactionData.StatusData.StatusCode;
                 showHideLoadingImage(false);
                 if(statusCode === "100"){
                 //isFirstLogin to be set after login implementation
					  if($scope.isFirstLogin){
                 	  		$location.path('/setSecretQuestion');
                 	  } else {
                 	  		$location.path('/dashboard');
                 	  }
                 	  $scope.$apply();
                 } 
				 else if(statusCode == "200")
				 {
				 $scope.passwordUpdateSuccess = true;
				 $scope.$apply();
				 }else if(statusCode === "504"){
					$scope.errorMessage = [];
                    $scope.errorMessage.push($scope.convertertranslate('settings.resetPasswordError'));
             		$scope.$apply();
                 } else if(statusCode === "503"){
                 	$scope.errorMessage = [];
                    $scope.errorMessage.push($scope.convertertranslate('settings.incorrectExistingPassword'));
                 	$scope.$apply();
                 } else if(statusCode === "502"){
                 	$scope.errorMessage = [];
                    $scope.errorMessage.push($scope.convertertranslate('settings.invalidUser'));
                 	$scope.$apply();
                 }else if(statusCode === "500")
				 {
					$scope.errorMessage = [];
                    $scope.errorMessage.push($scope.convertertranslate('settings.passwordChangeUnsuccess'));
             		$scope.$apply();
				 }else if(statusCode === "404" || statusCode === "300")
				 {
					$scope.errorMessage = [];
                    $scope.errorMessage.push($scope.convertertranslate('settings.passwordChangeEmailErrorMessage'));
             		$scope.$apply();
				 }else if(statusCode === "501")
				 {
					$scope.errorMessage = [];
                    $scope.errorMessage.push($scope.convertertranslate('settings.passwordChangeError'));
             		$scope.$apply();
				 }
    	}
    };
	$scope.passwordEmpty = true;
    $scope.isPasswordEmpty = function(){
    	if($scope.newPassword && $scope.confirmPassword && $scope.currentPassword){
    		$scope.passwordEmpty = false;
		} else {
			$scope.passwordEmpty = true;
		}
    };

    $scope.secrtQuesAnsEmpty = true;
    $scope.isSecrtQuesAnsEmpty = function(){
    	if($scope.questionCode && $scope.secretAns){
    		$scope.secrtQuesAnsEmpty = false;
    	} else {
    		$scope.secrtQuesAnsEmpty = true;
    	}
    };

	$scope.convertertranslate = function(name) {
    	return $filter('translate')(name);
    };

     $scope.validatePasswordPattern = function(){
        $scope.errorMessage = [];

        var userID = $rootScope.username.toLowerCase();
        var password = $scope.newPassword.toLowerCase();
        /*var agentCode = userID.split('');
        var count = [];
        var len = 0;
        for(var i=0; i<agentCode.length; i++){
            len = password.split(agentCode[i]).length - 1
            if( len > 0){
                count.push(len);
            }
        }*/
    	if(($scope.newPassword&&!$scope.passwordPattern.test($scope.newPassword)) ||
    			($scope.confirmPassword&&!$scope.passwordPattern.test($scope.confirmPassword))){
    			$scope.errorMessage.push($scope.convertertranslate('settings.passwordValidationMsg'));
    	}/*	else if(count.length > 1){
             $scope.passwordError = true;
             $scope.errorMessage.push(translateMessages($translate, "settings.passwordUserIDErrorMsg"));
             $scope.isSearchInValid = true;
        }*/
     }

    $scope.validatePassword = function(){
    	$scope.errorMessage = [];
		$scope.validatePasswordPattern();
		if($scope.newPassword !== $scope.confirmPassword){
			$scope.errorMessage.push($scope.convertertranslate('passwordMissmatchErrMsg'));
		}
		if($scope.errorMessage.length == 0){
			return true;
		} else {
			return false;
		}
    };
    $scope.saveSecretQues = function(){
   	 	var transObj = $scope.mapScopeToPersistance();
    	var securityOptions = {
        					"securityOptions": {
                								"questionCode": $scope.questionCode,
                								"answer": $scope.secretAns
                					  	 		}
                			  };
    	transObj.TransactionData = securityOptions;
    	transObj.Type = "CreateSecurityQuestion";
    	showHideLoadingImage(true, "Loading..");
		if((rootConfig.isDeviceMobile && checkConnection()) || !rootConfig.isDeviceMobile){
			dataService.searchTransactions(transObj,$scope.saveSecretQuesSuccess,$scope.getTransactionError);
		}else{
			$scope.getTransactionError();
		}
    };
    $scope.saveSecretQuesSuccess = function(data){
        	if(data[0] && data[0].TransactionData !== null){
                     var statusCode = data[0].TransactionData.StatusData.StatusCode;
                     showHideLoadingImage(false);
                     if(statusCode === "200"){
                     	$scope.showPopUpMsg = true;
                     	$scope.popUpMsg = "createSecrtQuseSucc";
                     	$scope.$apply();
                     }
        	}
        };
	$scope.closePopUp = function(){
		$scope.showPopUpMsg = false;
	};
	$scope.takeMeToLink = function(link){
		$scope.showPopUpMsg = false;
		$location.path(link);
	};
	$scope.redirectLogin = function() {
        $rootScope.completeLogOut();
    };
	$scope.mapScopeToPersistance = function(type) {
        PersistenceMapping.clearTransactionKeys();
        PersistenceMapping.Key5 = "Agent";
        PersistenceMapping.Key2 = $scope.username;
        PersistenceMapping.Type = "";
        var transactionObj = PersistenceMapping.mapScopeToPersistence({});
        return transactionObj;
    };
}]);







