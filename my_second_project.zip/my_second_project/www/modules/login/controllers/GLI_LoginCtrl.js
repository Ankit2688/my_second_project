/*
 * Copyright 2015, LifeEngage
 */
/*
 * Name:GLI_LoginController
 * For implementing Login specific changes
 */
mServiceApp
		.controller(
				'GLI_LoginCtrl',
				[
						'$controller','$rootScope',
						'$scope','$http',
						'$compile','$route',
						'$routeParams','$location',
						'$translate','dataService',
						'appDataShareService','authService',
						'UserDetailsService','LoginService',
						'AgentService','AutoSync',
						'debounce','$timeout','$window',
						'commonConfig','loginConfig',
						'PersistenceMapping','UtilityService',
						'DataLookupService',
						'DataWipeService',
						function GLI_LoginCtrl($controller ,$rootScope, $scope, $http, $compile, $route,
						    $routeParams, $location, $translate,dataService,appDataShareService,authService,
						    UserDetailsService,LoginService,AgentService,AutoSync,debounce,$timeout,$window,
						    commonConfig,loginConfig,PersistenceMapping,UtilityService,DataLookupService, DataWipeService) {
							$controller('LoginCtrl', {
								$rootScope:$rootScope,$scope:$scope,$http:$http,
								$compile: $compile,$route:$route,
								$routeParams:$routeParams,$location:$location,
								$translate:$translate,dataService:dataService,
								appDataShareService:appDataShareService,authService:authService,
								UserDetailsService:UserDetailsService,
								LoginService:LoginService,AgentService:AgentService,
								AutoSync:AutoSync,debounce:debounce,
								$timeout:$timeout,commonConfig:commonConfig,
								loginConfig:loginConfig,PersistenceMapping:PersistenceMapping,
								UtilityService:UtilityService,DataLookupService:DataLookupService
							});

			$rootScope.isLoggedOut = true;
			$rootScope.isSessionExpired = false;
			$scope.rememberMe = false;
			$scope.rootedDevice = false;
			$scope.isDeviceMobile = rootConfig.isDeviceMobile;
			$scope.selectedpage = commonConfig().PAGE_NAME.LOGIN_PAGE;
			if (JSON
            		.parse(localStorage.getItem('loginDetails')) !== null) {
            			$scope.loginObject = JSON.parse(localStorage
            					.getItem('loginDetails'));
            			if ($scope.loginObject !== null
            					&& $scope.loginObject !== undefined){
            				$scope.rememberMe = true;
            				$scope.username = $scope.loginObject.leuname;
            				$scope.password = $scope.loginObject.lepwd;
            			}
            	}
			$scope.$on('$routeChangeStart', function(scope, next, current){
                if(next.$$route.action!==undefined) {  
                    if(next.$$route.action.split(".")[1] != "Login")
                        $rootScope.isInLoginPage = false;
                }
			});
			if($route.current.action.split(".")[1] == "Login"){
				$rootScope.isInLoginPage = true;
			}
			else{
				$rootScope.isInLoginPage = false;
			}
			
			$scope.navigateToAppDownload = function(mode){
                if(mode=='android') {
                    window.open(rootConfig.appDownloadURLAndroid, '_blank');	
                }
                else if(mode=='ios') {
                    window.open(rootConfig.appDownloadURLiOS, '_blank');
                }
			}
		    $scope.login = function() {
				$scope.isLoggingError = false;
                $rootScope.passwordUpdated = false;
        		if (navigator.userAgent.search(commonConfig().SEARCH_OPTION.MSIE) >= 0) {
        			showHideLoadingImage(true, "Authenticating User", null,"Authenticate");
        		}
        		if (rootConfig.isDeviceMobile) {
        			if (navigator.network.connection.type == Connection.NONE) {
						$scope.isLoggingError = true;
        				$scope.loginError = translateMessages($translate,"networkErrorMessage");
        			} else {
        				$scope.authenticateUserOnline();
        			}
        		} else {
        			$scope.authenticateUserOnline();
        		}
        	};
		$scope.checkLoginBtn = function(){
			if(typeof $scope.username == 'undefined' || typeof $scope.password == 'undefined'){
				return true
			}
			else if($scope.username.length == 0 || $scope.password.length == 0){
				return true
			}
			else{
				return false
			}	
		}
		/*$scope.linkTo = function(link) {
            $rootScope.isAuthenticated = true;
            $rootScope.isLoggedOut = true;
			$rootScope.isInLoginPage = false;
            $location.path(link);
            $scope.$apply();
        };*/
		$scope.registerNewUser = function()
		{			
			var url = rootConfig.registerNewUserURL;
			
			if(rootConfig.isDeviceMobile)
			{
            var ref = window.open(url, '_blank','location=yes', 'toolbar=yes');
			ref.addEventListener('loadstart', 
					function(event) 
					{
                        if(event.url.indexOf("yahoo.co") > -1) 
						{
                            ref.close();
                        }
                    }
			);                       
		}
			else
			{
				$window.location.href = 'file:///C:/Users/323970/Desktop/newWindowPOC.html';
			}
		}
		$scope.forgotPassword = function()
		{
			if(rootConfig.isDeviceMobile)
			{
			PMF = "M";
			}
			else{
			PMF = "P";
			}
			var url = rootConfig.forgotPasswordURL+"?PMF="+PMF+"&RETURNURL="+rootConfig.omniReturnURL;;
			if(rootConfig.isDeviceMobile)
			{
				var ref = window.open(url, '_blank','location=yes', 'toolbar=yes');
			}
			else
			{
                var form = document.createElement('form');
                form.method = 'post';
                form.action = url;
                document.body.appendChild(form);
                form.submit();
			}
			
		}
        function proceedWithLogin() {
            authService.login(
            	{
            		username : $scope.username,
            		password : CryptoJS.SHA512($scope.password).toString(CryptoJS.enc.Hex)

            	},
            	function(data,res) {
            		$rootScope.username = $scope.username;
            		$rootScope.isAuthenticated = true;
            	    $rootScope.isLoggedOut = true;
            		$rootScope.username = $scope.username;
            		$rootScope.authenticationStatus = "SUCCESS";
					$rootScope.role = data.roles[0];
            		$scope.userDetails.user.userId = $scope.username;
            		$scope.userDetails.user.password = Encrypt_text($scope.password);
					$scope.userDetails.user.shaPassword = CryptoJS.SHA512($scope.password).toString(CryptoJS.enc.Hex); 
                    $scope.userDetails.user.token = res;
            		$scope.userDetails.options.headers.Token=res;
					$scope.userDetails.user.rexitLoginId  = data.userCode;
					$rootScope.agentId = angular.copy(data.userCode);
            		$rootScope.firstTimeLogin = data.firstTimeLogin;
            	    $rootScope.isTemporaryPassword = data.isTemporaryPassword;
            	    $rootScope.role = data.roles[0];
					sessionStorage.userDetails = JSON.stringify($scope.userDetails);
					sessionStorage.loginData = JSON.stringify(data);
            		UserDetailsService.setUserDetailsModel($scope.userDetails);
            		if ($rootScope.authenticationStatus == commonConfig().STATUS.SUCCESS) {
            			// Push Notification registering
            		    $scope.loadLandingPage()
            		    if(!(rootConfig.isDeviceMobile)){
            		        LoginService.saveToken(appDataShareService.mContentRoles
            					,function(res){
            					    localStorage[getUniqueAppNamePattern(commonConfig().STORAGE.MCONTENTROLES)]=commonConfig().STATUS.NOT_AUTHENTICATED;
            					},function(res){
            					}
            				);
            		    }
            		} else {
            			$scope.isLoggingError = true;
            			showHideLoadingImage(false,null,null,"Authenticate");
            			$rootScope.isAuthenticated = false;
            			$scope.loginError = translateMessages($translate,"credentialsValidationErrorMessage");
            			$scope.$apply();
            		}
            	}, function(data, status) {
					showHideLoadingImage(false,null,null,"Authenticate");
                    $scope.isLoggingError = true;
                    $rootScope.isAuthenticated = false;
                    $rootScope.isOnlineAuthenticated=false;
                    switch(status) {
                        case 401:  $scope.loginError = translateMessages($translate, "loginCredentialErrorMsg"); break;
                        case 404: $scope.loginError = translateMessages($translate, "resourceNotFoundErrMsg"); break;
                        case 500 : $scope.loginError = translateMessages($translate, "resourceUnAvailableErrMsg"); break;
                        case 475 : $scope.loginError = translateMessages($translate, "temPasswordExpirdMsg"); break;
                        case 476 : $scope.loginError = translateMessages($translate, "accountLocked"); break;
                        case 477 : $scope.loginError = translateMessages($translate, "passwordExpiryMsg"); break;
                        case 472 : $scope.loginError = translateMessages($translate, "accNotActive"); break;
                        case 474 : $scope.loginError = translateMessages($translate, "usernameOrPwdIncorrectErrorMsg"); break;
                        case 471 : $scope.loginError = translateMessages($translate, "usernameOrPwdIncorrectErrorMsg"); break;    
                        default : $scope.loginError = translateMessages($translate, "serviceUnAvailable");
                    }
            });
        }
        $scope.authenticateUserOnline = function() {
        		if ($scope.username == undefined || $scope.username == "" || $scope.password == undefined || $scope.password == "") {
        			$scope.isLoggingError = true;
        			showHideLoadingImage(false,null,null,"Authenticate");
        			$rootScope.isAuthenticated = false;
        			$scope.loginError = translateMessages($translate,"usernameOrPwdEmptyErrorMsg");
        			$scope.$apply();
        		} else {
                    if(rootConfig.isDeviceMobile) {
                        CheckforRootedDevice(proceedWithLogin, rootCheckError);
                    }
                    else {
                        proceedWithLogin();
                    }
        		    
        		}
        	};
			
			//ReAuthentication CR Starts
			$scope.authenticateUserOnlineReDirect = function() {
        		if ($scope.username == undefined || $scope.username == "" || $scope.password == undefined || $scope.password == "") {
        			$scope.isLoggingError = true;
        			showHideLoadingImage(false,null,null,"Authenticate");
        			$rootScope.isAuthenticated = false;
        			$scope.loginError = translateMessages($translate,"usernameOrPwdEmptyErrorMsg");
        			$scope.$apply();
        		} else {
                    if(rootConfig.isDeviceMobile) {
                        CheckforRootedDevice(proceedWithLoginReDirect, rootCheckError);
                    }
                    else {
                        proceedWithLoginReDirect();
                    }
        		    
        		}
        	};
			
			function proceedWithLoginReDirect() {
            authService.login(
            	{
            		username : $scope.username,
            		password : CryptoJS.SHA512($scope.password).toString(CryptoJS.enc.Hex)

            	},
            	function(data,res) {
            		/*$rootScope.username = $scope.username;
            		$rootScope.isAuthenticated = true;
            	    $rootScope.isLoggedOut = true;
            		$rootScope.username = $scope.username;
            		$rootScope.authenticationStatus = "SUCCESS";
					$rootScope.role = data.roles[0];
            		$scope.userDetails.user.userId = $scope.username;
            		$scope.userDetails.user.password = Encrypt_text($scope.password);
					$scope.userDetails.user.shaPassword = CryptoJS.SHA512($scope.password).toString(CryptoJS.enc.Hex); */
                    var userDetilsModel = JSON.parse(sessionStorage.userDetails);
					UserDetailsService.userDetilsModel.user.token = res;
            		userDetilsModel.options.headers.Token=res;
					UserDetailsService.userDetilsModel.user.token = res;
            		UserDetailsService.userDetilsModel.options.headers.Token=res;
					sessionStorage.userDetails = JSON.stringify(userDetilsModel);
					$route.reload();
					//$location.path($scope.url);
					/*$scope.userDetails.user.rexitLoginId  = data.userCode;
					$rootScope.agentId = angular.copy(data.userCode);
            		$rootScope.firstTimeLogin = data.firstTimeLogin;
            	    $rootScope.isTemporaryPassword = data.isTemporaryPassword;
            	    $rootScope.role = data.roles[0];
					sessionStorage.userDetails = JSON.stringify($scope.userDetails);
					sessionStorage.loginData = JSON.stringify(data);
            		UserDetailsService.setUserDetailsModel($scope.userDetails);
            		if ($rootScope.authenticationStatus == commonConfig().STATUS.SUCCESS) {
            			// Push Notification registering
            		    $scope.loadLandingPage()
            		    if(!(rootConfig.isDeviceMobile)){
            		        LoginService.saveToken(appDataShareService.mContentRoles
            					,function(res){
            					    localStorage[getUniqueAppNamePattern(commonConfig().STORAGE.MCONTENTROLES)]=commonConfig().STATUS.NOT_AUTHENTICATED;
            					},function(res){
            					}
            				);
            		    }
            		} else {
            			$scope.isLoggingError = true;
            			showHideLoadingImage(false,null,null,"Authenticate");
            			$rootScope.isAuthenticated = false;
            			$scope.loginError = translateMessages($translate,"credentialsValidationErrorMessage");
            			$scope.$apply();
            		}*/
            	}, function(data, status) {
					/*showHideLoadingImage(false,null,null,"Authenticate");
                    $scope.isLoggingError = true;
                    $rootScope.isAuthenticated = false;
                    $rootScope.isOnlineAuthenticated=false;
                    switch(status) {
                        case 401:  $scope.loginError = translateMessages($translate, "loginCredentialErrorMsg"); break;
                        case 404: $scope.loginError = translateMessages($translate, "resourceNotFoundErrMsg"); break;
                        case 500 : $scope.loginError = translateMessages($translate, "resourceUnAvailableErrMsg"); break;
                        case 475 : $scope.loginError = translateMessages($translate, "temPasswordExpirdMsg"); break;
                        case 476 : $scope.loginError = translateMessages($translate, "accountLocked"); break;
                        case 477 : $scope.loginError = translateMessages($translate, "passwordExpiryMsg"); break;
                        case 472 : $scope.loginError = translateMessages($translate, "accNotActive"); break;
                        default : $scope.loginError = translateMessages($translate, "usernameOrPwdIncorrectErrorMsg");
                    }*/
					if (rootConfig.isDeviceMobile && !checkConnection()) {
						$scope.message = translateMessages($translate, "networkValidationErrorMessage");
					}else{
						//$scope.message = translateMessages($translate, "validToken");
						switch(status) {
                        case 401:  $scope.message = translateMessages($translate, "loginCredentialErrorMsg"); break;
                        case 404: $scope.message = translateMessages($translate, "resourceNotFoundErrMsg"); break;
                        case 500 : $scope.message = translateMessages($translate, "resourceUnAvailableErrMsg"); break;
                        case 475 : $scope.message = translateMessages($translate, "temPasswordExpirdMsg"); break;
                        case 476 : $scope.message = translateMessages($translate, "accountLocked"); break;
                        case 477 : $scope.message = translateMessages($translate, "passwordExpiryMsg"); break;
                        case 472 : $scope.message = translateMessages($translate, "accNotActive"); break;
                        default : $scope.message = translateMessages($translate, "validToken");
						}
					}		
					$rootScope.$emit('tokenEvent', { message: $scope.message });
            });
        }
		$rootScope.$on('mobilereAuthentication', function (event, args) {
								 $scope.authenticateUserOnlineReDirect();
							});		
		
		//ReAuthentication CR ends
		
        	$scope.getFromApplicationPath = function(jsonFile,
            		successCallBack, errorCallback) {
            	var self = this;
            	self._prepareErrorCallBack = function(
            			errorCode, errorMessage) {
            		console.log(errorMessage);
            	};
            	if (rootConfig && rootConfig.isOfflineDesktop) {
            		var fs = require('fs');
            		fs.readFile(jsonFile, 'utf8', function(err,
            				data) {
            			if (err) {
            				self._prepareErrorCallBack(
            						'Error_106',
            						'Error while fetching config JSON from remote location'
            								+ jsonFile,
            						errorCallback);
            			}
            			successCallBack(data);
            		});
            	} else {
            		url:
            				rootConfig.contentAdminDownLoadURL
            						+ jsonFile,
            				$
            						.getJSON(jsonFile)
            						.done(
            								function(
            										jsonObject,
            										textStatus) {
            									successCallBack(jsonObject);
            								})
            						.fail(
            								function(jqxhr,
            										settings,
            										exception) {
            									self
            											._prepareErrorCallBack(
            													'Error_106',
            													'Error while fetching config JSON from remote location . '
            															+ JSON
            																	.stringify(error),
            													errorCallback);
            								});
            	}
            };
    $scope.loadLandingPage = function() {
		showHideLoadingImage(false,null,null,"Authenticate");
        if(rootConfig.isDeviceMobile) {
            var configuration = JSON.parse(localStorage.getItem('configuration'));
            if (!configuration) {
                configuration = JSON.parse('{"appMajorVersion": "'+ rootConfig.majorVersion
                                + '", "appMinorVersion": "'+ rootConfig.minorVersion + '"}');
                localStorage.setItem('configuration',JSON.stringify(configuration));
            }
            else {
                var appUpgrade = false;
                if (Number(configuration.appMajorVersion) < Number(rootConfig.majorVersion)) {
                    appUpgrade = true;
                } else if (Number(configuration.appMajorVersion) == Number(rootConfig.majorVersion)
                        && Number(configuration.appMinorVersion) < Number(rootConfig.minorVersion)) {
                    appUpgrade = true;
                }
            }
            if(appUpgrade) {
                configuration = JSON.parse('{"appMajorVersion": "'+ rootConfig.majorVersion
                                            + '", "appMinorVersion": "'+ rootConfig.minorVersion
                                            + '"}');
                localStorage.setItem('configuration',JSON.stringify(configuration));
            }
        }

        showHideLoadingImage(false);
		if ($scope.rememberMe == true) {
        	var loginDetails = {
        		'leuname' : $scope.username
        	};
        	localStorage
        			.setItem(
        					'loginDetails',
        					JSON
        							.stringify(loginDetails));
        } else {
        	localStorage
        			.removeItem('loginDetails');
        }
		$rootScope.isRedirectFromLogin = true;
		$rootScope.isAuthenticated = true;
		$rootScope.isInLoginPage = false;
		localStorage[getUniqueAppNamePattern(commonConfig().STORAGE.AUTHENTICATED_USER)]="yes";
		$rootScope.isRedirectFromLogin = false;
		
		if($rootScope.isTemporaryPassword){
			if($rootScope.firstTimeLogin){
				$('#privacyPopup').modal();//ON agree click move to change password page.
				$('.modal-backdrop.fade.in').addClass('no-click');
			}
			else{
			 	$scope.agreeClick();
			}
         }  else {
             $rootScope.isLoggedOut = false;
		    $location.path('/dashboard');
		}
        $timeout(function(){
            $scope.$apply();
        }, 100);
    };
	$scope.navigateToLink = function(path){
		window.open(path, '_system');
	}
	$scope.agreeClick = function(){
		 $('#privacyPopup').modal('hide');
		 $rootScope.isLoggedOut = true;
         $location.path('/resetPassword');
	}
	$scope.disagreeClick = function(){
		 $rootScope.completeLogOut();
		 $('#privacyPopup').modal('hide');
	}
	$rootScope.$on("$locationChangeStart", function(e,
    		currentLocation, previousLocation) {
    	localStorage["prevPath"] = previousLocation;
    });

    function CheckforRootedDevice (successcallback, errorcallback) {
    	// Checking is the device rooted or
    	// jailbroken through Cordova
    	// plugin
    	if (rootConfig.rootCheckEnabled) {
    		CDVPLUGIN.SystemCheck
    			.RootCheck({
    					action : 'RootCheck'
    				},
    				function(res) {
    					if (res.rootedStatus) {
    						$scope.alertMessage = translateMessages(
    								$translate,
    								res.message);
    						if (res.message == "rootediOS") {
    						    $scope.isRootediOS = true;
    						    $scope.rootedDevice = true;
                                $scope.rootedMessage = translateMessages($translate,"rootediOS");
    						    if  (rootConfig.allowDataWipeInRootedDevice){
    						        DataWipeService.deleteAllConfigFiles(commonConfig().DATA_WIPE_REASON.ROOTED_DEVICE, function(){
                                        console.log("Data wipe done!");
                                    }, function(error){
                                        console.log("Error occurred during data wipe : " + " : " + error);
                                    });
    						    }
    						} else {
    						    $scope.exitApp = true;
    						    $scope.rootedDevice = true;
                                $scope.rootedMessage = translateMessages($translate,"rootedAndroid");
    						    if  (rootConfig.allowDataWipeInRootedDevice){
    						        DataWipeService.deleteAllConfigFiles(commonConfig().DATA_WIPE_REASON.ROOTED_DEVICE,function(){
                                        console.log("Data wipe done!");
                                    }, function(error){
                                        console.log("Error occurred during data wipe : " + " : " + error);
                                    });
    						    }
    						}
    					} else {
    						successcallback();
    					}
    				}, function(err) {
    					errorcallback();
    		        }
    		    );
    	} else {
    		successcallback();
    	}
    }

    function rootCheckError(error) {
        console.log("Error::" + error);
    }

}]);
