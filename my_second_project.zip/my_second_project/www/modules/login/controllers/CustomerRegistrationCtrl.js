mServiceApp.controller('CustomerRegistrationCtrl',['$controller','$rootScope', '$scope',  '$compile', '$route', '$routeParams',
						'$location', '$translate','dataService','appDataShareService','authService','UserDetailsService',
						'LoginService','gli_dataservice','debounce','$timeout','PersistenceMapping','$filter','$window',
						function($controller ,$rootScope, $scope,  $compile, $route, $routeParams, $location,
								 $translate,dataService,appDataShareService,authService,UserDetailsService,LoginService,gli_dataservice,
								 debounce,$timeout,PersistenceMapping,$filter,$window) {
	angular.extend(this, $controller('BaseCtrl',{$scope:$scope, $rootScope:$rootScope, dataService:dataService, type:'ValidateCustomer', userId:appDataShareService.selectedUser.userId, userCode:appDataShareService.userCode,loggedInUserType:$rootScope.moduleVariable}));
	var _this = this;
	$scope.agentCode = "";
	$scope.businessRegNo = "";
	$scope.nomineeMobNo = "";
	$scope.emailAdd = "";
	$scope.errorFlag = false;
	$scope.registrationSuccessfull = false;
	$scope.successMsg = "";
	$scope.showPopUpMsg = false;
    $scope.activeResendBtn = true;
	$scope.selectedpage = "User Registration";
	$scope.convertertranslate = function(name) {
        	return $filter('translate')(name);
        };
	$scope.getTransationSuccess = function(data) {
    	 $scope.errorMessage = [];
    	 if(data[0] !== undefined && data[0].TransactionData !== null){
    		   var statusCode = data[0].TransactionData.StatusData.StatusCode;
    		   showHideLoadingImage(false);
    		   //Authorization is successful
    		   if(statusCode === "200"){
    			  $scope.registrationSuccessfull = true;
    			  /* $scope.showPopUpMsg = true; */
				  /* $('#authorizationStatus').modal(); */
    			  $scope.successMsg = $scope.convertertranslate("userRegnSucc");
                   $scope.activeResendBtn = false;
    		   }
    		   else if(statusCode === "500"){
    			  $scope.errorMessage.push("userRegInvalidDataMsg");
    		   }
    		   else if(statusCode === "501"){
    			   $scope.errorMessage.push("agentAlreadyExistMsg");
    		   }
			   else{
				   $scope.errorMessage.push("userRegInvalidDataMsg");
			   }
    		   $scope.$apply();
    	}
    };
		$scope.getTransationError = function(data) {
			 $rootScope.serviceFailed=true;
                	if (rootConfig.isDeviceMobile && !checkConnection()) {
						$scope.message = translateMessages($translate, "networkValidationErrorMessage");
					}else{
						$scope.message = translateMessages($translate, "regServerError");
					}
                	$scope.$emit('tokenEvent', { message: $scope.message });
                	if (data == "Error in ajax callE")
                       {
                           $scope.onServerError=true;
                           $scope.serverErrorMessage= translateMessages($translate, "serverErrorMessage");
                          showHideLoadingImage(false);
                       }
                       else
                       {
                		showHideLoadingImage(false);
                       }
                	$rootScope.$apply();
		};
		$scope.validateUserDetails = function(){
        	$scope.errorMessage = [];
        	if(!$scope.agentCode){
        		$scope.errorFlag = true;
        		$scope.errorMessage.push("agentCodeEmptyMsg");
        	}
        	if(!$scope.businessRegNo){
            	$scope.errorFlag = true;
            	$scope.errorMessage.push("businessRegNoEmptyMsg");
            }
        	if(!$scope.nomineeMobNo){
            	$scope.errorFlag = true;
            	$scope.errorMessage.push("nomineeMobNoEmptyMsg");
            }
        	if(!$scope.emailAdd){
            	$scope.errorFlag = true;
            	$scope.errorMessage.push("emailAddEmptyMsg");
            }
			if($scope.errorFlag){
				return false;
			} else {
				return true;
			}
		};
		$scope.registerUser = function() {
			$scope.errorFlag = false;
			$scope.showPopUpMsg = false;
			$scope.successMsg = "";
			$scope.registrationSuccessfull = false;
			$scope.errorMessage = [];
			if($scope.validateUserDetails()){
				var transObj = $scope.mapScopeToPersistance();
				var userDetails = {
							"userDetails": {
                                				"agentCode": $scope.agentCode,
                                				"businessRegCode": $scope.businessRegNo,
                                				"nomineeMob": $scope.nomineeMobNo,
                                				"email": $scope.emailAdd
                                			}
                                };
				transObj.TransactionData = userDetails;
				transObj.Type  = "UserDetails";
				showHideLoadingImage(true, "Loading...");
				if((rootConfig.isDeviceMobile && checkConnection()) || !rootConfig.isDeviceMobile){
			        gli_dataservice.getTransactions(transObj,$scope.getTransationSuccess,$scope.getTransationError);
			     }else{
			        $scope.getTransationError();
			     }
				}
		};
		$scope.getTransationResendSuccess = function(data){
				 $scope.errorMessage = [];
                    if(data[0] !== undefined && data[0].TransactionData !== null){
                    	var statusCode = data[0].TransactionData.StatusData.StatusCode;
                    	showHideLoadingImage(false);
                    	//Authorization is successful
                    	if(statusCode === "100"){
							$scope.registrationSuccessfull = true;
                    		$scope.errorMessage.push("userRegnSucc");
						}
                    }
		};
		$scope.resendAuthorizationCode = function(customValidate) {
			    var transObj = $scope.mapScopeToPersistance();
				transObj.Key5 = $scope.customerType;
				var searchObj = {
                                	"context" : "CUSTOMER_PORTAL",
                                	"transactionType" : "REGISTRATION"
                                };
				transObj.TransactionData = searchObj;
				transObj.Type  = "ResendAuthorizationCode";
				showHideLoadingImage(true, "Loading..");
				if((rootConfig.isDeviceMobile && checkConnection()) || !rootConfig.isDeviceMobile){
			        dataService.searchTransactions(transObj, $scope.authorizationToken, $scope.getTransationResendSuccess,$scope.getTransationError);
			     }else{
			        $scope.getTransationError();
			     }
				$scope.showNetworkMessage = false;
		};
		$scope.mapScopeToPersistance = function(type) {
	        PersistenceMapping.clearTransactionKeys();
	        PersistenceMapping.Key5 = "Agent";
	        PersistenceMapping.Key2 = $scope.agentCode;
	        PersistenceMapping.Type = "";
	        var transactionObj = PersistenceMapping.mapScopeToPersistence({});
	        return transactionObj;
	    };
		$scope.okClick = function(){
			$('#authorizationStatus').modal('hide');
			$location.path('/login');
			
		};
}]);











