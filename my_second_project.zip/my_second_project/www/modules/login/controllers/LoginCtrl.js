mServiceApp.controller('LoginCtrl',['$controller','$rootScope', '$scope', '$http', '$compile', '$route', '$routeParams', '$location', '$translate','dataService','appDataShareService','authService','UserDetailsService','LoginService','AgentService','AutoSync','debounce','$timeout','commonConfig','loginConfig','PersistenceMapping','UtilityService','DataLookupService',function($controller ,$rootScope, $scope, $http, $compile, $route, $routeParams, $location, $translate,dataService,appDataShareService,authService,UserDetailsService,LoginService,AgentService,AutoSync,debounce,$timeout,commonConfig,loginConfig,PersistenceMapping,UtilityService,DataLookupService) {

	popupOver = false;
	$rootScope.noSDRole=false;
	$rootScope.isDevicePhone=rootConfig.isDevicePhone;
	$rootScope.version = rootConfig.version;
	$scope.userDetails = UserDetailsService.getUserDetailsModel();
	if(typeof sessionStorage.currentUser!="undefined" && !(rootConfig.isDeviceMobile))
        {	
   appDataShareService.isSwitchEnabled=true;
	showHideLoadingImage(true, "Loading ..", null,"Authenticate");
	$rootScope.isAuthenticated = true;
	$rootScope.loginflag = false;
	var logedinuser = $.parseJSON(sessionStorage.getItem('currentUser'));
	appDataShareService.selectedUser.userId=logedinuser[0].userId;
	$rootScope.loggedInUser = logedinuser[0].userName;
	appDataShareService.selectedUser.name=logedinuser[0].userName;
	var userDetilsModel = JSON.parse(sessionStorage.userDetails);
	$scope.password = angular.copy(userDetilsModel.user.password);
	if(typeof sessionStorage.isAGT!="undefined")
	{
		if (sessionStorage.isAGT=="true"){
	              $rootScope.isAGT = true;
		}
		else
		{
		  $rootScope.isAGT = false;
		}
	}
	if(typeof sessionStorage.isAA!="undefined")
	{
		if (sessionStorage.isAA=="true") {
			$rootScope.isAA = true;
		}
		else{
			$rootScope.isAGT = false;
		}
	}

	if(typeof sessionStorage.isShowADM!="undefined")
	{
		if (sessionStorage.isShowADM=="true") {
			$rootScope.isShowADM = true;
		}
		else{
			$rootScope.isShowADM = false;
		}
	}
	$scope.authenticateUserOnlineReDirect = function() {
        		if ($scope.username == undefined || $scope.username == "" || $scope.password == undefined || $scope.password == "") {
        			$scope.isLoggingError = true;
        			showHideLoadingImage(false,null,null,"Authenticate");
        			$rootScope.isAuthenticated = false;
        			$scope.loginError = translateMessages($translate,"usernameOrPwdEmptyErrorMsg");
        			$scope.$apply();
        		} else {
                    if(rootConfig.isDeviceMobile) {
                        CheckforRootedDevice(proceedWithLoginReDirect, rootCheckError);
                    }
                    else {
                        proceedWithLoginReDirect();
                    }
        		    
        		}
        	};
			
		function proceedWithLoginReDirect() {
            authService.login(
            	{
            		username : $scope.username,
            		password : CryptoJS.SHA512($scope.password).toString(CryptoJS.enc.Hex)

            	},
            	function(data,res) {
            		/*$rootScope.username = $scope.username;
            		$rootScope.isAuthenticated = true;
            	    $rootScope.isLoggedOut = true;
            		$rootScope.username = $scope.username;
            		$rootScope.authenticationStatus = "SUCCESS";
					$rootScope.role = data.roles[0];
            		$scope.userDetails.user.userId = $scope.username;
            		$scope.userDetails.user.password = Encrypt_text($scope.password);
					$scope.userDetails.user.shaPassword = CryptoJS.SHA512($scope.password).toString(CryptoJS.enc.Hex); */
                    var userDetilsModel = JSON.parse(sessionStorage.userDetails);
					userDetilsModel.user.token = res;
            		userDetilsModel.options.headers.Token=res;
					sessionStorage.userDetails = JSON.stringify(userDetilsModel);
					showHideLoadingImage(false,null,null,"Authenticate");
					sessionStorage.removeItem("reAuthentication");
					$location.path(logedinuser[0].currentUrl);
					/*$scope.userDetails.user.rexitLoginId  = data.userCode;
					$rootScope.agentId = angular.copy(data.userCode);
            		$rootScope.firstTimeLogin = data.firstTimeLogin;
            	    $rootScope.isTemporaryPassword = data.isTemporaryPassword;
            	    $rootScope.role = data.roles[0];
					sessionStorage.userDetails = JSON.stringify($scope.userDetails);
					sessionStorage.loginData = JSON.stringify(data);
            		UserDetailsService.setUserDetailsModel($scope.userDetails);
            		if ($rootScope.authenticationStatus == commonConfig().STATUS.SUCCESS) {
            			// Push Notification registering
            		    $scope.loadLandingPage()
            		    if(!(rootConfig.isDeviceMobile)){
            		        LoginService.saveToken(appDataShareService.mContentRoles
            					,function(res){
            					    localStorage[getUniqueAppNamePattern(commonConfig().STORAGE.MCONTENTROLES)]=commonConfig().STATUS.NOT_AUTHENTICATED;
            					},function(res){
            					}
            				);
            		    }
            		} else {
            			$scope.isLoggingError = true;
            			showHideLoadingImage(false,null,null,"Authenticate");
            			$rootScope.isAuthenticated = false;
            			$scope.loginError = translateMessages($translate,"credentialsValidationErrorMessage");
            			$scope.$apply();
            		}*/
            	}, function(data, status) {
					/*showHideLoadingImage(false,null,null,"Authenticate");
                    $scope.isLoggingError = true;
                    $rootScope.isAuthenticated = false;
                    $rootScope.isOnlineAuthenticated=false;
                    switch(status) {
                        case 401:  $scope.loginError = translateMessages($translate, "loginCredentialErrorMsg"); break;
                        case 404: $scope.loginError = translateMessages($translate, "resourceNotFoundErrMsg"); break;
                        case 500 : $scope.loginError = translateMessages($translate, "resourceUnAvailableErrMsg"); break;
                        case 475 : $scope.loginError = translateMessages($translate, "temPasswordExpirdMsg"); break;
                        case 476 : $scope.loginError = translateMessages($translate, "accountLocked"); break;
                        case 477 : $scope.loginError = translateMessages($translate, "passwordExpiryMsg"); break;
                        case 472 : $scope.loginError = translateMessages($translate, "accNotActive"); break;
                        default : $scope.loginError = translateMessages($translate, "usernameOrPwdIncorrectErrorMsg");
                    }*/
					if (rootConfig.isDeviceMobile && !checkConnection()) {
						$scope.message = translateMessages($translate, "networkValidationErrorMessage");
					}else{
						//$scope.message = translateMessages($translate, "validToken");
						switch(status) {
                        case 401:  $scope.message = translateMessages($translate, "loginCredentialErrorMsg"); break;
                        case 404: $scope.message = translateMessages($translate, "resourceNotFoundErrMsg"); break;
                        case 500 : $scope.message = translateMessages($translate, "resourceUnAvailableErrMsg"); break;
                        case 475 : $scope.message = translateMessages($translate, "temPasswordExpirdMsg"); break;
                        case 476 : $scope.message = translateMessages($translate, "accountLocked"); break;
                        case 477 : $scope.message = translateMessages($translate, "passwordExpiryMsg"); break;
                        case 472 : $scope.message = translateMessages($translate, "accNotActive"); break;
                        default : $scope.message = translateMessages($translate, "validToken");
						}						
					}
					$scope.password	= '';
					sessionStorage.removeItem("reAuthentication");					
					$rootScope.$emit('tokenEvent', { message: $scope.message });
            });
        }
		
		if(typeof sessionStorage.reAuthentication!="undefined" && !(rootConfig.isDeviceMobile))
		{
			$scope.username = angular.copy(userDetilsModel.user.userId);
			$scope.password = angular.copy(Decrypt_text(userDetilsModel.user.password));
			$scope.url = angular.copy(logedinuser[0].currentUrl);
			$scope.authenticateUserOnlineReDirect();    
		}
		else
		{
			showHideLoadingImage(false,null,null,"Authenticate");
			$location.path(logedinuser[0].currentUrl);
		}
	
    }
	else{
	$rootScope.loginflag = true;
        $rootScope.isAuthenticated = false;
	var serviceFailedTimes = 0;
	$rootScope.isAutoSyncCompleted = true;
	$scope.noOfReporties = 0;
	$scope.isSubmitted = false;
	var IntialLoggedUser;
	$scope.isLoggingError = false;


	if (JSON.parse(localStorage.getItem(getUniqueAppNamePattern(commonConfig().PAGE_DETAILS.LOGIN))) !== null) {
		var retrievedObject = JSON.parse(localStorage.getItem(getUniqueAppNamePattern(commonConfig().PAGE_DETAILS.LOGIN)));
		$scope.username = retrievedObject.uname;
	if (rootConfig.isDeviceMobile)
		$scope.password = Decrypt_text(retrievedObject.pwd);

	}
	/*if (typeof(localStorage[getUniqueAppNamePattern(commonConfig().PAGE_DETAILS.LOGIN)])!="undefined") {
			$scope.rememberme = true;

	}
	else
	{
		$scope.rememberme=false;
	}*/


	$scope.loginAftrFetchKey = function() {
		if (navigator.userAgent.search(commonConfig().SEARCH_OPTION.MSIE) >= 0) {
			showHideLoadingImage(true, "Authenticating User", null,"Authenticate");
		} 
		/*else {
			showHideLoadingImage(true, "authenticatingUser", $translate,"Authenticate");
		}*/

		if (rootConfig.isDeviceMobile) {

			if (navigator.network.connection.type == Connection.NONE) {
				LoginService.checkAgentIdExistingInDb(
								{
									userId : $scope.username,
									password : $scope.password
								},
								function(agentData) {
										
									if (agentData.length > 0) {
										PersistenceMapping.clearTransactionKeys();
										var transactionObj = PersistenceMapping
										.mapScopeToPersistence({});
										transactionObj.Key1 = $scope.username;
										$scope.userDetails.user.userId = agentData[0].agentId;
										$scope.userDetails.user.password = Encrypt_text(agentData[0].password)
										$scope.userDetails.user.token = agentData[0].token;
										$scope.userDetails.options.headers.Token=agentData[0].token;
										UserDetailsService.setUserDetailsModel($scope.userDetails);
										dataService.retrieveAgentDetails(
											transactionObj, function(data) {
												if ($scope.password == Decrypt_text(agentData[0].password)) {
											showHideLoadingImage(false,null,null,"Authenticate");
											// check the offline max days
											var currentDate = new Date();
											var offlineDueDate = new Date(
													currentDate
															.setDate(currentDate
																	.getDate()
																	- rootConfig.maxPermittedOfflineDuration));
											var lastLoggedIn = agentData[0].lastLoggedDate;

											if (new Date(lastLoggedIn) > offlineDueDate) {

												$rootScope.username = $scope.username;
												//DeviceUserID = $rootScope.username;

												appDataShareService.selectedUser.userId = agentData[0].agentId;
												var agentId = {
														'Id' : agentData[0].agentId
													};
												localStorage.setItem(getUniqueAppNamePattern(commonConfig().STORAGE.AGENT_ID),JSON.stringify(agentId));

												var loginDetailsList = $
														.parseJSON(localStorage
																.getItem(getUniqueAppNamePattern(commonConfig().PAGE_DETAILS.INITIAL_LOGIN)));
												for (var i = 0; i < loginDetailsList.length; i++) {
													if (loginDetailsList[i].IntialLoggedUserId == $scope.username) {
														$rootScope.loggedInUser = loginDetailsList[i].IntialLoggedUserName;
														appDataShareService.selectedUser.name = $rootScope.loggedInUser;
														break;
													}
												}

												// $rootScope.loggedInUser =
												// localStorage.getItem(getUniqueAppNamePattern(commonConfig().PAGE_DETAILS.INITIAL_LOGIN));
												var lastSyncInfo = $
														.parseJSON(localStorage
																.getItem(getUniqueAppNamePattern(commonConfig().PAGE_DETAILS.LAST_SYNCED)));
												$rootScope.syncLabel = lastSyncInfo.syncLabel;
												$rootScope.lastSyncedDate = lastSyncInfo.lastSyncedDate;

												$rootScope.IntialloggedInUser =  agentData[0].agentId;
												$rootScope.isAuthenticated = true;
												localStorage[getUniqueAppNamePattern(commonConfig().STORAGE.AUTHENTICATED_USER)]="yes";
												//localStorage.userDetails.authenticateduser="yes";
												if ($scope.rememberme == true) {
													var loginDetails = {
														'uname' : $scope.username,
														'pwd' : Encrypt_text($scope.password)
													};
													localStorage
															.setItem(getUniqueAppNamePattern(
																	commonConfig().PAGE_DETAILS.LOGIN),
																	JSON
																			.stringify(loginDetails));
												} else {
													localStorage
															.removeItem(getUniqueAppNamePattern(commonConfig().PAGE_DETAILS.LOGIN));
												}

												if (agentData[0].designation == loginConfig().DESIGNATION.PSA || agentData[0].designation == loginConfig().DESIGNATION.SAD||agentData[0].designation == loginConfig().DESIGNATION.AAM || agentData[0].designation == loginConfig().DESIGNATION.SAP || agentData[0].designation == loginConfig().DESIGNATION.APA || agentData[0].designation == loginConfig().DESIGNATION.ADM)
												{

													$rootScope.isShowADM = true;
													sessionStorage.isShowADM = true;
													var admDetails = {
															'isShowADM' : $rootScope.isShowADM
														};
													localStorage.setItem(getUniqueAppNamePattern(commonConfig().PAGE_DETAILS.ADM),JSON.stringify(admDetails));
												}
											else
												{
													$rootScope.isShowADM = false;
													sessionStorage.isShowADM = false;
													var admDetails = {
															'isShowADM' : $rootScope.isShowADM
														};
													localStorage.setItem(getUniqueAppNamePattern(commonConfig().PAGE_DETAILS.ADM),JSON.stringify(admDetails));
												}


												var aaDetails = $.parseJSON(localStorage.getItem(getUniqueAppNamePattern(commonConfig().PAGE_DETAILS.AA)));
                                                $rootScope.isAA = aaDetails.isAA;

                                                $location.path('/dashboard');
												$scope.$apply();

											} else {
												$scope.isLoggingError = true;
												$rootScope.isAuthenticated = false;
												$scope.loginError = "You are offline for last"+" "
														+ rootConfig.maxPermittedOfflineDuration+" "
														+ "days. Please be online and login using your SSO ID & password";
												$scope.$apply();
											}
										} else {
											showHideLoadingImage(false,null,null,"Authenticate");
											$scope.isLoggingError = true;
											LoginService
													.deleteToken(
															$scope.userDetails,
															function(res) {

															},
															function(error) {


															});
											$rootScope.isAuthenticated = false;
											$scope.loginError = translateMessages($translate,"credentialsValidationErrorMessage");
											$scope.$apply();
										}
												
												});
										
									} else {
										showHideLoadingImage(false,null,null,"Authenticate");
										$scope.isLoggingError = true;
										$rootScope.isAuthenticated = false;
										$scope.loginError = translateMessages($translate,"networkErrorMessage");
										$scope.$apply();
									}
								},
								function(err) {
									showHideLoadingImage(false,null,null,"Authenticate");
									$scope.isLoggingError = true;

									$rootScope.isAuthenticated = false;
									$scope.loginError = translateMessages($translate,"credentialsValidationErrorMessage");
									$scope.$apply();
								});
			} else {
				$scope.authenticateUserOnline();
			}
		} else {
			$scope.authenticateUserOnline();
		}
	};
	}
	$scope.loadConfigfile = function(successCallBack) {
		var configUrl = null;
		var resourceUrl = null;
		var documentsPath;
		if (rootConfig.isDeviceMobile) {
				documentsPath = rootConfig.contentAdminDownLoadURL;
				configUrl = documentsPath +"/" +"appconfig.json";

			$scope.getFromApplicationPath(configUrl,
				function(
					jsonObject) {
					config = jsonObject;
					$
						.extend(
							true,
							rootConfig,
							config);
					successCallBack();

				});

		} else {
			$scope
				.getFromRemote(
					"appconfig.json",
					false,
					function(jsonObject) {
						config = JSON.parse(jsonObject);
						$.extend(true,
							rootConfig,
							config);
						successCallBack();
					});



		}
};
	
	$scope.retrieveAgentProfile = function(successCallBack) {
					PersistenceMapping.clearTransactionKeys();
					var transactionObj = PersistenceMapping
							.mapScopeToPersistence({});
					transactionObj.Key1 = $scope.userDetails.user.userId;		
					if(rootConfig.isDeviceMobile) {
						$scope.checkConnection = checkConnection();
						if ($scope.checkConnection) {
							AgentService.retrieveAgentProfileOnline(
									transactionObj,
									$scope.onRetrieveAgentProfileSuccess,
									$scope.onRetrieveAgentProfileError);
						} else {
							AgentService.retrieveAgentProfileOffline(
									transactionObj,
									$scope.onRetrieveAgentProfileDataSuccess,
									$scope.onRetrieveAgentProfileError);
						}
					} else {
						AgentService.retrieveAgentProfileOnline(
									transactionObj,
									$scope.onRetrieveAgentProfileSuccess,
									$scope.onRetrieveAgentProfileError);
					}
									
									
    };
	
	  $scope.onRetrieveAgentProfileDataSuccess = function(data) {
									var AgentDetails;
									 if(data[0].channelId) {
										 data.AgentDetails = data[0];
										 $scope.onRetrieveAgentProfileSuccess(data);
									 } else if(data.AgentDetails){
										 $scope.onRetrieveAgentProfileSuccess(data);
									 } 
								};
								
	$scope.authenticateUserOnline = function() {

		if ($scope.username == undefined || $scope.password == undefined) {
			$scope.isLoggingError = true;
			showHideLoadingImage(false,null,null,"Authenticate");
			$rootScope.isAuthenticated = false;
			$scope.loginError = translateMessages($translate,"credentialsValidationErrorMessage");
			$scope.$apply();
		} else {
			authService
					.login(
							{
								username : $scope.username,
								password : $scope.password

							},
							function(res) {
								$rootScope.username = $scope.username;
								$rootScope.isAuthenticated = true;
								if (rootConfig.isDeviceMobile) {
									$rootScope.lastSyncedDate = Date.now();// "Last
									// synched
									// on :
									// ";
									$rootScope.syncLabel = commonConfig().STATUS.LAST_SYNC_ON;
								}
								$rootScope.username = $scope.username;
								$rootScope.authenticationStatus = "SUCCESS";
								$scope.userDetails.user.userId = $scope.username;
								$scope.userDetails.user.password = Encrypt_text($scope.password)
                                $scope.userDetails.user.token = res;
								$scope.userDetails.options.headers.Token=res;
								
								UserDetailsService.setUserDetailsModel($scope.userDetails);


								if ($rootScope.authenticationStatus == commonConfig().STATUS.SUCCESS) {

									// Push Notification registering
									$scope.loadConfigfile($scope.retrieveAgentProfile);
							
								if(!(rootConfig.isDeviceMobile)){
								LoginService.saveToken(appDataShareService.mContentRoles
																		,function(res){
																			//alert("---");
																		localStorage[getUniqueAppNamePattern(commonConfig().STORAGE.MCONTENTROLES)]=commonConfig().STATUS.NOT_AUTHENTICATED;
																		//alert("--"+localStorage.mContentRoles);
																		},function(res){
																			//alert("err---");
																		});
								}
								

								} else {
									$scope.isLoggingError = true;
									showHideLoadingImage(false,null,null,"Authenticate");
									$rootScope.isAuthenticated = false;
									$scope.loginError = translateMessages($translate,"credentialsValidationErrorMessage");

									$scope.$apply();
								}
				}, function(data, status) {
                $rootScope.isAuthenticated = false;
				$rootScope.isOnlineAuthenticated=false;
                if (status == 401) {
                    $scope.loginError = translateMessages($translate, "loginCredentialErrorMsg");
                } else if (status == 404) {
                    $scope.loginError = translateMessages($translate, "resourceNotFoundErrMsg");
                } else if (status == 500) {
                    $scope.loginError = translateMessages($translate, "resourceUnAvailableErrMsg");
                } else {
                    $scope.loginError = translateMessages($translate, "loginCredentialErrorMsg");
                }				
						
            				});
		}
		

	}
	$scope.logout = function() {
		$rootScope.isAuthenticated = false;
	}

	$scope.hidemakeDeviceOnlinePopup = function() {
		$('#makeDeviceOnlineId').modal('hide');
	}
	$scope.forgotPassword = function() {
		if ($scope.username) {
			$scope.isLoggingError = false;
			window.open(rootConfig.forgotPassword + "user=" + $scope.username,
					'_system');
		} else {
			$scope.loginError = "Please Enter User ID";
			$scope.isLoggingError = true;
		}
	}
	$scope.loginServiceSuccessCallback = function() {
	}
	$scope.loginServiceErrorCallback = function() {

	}
    $scope.login = function(){
       
 			 if(rootConfig.isDeviceMobile){
				$scope.createKeyIfNotExists(function(){
					var filesToBeEncrypted = $scope.getFilesToBeEncrypted();
					window.plugins.LEEncryption.encryptDB(filesToBeEncrypted, function(data){
						console.log("db encrypted");
							$scope.loginAftrFetchKey();
						}, function(){
						console.log("Error while encrypting db");

					});
				});

			}else{
				$scope.loginAftrFetchKey();
			}
    	}

 		$scope.getFromRemote = function(jsonFile, callmode,
            									successCallBack, errorCallback) {
                    var self = this;
                    $
                            .ajax({
                                type : "GET",
                                url : rootConfig.contentAdminDownLoadURL+"/"
                                        + jsonFile,
                                dataType : "text",
                                success : function(jsonObject) {
                                    successCallBack(jsonObject);

                                },
                                async : callmode,
                                error : function(error) {
                                    self
                                            ._prepareErrorCallBack(
                                                    'Error_106',
                                                    'Error while fetching config JSON from remote location . '
                                                            + JSON
                                                                    .stringify(error),
                                                    errorCallback);
                                }
                            });
       };

 			$scope.getFromApplicationPath = function(jsonFile,
        									successCallBack, errorCallback) {
        								var self = this;
        								self._prepareErrorCallBack = function(
        										errorCode, errorMessage) {
        									console.log(errorMessage);
        								}
        								if (rootConfig && rootConfig.isOfflineDesktop) {
        									var fs = require('fs');
        									fs.readFile(jsonFile, 'utf8', function(err,
        											data) {
        										if (err) {
        											self._prepareErrorCallBack(
        													'Error_106',
        													'Error while fetching config JSON from remote location'
        															+ jsonFile,
        													errorCallback);
        										}
        										successCallBack(data);
        									});
        								} else {
        									url:
        											rootConfig.contentAdminDownLoadURL
        													+ jsonFile,
        											$
        													.getJSON(jsonFile)
        													.done(
        															function(
        																	jsonObject,
        																	textStatus) {
        																successCallBack(jsonObject);
        															})
        													.fail(
        															function(jqxhr,
        																	settings,
        																	exception) {
        																self
        																		._prepareErrorCallBack(
        																				'Error_106',
        																				'Error while fetching config JSON from remote location . '
        																						+ JSON
        																								.stringify(error),
        																				errorCallback);
        															});

        								}
        							};

	$scope.onRetrieveAgentProfileSuccess = function(data) {

		

            if (rootConfig.isDeviceMobile && $scope.checkConnection ) {
			dataService.saveAgentProfile(data, function(){$scope.loadLandingPage(data)}, $scope.onRetrieveAgentProfileError);
			}else{
			$scope.loadLandingPage(data)
				
			}
	};
	$scope.loadLandingPage = function(data) {
	var channel = data.AgentDetails.channelId;
		var channelName = rootConfig.themeList["Theme"
				+ channel];
		var themeName = "MainTheme";
		if (channelName != undefined) {
			themeName = channelName.theme;
		}
		UtilityService.initiateThemeChange(themeName);
		showHideLoadingImage(false);
		$scope.onRetrieveAgentProfileDataSucess(data)
	}
	$scope.onRetrieveAgentProfileDataSucess= function(res){
			showHideLoadingImage(false,null,null,"Authenticate");
			appDataShareService.selectedUser.name = res.AgentDetails.agentName;
			IntialLoggedUser = appDataShareService.selectedUser.name;
			var intialLoginDetails = {
				'IntialLoggedUserId' : $scope.username,
				'IntialLoggedUserName' : IntialLoggedUser
			};
			if (localStorage
					.getItem(getUniqueAppNamePattern(commonConfig().PAGE_DETAILS.INITIAL_LOGIN))) {

				var loginDetailsList = $
						.parseJSON(localStorage
								.getItem(getUniqueAppNamePattern(commonConfig().PAGE_DETAILS.INITIAL_LOGIN)));
				loginDetailsList
						.push(intialLoginDetails);
				localStorage
						.setItem(getUniqueAppNamePattern(
								commonConfig().PAGE_DETAILS.INITIAL_LOGIN),
								JSON
										.stringify(loginDetailsList));

			}

			else {

				var loggedInUsersList = [];
				loggedInUsersList
						.push(intialLoginDetails);
				localStorage
						.setItem(getUniqueAppNamePattern(
								commonConfig().PAGE_DETAILS.INITIAL_LOGIN),
								JSON
										.stringify(loggedInUsersList));
			}

			$rootScope.loggedInUser = res.AgentDetails.agentName;

			$scope.userDetails.user.firstName = escape(res.AgentDetails.agentName);
			//$scope.userDetails.user.lastName = escape(res.information.last_name);
			//$scope.userDetails.user.password = Encrypt_text($scope.password);
			//$scope.userDetails.user.displayName = escape(res.information.display_name);
			$scope.userDetails.user.emailId = escape(res.AgentDetails.emailId);
			//$scope.userDetails.user.appRole = escape(res.information.app_role);
			$scope.userDetails.user.memberOf = escape(res.AgentDetails.agentGroup);
			$scope.userDetails.user.agentId = escape(res.AgentDetails.agentCode);
			$scope.userDetails.user.designation = escape(res.AgentDetails.designation);
			appDataShareService.selectedUser.userId = escape(res.AgentDetails.agentCode);


			var agentId = {
					'Id' : $scope.userDetails.user.agentId
				};
			localStorage.setItem(getUniqueAppNamePattern(commonConfig().STORAGE.AGENT_ID),JSON.stringify(agentId));
			$rootScope.IntialloggedInUser = appDataShareService.selectedUser.userId;
			$scope.userDetails.user.lastLoggedDate = new Date();



			if(rootConfig.isDeviceMobile && rootConfig.pushNotificationEnabled){
			// Uncomment to enable push notification
			 DeviceUserID  = $scope.userDetails.user.agentId;
			 RegisterPushNotification(); }


			if (res.AgentDetails.designation ==loginConfig().DESIGNATION.AGT)
				{
				$rootScope.isAGT = true;
				sessionStorage.isAGT = true;
				var agtDetails = {
						'isAGT' : $rootScope.isAGT
					};
				localStorage.setItem(getUniqueAppNamePattern(commonConfig().PAGE_DETAILS.AGENT),JSON.stringify(agtDetails));
				}
			else
				{
				$rootScope.isAGT = false;
				sessionStorage.isAGT = false;
				var agtDetails = {
						'isAGT' : $rootScope.isAGT
					};
				localStorage.setItem(getUniqueAppNamePattern(commonConfig().PAGE_DETAILS.AGENT),JSON.stringify(agtDetails));
				}


			if (res.AgentDetails.designation == loginConfig().DESIGNATION.AA || res.AgentDetails.designation == loginConfig().DESIGNATION.ADM)
				{

					$rootScope.isAA = false;
					sessionStorage.isAA = false;
					var aaDetails = {
							'isAA' : $rootScope.isAA
						};
					localStorage.setItem(getUniqueAppNamePattern(commonConfig().PAGE_DETAILS.AA),JSON.stringify(aaDetails));
				}
			else
				{
					$rootScope.isAA = true;
					sessionStorage.isAA = true;
					var aaDetails = {
							'isAA' : $rootScope.isAA
						};
					localStorage.setItem(getUniqueAppNamePattern(commonConfig().PAGE_DETAILS.AA),JSON.stringify(aaDetails));
				}
					if ( res.AgentDetails.designation == loginConfig().DESIGNATION.PSA || res.AgentDetails.designation == loginConfig().DESIGNATION.SAD || res.AgentDetails.designation == loginConfig().DESIGNATION.AAM || res.AgentDetails.designation ==loginConfig().DESIGNATION.SAP || res.AgentDetails.designation == loginConfig().DESIGNATION.APA || res.AgentDetails.designation == loginConfig().DESIGNATION.ADM)
				{

					$rootScope.isShowADM = true;
					sessionStorage.isShowADM = true;
					var admDetails = {
							'isShowADM' : $rootScope.isShowADM
						};
					localStorage.setItem(getUniqueAppNamePattern(commonConfig().PAGE_DETAILS.ADM),JSON.stringify(admDetails));
				}
			else
				{
					$rootScope.isShowADM = false;
					sessionStorage.isShowADM = false;
					var admDetails = {
							'isShowADM' : $rootScope.isShowADM
						};
					localStorage.setItem(getUniqueAppNamePattern(commonConfig().PAGE_DETAILS.ADM),JSON.stringify(admDetails));
				}


			LoginService
					.saveToken(
							$scope.userDetails.user,
							function(
									res) {

								if ($scope.rememberme == true) {
									//if(rootConfig.isDeviceMobile){
									var loginDetails = {
										'uname' : $scope.username,
										'pwd' : Encrypt_text($scope.password)
									};
									//}else{
									//	var loginDetails = {
									//	'uname' : $scope.username
									//};
									//}

									localStorage
											.setItem(getUniqueAppNamePattern(
													commonConfig().PAGE_DETAILS.LOGIN),
													JSON
															.stringify(loginDetails));
								} else {
									localStorage
											.removeItem(getUniqueAppNamePattern(commonConfig().PAGE_DETAILS.LOGIN));
								}

								$rootScope.isRedirectFromLogin = true;

								if (rootConfig.isDeviceMobile) {
									$rootScope
											.$broadcast(commonConfig().STATUS.IS_DEVICE_ONLINE);
								} else {
									$rootScope.isAuthenticated = true;
									localStorage[getUniqueAppNamePattern(commonConfig().STORAGE.AUTHENTICATED_USER)]="yes";
									//localStorage.userDetails.authenticateduser="yes";
									$rootScope.isRedirectFromLogin = false;
									$location
											.path('/dashboard');
								}
								showHideLoadingImage(false,null,null,"Authenticate");
								$scope.$apply();
							},
							function(
									err) {
								$scope.isLoggingError = true;
								showHideLoadingImage(false,null,null,"Authenticate");
								$rootScope.isAuthenticated = false;
								$scope.loginError = translateMessages($translate,"credentialsValidationErrorMessage");
								$scope
										.$apply();
							});

	}			
		
	$scope.onRetrieveAgentProfileError = function() {
	};
    	
	$scope.createKeyIfNotExists = function(success){
		var options = [];
		var obj = {};
		obj.appName = rootConfig.appName;
		options.push(obj);
		window.plugins.LEEncryption.checkKeyAvailability(options,
			function (data){
				if(data == "key exists"){
					success();
				} else {
					authService.fetchKey({
										username : $scope.username,
										password : $scope.password
									},function(data){

									if(data.StatusData.Status == "SUCCESS"){
									var KeyArray = [];
									var keyObj = {};
									keyObj.key = data.encryptionKey;
									keyObj.appName = rootConfig.appName;
									KeyArray.push(keyObj);

									window.plugins.LEEncryption.insertKey(KeyArray,
										function (data){
											if(data == "key entered successfully"){
											}
											success();
										},  function (data){
											console.log("failure to insert key. " + data);
										}
									);
									}else{
										console.log("failure to fetch key. " + data);

									}

					},
					function(data, status) {
						showHideLoadingImage(false,null,null,"Authenticate");
										$scope.isLoggingError = true;
										$rootScope.isAuthenticated = false;
										$scope.loginError = translateMessages($translate,"networkValidationErrorMessage");
										$scope.$apply();
					});


				}
			},
			function(error) {
				console.log("Failed to check key availability. " + error);
			}
		);
    	}
		
    	$scope.pushEncryptionFilesToArray = function(fileArray, files){
    		for(var i=0 ;i<fileArray.length; i++) {
    			var fileDesc = {};
    			fileDesc.fileName = fileArray[i];
    			files.push(fileDesc);
    		}
    		return files;
    	}

    	$scope.getFilesToBeEncrypted = function() {
    		var filesToBeEncrypted = [];
    		var filesArray = ["eServiceDB.db","code-lookup.db"];
    		filesToBeEncrypted = $scope.pushEncryptionFilesToArray(filesArray,filesToBeEncrypted);
    		//return filesToBeEncrypted;
    		var options = []
            var obj = {}
            obj.appName = rootConfig.appName;
            obj.fileArray = filesToBeEncrypted;
            options.push(obj);
            return options;
    	}

	// Push notification
	var RegisterPushNotification = function() {
		pushArray = [];
        var successHandleriOS = function(res) {
        	 //PushMsgRegisteredID = res;
            registerPushNotificationToServer(res);

		}
		var errorHandleriOS = function (error) {
         //TODO

		}
		 var successHandler = function(res) {
        	 //PushMsgRegisteredID = res;
           // registerPushNotificationToServer(res);

		}
		var errorHandler = function (error) {
         //TODO

		}


		var pushNotification = window.plugins.pushNotification;
        // alert("pushNotification=="+angular.toJson(pushNotification));
		if (/Android/i.test(navigator.userAgent) ) {// && (localStorage[getUniqueAppNamePattern(commonConfig().DEVICE_USER_ID)]==null ||localStorage[getUniqueAppNamePattern(commonConfig().DEVICE_USER_ID)]==undefined )
			pushNotification.register(successHandler,errorHandler, {
                                      "senderID" : "118709788468",//API key  : AIzaSyBi91jSVFr9AbIl1voUGBqRHXTeOb6ktco
                                      "ecb" : "onNotificationGCM"
                                      });

		}else if (/iPhone|iPad|iPod/i.test(navigator.userAgent)) {

			pushNotification.register(successHandleriOS, errorHandleriOS, {
                                      "badge" : "true",
                                      "sound" : "true",
                                      "alert" : "true",
                                      "ecb" : "onNotificationAPN"
                                      });
		}


				var myVar = setInterval(function() {
			myTimer()
		}, 30000);

		function myTimer() {
			/*if (PushMsgRegisteredID == null) {
				if (popupOver) {
					$("#gcm_not_sub")
							.html(
									"Push notification registration was unsuccessful. You will not recieve Push notifications");
					$('#dvShowDecisionBoxGCM').modal('show');
					popupOver = false;
					regTimeOut = false;
				} else {
					regTimeOut = true;
				}
			}
			clearInterval(myVar);*/
			if (popupOver) {

				if (PushMsgRegisteredID == null) {

					$("#gcm_not_sub")
					.html(
							"Push notification registration was unsuccessful. You will not receive Push notifications");
			$('#dvShowDecisionBoxGCM').modal('show');
			popupOver = false;
				}


				clearInterval(myVar);

			}
		}



	}

    if(rootConfig.isDeviceMobile){
        document.addEventListener("deviceready", onDeviceReady, false);
        function onDeviceReady() {
        var deviceId = device.uuid;
        appDataShareService.deviceId = deviceId

        }
        }

}]);


var registerPushNotificationToServer = function(token)
{
	
	var registerRequest = PushNotificationRegisterRequest();
    registerRequest.registerDeviceRequest.DeviceUserID = DeviceUserID;
	registerRequest.registerDeviceRequest.Application_Name = rootConfig.applicationName;
	registerRequest.registerDeviceRequest.Device_ID = token;
    registerRequest.registerDeviceRequest.PushMsgRegisteredID = token;
    registerRequest.registerDeviceRequest.DeviceType = "APNS";
    registerRequest.registerDeviceRequest.MobileAppBundleID = rootConfig.iOSAppBundleIdentifier;
    var transactionObj = {};
    transactionObj.Type = "PushNotification";
    transactionObj.TransactionData = registerRequest;

    var successcallback = function(res){
    	PushMsgRegisteredID=token;
        //localStorage.DeviceUserID = ev.regid;
        //alert("ls :"+localStorage.DeviceUserID);
    }

    var errorcallback = function(error){
    	// $("#gcm_not_sub").html("Push notification registration was unsuccessful. You will not recieve Push notifications");
		// $('#dvShowDecisionBoxGCM').modal('show');
    }

    PushNotificationService.registerdevice(transactionObj,successcallback,errorcallback); //register with the service
}

// Push Notification

var notificationData = [];
var DeviceUserID = null;
var PushMsgRegisteredID = null;
var popupOver = false;

var birthdayPNcount = 0;
var anniversaryPNcount = 0;
var openSerReqcount = 0;
var renewalPNcount = 0;
var upsellPNcount = 0;
var issuancePendingPNcount = 0;
var RRPNcpcount = 0;
var disbursePNcount = 0;
var issuancePNcount = 0;
var surrenderPNcount = 0;
var lapseAlertsPNcount = 0;
var schMtngPNcount = 0;
var leadActnPNcount = 0;
var trainingPNcount = 0;
var futureTrainingPNcount = 0;
var otherCommPNcount = 0;


var onNotificationGCM = function(ev) {
    switch (ev.event) {
        case 'registered':
            if (ev.regid.length > 0) {
                var registerRequest = PushNotificationRegisterRequest();
                registerRequest.registerDeviceRequest.DeviceUserID = DeviceUserID;
				registerRequest.registerDeviceRequest.Application_Name = rootConfig.applicationName;
				registerRequest.registerDeviceRequest.Device_ID = ev.regid;
			    registerRequest.registerDeviceRequest.PushMsgRegisteredID = ev.regid;
			    registerRequest.registerDeviceRequest.DeviceType = "GCM";
			    registerRequest.registerDeviceRequest.MobileAppBundleID = rootConfig.AndroidPackageName;
			    var transactionObj = {};
			    transactionObj.Type = "PushNotification";
			    transactionObj.TransactionData = registerRequest;

                var successcallback = function(res){
                    localStorage[getUniqueAppNamePattern(commonConfig().DEVICE_USER_ID)] = ev.regid;
                    PushMsgRegisteredID=ev.regid;
                }

                var errorcallback = function(error){
                	// $("#gcm_not_sub").html("Push notification registration was unsuccessful. You will not recieve Push notifications");
        			// $('#dvShowDecisionBoxGCM').modal('show');
                }
                PushNotificationService.registerdevice(transactionObj,successcallback,errorcallback); //register with the service

            }

            break;



        case 'error':

            break;

        default:

            break;
    }
}

function onNotificationAPN(event) {

    var scope = angular.element($("#pushMenuId")).scope();
    scope.$apply(function(){
        scope.msg = 'pushMenu';
    });
    if (navigator.network.connection.type == Connection.NONE)
    {
	$('#makeDeviceOnlineId').modal('show');
    }
        if(event.body){

            var pushMessage = JSON.parse(event.body);
            notifierId = pushMessage.AgentID;
	    if (notifierId == DeviceUserID)
	    {
	    	var newNotification = true;
			for(var i=0;i<pushArray.length;i++){
				if(angular.toJson(pushArray[i])==angular.toJson(pushMessage.message))
				newNotification=false;
			}

				if(newNotification){
				pushArray.push(pushMessage.message);
				globalPushReceived = true;
				}

	    }

        }
	scope.$apply();
}

function onNotificationAPN2(event) {

    var scope = angular.element($("#pushMenuId")).scope();
    scope.$apply(function(){
        scope.msg = 'pushMenuId';
    });

    pushArray =[
		{"type":"IssuPndg","prNo":"262296692","nTime":""}];

    /*[
		{"type":"Bdy","plNo":"101010119","nTime":"09-25-2013 23:15:45:455"},
		{"type":"Bdy","plNo":"101010115","nTime":"09-25-2013 23:15:45:455"},
		{"type":"Ansry","plNo":"101010114","nTime":"09-25-2013 23:15:45:455"},
		{"type":"OpnSrRqt","srNo":"1210","nTime":"09-25-2013 23:15:45:455"},
		{"type":"Rnwl","plNo":"1010101119","nTime":"09-25-2013 23:15:45:455"},
		{"type":"Issu","prNo":"1010101189","nTime":"09-25-2013 23:15:45:455"},
		{"type":"Upsell","plNo":"1010101143","nTime":"09-25-2013 23:15:45:455"}
		];*/
	console.log("pushArray= =="+angular.toJson(pushArray));

    var notifierId = "381212";
    globalPushReceived = true;


}

var globalPushReceived = false;
var showAlertClickedFlag = false;
var showActivityFlag = false;
var pushArray = [];
var selectedAgent = "";
var notifierId = "";



