mServiceApp.constant('dashBoardConfig',  function(){return{
	"DASH_BOARD_FILTER" : {
							"EARINGS" : "earnings",
							"ISSUANCE" : "issuance",
							"LOGINS" : "logins",
							"MEETINGS" : "meetings"
	},
	"DASH_BOARD_POLICYRENEWALFILTER" : {
		"SEVENDAYS" : "dueForRenewal7days",
		"THIRTYDAYS" : "dueForRenewal30days",
		"SIXTYDAYS" : "dueForRenewal60days"
}
}});  