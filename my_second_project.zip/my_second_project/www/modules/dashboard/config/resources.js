﻿

resources = {
    "saveTransactionsSuccess": "Proposal saved successfully,your proposal number is:",
    "saveTransactionsSuccessOffline": "Proposal saved successfully",
    "successMessage": "Saved Successfully",
    "saveTransactionsError": "Error occured while saving your proposal.Please try later",
    "onGetListingsError": "Error occured while fetching proposal",
    "shareValidationMessage":"Total share across beneficiaries should be equal to 100.",
    "fundAllocationValidationMessage": "Total fund allocation should be less than or equal to 100.",
    "stpRulePassed":"Thank you for your insurance application, you belong to Non-Medical category and you need not go through any extensive medical test. Please proceed with the Payment Process to buy the policy online",
    "stpRuleFailed":"STP Rule Failed!!",
    "docUploadTransactionsSuccess": "The documents have been successfully uploaded, please proceed to Summary ", //"Successfully uploaded the documents",
    "docUploadTransactionsError": "Document upload  failed",
    "docDeleteSuccess": "Document Deleted",
	"docExtInvalid":"Invalid Document Extension",
	"docSizeExceeded":"Document Size Exceeded 2MB",
	"docDuplicate":"Same Document,Document Type,Document Proof should not be uploaded twice",
	"beneficiarySaveSuccess":"Beneficiary Details saved successfully"
};