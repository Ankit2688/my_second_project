mServiceApp.controller('performanceCtrl',['$rootScope', '$scope',  '$compile', '$route', '$routeParams', '$location', '$translate','dataService','appDataShareService','commonConfig','PersistenceMapping','$filter',function($rootScope, $scope,  $compile, $route, $routeParams, $location, $translate,dataService,appDataShareService,commonConfig,PersistenceMapping,$filter) {
    $scope.paintUISuccess = function (callbackId, data) {
		//showHideLoadingImage(false,"Loading Performance",null,null);
		$scope.isPainted = true;
    };
	$scope.performance = {};
	$scope.isValid = false;
	$scope.majorClassDataActive=false;
	$scope.productTypeDataActive=false;
	$scope.noData = false;
	$scope.dataFound = false;
	$scope.selectedpage = commonConfig().PAGE_NAME.PERFORMANCE;
	$scope.mapScopeToPersistance = function (type) {
		var newDate = new Date();
		PersistenceMapping.clearTransactionKeys();
	    PersistenceMapping.Key2 = $rootScope.username;
		PersistenceMapping.Key5 = "Agent";
	    PersistenceMapping.Type = type;
	    var transactionObj =  PersistenceMapping.mapScopeToPersistence({});
	    return transactionObj;
	};
    $scope.intialLoad=function() {
         //For agent code dropdown values
		   var transactionObj = $scope.mapScopeToPersistance();
		   transactionObj.Type = "AgentCode";
		   dataService.searchTransactions(transactionObj,$scope.getTransactionSuccessAgentCode,$scope.getTransactionError);
			//For branch drop down values
		   var transactionObj = $scope.mapScopeToPersistance();
		   transactionObj.Type = "BranchCode"; dataService.searchTransactions(transactionObj,$scope.getTransactionSuccessBranch,$scope.getTransactionError);
		var curDate = new Date();
		var past7days = new Date(curDate.setDate(curDate.getDate() - rootConfig.defaultDayCount));
		$scope.performance.periodFrom = getFormattedDateFromDate(past7days);
		$scope.performance.periodTo = getFormattedDate();
		$scope.searchPerformance($scope.performance);

    };
    $scope.getTransactionSuccessAgentCode = function(data){
        		$scope.agentCodeDropDownList=[];
        		if(data[0] !== undefined && data[0].TransactionData !== null)
        		 {
        			if (data[0].TransactionData.mappedIds.length !== 0) {
        				$scope.agentCodeDropDownList = data[0].TransactionData.mappedIds;
        				$scope.$apply();
        			}
        		 }
        		else{
        			   $scope.agentCodeDropDownList=[];
        		}
       };
       $scope.getTransactionSuccessBranch = function(data){
        		$scope.branchDropDownList=[];
        		if(data[0] !== undefined && data[0].TransactionData !== null)
        		 {
        			if (data[0].TransactionData.branches.length !== 0) {
        				$scope.branchDropDownList = data[0].TransactionData.branches;
        				$scope.$apply();
        			}
        		 }
        		else{
        			   $scope.branchDropDownList=[];
        		}
        };
	$scope.validateFields = function(performance){
		$scope.performance = performance;
		$scope.noData = false;
		$scope.dataFound = false;
		//Date validation for claim incurred date
		if($scope.performance.periodFrom && $scope.performance.periodTo){
			if(isFutureDate($scope.performance.periodFrom) || isFutureDate($scope.performance.periodTo)){
				$scope.errorMessage = [];
				$scope.isValid = true;
				$scope.futureDateValidationMessage = translateMessages($translate, "claimAlerts.futureDateValidationMessage");
                $scope.errorMessage.push($scope.futureDateValidationMessage);
            }else if(!validateDateRange($scope.performance.periodFrom, 365) || !validateDateRange($scope.performance.periodTo, 365)){
            	$scope.errorMessage = [];
            	$scope.isValid = true;
				$scope.dateRangeSixtyValidationMessage = translateMessages($translate, "performance.dateRangeValidationMessage");
                $scope.errorMessage.push($scope.dateRangeSixtyValidationMessage);
            }else if($scope.performance.periodTo < $scope.performance.periodFrom){
            	$scope.errorMessage = [];
            	$scope.isValid = true;
				$scope.dateRangeSixtyValidationMessage = translateMessages($translate, "claimAlerts.fromGreaterthanToValidationMessage");// have'nt got the error message
                $scope.errorMessage.push($scope.dateRangeSixtyValidationMessage);
            }else{
            	$scope.isValid = false;
            }
		}else{
        	$scope.errorMessage = [];
			$scope.fromTodateValidationErrorMessage = translateMessages($translate, "claimAlerts.fromTodateValidationErrorMessage");
			$scope.errorMessage.push($scope.fromTodateValidationErrorMessage);
			$scope.isValid = true;
		}
	    if($scope.isValid){
			 $scope.majorClassDataActive=false;
			 $scope.productTypeDataActive=false;
			 $scope.majorClassData = [];
			 $scope.productTypeData = [];
		}else{
			$scope.errorMessage = [];
			$scope.searchPerformance($scope.performance);
		}
	};
	$scope.getTransactionSuccess = function(data){
		$scope.majorClassData = [];
		$scope.productTypeData = [];
		$scope.productTypeDataActive=false;
		$scope.majorClassDataActive=false;
		$scope.motorPerformanceNewPremium = 0;
		$scope.nonMotorPerformanceNewPremium = 0;
		$scope.motorPerformanceRenewalPremium = 0;
		$scope.nonMotorPerformanceRenewalPremium = 0;
		$scope.noData = false;
		$scope.dataFound = false;
		 if(data[0] !== undefined)
		 {
			if(data[0].TransactionData !== null) {
				$scope.validSearch = true;
				if (data[0].TransactionData.length !== 0) {
					$scope.majorClassData = data[0].TransactionData.perfomanceByMajorClassList;
					$scope.productTypeData = data[0].TransactionData.perfomanceByProductTypeList;
					$scope.perfomancePiechartList = data[0].TransactionData.perfomancePiechartList;
					$scope.majorClassDataActive=true;
					if($scope.perfomancePiechartList.length === 0){
						$scope.noData = true;
						$scope.dataFound = false;
					}else{
						$scope.noData = false;
						$scope.dataFound = true;
						for(var i=0;i<$scope.perfomancePiechartList.length;i++){
							if($scope.perfomancePiechartList[i].renewalIndicator === "N" && $scope.perfomancePiechartList[i].typeOfBusiness === "M"){
								$scope.motorPerformanceNewPremium = $scope.motorPerformanceNewPremium + Number($scope.perfomancePiechartList[i].totalPremium);
							}else if($scope.perfomancePiechartList[i].renewalIndicator === "N" && $scope.perfomancePiechartList[i].typeOfBusiness === "N"){
								$scope.nonMotorPerformanceNewPremium = $scope.nonMotorPerformanceNewPremium + Number($scope.perfomancePiechartList[i].totalPremium);
							}if($scope.perfomancePiechartList[i].renewalIndicator === "R" && $scope.perfomancePiechartList[i].typeOfBusiness === "M"){
								$scope.motorPerformanceRenewalPremium = $scope.motorPerformanceRenewalPremium + Number($scope.perfomancePiechartList[i].totalPremium);
							}if($scope.perfomancePiechartList[i].renewalIndicator === "R" && $scope.perfomancePiechartList[i].typeOfBusiness === "N"){
								$scope.nonMotorPerformanceRenewalPremium = $scope.nonMotorPerformanceRenewalPremium + Number($scope.perfomancePiechartList[i].totalPremium);
							}
						}
                        $scope.newPerformanceOverviewData=[
                            ['Motor', $scope.motorPerformanceNewPremium], //$scope.motorPerformanceNewPremium
                            ['Non Motor', $scope.nonMotorPerformanceNewPremium] //$scope.nonMotorPerformanceNewPremium
                        ];
                        $scope.renewalPerformanceOverviewData=[
                            ['Motor', $scope.motorPerformanceRenewalPremium ], //$scope.motorPerformanceRenewalPremium
                            ['Non Motor', $scope.nonMotorPerformanceRenewalPremium ]
                        ];
						$scope.majorClassTotalSum = 0;
						$scope.majorClassNewSum = 0;
						$scope.majorClassRenewalSum = 0;
                        $scope.majorClassFooter = [];
						for(var i=0;i<$scope.majorClassData.length;i++){
							$scope.majorClassTotalSum = $scope.majorClassTotalSum + Number($scope.majorClassData[i].totalPrem);
							$scope.majorClassNewSum = $scope.majorClassNewSum + Number($scope.majorClassData[i].totalPremNewIndicator);
							$scope.majorClassRenewalSum = $scope.majorClassRenewalSum + Number($scope.majorClassData[i].totalPremRenewalIndicator);
						}
                        $scope.majorClassFooter=[
                            {
                                key:'Total',
                                value : 'Total'
                            },
                            {
                                 'key' : 'Major Class New Sum',
                                 value : $scope.majorClassNewSum.toFixed(2)
                             },
                             {
                                  'key' : 'Major Class Renewal Sum',
                                  value : $scope.majorClassRenewalSum.toFixed(2)
                              },
                              {
                                   'key' : 'Major Class Total Sum',
                                   value : $scope.majorClassTotalSum.toFixed(2)
                        }]; 
						$scope.productTypeTotalSum = 0;
						$scope.productTypeNewSum = 0;
						$scope.productTypeRenewalSum = 0;
						for(var i=0;i<$scope.productTypeData.length;i++){
							$scope.productTypeTotalSum = $scope.productTypeTotalSum + Number($scope.productTypeData[i].totalPrem);
							$scope.productTypeNewSum = $scope.productTypeNewSum + Number($scope.productTypeData[i].totalPremNewIndicator);
							$scope.productTypeRenewalSum = $scope.productTypeRenewalSum + Number($scope.productTypeData[i].totalPremRenewalIndicator);
						}
                       
                        $scope.productTypeFooter=[
                            {
                                key:'Total',
                                value : 'Total'
                            },
                            {
                                 'key' : 'Major Class New Sum',
                                 value : $scope.productTypeNewSum.toFixed(2)
                             },
                             {
                                  'key' : 'Major Class Renewal Sum',
                                  value : $scope.productTypeRenewalSum.toFixed(2)
                              },
                              {
                                   'key' : 'Major Class Total Sum',
                                   value : $scope.productTypeTotalSum.toFixed(2)
                        }];
					}
				}else{
					$scope.noData = true;
					$scope.dataFound = false;
					$scope.validSearch = false;
					$scope.errorMessage = [];
					$scope.majorClassDataActive=false;
					$scope.productTypeDataActive=false;
					$scope.searchFailedMessage = translateMessages($translate, "claimAlerts.searchFailedMessage");
		            $scope.errorMessage.push($scope.searchFailedMessage);
				}
			}
		 }else{
				$scope.noData = true;
				$scope.dataFound = false;
				$scope.validSearch = false;
				$scope.errorMessage = [];
				$scope.majorClassDataActive=false;
				$scope.productTypeDataActive=false;
				$scope.searchFailedMessage = translateMessages($translate, "claimAlerts.searchFailedMessage");
	            $scope.errorMessage.push($scope.searchFailedMessage);
	     }
         $scope.refresh();
          showHideLoadingImage(false,"Loading Performance",null,null);

	};
	$scope.getTransactionError = function(data){
		$rootScope.serviceFailed=true;
        if (rootConfig.isDeviceMobile && !checkConnection()) {
			$scope.message = translateMessages($translate, "networkValidationErrorMessage");
		}else{
			$scope.message = translateMessages($translate, "validToken");
		}
        $scope.$emit('tokenEvent', { message: $scope.message });
        if (data == "Error in ajax callE"){
            $scope.onServerError=true;
            $scope.serverErrorMessage= translateMessages($translate, "serverErrorMessage");
            showHideLoadingImage(false,"Loading Performance",null,null);
        }else{
            showHideLoadingImage(false,"Loading Performance",null,null);
        }
		$rootScope.$apply();
	};
    $scope.searchPerformance = function(performance){
		showHideLoadingImage(true,"Loading Performance",null,null);
		$scope.performance = performance;
		$scope.errorMessage = [];
		$scope.isSearchInValid = false;
		var transactionObj = $scope.mapScopeToPersistance("Performance");
    	$scope.periodFrom = $filter('date')($scope.performance.periodFrom, "yyyy-MM-dd");
        $scope.periodTo = $filter('date')($scope.performance.periodTo, "yyyy-MM-dd");
        if($scope.performance.branch){
            $scope.branch = $scope.performance.branch.code;
         }
        else{
            $scope.branch = "";
        }
        if($scope.performance.agentCode){
           $scope.agentCode = $scope.performance.agentCode;
         }
         else{
           $scope.agentCode = "";
         }
		var searchObj = {
				"SearchCriteria" : {
					"policyDateFrom" : $scope.periodFrom,
					"policyDateTo" : $scope.periodTo,
					"agentCode": $scope.agentCode,
                    "branchCode" : $scope.branch
				}
		};
		transactionObj.TransactionData = searchObj;
		if((rootConfig.isDeviceMobile && checkConnection()) || !rootConfig.isDeviceMobile){
			dataService.searchTransactions(transactionObj, $scope.getTransactionSuccess, $scope.getTransactionError);
		}else{
			$scope.getTransactionError();
		}
	};
    $scope.switchTab = function(tabName) {
        switch(tabName) {
            case 'majorClassData': $scope.majorClassDataActive=true;
                                   $scope.productTypeDataActive=false;
								   break;
            case 'productTypeData': $scope.majorClassDataActive=false;
									$scope.productTypeDataActive=true;
									break;
			default:break;
        }
    };
    
	$scope.$on("$destroy", function() {
		for (var i = 0; i < plotArrayPie.length; i++)
			plotArrayPie[i].destroy();
		plotArrayPie = [];
	});
	
	
    LEDynamicUI.paintUI(rootConfig.template, "performance-ui-json.json", "majorClass", "#dvMajorClass", true, $scope.paintUISuccess, $scope, $compile);
    LEDynamicUI.paintUI(rootConfig.template, "performance-ui-json.json", "productType", "#dvproductType", true, $scope.paintUISuccess, $scope, $compile);
    LEDynamicUI.paintUI(rootConfig.template, "performance-ui-json.json", "motorPerformanceOverview", "#dvMotorPreformance", true, $scope.paintUISuccess, $scope, $compile);
    LEDynamicUI.paintUI(rootConfig.template, "performance-ui-json.json", "nonMotorPerformanceOverview", "#dvNonMotorPreformance", true, $scope.paintUISuccess, $scope, $compile);
    $scope.intialLoad();
    }
]);