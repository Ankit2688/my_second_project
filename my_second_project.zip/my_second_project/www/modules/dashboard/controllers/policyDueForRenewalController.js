
mServiceApp.controller('policyDueForRenewalController',['$controller','$rootScope', '$scope',  '$compile', '$route', '$routeParams', '$location', '$translate','dataService','UserDetailsService','$window','$interval','$anchorScroll',
'appDataShareService','AutoSync','debounce','$timeout','$filter','mServiceConstants','commonConfig','customerServiceConfig','gli_dataservice','PersistenceMapping',function($controller ,$rootScope, $scope,
$compile, $route, $routeParams, $location, $translate,dataService,UserDetailsService,$window,$interval,$anchorScroll,appDataShareService,AutoSync,debounce,$timeout,$filter,mServiceConstants,commonConfig,customerServiceConfig,gli_dataservice,PersistenceMapping) {
	$scope.authorizationToken = appDataShareService.authorizationToken;
	$rootScope.isLoggedOut = false;
	$scope.expandedAccordionFlag = false;
	$scope.autoUpdate = false;
	$anchorScroll = angular.noop;
	if(!(rootConfig.isDeviceMobile) && !(UserDetailsService.userDetilsModel)){
		var userDetilsModel = JSON.parse(sessionStorage.userDetails);
		var userDetailData = JSON.parse(sessionStorage.loginData);
		$rootScope.username = userDetilsModel.user.userId;
		$rootScope.agentId = userDetilsModel.user.rexitLoginId;
		$rootScope.isAuthenticated = true;
		$rootScope.username = userDetilsModel.user.userId;
		$rootScope.authenticationStatus = "SUCCESS";
		$rootScope.firstTimeLogin = userDetailData.firstTimeLogin;
		$rootScope.isTemporaryPassword = userDetailData.isTemporaryPassword;
		$rootScope.role = userDetailData.roles[0];
		UserDetailsService.setUserDetailsModel(userDetilsModel);
		$rootScope.isInLoginPage = false;
	}
	//$scope.setRedirectionDetails = function()
	//{
		var userDetails={};
		userDetails.currentUrl=$location.path();
		userDetails.userId=appDataShareService.selectedUser.userId;
		userDetails.userName=appDataShareService.selectedUser.name;
		var logedin = [];
		logedin.push(userDetails);
		sessionStorage.setItem('currentUser',JSON.stringify(logedin));
	//}
	
    var _this = this;
    $scope.isValid = false;
    $scope.isSearchInValid = false;
    $scope.policyDueForRenewal = {};
    $scope.selectedpage = commonConfig().PAGE_NAME.POLICY_DUE_FOR_RENEWAL;
    $scope.actionTaken = {};
    $scope.emptyDataforSevenDays = false;
	$scope.isSeven = false;
	$scope.emptyData = false;
    $scope.hideFilter = false;
	angular.extend(this, $controller('BaseCtrl',{$scope:$scope, $rootScope:$rootScope, dataService:dataService, type:'policyDueRenewalSearch', userId:appDataShareService.selectedUser.userId}));
	$scope.setData = function() {	    
		$scope.policyDueForRenewal.majorClass = "";
		$scope.policyDueForRenewal.contractType = "";
		if($routeParams.defaultDays == 'premiumCalendar') {
            $scope.policyDueForRenewal.policyExpiryDateFrom = getFormattedDateFromDate($scope.defaultEndDate);
		}
		else {
		    $scope.policyDueForRenewal.policyExpiryDateFrom = getFormattedDate();
		}
		$scope.policyDueForRenewal.policyExpiryDateTo = getFormattedDateFromDate($scope.defaultEndDate);
		$scope.policyDueForRenewal.policyHolderName = "";
		$scope.policyDueForRenewal.identityNo = "";
		$scope.policyDueForRenewal.mobileNo = "";
		$scope.policyDueForRenewal.vehicleNumber = "";
		$scope.$apply();
	};
	// reset the search form fields
	$scope.reset = function() {
		$scope.policyDueForRenewal.majorClass = "";
		$scope.policyDueForRenewal.contractType = "";
		$scope.policyDueForRenewal.policyExpiryDateFrom = "";
		$scope.policyDueForRenewal.policyExpiryDateTo = "";
        $scope.policyDueForRenewal.policyNumber = "";
		$scope.policyDueForRenewal.policyHolderName = "";
		$scope.policyDueForRenewal.identityNo = "";
		$scope.policyDueForRenewal.mobileNo = "";
		$scope.errorMessage = [];
		$scope.policyRenewalDetails = [];
		$scope.isValid = false;
		$scope.isSearchInValid = false;
		$scope.emptyDataforSevenDays = false;
		$scope.isSeven = false;
		$scope.emptyData = false;
		$scope.getContractTypesByMajorClass();
        $scope.policyDueForRenewal.vehicleNumber = "";
		$scope.$apply();
	};

	$scope.downloadSchedule = function(fileId, fileName) {
        var downloadPdfUrl = rootConfig.serviceBaseUrl + "policyService/download/"+ $rootScope.username +"/RENEWALNOTICEPDF/" + fileId;
        if(rootConfig.isDeviceMobile && navigator.userAgent.includes('Android'))
        {
            downloadPdfFromRemote(downloadPdfUrl, fileName);
        }
        else {
    	    window.open(downloadPdfUrl, '_system');
        }
    };
    
    $scope.rerouteLink = function(){
		if($location.path().indexOf('premiumCalendar') > 0){
            $rootScope.backToPremiumCalendar = true;
			$location.path('/customerService/premiumCalendar');
        }else{
			$location.path('/dashboard');
		}
	}

	$scope.mapScopeToPersistance = function () {
	    var newDate = new Date();
	    PersistenceMapping.clearTransactionKeys();
	    PersistenceMapping.Key2 = $rootScope.username;
	    PersistenceMapping.Key5 = "Agent";
	    PersistenceMapping.Type = _this.Type;
	    var transactionObj =  PersistenceMapping.mapScopeToPersistence({});
	    return transactionObj;
	};
	$scope.paintUISuccess = function (callbackId, data) {
	    if (!showActivityFlag)
	    {
		 //showHideLoadingImage(false);
	    }
	    $scope.isPainted = true;
	};
	/*LEDynamicUI.paintUI(rootConfig.template, "policyrenewal-ui-json.json", "policyRenewal", "#dvPolicyRenewal", true, $scope.paintUISuccess, $scope, $compile);*/
	function getPreCompiledTemplate(callback) {
        if (rootConfig.isPrecomiledTemplate) {
            LEDynamicUI.loadPrecompiledTemplate(function () {
                              // success callback
                               callback();
                            }, function(){
                                console.log('error');
                            });
        }
        else {
            callback();
        }
    }
		getPreCompiledTemplate(function () {
            LEDynamicUI.paintUI(rootConfig.template, "policyrenewal-ui-json.json", "policyRenewal", "#dvPolicyRenewal", true, $scope.paintUISuccess, $scope, $compile);			
        });	
	$scope.initialLoad = function(){
       //For major class dropdown value
       var transactionObj = $scope.mapScopeToPersistance();
	   transactionObj.Type = "majorclass";
        dataService.searchTransactions(transactionObj,$scope.getTransactionSuccessMajorClass,$scope.getTransactionError);
	 //For contract type dropdown value
       var transactionObj = $scope.mapScopeToPersistance();
	   transactionObj.Type = "contracttype";
        $scope.policyDueForRenewal.policyExpiryDateFrom = getFormattedDate();
	    var cur = new Date();
        var defaultDays=$routeParams.defaultDays;
        if(defaultDays=='7days') {
            $scope.defaultEndDate = new Date(cur.setDate(cur.getDate() + 6));
        }
        else if(defaultDays=='30days') {
            $scope.defaultEndDate = new Date(cur.setDate(cur.getDate() + 29));
        }
        else if(defaultDays=='60days') {
            $scope.defaultEndDate = new Date(cur.setDate(cur.getDate() + 59));
        }
        else if(defaultDays=='premiumCalendar') {
            $scope.defaultEndDate = new Date($rootScope.policyRenewalDate);
            $scope.policyDueForRenewal.policyExpiryDateFrom = getFormattedDateFromDate($scope.defaultEndDate);
            $scope.hideFilter = true;
        }
        else {
            $scope.defaultEndDate = new Date(cur.setDate(cur.getDate() + 6));
        }
        dataService.searchTransactions(transactionObj,$scope.getTransactionSuccessContractType,$scope.getTransactionError);
	   //For policy details within 7days       
	   
	   $scope.policyDueForRenewal.policyExpiryDateTo = getFormattedDateFromDate($scope.defaultEndDate);
       showHideLoadingImage(false);
       $scope.searchData = JSON.parse(JSON.stringify($scope.policyDueForRenewal));
//323970
	   if(typeof sessionStorage.renewalFilterSection!="undefined" && !(rootConfig.isDeviceMobile))
	   {
		   var sessionData = $.parseJSON(sessionStorage.getItem('renewalFilterSection'));
		   $scope.policyDueForRenewal = angular.copy(sessionData);
		   sessionStorage.removeItem('renewalFilterSection');
	   }
	   $scope.searchPolicyDueForRenewal($scope.policyDueForRenewal);       
	};
	$scope.getTransactionSuccessMajorClass = function(data){
		$scope.majorClassDropDownList = [];
		if(data[0] !== undefined && data[0].TransactionData !== null)
		 {
			if (data[0].TransactionData.lookUps.length !== 0) {
				$scope.majorClassDropDownList = data[0].TransactionData.lookUps;
				$scope.$apply();
			}
		 }
		else{
			$scope.majorClassDropDownList = [];
		}
	};
	$scope.getTransactionSuccessContractType = function(data){
		$scope.contractTypeDropDownList = [];
		if(data[0] !== undefined && data[0].TransactionData !== null)
		 {
			if (data[0].TransactionData.lookUps.length !== 0) {
				$scope.contractTypeDropDownList = data[0].TransactionData.lookUps;
			}
		 }
		else{
			$scope.contractTypeDropDownList = [];
		}
		$scope.$apply();
	};
	$scope.getContractTypesByMajorClass = function(){
	if($scope.policyDueForRenewal.majorClass){
		var transactionObj = $scope.mapScopeToPersistance();
		transactionObj.Type = "getContractTypesByMajorClass";
		var searchObj = {
			"SearchCriteria" : {
				"majorClass" : $scope.policyDueForRenewal.majorClass.code
			}
		};
		transactionObj.TransactionData = searchObj;
		dataService.searchTransactions(transactionObj,$scope.getTransactionSuccessContractType,$scope.getTransactionError);
	}else{
	    var transactionObj = $scope.mapScopeToPersistance();
		transactionObj.Type = "contracttype";
		dataService.searchTransactions(transactionObj,$scope.getTransactionSuccessContractType,$scope.getTransactionError);	
	}
	};
	$scope.searchPolicyDueForRenewal = function(policyDueForRenewal){
		$scope.policyDueForRenewalSearchData = policyDueForRenewal;
		$scope.errorMessage = [];
		$scope.isSearchInValid = false;
		var transactionObj = $scope.mapScopeToPersistance();
		if(isDateWithinSeven($scope.policyDueForRenewalSearchData.policyExpiryDateTo)){
			$scope.isSeven = true;
		}
		else{
			$scope.isSeven = false;
		}
    	$scope.policyExpiryDateFrom = $filter('date')($scope.policyDueForRenewalSearchData.policyExpiryDateFrom, "yyyy-MM-dd");
        $scope.policyExpiryDateTo = $filter('date')($scope.policyDueForRenewalSearchData.policyExpiryDateTo, "yyyy-MM-dd");
		if($scope.policyDueForRenewalSearchData.majorClass){
        	$scope.majorClass = $scope.policyDueForRenewal.majorClass.code;
        }
        else{
        	$scope.majorClass = "";
        }
        if($scope.policyDueForRenewalSearchData.contractType){
        	$scope.contractType = $scope.policyDueForRenewalSearchData.contractType.code;
        }
        else{
        	$scope.contractType = "";
        }
        var searchFieldCount = 0, searchFieldEmptyCount = 0;
		var searchObj = {
				"SearchCriteria" : {
					"majorClass" : $scope.majorClass,
					"contractType": $scope.contractType,
					"policyHolderName" : $scope.policyDueForRenewalSearchData.policyHolderName,
					"policyHolderMobileNo" : $scope.policyDueForRenewalSearchData.mobileNo,
					"identityNumber" : $scope.policyDueForRenewalSearchData.identityNo,
					"policyDateFrom" : $scope.policyExpiryDateFrom,
					"policyDateTo" : $scope.policyExpiryDateTo,
					"policyNumber" : $scope.policyDueForRenewalSearchData.policyNumber,
					"vehicleNumber" : $scope.policyDueForRenewalSearchData.vehicleNumber
				}
		    };
		Object.keys(searchObj.SearchCriteria).forEach(function(key) {
			  if (searchObj.SearchCriteria[key] == undefined) {
				  searchObj.SearchCriteria[key] = "";
			  }
		});
		Object.keys(searchObj.SearchCriteria).forEach(function(key) {
			  if (searchObj.SearchCriteria[key] == "") {
				  searchFieldEmptyCount++;
			  }
		});
		//To get count of searchObj
		Object.keys(searchObj.SearchCriteria).forEach(function(key) {
			  if (searchObj.SearchCriteria) {
				  searchFieldCount++;
			  }
		});
		if(searchFieldEmptyCount == searchFieldCount){
			$scope.isSearchInValid = true;
            $scope.isValid = true;
			$scope.validSearch = false;
			$scope.errorMessage = [];
			$scope.policyRenewalDetails = [];
			$scope.minOneSearchFieldValidationMessage = translateMessages($translate, "claimLogged.minOneSearchFieldValidationMessage");
            $scope.errorMessage.push($scope.minOneSearchFieldValidationMessage);
		}
		else{
			if(!$scope.autoUpdate)
			{	
            transactionObj.TransactionData = searchObj;
            showHideLoadingImage(true,"Loading Policy Due For Renewal",null,null);
            if((rootConfig.isDeviceMobile && checkConnection()) || !rootConfig.isDeviceMobile){
                dataService.searchTransactions(transactionObj, $scope.getTransactionSuccess, $scope.getTransactionError);
            }else{
                $scope.getTransactionError();
            }
        }
			else
			{
				transactionObj.TransactionData = searchObj;
				//showHideLoadingImage(true,"Loading Policy Due For Renewal",null,null);
				if((rootConfig.isDeviceMobile && checkConnection()) || !rootConfig.isDeviceMobile){
					dataService.searchTransactions(transactionObj, $scope.getTransactionAutoUpdateSuccess, $scope.getTransactionError);
				}else{
					$scope.getTransactionError();
				}
			}
        }
	};
			$scope.getTransactionAutoUpdateSuccess = function(data){
							//$scope.prevPolicyRenewalDetails = angular.copy($scope.policyRenewalDetails);
						//	$scope.policyRenewalDetails = [];
							//var formattedDate1="";
							//var formattedDate="";
							var currentDate = (new Date().toJSON().slice(0,10).replace(/-/g,'-')).toString();
							 if(data[0] !== undefined && data[0].TransactionData !== null)
							 {
									$scope.validSearch = true;
									if (data[0].TransactionData.policyDueRenewalSearchResult.length !== 0) {
										$scope.newPolicyRenewalDetails =[];
										$scope.newPolicyRenewalDetails = angular.copy(data[0].TransactionData.policyDueRenewalSearchResult);
										for(var j=0; j < $scope.newPolicyRenewalDetails.length; j++){
											for(var i=0; i < $scope.policyRenewalDetails.length; i++){	
												  /*if($scope.expandedAccordionFlag==true && $scope.expandedAccordionId==$scope.policyRenewalDetails[i].policyNumber)
												  {
														$scope.policyRenewalDetails[i].isActive = true;
														$scope.expandedAccordionFlag=false;
												  }*/
	//for renewal/new business button											
												/*$scope.policyRenewalDetails[i].agentCode = $scope.policyRenewalDetails[i].branchCode+' '+$scope.policyRenewalDetails[i].agentCode;
												if(i%2==0)
												{
													  $scope.policyRenewalDetails[i].renewalStatus = "Y";
												}
												if(currentDate > $scope.policyRenewalDetails[i].expiryDate)
												{
													  $scope.policyRenewalDetails[i].isNewBusiness = true;
												}*/
													if($scope.newPolicyRenewalDetails[j].policyNumber == $scope.policyRenewalDetails[i].policyNumber && $scope.newPolicyRenewalDetails[j].inceptionDate == $scope.policyRenewalDetails[i].inceptionDate)
												{
													$scope.policyRenewalDetails[i].renewalStatus = angular.copy($scope.newPolicyRenewalDetails[j].renewalStatus);													
													$scope.policyRenewalDetails[i].rexitrenewalStatus = angular.copy($scope.newPolicyRenewalDetails[j].rexitrenewalStatus);
													$scope.policyRenewalDetails[i].NewpolicyNumber = angular.copy($scope.newPolicyRenewalDetails[j].NewpolicyNumber);													
												}
												if(currentDate > $scope.policyRenewalDetails[i].expiryDate || $scope.policyRenewalDetails[i].renewalStatus == 'C')
												{
												  $scope.policyRenewalDetails[i].isNewBusiness = true;
												}												
												
											}
										}
										
										
														 
										$scope.$apply();
									}
									else {
										$scope.noOfPolicies = 0;
										$scope.validSearch = false;
										$scope.errorMessage = [];
										if($scope.isSeven){
											$scope.emptyDataforSevenDays = true;
											$scope.emptyData = false;
										}
										else{
											$scope.emptyDataforSevenDays = false;
											$scope.emptyData = true;
										}
										$scope.searchFailedMessage = translateMessages($translate, "policySearch.searchFailedMessage");
										$scope.errorMessage.push($scope.searchFailedMessage);
										$scope.$apply();
									}
							 }
							 else {
									$scope.noOfPolicies = 0;
									$scope.validSearch = false;
									$scope.errorMessage = [];
									if($scope.isSeven){
										$scope.emptyDataforSevenDays = true;
									}
									else{
										$scope.emptyData = true;
									}
									$scope.searchFailedMessage = translateMessages($translate, "policySearch.searchFailedMessage");
									$scope.errorMessage.push($scope.searchFailedMessage);
									$scope.$apply();
							 }							
							/* showHideLoadingImage(false,"Loading Policy Due For Renewal",null,null);
							 $interval(function()
							 {
								$scope.autoUpdate = true;
							 },5000)*/
	};
	
								$scope.getTransactionSuccess = function(data){
							$scope.policyRenewalDetails = [];
							var formattedDate1="";
							var formattedDate="";
							var currentDate = (new Date().toJSON().slice(0,10).replace(/-/g,'-')).toString();
							 if(data[0] !== undefined && data[0].TransactionData !== null)
							 {
									$scope.validSearch = true;
									if (data[0].TransactionData.policyDueRenewalSearchResult.length !== 0) {
										$scope.policyRenewalDetails = data[0].TransactionData.policyDueRenewalSearchResult;
										
										for(var i=0; i < $scope.policyRenewalDetails.length; i++){	
											  if($scope.expandedAccordionFlag==true && $scope.expandedAccordionId==$scope.policyRenewalDetails[i].policyNumber)
											  {
													$scope.policyRenewalDetails[i].isActive = true;
													$scope.expandedAccordionFlag=false;
											  }
//for renewal/new business button											
											$scope.policyRenewalDetails[i].agentCode = $scope.policyRenewalDetails[i].branchCode+' '+$scope.policyRenewalDetails[i].agentCode;
											/*if($scope.policyRenewalDetails[i].rexitrenewalStatus=='JPJ APPROVED' || $scope.policyRenewalDetails[i].rexitrenewalStatus == 'RENEWED')
												{
												  $scope.policyRenewalDetails[i].renewalStatus = "Y";
												} */
											if(currentDate > $scope.policyRenewalDetails[i].expiryDate || $scope.policyRenewalDetails[i].renewalStatus == 'C')
												{
												  $scope.policyRenewalDetails[i].isNewBusiness = true;
												}
											   
										}
										
								
														 
										$scope.$apply();
									}
									else {
										$scope.noOfPolicies = 0;
										$scope.validSearch = false;
										$scope.errorMessage = [];
										if($scope.isSeven){
											$scope.emptyDataforSevenDays = true;
											$scope.emptyData = false;
										}
										else{
											$scope.emptyDataforSevenDays = false;
											$scope.emptyData = true;
										}
										$scope.searchFailedMessage = translateMessages($translate, "policySearch.searchFailedMessage");
										$scope.errorMessage.push($scope.searchFailedMessage);
										$scope.$apply();
									}
							 }
							 else {
									$scope.noOfPolicies = 0;
									$scope.validSearch = false;
									$scope.errorMessage = [];
									if($scope.isSeven){
										$scope.emptyDataforSevenDays = true;
									}
									else{
										$scope.emptyData = true;
									}
									$scope.searchFailedMessage = translateMessages($translate, "policySearch.searchFailedMessage");
									$scope.errorMessage.push($scope.searchFailedMessage);
									$scope.$apply();
							 }							
							 showHideLoadingImage(false,"Loading Policy Due For Renewal",null,null);
							  var promise =$interval(function(event)
							 {
								$scope.autoUpdate = true;
								$scope.searchPolicyDueForRenewal($scope.searchData);
								//event.preventDefault();
							 },5000);
							 //logic added to prevent the refresh from happening in other pages
							  $scope.$on('$destroy',function(){
							if(promise)
								$interval.cancel(promise);   
						});
						};
						
	$scope.getTransactionError = function(data) {
		$rootScope.serviceFailed=true;
        if (rootConfig.isDeviceMobile && !checkConnection()) {
			$scope.message = translateMessages($translate, "networkValidationErrorMessage");
		}else{
			$scope.message = translateMessages($translate, "validToken");
		}
        $scope.$emit('tokenEvent', { message: $scope.message });
        if (data == "Error in ajax callE"){
            $scope.onServerError=true;
            $scope.serverErrorMessage= translateMessages($translate, "serverErrorMessage");
            showHideLoadingImage(false,"Loading Policy Due For Renewal",null,null);
		}else{
            showHideLoadingImage(false,"Loading Policy Due For Renewal",null,null);
        }
		showHideLoadingImage(false);
        $rootScope.$apply();
	};
   $scope.validateFields = function(policyDueForRenewal){
	   $scope.autoUpdate=false;
		$scope.policyDueForRenewal = policyDueForRenewal;
//323970
		//sessionStorage.setItem('renewalFilterSection',JSON.stringify(policyDueForRenewal));
		$scope.emptyDataforSevenDays = false;
		$scope.emptyData = false;
		//Date validation for claim incurred date
       if($scope.policyDueForRenewal.policyExpiryDateFrom && $scope.policyDueForRenewal.policyExpiryDateTo){
			if($scope.policyDueForRenewal.policyExpiryDateTo < $scope.policyDueForRenewal.policyExpiryDateFrom){
            	$scope.errorMessage = [];
            	$scope.isValid = true;
				$scope.dateRangeSixtyValidationMessage = translateMessages($translate, "policySearch.fromGreaterthanToValidationMessage");// have'nt got the error message
                $scope.errorMessage.push($scope.dateRangeSixtyValidationMessage);
            }
            else{
            	$scope.isValid = false;
            }
		}
		else if(($scope.policyDueForRenewal.policyExpiryDateFrom && !$scope.policyDueForRenewal.policyExpiryDateTo) || (!$scope.policyDueForRenewal.policyExpiryDateFrom && $scope.policyDueForRenewal.policyExpiryDateTo)){
				$scope.errorMessage = [];
				$scope.fromTodateValidationErrorMessage = translateMessages($translate, "policySearch.fromTodateValidationErrorMessage");
				$scope.errorMessage.push($scope.fromTodateValidationErrorMessage);
				$scope.isValid = true;
		}       
		else{
        	$scope.isValid = false;
		}
		 
	    if($scope.isValid){
		  //errror message
		     $scope.isSearchInValid = true;
		     $scope.policyRenewalDetails = [];
		}
		else{
		     $scope.isSearchInValid = false;
			 $scope.errorMessage = [];
             $scope.searchData = JSON.parse(JSON.stringify($scope.policyDueForRenewal));
			 $scope.searchPolicyDueForRenewal($scope.policyDueForRenewal);
		}
	 };
	$scope.saveActionTaken = function(actionTaken){
		            showHideLoadingImage(true,"Loading Policy Due For Renewal",null,null);
	     $scope.saveAction = actionTaken;
	     var transactionObj = $scope.mapScopeToPersistance();
		 transactionObj.Type = "actionTaken";
		 var searchObj = {				
							"remarksId":$scope.actionTaken.remarkId,
							"remarksidentifier":$scope.actionTaken.remarkId,
							"remarkStatus":"",
							"savedid":"",
							"remarkUpdatedDate": PersistenceMapping.getFormattedDate(),
							"policyNumber" : $scope.saveAction.policyNumber,
							"inceptionDate": $scope.saveAction.inceptionDate,
							"actionTaken" : $scope.saveAction.actionTaken,
							"comments" : $scope.saveAction.comments
		 };
		 transactionObj.TransactionData = searchObj;
		if((rootConfig.isDeviceMobile && checkConnection()) || !rootConfig.isDeviceMobile){
			 dataService.searchTransactions(transactionObj,  $scope.getTransactionSaveSuccess, $scope.getTransactionError);
		}else{
			$scope.getTransactionError();
		}
   };
   $scope.getTransactionSaveSuccess = function(data){
	   if(data[0] !== undefined && data[0].TransactionData !== null)
		 {
			if (data[0].TransactionData.length !== 0) {
				$scope.saveStatus = data[0].TransactionData.UpdateRenewalinformation[0].Status;
				$scope.searchPolicyDueForRenewal($scope.searchData);
			}
		 }
	   else{
		   showHideLoadingImage(false);
	   }
   };
	
	$scope.saveRemark = function(remarkValue,policyNumber,checkedValue,inceptionDate,policyInfo){
					$scope.actionTaken.comments = remarkValue;
					$scope.actionTaken.policyNumber = policyNumber;
					$scope.actionTaken.inceptionDate = inceptionDate;
					//var checked = checkedValue;
					$scope.actionTaken.actionTaken = true;
					$scope.actionTaken.remarkId=angular.copy($scope.getRemarkId(policyInfo).toString());
					$scope.expandedAccordionFlag = true
					$scope.expandedAccordionId = angular.copy(policyNumber);
					$scope.saveActionTaken($scope.actionTaken);
					$scope.autoUpdate=false;

				};
	
    $scope.checkRemarks = function(event,remarksLength){
    	if(remarksLength > 0){
    		event.preventDefault();
    	}
    	$scope.actionTaken.actionTaken = checkedValue;
    	$scope.saveActionTaken($scope.actionTaken);
    };
	$scope.openRexit = function(policyRenewal)
	{
		var pass = "RENEWOMNIREXIT";
		var userID= UserDetailsService.userDetilsModel.user.userId;
		var timeStamp = PersistenceMapping.getFormattedDate();
		var accode=$rootScope.agentId;
		var password=UserDetailsService.userDetilsModel.user.shaPassword;
		var checkSum = CryptoJS.SHA512($rootScope.username+UserDetailsService.userDetilsModel.user.shaPassword+$rootScope.agentId+timeStamp).toString(CryptoJS.enc.Hex);
		/*if((policyRenewal.businessNo!="" || typeof(policyRenewal.businessNo)!='undefined') && (policyRenewal.newICNO==''|| typeof(policyRenewal.newICNO)=='undefined')&& (policyRenewal.others==''|| typeof(policyRenewal.others)=='undefined'))
		{
		var conType = "B";
		}
		else if((policyRenewal.newICNO!="" || typeof(policyRenewal.newICNO)!='undefined') && (policyRenewal.businessNo==''|| typeof(policyRenewal.businessNo)=='undefined')&& (policyRenewal.others==''|| typeof(policyRenewal.others)=='undefined'))
		{
		var conType = "I";
		}
		else if((policyRenewal.others!="" || typeof(policyRenewal.others)!='undefined') && (policyRenewal.businessNo==''|| typeof(policyRenewal.businessNo)=='undefined')&& (policyRenewal.newICNO==''|| typeof(policyRenewal.newICNO)=='undefined'))
		{
		var conType = "O";
		}*/
		var conType =policyRenewal.CONTYPE;
		//var newICNO =UserDetailsService.userDetilsModel.NEWICNO;
		var newICNO =policyRenewal.NEWICNO;
		newICNO = newICNO.replace(/-/g,'');
		//var businessNo=UserDetailsService.userDetilsModel.BUSINESSNO;
		//var others =UserDetailsService.userDetilsModel.OTHERS;
		var businessNo=policyRenewal.BUSINESSNO;
		var others =policyRenewal.OTHERS;
		var PMF = "";
		var policyNumber = policyRenewal.policyNumber;
		var policyExpiryDate = policyRenewal.expiryDate;
		var policyInceptionDate = policyRenewal.inceptionDate;
		var vehicleNumber = policyRenewal.vehicleNumber;
		var lob=rootConfig.LOBs;
		var cls =policyRenewal.contractType;
		for(var i in rootConfig.LOBs)
		{
			if(policyRenewal.contractType == lob[i].Omni)
			{
				var cls = lob[i].Rexit;
			}
		}
		policyExpiryDate = policyExpiryDate.replace(/-/g,'');
		policyInceptionDate = policyInceptionDate.replace(/-/g,'');
		if(typeof(policyRenewal.NAME)=='undefined' || policyRenewal.NAME == "null")
		{
			var name = "";
		}
		else
		{
			var name = policyRenewal.NAME;
		}
		if(typeof(policyRenewal.SALUTATION)=='undefined' || policyRenewal.SALUTATION == "null")
		{
			var salutation = "";
		}
		else
		{
			var salutation = policyRenewal.SALUTATION;
		}
		if(typeof(policyRenewal.NATIONALITY)=='undefined' || policyRenewal.NATIONALITY == "null")
		{
			var nationality = "";
		}
		else
		{
			var nationality = policyRenewal.NATIONALITY;
		}
		if(typeof(policyRenewal.RACE)=='undefined' || policyRenewal.RACE == "null")
		{
			var race = "";
		}
		else
		{
			var race = policyRenewal.RACE;
		}
		if(typeof(policyRenewal.DOB)=='undefined' || policyRenewal.DOB == "null")
		{
			var dob = "";
		}
		else
		{
			var dob = policyRenewal.DOB;
		}
		if(typeof(policyRenewal.MARITAL_STATUS)=='undefined' || policyRenewal.MARITAL_STATUS == "null")
		{
			var marital_status = "";
		}
		else
		{
			var marital_status = policyRenewal.MARITAL_STATUS;
		}
		if(typeof(policyRenewal.GENDER)=='undefined' || policyRenewal.GENDER == "null")
		{
			var gender = "";
		}
		else
		{
			var gender = policyRenewal.GENDER;
		}
		if(typeof(policyRenewal.ADDRESS1)=='undefined' || policyRenewal.ADDRESS1 == "null")
		{
			var address1 = "";
		}
		else
		{
			var address1 = policyRenewal.ADDRESS1;
		}
		if(typeof(policyRenewal.ADDRESS2)=='undefined' || policyRenewal.ADDRESS2 == "null")
		{
			var address2 = "";
		}
		else
		{
			var address2 = policyRenewal.ADDRESS2;
		}
		if(typeof(policyRenewal.ADDRESS3)=='undefined' || policyRenewal.ADDRESS3 == "null")
		{
			var address3 = "";
		}
		else
		{
			var address3 = policyRenewal.ADDRESS3;
		}
		if(typeof(policyRenewal.ADDRESS4)=='undefined' || policyRenewal.ADDRESS4 == "null")
		{
			var address4 = "";
		}
		else
		{
			var address4 = policyRenewal.ADDRESS4;
		}
		if(typeof(policyRenewal.POSTCODE)=='undefined' || policyRenewal.POSTCODE == "null")
		{
			var postcode = "";
		}
		else
		{
			var postcode = policyRenewal.POSTCODE;
		}
		if(typeof(policyRenewal.STATE)=='undefined' || policyRenewal.STATE == "null")
		{
			var state = "";
		}
		else
		{
			var state = policyRenewal.STATE;
		}
		if(typeof(policyRenewal.OCCUPATION)=='undefined' || policyRenewal.OCCUPATION == "null")
		{
			var occupation = "";
		}
		else
		{
			var occupation = policyRenewal.OCCUPATION;
		}
		if(typeof(policyRenewal.TELNO_H)=='undefined' || policyRenewal.TELNO_H == "null")
		{
			var telno_H = "";
		}
		else
		{
			var telno_H = policyRenewal.TELNO_H;
		}
		if(typeof(policyRenewal.TELNO_O)=='undefined' || policyRenewal.TELNO_O == "null")
		{
			var telno_O = "";
		}
		else
		{
			var telno_O = policyRenewal.TELNO_O;
		}
		if(typeof(policyRenewal.FAXNO_H)=='undefined' || policyRenewal.FAXNO_H == "null")
		{
			var faxno_H = "";
		}
		else
		{
			var faxno_H = policyRenewal.FAXNO_H;
		}
		if(typeof(policyRenewal.FAXNO_O)=='undefined' || policyRenewal.FAXNO_O == "null")
		{
			var faxno_O = "";
		}
		else
		{
			var faxno_O = policyRenewal.FAXNO_O;
		}
		if(typeof(policyRenewal.MOBILENO)=='undefined' || policyRenewal.MOBILENO == "null")
		{
			var mobileno = "";
		}
		else
		{
			var mobileno = policyRenewal.MOBILENO;
		}
		if(typeof(policyRenewal.EMAIL)=='undefined' || policyRenewal.EMAIL == "null")
		{
			var email = "";
		}
		else
		{
			var email = policyRenewal.EMAIL;
		}
		if(typeof(policyRenewal.TRADE)=='undefined' || policyRenewal.TRADE == "null")
		{
			var trade = "";
		}
		else
		{
			var trade = policyRenewal.TRADE;
		}
		if(rootConfig.isDeviceMobile)
		{
			PMF = "M";
		}
		else{
			PMF = "P";
		}
		if(policyRenewal.originoflob == 'R')
		{
		var params="PASS="+pass+"&PMF="+PMF+"&USERID="+userID+"&POLNO="+policyNumber+"&POLEXPDATE="+policyExpiryDate+"&POLEFFDATE="+policyInceptionDate+"&VEHNO="+vehicleNumber+"&CLS="+cls+"&CONTYPE="+conType+"&BUSINESSNO="+businessNo+"&NEWICNO="+newICNO+"&OTHERS="+others+"&ACCODE="+accode+"&Password="+password+"&DateTimeStamp="+timeStamp+"&Checksum="+checkSum+"&RETURNURL="+rootConfig.omniReturnURL;
		var url=rootConfig.renewButtonBaseURL+'?'+params;
		if(rootConfig.isDeviceMobile)
		{
			$scope.expandedAccordionFlag = true
			$scope.expandedAccordionId = angular.copy(policyNumber);
			var ref=window.open(url, '_blank','location=yes', 'toolbar=yes');
			ref.addEventListener('exit', 
							function(event) 
							{
								$scope.searchPolicyDueForRenewal($scope.searchData);
							}
			); 
		}	
		else
		{
			sessionStorage.setItem('renewalFilterSection',JSON.stringify($scope.policyDueForRenewal));
			sessionStorage.setItem('reAuthentication',"enabled");
			var form = document.createElement('form');
            form.method = 'post';
            form.action = url;
            document.body.appendChild(form);
            form.submit();
		}
	}
	else if(policyRenewal.originoflob == 'O')
	{
	var params="PASS="+pass+"&PMF="+PMF+"&USERID="+userID+"&POLNO="+policyNumber+"&POLEXPDATE="+policyExpiryDate+"&POLEFFDATE="+policyInceptionDate+"&VEHNO="+vehicleNumber+"&CLS="+cls+"&CONTYPE="+conType+"&BUSINESSNO="+businessNo+"&NEWICNO="+newICNO+"&OTHERS="+others+"&NAME="+name+"&SALUTATION="+salutation+"&NATIONALITY="+nationality+"&RACE="+race+"&DOB="+dob+"&MARITAL_STATUS="+marital_status+"&GENDER="+gender+"&ADDRESS1="+address1+"&ADDRESS2="+address2+"&ADDRESS3="+address3+"&ADDRESS4="+address4+"&POSTCODE="+postcode+"&STATE="+state+"&OCCUPATION="+occupation+"&TELNO_H="+telno_H+"&FAXNO_H="+faxno_H+"&TELNO_O="+telno_O+"&FAXNO_O="+faxno_O+"&MOBILENO="+mobileno+"&EMAIL="+email+"&TRADE="+trade+"&ACCODE="+accode+"&Password="+password+"&DateTimeStamp="+timeStamp+"&Checksum="+checkSum+"&RETURNURL="+rootConfig.omniReturnURL;
	var url=rootConfig.renewButtonBaseURL+'?'+params;
	if(rootConfig.isDeviceMobile)
		{
			$scope.expandedAccordionFlag = true
			$scope.expandedAccordionId = angular.copy(policyNumber);
			var ref=window.open(url, '_blank','location=yes', 'toolbar=yes');
			ref.addEventListener('exit', 
							function(event) 
							{
								$scope.searchPolicyDueForRenewal($scope.searchData);
							}
			); 
		}	
		else
		{
			sessionStorage.setItem('renewalFilterSection',JSON.stringify($scope.policyDueForRenewal));
			sessionStorage.setItem('reAuthentication',"enabled");
			var form = document.createElement('form');
            form.method = 'post';
            form.action = url;
            document.body.appendChild(form);
            form.submit();
		}
	}
	};
	$scope.openRexitNew = function(policyRenewal)
	{
		var pass = "RENEWOMNIREXIT";
		var userID= UserDetailsService.userDetilsModel.user.userId;
		var timeStamp = PersistenceMapping.getFormattedDate();
		var accode=$rootScope.agentId;
		var password=UserDetailsService.userDetilsModel.user.shaPassword;
		var PMF="";
		var policyNumber = policyRenewal.policyNumber;
		var lob=rootConfig.LOBs;
		//var conType =UserDetailsService.userDetilsModel.CONTYPE;
		var conType =policyRenewal.CONTYPE;
		var checkSum = CryptoJS.SHA512($rootScope.username+UserDetailsService.userDetilsModel.user.shaPassword+$rootScope.agentId+timeStamp).toString(CryptoJS.enc.Hex);
		if(rootConfig.isDeviceMobile)
		{
			PMF = "M";
		}
		else{
			PMF = "P";
		}
		var cls =policyRenewal.contractType;
		for(var i in rootConfig.LOBs)
		{
			if(policyRenewal.contractType == lob[i].Omni)
			{
				var cls = lob[i].Rexit;
			}
		}
		/*var params="ACCODE="+accode+"&USERID="+userID+"&PASSWORD="+password+"&CLS="+cls+"&PMF="+PMF+"&POLNO="+policyNumber+"&CONTYPE="+conType+"&DateTimeStamp="+timeStamp+"&Checksum="+checkSum+"&RETURNURL="+rootConfig.omniReturnURL;
		var url=rootConfig.newCoverNoteRexitURL+'?'+params;*/
		var policyInceptionDate = policyRenewal.inceptionDate;
		var policyExpiryDate = policyRenewal.expiryDate;
		var vehicleNumber = policyRenewal.vehicleNumber;
		//var cls =policyRenewal.contractType;
		
		policyExpiryDate = policyExpiryDate.replace(/-/g,'');
		policyInceptionDate = policyInceptionDate.replace(/-/g,'');
		
		/*
		var newICNO =UserDetailsService.userDetilsModel.NEWICNO;
		newICNO = newICNO.replace(/-/g,'');
		var businessNo=UserDetailsService.userDetilsModel.BUSINESSNO;
		var others =UserDetailsService.userDetilsModel.OTHERS;
		*/
		
		var newICNO =policyRenewal.NEWICNO;
		newICNO = newICNO.replace(/-/g,'');
		var businessNo=policyRenewal.BUSINESSNO;
		var others =policyRenewal.OTHERS;
		var params="PASS="+pass+"&PMF="+PMF+"&USERID="+userID+"&POLNO="+policyNumber+"&POLEXPDATE="+policyExpiryDate+"&POLEFFDATE="+policyInceptionDate+"&VEHNO="+vehicleNumber+"&CLS="+cls+"&CONTYPE="+conType+"&BUSINESSNO="+businessNo+"&NEWICNO="+newICNO+"&OTHERS="+others+"&ACCODE="+accode+"&Password="+password+"&DateTimeStamp="+timeStamp+"&Checksum="+checkSum+"&RETURNURL="+rootConfig.omniReturnURL;
		var url=rootConfig.newCoverNoteRexitURL+'?'+params;
		if(rootConfig.isDeviceMobile)
		{
			$scope.expandedAccordionFlag = true
			$scope.expandedAccordionId = angular.copy(policyNumber);
			var ref=window.open(url, '_blank','location=yes', 'toolbar=yes');
			ref.addEventListener('exit', 
							function(event) 
							{
								$scope.searchPolicyDueForRenewal($scope.searchData);
							}
			); 
		}	
		else
		{
			sessionStorage.setItem('renewalFilterSection',JSON.stringify($scope.policyDueForRenewal));
			sessionStorage.setItem('reAuthentication',"enabled");
			var form = document.createElement('form');
            form.method = 'post';
            form.action = url;
            document.body.appendChild(form);
            form.submit();
		}
	};
	$scope.getRemarkId = function(policyArray)
	{										
		if(typeof(policyArray.PolicyRemarksHistory)!='undefined' && policyArray.PolicyRemarksHistory.length>0)
		{
			var max = angular.copy(parseInt(policyArray.PolicyRemarksHistory[0].remarksId));
			for(var i=0;i<policyArray.PolicyRemarksHistory.length;i++)
			{
				if(parseInt(policyArray.PolicyRemarksHistory[i].remarksId)>max)
				{
					max = angular.copy(policyArray.PolicyRemarksHistory[i].remarksId);
				}												
			}
			var id = parseInt(max)+1;
		}
		else if(typeof(policyArray.PolicyRemarksHistory)!='undefined'&& policyArray.PolicyRemarksHistory.length == 0)
		{
			var id = "1";
		}
		else
		{
			var id = "";
		}
		return id;
	}
	
	$scope.eCoverNoteRexitNavigation = function(newPolicyNumber,policyNumber,contractType,status)
	{
	if(status!='')
		{
			var timeStamp = PersistenceMapping.getFormattedDate();
			var accode=$rootScope.agentId;
			var password=UserDetailsService.userDetilsModel.user.shaPassword;
			var checkSum = CryptoJS.SHA512($rootScope.username+UserDetailsService.userDetilsModel.user.shaPassword+$rootScope.agentId+timeStamp).toString(CryptoJS.enc.Hex);
			var baseUrl = rootConfig.eCoverNoteRenewalRexitURL+'?';	
			var PMF;
			var lob=rootConfig.LOBs;
			var cls =contractType;
			for(var i in rootConfig.LOBs)
			{
			if(contractType == lob[i].Omni)
			{
				 cls = lob[i].Rexit;
			}
			}
			if(newPolicyNumber != '' || typeof(newPolicyNumber)	!='undefined' || newPolicyNumber != 'null')
			{
			policyNumber = newPolicyNumber;
			}
			if(rootConfig.isDeviceMobile)
			{
				PMF = "M";
			}
			else{
				PMF = "P";
			}			
				var params = "USERID="+UserDetailsService.userDetilsModel.user.userId+"&CNCODE="+policyNumber+"&CLASS="+cls+"&PMF="+PMF+"&ACCODE="+accode+"&Password="+password+"&DateTimeStamp="+timeStamp+"&Checksum="+checkSum+"&RETURNURL="+rootConfig.omniReturnURL;
				var url = baseUrl+params;
				
				if(rootConfig.isDeviceMobile)
				{
					var ref = window.open(url, '_blank','location=yes', 'toolbar=yes');
					ref.addEventListener('exit', 
							function(event) 
							{
															$scope.expandedAccordionFlag = true
												$scope.expandedAccordionId = angular.copy(policyNumber);
								$scope.searchPolicyDueForRenewal($scope.searchData);
							}
					);    
				}
				else
				{
					//$scope.setRedirectionDetails();
					sessionStorage.setItem('renewalFilterSection',JSON.stringify($scope.policyDueForRenewal));
					sessionStorage.setItem('reAuthentication',"enabled");
					//$window.location.href = 'file:///C:/Users/323970/Desktop/newWindowPOC.html';
					var form = document.createElement('form');
                    form.method = 'post';
                    form.action = url;
                    document.body.appendChild(form);
                    form.submit();
				}
		}
		else{}
	}
	$scope.policyPrintIconNavigation = function(newPolicyNumber,policyNumber,contractType,status)
	{	
		if((status =='Y' )||(status =='R'))
		{
			var timeStamp = PersistenceMapping.getFormattedDate();
			var accode=$rootScope.agentId;
			var password=UserDetailsService.userDetilsModel.user.shaPassword;
			var checkSum = CryptoJS.SHA512($rootScope.username+UserDetailsService.userDetilsModel.user.shaPassword+$rootScope.agentId+timeStamp).toString(CryptoJS.enc.Hex);
			var baseUrl = rootConfig.printRenewalRexitURL+'?';	
			var PMF;
			var lob=rootConfig.LOBs;
			var cls =contractType;
			for(var i in rootConfig.LOBs)
			{
			if(contractType == lob[i].Omni)
			{
				 cls = lob[i].Rexit;
			}
			}
			if(newPolicyNumber != '' || typeof(newPolicyNumber)	!='undefined' || newPolicyNumber != 'null')
			{
			policyNumber = newPolicyNumber;
			}			
			if(rootConfig.isDeviceMobile)
			{
				PMF = "M";
			}
			else{
				PMF = "P";
			}			
				var params = "USERID="+UserDetailsService.userDetilsModel.user.userId+"&CNCODE="+policyNumber+"&CLASS="+cls+"&PMF="+PMF+"&ACCODE="+accode+"&Password="+password+"&DateTimeStamp="+timeStamp+"&Checksum="+checkSum+"&RETURNURL="+rootConfig.omniReturnURL;
				var url = baseUrl+params;
				
				if(rootConfig.isDeviceMobile)
				{
					var ref = window.open(url, '_blank','location=yes', 'toolbar=yes');
					ref.addEventListener('exit', 
							function(event) 
							{
															$scope.expandedAccordionFlag = true
												$scope.expandedAccordionId = angular.copy(policyNumber);
								$scope.searchPolicyDueForRenewal($scope.searchData);
							}
					);    
				}
				else
				{
					//$scope.setRedirectionDetails();
					sessionStorage.setItem('renewalFilterSection',JSON.stringify($scope.policyDueForRenewal));
					sessionStorage.setItem('reAuthentication',"enabled");
					//$window.location.href = 'file:///C:/Users/323970/Desktop/newWindowPOC.html';
                    var form = document.createElement('form');
                    form.method = 'post';
                    form.action = url;
                    document.body.appendChild(form);
                    form.submit();
				}
		}
		else{}		
	}
	$scope.updateRenewal = function(RenewalData){
		if((RenewalData =='Y' )||(RenewalData =='R'))
		{
			return true;
		}
		else
		{
			return false;
		}
		
	};
	$scope.enablePrint = function(printData){
		if((printData =='Y' )||(printData =='R'))
		{
			return false;
		}
		else
		{
			return true;
		}
	};
	$scope.disableEicon = function(disValue){
		if(disValue =='')
		{
			return true;
		}
		else
		{
			return false;
		}
	};
	
	
        $scope.accordionFlag = function(policyNumber)
	{
		for(i=0;i<$scope.policyRenewalDetails.length;i++)
		{
			if($scope.policyRenewalDetails[i].policyNumber == policyNumber)
			{
				$scope.policyRenewalDetails[i].isActive = angular.copy(!$scope.policyRenewalDetails[i].isActive);
			}
		}
		
	};
	$scope.disableNewButton=function(rexitRenewalStatus,originOfLob,renewalStatus)
	{
	if(originOfLob =='R'){
		if(rexitRenewalStatus  == 'JPJ-OK' || rexitRenewalStatus  == 'JPJ-Not OK' || rexitRenewalStatus == 'RENEWED')
		{
		return true;
		}
		else
		{
		return false;
		}
	}
	else if(originOfLob == 'O'){
		if(renewalStatus == 'Y' || renewalStatus == 'R')
		{
		return true;
		}
		else
		{
		return false;
		}
	}
	};
	
	$scope.disableRenewButton=function(rexitRenewalStatus,originOfLob,renewalStatus)
	{
	if(originOfLob == 'R'){
		if(rexitRenewalStatus  == 'JPJ-OK' || rexitRenewalStatus  == 'JPJ-Not OK' || rexitRenewalStatus == 'RENEWED')
		{
		return true;
		}
		else
		{
		return false;
		}
	}
	else if(originOfLob == 'O'){
		if(renewalStatus == 'Y' || renewalStatus == 'R')
		{
		return true;
		}
		else
		{
		return false;
		}
	}
	};
    $scope.initialLoad();
	

}]);
