﻿mServiceApp.controller('DashBoardCtrl',['$controller','$rootScope', '$scope',  '$compile', '$route', '$routeParams', '$location', '$translate','dataService','appDataShareService','AutoSync','debounce','$timeout','commonConfig','dashBoardConfig','UserDetailsService',function($controller,$rootScope, $scope,  $compile, $route, $routeParams, $location, $translate,dataService,appDataShareService,AutoSync,debounce,$timeout,commonConfig,dashBoardConfig,UserDetailsService) {
	$rootScope.serviceFailed=false;
	var userDetails={};
	userDetails.currentUrl=$location.path();
	userDetails.userId=appDataShareService.selectedUser.userId;
	userDetails.userName=appDataShareService.selectedUser.name;
	$rootScope.isSyncStarted = false;
	var logedin = [];
	$scope.selectedpage = commonConfig().PAGE_NAME.DASH_BOARD;
	$scope.subModule = "";
	logedin.push(userDetails);
	sessionStorage.setItem('currentUser',JSON.stringify(logedin));
   
	$scope.$on("$destroy", function() {
		for (var i = 0; i < plotArrayLine.length; i++)
			plotArrayLine[i].destroy();
		for (var i = 0; i < plotArrayBar.length; i++)
			plotArrayBar[i].destroy();
		for (var i = 0; i < plotArrayPie.length; i++)
			plotArrayPie[i].destroy();
		plotArrayLine = [];
		plotArrayBar = [];
		plotArrayPie = [];
	});
	
	if (rootConfig.autoSync && ($rootScope.isAutoSyncCompleted)) {
		
		//alert("inside if...");
	   	AutoSync.SyncData(dataService,$rootScope,appDataShareService,debounce,$scope,$timeout);
		}

//	angular.extend(this, new BaseCtrl($scope, $rootScope, dataService, 'PotentialToEarn', appDataShareService.selectedUser.userId));
	angular.extend(this, $controller('BaseCtrl',{$scope:$scope, $rootScope:$rootScope, dataService:dataService, type:'PotentialToEarn', userId:appDataShareService.selectedUser.userId}));
	
	$scope.alertMessage
	$scope.dataEmpty = false;
	$scope.selectedDashBoardFilter = appDataShareService.dashboard.selectedFilter;
	$scope.chartId = "bar_chart";
	$scope.errorMessage ="No Records Found";
	$scope.img64;
	$scope.imgType;
	$scope.filterDashboard = function(selectedFilter) {
		$scope.selectedDashBoardFilter = selectedFilter;
		$scope.isMeetings = ($scope.selectedDashBoardFilter == dashBoardConfig().DASH_BOARD_FILTER.MEETINGS);
		$scope.isLogins = ($scope.selectedDashBoardFilter == dashBoardConfig().DASH_BOARD_FILTER.LOGINS);
		$scope.isIssuance = ($scope.selectedDashBoardFilter == dashBoardConfig().DASH_BOARD_FILTER.ISSUANCE);
		$scope.isEarning = ($scope.selectedDashBoardFilter == dashBoardConfig().DASH_BOARD_FILTER.EARINGS);
		$scope.graphData = [];
		$scope.performanceXaxisTicks = [];
		if ($scope.performaceReviewData != null && $scope.performaceReviewData != undefined) {
			for (var i = 0; i < $scope.performaceReviewData.length; i++) {
				for (var j = 0; j < $scope.performaceReviewData[i].data.length; j++) {
					if ($scope.performaceReviewData[i].type == selectedFilter)
					{
						var x1 ="";
						var x2 ="";
						var xTicks ="";
						x1 = $scope.performaceReviewData[i].data[j].month.substring(0,3);
						x2 = $scope.performaceReviewData[i].data[j].month.substring(6,8);
						var xTicks =x1+" "+x2;
						$scope.performanceXaxisTicks.push(xTicks);
					}
				}
			}
		}
		if ($scope.performanceXaxisTicks != null && $scope.performanceXaxisTicks != undefined && $scope.performanceXaxisTicks.length !=0 ) {
			var earningsAmount=0;
			for ( i = 0; i < $scope.performanceXaxisTicks.length; i++) {
				for (var j = 0; j < $scope.performaceReviewData.length; j++) {
					if ($scope.performaceReviewData[j].type == selectedFilter) {
						for (var k = 0; k < $scope.performaceReviewData[j].data.length; k++) {
							if ($scope.performanceXaxisTicks[i].substring(0,3) == $scope.performaceReviewData[j].data[k].month.substring(0,3))
							{
								if ($scope.performaceReviewData[j].type == "earnings")
								{
									earningsAmount=parseFloat($scope.performaceReviewData[j].data[k].count);
									$scope.graphData.push(earningsAmount.toFixed(2));
									earningsAmount=0;
								}
								else
								{
									$scope.graphData.push($scope.performaceReviewData[j].data[k].count);
								}
								
							}
						}
					}
				}

			}
			$scope.performanceOverview = [$scope.graphData];
		}
		else
		{
			$scope.graphData.push(' ');
			$scope.performanceOverview = [$scope.graphData];
			
		}
	}

	$scope.getTransationSuccessLoginPopup = function(data) {
		if (data[0] != undefined) {
			
			if (data[0].TransactionData != null) {
				var popupData = [];
				popupData = {
					"popupData" : ""
				};
				
					
				popupData.popupData = data[0].TransactionData;
				appDataShareService.loginPopupJson = popupData;
			
				if(appDataShareService.loginPopupJson.popupData != undefined){
				
					if(popupData.popupData.LoginPopUp.base64Data!=""){
						
						$rootScope.startupPopup = true;	
						$rootScope.img64 = popupData.popupData.LoginPopUp.base64Data;
						$scope.imgType = popupData.popupData.LoginPopUp.base64Type;
						$scope.$apply();
						}
						else
						{
							$rootScope.startupPopup=false;	
						}
				}
				
				else{
					$rootScope.popupOver = true;
					$rootScope.startupPopup=false;	
				}
			}
		} else {
			
			
			if(appDataShareService.selectedUser.userId != $rootScope.IntialloggedInUser){		
				$rootScope.startupPopup=false;
				
				if (rootConfig.isDeviceMobile){
					
					if (navigator.network.connection.type == Connection.NONE) {
						$scope.dataEmpty = true;
						$scope.alertMessage = translateMessages($translate, "alerts.offlineAlertMessage");
					}
					else{
						
						if(!$rootScope.isSyncStarted){
							
							$rootScope.$broadcast(commonConfig().STATUS.IS_DEVICE_ONLINE);
						}
						
					}
					
					
				}
					
				else{
					$scope.dataEmpty = true;
					$scope.alertMessage = translateMessages($translate, "alerts.onlineAlertMessage");
				}
			}
	
				
		}
		$scope.refresh();
		//showHideLoadingImage(false);
	}
	
	$scope.getTransationSuccessPerformance = function(data) {
			showHideLoadingImage(false,null,null,"Performance");
		if (data[0] != undefined) {
			if (data[0].TransactionData != null) {
				var performaceData = [];
				performaceData = {
					"Performance" : ""
				};
				performaceData.Performance = data[0].TransactionData;
				appDataShareService.performanceJson = performaceData;
				$scope.performaceReviewData = performaceData.Performance.myPerformanceOverview;
				$scope.filterDashboard($scope.selectedDashBoardFilter);
			}
		} else {
			
			if(appDataShareService.selectedUser.userId != $rootScope.IntialloggedInUser){	
				 if (rootConfig.isDeviceMobile){
						
						if (navigator.network.connection.type == Connection.NONE) {
							$scope.dataEmpty = true;
							$scope.alertMessage = translateMessages($translate, "alerts.offlineAlertMessage");
						}
						else{
							if(!$rootScope.isSyncStarted){
							
								$rootScope.$broadcast(commonConfig().STATUS.IS_DEVICE_ONLINE);
							}
							
						}
						
						
					}
					else{
						$scope.dataEmpty = true;
						$scope.alertMessage = translateMessages($translate, "alerts.onlineAlertMessage");
					}	
			}
	       
}
		$scope.refresh();
		//showHideLoadingImage(false);
	}

	$scope.getTransationSuccess = function(data) {
		showHideLoadingImage(false,null,null,"Potential");
		if (data[0] != undefined) {
			if (data[0].TransactionData != null) {
				$scope.dashBoardData = {
					"Pottential" : ""
				};
				$scope.dashBoardData.Pottential = data[0].TransactionData;
				appDataShareService.pottentialJson = $scope.dashBoardData;
				$scope.transactionSuccess = true;
				$scope.setPottentialToEarnData();
				$scope.refresh();
			   // showHideLoadingImage(false);
			}
		} else {
			
			if(appDataShareService.selectedUser.userId != $rootScope.IntialloggedInUser){	
				 if (rootConfig.isDeviceMobile){
						
						if (navigator.network.connection.type == Connection.NONE) {
							$scope.dataEmpty = true;
							$scope.alertMessage = translateMessages($translate, "alerts.offlineAlertMessage");
						}
						else{
							if(!$rootScope.isSyncStarted){
								
								$rootScope.$broadcast(commonConfig().STATUS.IS_DEVICE_ONLINE);
							}
							
						}
						
						
					} else {
						$scope.dataEmpty = true;
					$scope.alertMessage = translateMessages($translate, "alerts.onlineAlertMessage");
				}
       	}
		    
		
		}
	}
	
	$scope.getAlertMessage = function() {
		return $scope.alertMessage;
	}
	

	$scope.getTransationError = function(data) {
		
		showHideLoadingImage(false,null,null,"Potential");
			$rootScope.serviceFailed=true;	
			if (rootConfig.isDeviceMobile && !checkConnection()) {
				$scope.message = translateMessages($translate, "networkValidationErrorMessage");
			}else{
				$scope.message = translateMessages($translate, "validToken");
			}		
		    $scope.$emit('tokenEvent', { message: $scope.message });	
	}
$scope.getTransationErrorPerformance = function(data) {
		
		showHideLoadingImage(false,null,null,"Performance");
		$rootScope.serviceFailed=true;
		$rootScope.$apply();
	}
	$scope.setPottentialToEarnData = function() {
		$scope.potentialtoEarn = [];
		
		for ( var i = 0; i < $scope.dashBoardData.Pottential.potentialToEarnByType.length; i++) {
		
			var inputType = $scope.dashBoardData.Pottential.potentialToEarnByType[i].type;
			
			var potentialFilteredDetails = [];
			for(var j = 0 ;j < $scope.dashBoardData.Pottential.potentialToEarnByType[i].data.length ; j++){
				var dateFromServer = "";
				switch (inputType) {

				case commonConfig().FILTER.PREMIUM_DUE:	
					if($scope.dashBoardData.Pottential.potentialToEarnByType[i].data[j].renewalDate != ""){
						dateFromServer = convertDateFromISO($scope.dashBoardData.Pottential.potentialToEarnByType[i].data[j].renewalDate);
					}
					
					break;
				case commonConfig().FILTER.CHEQUE_BOUNCE:	
					if($scope.dashBoardData.Pottential.potentialToEarnByType[i].data[j].receivedDate != ""){
						dateFromServer = convertDateFromISO($scope.dashBoardData.Pottential.potentialToEarnByType[i].data[j].receivedDate);
					}
					
					break;
				case commonConfig().FILTER.ISSUANCE_PENDING:
					if($scope.dashBoardData.Pottential.potentialToEarnByType[i].data[j].loginDate != ""){
						dateFromServer = convertDateFromISO($scope.dashBoardData.Pottential.potentialToEarnByType[i].data[j].loginDate);
					}
					

					break;
				}
				if(dateFromServer != ""){
					var month = dateFromServer.getMonth() + 1;
					var year = dateFromServer.getFullYear();
					var validDate = true;//getBetweenDates(month, year, 0, 0, false);
					if(validDate){
						potentialFilteredDetails.push($scope.dashBoardData.Pottential.potentialToEarnByType[i].data[j]);
					}
				}
				}
				
			
			$scope.potentialtoEarn.push([inputType, potentialFilteredDetails.length]);
		}
	}
	
	$scope.initialLoad = function(){
		if (appDataShareService.refreshApp || (!(appDataShareService.pottentialJson.hasOwnProperty('Pottential'))  && !(appDataShareService.performanceJson.hasOwnProperty('Performance')))) {
			
			appDataShareService.refreshApp =  false;
			appDataShareService.pottentialJson = {};
			appDataShareService.performanceJson = {};
			appDataShareService.loginPopupJson = {};
			// call get transaction and reload data
			this.getTransactions($scope.getTransationSuccess, $scope.getTransationError);

	if (navigator.userAgent.search(commonConfig().SEARCH_OPTION.MSIE) >= 0)
					showHideLoadingImage(true, "Loading Potential to Earn", null,"Potential");
			else
				showHideLoadingImage(true, "Loading Potential to Earn", $translate,"Potential");
			
			var transactionObj = this.mapScopeToPersistance();
			transactionObj.Type = commonConfig().TRANSACTION_TYPE.PERFORMANCE_OVERVIEW;
			this.getTransactions($scope.getTransationSuccessPerformance, $scope.getTransationErrorPerformance, transactionObj);
			if (navigator.userAgent.search(commonConfig().SEARCH_OPTION.MSIE) >= 0)
					showHideLoadingImage(true, "Loading Performance DashBoard", null,"Performance");
			else
				showHideLoadingImage(true, "Loading Performance DashBoard", $translate,"Performance");
			
			
			if(rootConfig.isDeviceMobile){ 
			if(!appDataShareService.isSwitchEnabled && appDataShareService.isSync){
				
				var transactionObj = this.mapScopeToPersistance();
				transactionObj.Type = commonConfig().TRANSACTION_TYPE.LOGIN_POPUP;
				this.getTransactions($scope.getTransationSuccessLoginPopup, $scope.getTransationError, transactionObj);
			}
			}else{
			
				if(!appDataShareService.isSwitchEnabled){
					
					var transactionObj = this.mapScopeToPersistance();
					transactionObj.Type = commonConfig().TRANSACTION_TYPE.LOGIN_POPUP;
					this.getTransactions($scope.getTransationSuccessLoginPopup, $scope.getTransationError, transactionObj);
				}
				
			}


			//appDataShareService.refreshApp = false;
		} else {
			showHideLoadingImage(false,null,null,"Potential");
			
			if (appDataShareService.pottentialJson != "undefined" && appDataShareService.pottentialJson.hasOwnProperty('Pottential')) {
				$scope.dashBoardData = appDataShareService.pottentialJson;
				$scope.setPottentialToEarnData();
			}
			showHideLoadingImage(false,null,null,"Performance");
			if (appDataShareService.performanceJson != "undefined" && appDataShareService.performanceJson.hasOwnProperty('Performance')) {
				$scope.performaceReviewData = appDataShareService.performanceJson.Performance.myPerformanceOverview;
				$scope.filterDashboard($scope.selectedDashBoardFilter);

			}
		}
	}

	/*$scope.paintUISuccess = function(callbackId, data) {
		$scope.isPainted = true;
			//showHideLoadingImage(false,null,null,"Potential");
	}
	$scope.paintUISuccessPerformance = function(callbackId, data) {
		$scope.isPainted = true;
		//showHideLoadingImage(false,null,null,"Performance");
	}
	//call the paint UI with "scope.item.subType" as view name and define this view in alerts-ui-json
	LEDynamicUI.paintUI(rootConfig.template, "dashboard-ui-json.json", "PerformanceOverview", "#dvPerformanceOverview", true, $scope.paintUISuccessPerformance, $scope, $compile);
	LEDynamicUI.paintUI(rootConfig.template, "dashboard-ui-json.json", "PotentialtoEarn", "#dvPotentialtoEarn", true, $scope.paintUISuccess, $scope, $compile);
*/
	$scope.$on('$viewContentLoaded', function(){
		$scope.initialLoad();
	  });
	

function getFormattedDate(inputDate){
	inputDate = inputDate ? inputDate.replace(/-/g, '/'): '';
    var splitDate = inputDate ? inputDate.split("/") : '';
    var dateFromServer = new Date(splitDate[2], splitDate[1] - 1, splitDate[0]);
    return dateFromServer;
}

function getBetweenDates(inputMonth, inputYear, startMonthCount, monthsCount,
		identify) {
	var now = new Date();
	var preDateStart;
	var preDateEnd;

	if (identify) {
		preDateStart = new Date(now.getFullYear(), now.getMonth()
				+ startMonthCount, 31);
		preDateEnd = new Date(now.getFullYear(), now.getMonth() + monthsCount,
				1);
	} else {
		preDateStart = new Date(now.getFullYear(), now.getMonth()
				- startMonthCount, 31);
		preDateEnd = new Date(now.getFullYear(), now.getMonth() - monthsCount,
				1);

	}
	var successflag = true;//getAcutalFilteredData(preDateStart, preDateEnd,inputMonth, inputYear, identify);
	return successflag;

}
function getAcutalFilteredData(start, end, month, year, identify) {
	var dateFromServer = new Date();
	dateFromServer.setMonth((month) - 1);
	dateFromServer.setUTCFullYear(year);

	if (identify) {
		if (dateFromServer >= start && dateFromServer <= end)
			return true;
	} else {
		if (dateFromServer <= start && dateFromServer >= end)
			return true;
	}
	if (dateFromServer <= start && dateFromServer >= end) {
		return true;
	}
	return false;
}

}]);