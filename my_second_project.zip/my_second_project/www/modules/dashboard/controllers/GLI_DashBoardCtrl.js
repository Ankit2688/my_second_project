mServiceApp.controller('GLI_DashBoardCtrl',['$controller','$rootScope', '$scope',  '$compile', '$route', '$routeParams', '$location', '$translate','dataService','$window',
'appDataShareService','UserDetailsService','AutoSync','debounce','$timeout','$filter','commonConfig','dashBoardConfig','PersistenceMapping',function GLI_DashBoardCtrl($controller ,$rootScope, $scope,
$compile, $route, $routeParams, $location, $translate,dataService,$window,appDataShareService,UserDetailsService,AutoSync,debounce,$timeout,$filter,commonConfig,dashBoardConfig,PersistenceMapping) {
    $controller('DashBoardCtrl',{
        $rootScope:$rootScope,
        $scope:$scope,
        $compile:$compile,
        $route:$route,
        $routeParams:$routeParams,
        $location:$location,
        $translate:$translate,
        dataService:dataService,
        appDataShareService:appDataShareService,
		UserDetailsService:UserDetailsService,
        AutoSync:AutoSync,
        debounce:debounce,
        $timeout:$timeout,
        $filter:$filter,
        commonConfig:commonConfig,
        dashBoardConfig:dashBoardConfig});
    $scope.selectedDashBoardFilter = appDataShareService.dashboard.selectedFilter;
	var _this = this;
	$rootScope.isLoggedOut = false;
	 $scope.isDeviceMobile = rootConfig.isDeviceMobile;
    $scope.contentDownloadfail = false;
		$scope.initialDate = {};


	if(!(rootConfig.isDeviceMobile) && !(UserDetailsService.userDetilsModel)){
		var userDetilsModel = JSON.parse(sessionStorage.userDetails);
		var userDetailData = JSON.parse(sessionStorage.loginData);
		$rootScope.username = userDetilsModel.user.userId;
		$rootScope.agentId = userDetilsModel.user.rexitLoginId;
		$rootScope.isAuthenticated = true;
		$rootScope.username = userDetilsModel.user.userId;
		$rootScope.authenticationStatus = "SUCCESS";
		$rootScope.firstTimeLogin = userDetailData.firstTimeLogin;
		$rootScope.isTemporaryPassword = userDetailData.isTemporaryPassword;
		$rootScope.role = userDetailData.roles[0];
		UserDetailsService.setUserDetailsModel(userDetilsModel);
	}
	$scope.filterDashboard = function(selectedFilter) {
		$scope.selectedDashBoardFilter = selectedFilter;
		$scope.is7dayusFilter = ($scope.selectedDashBoardFilter === dashBoardConfig().DASH_BOARD_POLICYRENEWALFILTER.SEVENDAYS);
		$scope.is30dayusFilter = ($scope.selectedDashBoardFilter === dashBoardConfig().DASH_BOARD_POLICYRENEWALFILTER.THIRTYDAYS);
		$scope.is60dayusFilter = ($scope.selectedDashBoardFilter === dashBoardConfig().DASH_BOARD_POLICYRENEWALFILTER.SIXTYDAYS);
		if($scope.is7dayusFilter === true){
			$scope.policyRenewalData = $scope.dashBoardData.dueForRenewal7day;
		}
		else if($scope.is30dayusFilter === true){
			$scope.policyRenewalData = $scope.dashBoardData.dueForRenewal30day;
		}
		else{
			$scope.policyRenewalData = $scope.dashBoardData.dueForRenewal60day;
		}
		$scope.graphData = [];
		$scope.performanceXaxisTicks = [];
		$scope.totCount = 0;
		if ($scope.policyRenewalData !== null && $scope.policyRenewalData !== undefined) {
			for (var i = 0; i < $scope.policyRenewalData.length; i++) {
						var x1 ="";
						var x2 ="";
						var xTicks ="";
						x1 = $scope.policyRenewalData[i].majorClassName.substring(0,3);
						var xTicks =x1;
						$scope.performanceXaxisTicks.push(xTicks);
			}
		}
		if ($scope.performanceXaxisTicks !== null && $scope.performanceXaxisTicks !== undefined && $scope.performanceXaxisTicks.length !== 0 ) {
			for ( i = 0; i < $scope.performanceXaxisTicks.length; i++) {
				for (var j = 0; j < $scope.policyRenewalData.length; j++) {
							if ($scope.performanceXaxisTicks[i].substring(0,3) === $scope.policyRenewalData[j].majorClassName.substring(0,3))
							{
									$scope.graphData.push($scope.policyRenewalData[j].countByMajorClass);
									$scope.totCount = $scope.totCount + parseInt($scope.policyRenewalData[j].countByMajorClass);
							}
				}
			}
			$scope.performanceOverview = [$scope.graphData];
		}
		else
		{
			$scope.graphData.push(' ');
			$scope.performanceOverview = [$scope.graphData];
		}
		$scope.refresh();
	};
	angular.extend(this, $controller('BaseCtrl',{$scope:$scope, $rootScope:$rootScope, dataService:dataService, type:'AgentDashboard', userId:appDataShareService.selectedUser.userId}));
	$scope.mapScopeToPersistance = function () {
	    var newDate = new Date();
	    PersistenceMapping.clearTransactionKeys();
        PersistenceMapping.Key2 = $rootScope.username;
        PersistenceMapping.Key5 = "Agent";
        PersistenceMapping.Type = _this.Type;
        var transactionObj =  PersistenceMapping.mapScopeToPersistence({});
        return transactionObj;
    };
	$scope.mapScopeToPersistanceClientInfo = function () {
	    var newDate = new Date();
	    PersistenceMapping.clearTransactionKeys();
        PersistenceMapping.Key2 = $rootScope.username;
        PersistenceMapping.Key5 = "Agent";
        PersistenceMapping.Type = "clientInformation";
        var transactionObj =  PersistenceMapping.mapScopeToPersistence({});
        return transactionObj;
    };
    function getPreCompiledTemplate(callback) {
        if (rootConfig.isPrecomiledTemplate) {
            LEDynamicUI.loadPrecompiledTemplate(function () {
                              // success callback
                               callback();
                            }, function(){
                                console.log('error');
                            });
        }
        else {
            callback();
        }
    }
    $scope.loadDashBoardData = function(){
    	getPreCompiledTemplate(function () {
            LEDynamicUI.paintUI(rootConfig.template, "dashboard-ui-json.json", "PerformanceOverview", "#dvPerformanceOverview", true, $scope.paintUISuccessPerformance, $scope, $compile);
            LEDynamicUI.paintUI(rootConfig.template, "dashboard-ui-json.json", "PotentialtoEarn", "#dvPotentialtoEarn", true, $scope.paintUISuccess, $scope, $compile);
        });
        if (navigator.userAgent.search(commonConfig().SEARCH_OPTION.MSIE) >= 0){
			showHideLoadingImage(true, "Loading Dashboard", null,"Potential");
		}
    	else{
			showHideLoadingImage(true, "Loading Dashboard", $translate,"Potential");
		}
    	var transactionObj = $scope.mapScopeToPersistance();
		if((rootConfig.isDeviceMobile && checkConnection()) || !rootConfig.isDeviceMobile){
			dataService.searchTransactions(transactionObj, $scope.getTransactionSuccess, $scope.getTransactionError);
		}else{
			$scope.getTransactionError();
		}
    };
	$scope.retrieveClientInformation=function()
	{
	var transactionObj = $scope.mapScopeToPersistanceClientInfo();
		if((rootConfig.isDeviceMobile && checkConnection()) || !rootConfig.isDeviceMobile){
			dataService.searchTransactions(transactionObj, $scope.getClientInfoTransactionSuccess, $scope.getClientInfoTransactionError);
		}else{
			$scope.getClientInfoTransactionError();
		}
	};
	$scope.initialLoad = function(){
		$('.slider_menu ul li#dashboard-li').trigger('click');
		if (localStorage["prevPath"].indexOf("/login") > 0) {
			if((rootConfig.isDeviceMobile) && rootConfig.hasContentAdmin && checkConnection()) {
		            showHideLoadingImage(true, translateMessages($translate,
		            "downloadingMandatory"));
		            $scope.contentDownloader(function () {
                        //call the paint UI with "scope.item.subType" as view name and define this view in alerts-ui-json
                        $scope.loadDashBoardData();
                    });
		    } else {
				loadConfigfile(function(){
                	$scope.loadDashBoardData();
                	}
                	);
			}
		} else {
			$scope.loadDashBoardData();
		}
		
	   var cur = new Date();
	   var noOfDays = rootConfig.defaultDayCountRelationship;
	   var after7days = new Date(cur.setDate(cur.getDate() + noOfDays));
	   $scope.initialDate.dateFrom = getFormattedDate();
	   $scope.initialDate.dateTo = getFormattedDateFromDate(after7days);        
	   showHideLoadingImage(false);
	   $scope.searchBirthdays($scope.initialDate);
	   $scope.$apply();   			  
	};
	
	//client-bday-notification ----------
	
	   $scope.validateFields = function(relationshipMngmnt){
		 $scope.noData = false;
		 $scope.validSearch = false;
		 $scope.relationshipMngmnt = relationshipMngmnt;
		 //Date validation for claim incurred date
		 if(!$scope.initialDate.dateFrom || !$scope.initialDate.dateTo){
			    $scope.errorMessage = [];
				$scope.dateMandatoryErrorMessage = translateMessages($translate, "policySearch.dateMandatoryErrorMessage");
				$scope.errorMessage.push($scope.dateMandatoryErrorMessage);
				$scope.isValid = true;
		 }
		 else if(!isFtureDate($scope.initialDate.dateFrom) || !isFtureDate($scope.initialDate.dateTo)){
				 $scope.errorMessage = [];
	         	 $scope.isValid = true;
				 $scope.pastDateValidationMessage = translateMessages($translate, "policySearch.pastDateValidationMessage");
	             $scope.errorMessage.push($scope.pastDateValidationMessage);
		 }
		 else if($scope.initialDate.dateTo < $scope.initialDate.dateFrom){
	         	$scope.errorMessage = [];
	         	$scope.isValid = true;
				$scope.fromGreaterthanToValidationMessage = translateMessages($translate, "policySearch.fromGreaterthanToValidationMessage");// To got the error message
	            $scope.errorMessage.push($scope.fromGreaterthanToValidationMessage);
	     }
		 else if(!isDateWithinSixtyFuture($scope.initialDate.dateFrom) || !isDateWithinSixtyFuture($scope.initialDate.dateTo)){
			    $scope.errorMessage = [];
	         	$scope.isValid = true;
				$scope.dateRangeSixtyValidationMessage = translateMessages($translate, "policySearch.dateRangeSixtyValidationMessage");// To got the error message
	            $scope.errorMessage.push($scope.dateRangeSixtyValidationMessage);
		 }
		 else{
         	    $scope.isValid = false;
         }
	    if($scope.isValid){
		  //errror message
		     $scope.isSearchInValid = true;
		     $scope.policyRenewalDetails = [];
		}
		else{
		     $scope.isSearchInValid = false;
			 $scope.errorMessage = [];
			 $scope.searchBirthdays($scope.relationshipMngmnt);
		}
	 };
	
		$scope.mapScopeToPersistanceb = function () {
		var newDate = new Date();
		PersistenceMapping.clearTransactionKeys();
	    PersistenceMapping.Key2 = $rootScope.username;
	    PersistenceMapping.Key5 = "Agent";
	    PersistenceMapping.Type = _this.Type;
	    var transactionObj =  PersistenceMapping.mapScopeToPersistence({});
	    return transactionObj;
	};
	$scope.searchBirthdays = function(relationshipMngmnt){
       // showHideLoadingImage(true,"Loading Relationship Management", null, null);
		$scope.relationshipMngmnt = relationshipMngmnt;
		$scope.errorMessage = [];
		$scope.isSearchInValid = false;
		var transactionObj = $scope.mapScopeToPersistanceb();
    	$scope.relationshipMngmntDateFrom = $filter('date')($scope.initialDate.dateFrom, "yyyy-MM-dd");
        $scope.relationshipMngmntDateTo = $filter('date')( $scope.initialDate.dateTo, "yyyy-MM-dd");
		var searchObj = {
				"SearchCriteria" : {
					"fromDate" : $scope.relationshipMngmntDateFrom,
					"toDate" : $scope.relationshipMngmntDateTo
				}
		    };
		transactionObj.TransactionData = searchObj;
		transactionObj.Type = "relationshipSearch";
		if((rootConfig.isDeviceMobile && checkConnection()) || !rootConfig.isDeviceMobile){
			dataService.searchTransactions(transactionObj, $scope.getTransactionSuccessClientBday, $scope.getTransactionErrorClientBday);
		}else{
			$scope.getTransactionError();
		}
		};
	$scope.getTransactionSuccessClientBday = function(data) {
		var bithdayResults = [];
		 if(data[0] !== undefined && data[0].TransactionData !== null){
				$scope.validSearch = true;
				if (data[0].TransactionData.birthdayUserList.length !== 0) {
					bithdayResults = data[0].TransactionData.birthdayUserList;
					$scope.noOfPolicies = bithdayResults.length;
				    $scope.clientDetails = [];
					for ( var i = 0; i < bithdayResults.length; i++) {
					    bithdayResults[i].agentCode = bithdayResults[i].branchCode+' '+bithdayResults[i].agentCode;
						$scope.clientDetailsTemp = [];
						if (bithdayResults[i].dateOfBirth!="")
						{
							dob=$filter('date')(bithdayResults[i].dateOfBirth, "dd-MM-yyyy");
						}
						else
						{
							dob=bithdayResults[i].dateOfBirth;
						}
						$scope.clientDetailsTemp.push({
                        	key : '',
                        	value : bithdayResults[i].customerName
                        });
						$scope.clientDetailsTemp.push({
							key : translateMessages($translate, "alerts.dobLabel"),
							value : dob
						});
						$scope.clientDetailsTemp.push({
							key : translateMessages($translate, "alerts.policyNoLabel"),
							value : bithdayResults[i].policyNumber
						});
						$scope.clientDetailsTemp.push({
							key : translateMessages($translate, "alerts.productNameLabel"),
							value : bithdayResults[i].productName
						});
						$scope.clientDetailsTemp.push({
							key : translateMessages($translate, "alerts.occupationLabel"),
							value : bithdayResults[i].occupation
						});
						$scope.clientDetailsTemp.push({
							key : translateMessages($translate, "alerts.emailLabel"),
							value : bithdayResults[i].email
						});
						$scope.clientDetailsTemp.push({
							key : translateMessages($translate, "alerts.contactLabel"),
							value : bithdayResults[i].mobileNumber
						});
						$scope.clientDetailsTemp.push({
							key : translateMessages($translate, "alerts.addressLabel"),
							value : [bithdayResults[i].address.addressLine1, bithdayResults[i].address.addressLine2, bithdayResults[i].address.addressLine3, bithdayResults[i].address.addressLine4,bithdayResults[i].address.postalCode,bithdayResults[i].address.country].filter(function (val) {return val;}).join(', ')
						});
						$scope.clientDetails
								.push({
									"header" : bithdayResults[i].agentCode,
									"data" : $scope.clientDetailsTemp
								});
					}
					if(bithdayResults.length===0){
						$scope.noData = true;
					}else{
						$scope.noData = false;
					}
					//clientBirthdayDetails------
					var bdayData = angular.element("#snackbar")[0];
					bdayData.className = "show";
					setTimeout(function(){
					  $scope.isBirthday = true;
					  bdayData.className = bdayData.className.replace("show", ""); 
					  }, 30000);
					$scope.birthdayCount= $scope.noOfPolicies;
					$scope.$apply();
				}
				else {
					$scope.noData = true;
					$scope.noOfPolicies = 0;
					$scope.validSearch = false;
					$scope.errorMessage = [];
					$scope.searchFailedMessage = translateMessages($translate, "policySearch.noDataMessage");
		            $scope.errorMessage.push($scope.searchFailedMessage);
					$scope.searchBirthdays();
		            $scope.$apply();
		   }
		}else {
		 		$scope.noData = true;
				$scope.noOfPolicies = 0;
				$scope.validSearch = false;
				$scope.errorMessage = [];
				$scope.searchFailedMessage = translateMessages($translate, "policySearch.noDataMessage");
	            $scope.errorMessage.push($scope.searchFailedMessage);
	            $scope.$apply();
	    }
		showHideLoadingImage(false);
	};
	$scope.getTransactionErrorClientBday = function(data) {
		$rootScope.serviceFailed=true;
		if (rootConfig.isDeviceMobile && !checkConnection()) {
			$scope.message = translateMessages($translate, "networkValidationErrorMessage");
		}else{
			$scope.message = translateMessages($translate, "validToken");
		}
		$scope.$emit('tokenEvent', { message: $scope.message });
		if (data == "Error in ajax callE")
		   {
			   $scope.onServerError=true;
			   $scope.serverErrorMessage= translateMessages($translate, "serverErrorMessage");
		   }
		showHideLoadingImage(false);
		$rootScope.$apply();
	};
	
//client-bday-notification-ends-------------------------	


	$scope.paintUISuccess = function (callbackId, data) {
        $scope.isPainted = true;
        //showHideLoadingImage(false,null,null,"Potential");
    }
    $scope.paintUISuccessPerformance = function (callbackId, data) {
        $scope.isPainted = true;
        //showHideLoadingImage(false,null,null,"Performance");
    }
	$scope.getTransactionSuccess = function(data) {
			showHideLoadingImage(false,null,null,"Loading Dashboard");
			if (data[0] !== undefined) {
				if (data[0].TransactionData !== null) {
					$scope.dashBoardData = data[0].TransactionData;
					for(var i=0;i<$scope.dashBoardData.ClaimsLoggedSearchResult.length;i++){
					  $scope.dashBoardData.ClaimsLoggedSearchResult[i].policyNumber = $scope.dashBoardData.ClaimsLoggedSearchResult[i].policyNumber+'/'+$scope.dashBoardData.ClaimsLoggedSearchResult[i].claimNumber;
					}
					appDataShareService.dashBoardJson = $scope.dashBoardData;
					$scope.filterDashboard($scope.selectedDashBoardFilter);
					$scope.retrieveClientInformation();
					$scope.$apply();
				}
			} else {
				if(appDataShareService.selectedUser.userId != $rootScope.IntialloggedInUser){
					 if (rootConfig.isDeviceMobile){
							if (navigator.network.connection.type == Connection.NONE) {
								$scope.dataEmpty = true;
								$scope.alertMessage = translateMessages($translate, "alerts.offlineAlertMessage");
							}
							else{
								if(!$rootScope.isSyncStarted){
									$rootScope.$broadcast(commonConfig().STATUS.IS_DEVICE_ONLINE);
								}
							}
						}
						else{
							$scope.dataEmpty = true;
							$scope.alertMessage = translateMessages($translate, "alerts.onlineAlertMessage");
						}
				}
		   }
    };

    $scope.getTransactionError = function(data) {
		$rootScope.serviceFailed=true;
                	if (rootConfig.isDeviceMobile && !checkConnection()) {
						$scope.message = translateMessages($translate, "networkValidationErrorMessage");
					}else{
						$scope.message = translateMessages($translate, "validToken");
					}
                	$scope.$emit('tokenEvent', { message: $scope.message });

                	if (data == "Error in ajax callE")
                       {
                           $scope.onServerError=true;
                           $scope.serverErrorMessage= translateMessages($translate, "serverErrorMessage");
                          showHideLoadingImage(false,null,null,"Dashboard");
                       }
                       else
                       {
                		showHideLoadingImage(false,null,null,"Dashboard");
                       }
					   showHideLoadingImage(false,null,null,"Dashboard");
                	$rootScope.$apply();
	};
	$scope.getClientInfoTransactionSuccess = function(data) {
			if (data[0] !== undefined) {
				if (data[0].TransactionData !== null) {
					UserDetailsService.userDetilsModel.clientInfo = data[0].TransactionData;
					sessionStorage.userDetails = JSON.stringify(UserDetailsService.userDetilsModel);
					}
					
					$scope.$apply();
				}
			 else {
				if(appDataShareService.selectedUser.userId != $rootScope.IntialloggedInUser){
					 if (rootConfig.isDeviceMobile){
							if (navigator.network.connection.type == Connection.NONE) {
								$scope.dataEmpty = true;
								$scope.alertMessage = translateMessages($translate, "alerts.offlineAlertMessage");
							}
							else{
								if(!$rootScope.isSyncStarted){
									$rootScope.$broadcast(commonConfig().STATUS.IS_DEVICE_ONLINE);
								}
							}
						}
						else{
							$scope.dataEmpty = true;
							$scope.alertMessage = translateMessages($translate, "alerts.onlineAlertMessage");
						}
				}
		   }
    };

    $scope.getClientInfoTransactionError = function(data) {
		$rootScope.serviceFailed=true;
                	if (rootConfig.isDeviceMobile && !checkConnection()) {
						$scope.message = translateMessages($translate, "networkValidationErrorMessage");
					}else{
						$scope.message = translateMessages($translate, "validToken");
					}
                	$scope.$emit('tokenEvent', { message: $scope.message });

                	if (data == "Error in ajax callE")
                       {
                           $scope.onServerError=true;
                           $scope.serverErrorMessage= translateMessages($translate, "serverErrorMessage");
                          showHideLoadingImage(false,null,null,"Dashboard");
                       }
                       else
                       {
                		showHideLoadingImage(false,null,null,"Dashboard");
                       }
					   showHideLoadingImage(false,null,null,"Dashboard");
                	$rootScope.$apply();
	};
	$scope.mandatoryDownloadFailed = function(mandatory) {
    	if (mandatory == "mandatory") {
    		showHideLoadingImage(false, "");//generali specific change.
    		$scope.contentDownloadfail = true;
            $scope.$apply();
    	}
    };
   $scope.contentDownloader = function(callback) {
   			// le Content Admin starts
   			(function downloadContentFiles(mandatory, callAgain) {
   				$scope.serviceURL = rootConfig.contentAdminURL;
   				var options = {
   					contentManagerServiceurl : $scope.serviceURL,
   					debugMode : true,
   					appContext : rootConfig.appContext
   				};
   				if (mandatory) {
   					options.contentPreference = "mandatory";
   				}else{
   					options.contentPreference = "optional";
   				}
   				var le = new LEContentManager(options);
   				var options = {
   					syncMode : "all",
   					jsonFile : "initialContent.json",
   					headers : {
   						"nwsAuthToken" : "e03364fd-a8c6-7878-3d44-cff2a9d8e333"
   					}
   				};
   				le
   						.syncData(
   								function(type, data) {
   								},
   								function(successFileList, errorFileList) {

   									var message = "";
   									if (successFileList.length > 0) {
   										message = successFileList.length
   												+ " files successfully downloaded. "
   												+ JSON.stringify(successFileList)
   												+ ". ";

   									}
   									if (errorFileList.length > 0) {
   										message = message + errorFileList.length
   												+ " files failed to download. "
   												+ JSON.stringify(errorFileList)
   												+ ".";

   										$scope.mandatoryDownloadFailed(mandatory);
   									} else {
   										if (callAgain) {
   											/*
   											 * Loading Landinpage after manadatory
   											 * file download
   											 */
   											//$scope.loadLandingPage();
   											/*
   											 * Going to download Non mandatory
   											 * content files
   											 */
   											loadConfigfile(function(){
                                                isAppExpired(function (appExpired) {
                                                    if (!appExpired) {
                                                        $scope.loadDashBoardData();
                                                        downloadContentFiles("", false);
                                                        $scope.upgradeAvailable = false;
                                                        callback();
                                                    }
                                                    else {
                                                        showHideLoadingImage(false, "");
                                                        $scope.upgradeAvailable = true;
                                                        $scope.$apply();
                                                    }
                                                });        	
                                              });
   										}

   									}

   								}, function(message, data) {
   									$scope.mandatoryDownloadFailed(mandatory);
   									if (typeof message != undefined
   											&& typeof data != undefined) {

   									} else if (typeof message != undefined
   											&& typeof data == undefined) {

   									} else if (typeof message == undefined
   											&& typeof data != undefined) {

   									}

   								}, options);
   				// le Content Admin ends
   			})("mandatory", true)
   		};


   	$scope.getFromApplicationPath = function(jsonFile,
    								successCallBack, errorCallback) {
    	var self = this;
    							self._prepareErrorCallBack = function(
    									errorCode, errorMessage) {
    								if(rootConfig.isDebug){
    									console.log(errorMessage);
    	}
    							};
    	if (rootConfig && rootConfig.isOfflineDesktop) {
    		var fs = require('fs');
    								fs.readFile(jsonFile, 'utf8', function(err,
    										data) {
    			if (err) {
    										self._prepareErrorCallBack(
    												'Error_106',
    						'Error while fetching config JSON from remote location'
    														+ jsonFile,
    												errorCallback);
    			}
    			successCallBack(data);
    		});
    	} else {
    								url:
    										rootConfig.contentAdminDownLoadURL
    												+ jsonFile,
    										$
    												.getJSON(jsonFile, function(data){ //alert(data)

    												})
    												.done(
    														function(
    																jsonObject,
    																textStatus) {
    			successCallBack(jsonObject);
    		})
    				.fail(
    														function(jqxhr,
    																settings,
    																exception) {
    															self
    																	._prepareErrorCallBack(
    																			'Error_106',
    									'Error while fetching config JSON from remote location . '
    																					+ JSON
    																							.stringify(error),
    									errorCallback);
    						});

    	}
    };
    $scope.getFromRemote = function(jsonFile, callmode, successCallBack,
    			errorCallback) {
    		var self = this;
    		$.ajax({
    			type : "GET",
    			url : rootConfig.contentAdminDownLoadURL + jsonFile,
    			dataType : "text",
    			success : function(jsonObject) {
    				successCallBack(jsonObject);

    			},
    			async : callmode,
    			error : function(error) {
    				self._prepareErrorCallBack('Error_106',
    						'Error while fetching config JSON from remote location . '
    								+ JSON.stringify(error), errorCallback);
    			}
    		});
    	};
    
    //isAppExpired - Verify whether a new version of app is available
    function isAppExpired(successcallback) {
        var configuration = JSON.parse(localStorage.getItem('configuration'));
        var appExpired = false;
        if (Number(configuration.appMajorVersion) < Number(rootConfig.majorVersion)) {
            appExpired = true;
        }
        else if (Number(configuration.appMajorVersion) == Number(rootConfig.majorVersion) && Number(configuration.appMinorVersion) < Number(rootConfig.minorVersion)) {
            appExpired = true;
        }
        if (appExpired) {
            rootConfig.minorVersion = configuration.appMinorVersion;
            rootConfig.majorVersion = configuration.appMajorVersion;
        }
        successcallback(appExpired);
    }

    function loadConfigfile(successCallBack) {
        if(rootConfig.isDeviceMobile) {
           LEDynamicUI.getUIJson('appconfig.json', false, function(jsonObject) {
               config = eval(jsonObject);
               $.extend(true, rootConfig, config);
               successCallBack();
           });
        }
        else {
            $scope.getFromRemote("appconfig.json", false,
            function(jsonObject) {
            	config = JSON.parse(jsonObject);
            	$.extend(true, rootConfig, config);
            	successCallBack();
            });
        }
    }

    $scope.openDownloadLocation = function() {
        window.open(rootConfig.updateDownloadUrl, '_system');
    }
    $scope.loadPolicyRenewalDetails = function() {
        if($scope.is7dayusFilter) {
            $location.path('/policyDueForRenewal/7days');
        }
        else if($scope.is30dayusFilter) {
            $location.path('/policyDueForRenewal/30days');
        }
        else if($scope.is60dayusFilter) {
            $location.path('/policyDueForRenewal/60days');
        }
    }
		
	$scope.eBusinessRexitNavigation = function()
	{
		var timeStamp = PersistenceMapping.getFormattedDate();
		var checkSum = CryptoJS.SHA512($rootScope.username+UserDetailsService.userDetilsModel.user.shaPassword+$rootScope.agentId+timeStamp).toString(CryptoJS.enc.Hex);
		var baseUrl = rootConfig.eBusinessRexitURL+'?';
		var cnlist_ind = "Y";
		var PMF;
		if(rootConfig.isDeviceMobile)
		{
			PMF = "M";
		}
		else{
			PMF = "P";
		}
		var params = "USERID="+UserDetailsService.userDetilsModel.user.userId+
					 "&ACCODE="+$rootScope.agentId+
					 "&PMF="+PMF+
					 "&Password="+UserDetailsService.userDetilsModel.user.shaPassword+
					 "&DateTimeStamp="+timeStamp+
					 "&Checksum="+checkSum+
					 "&CNLIST_IND="+cnlist_ind+
					 "&RETURNURL="+rootConfig.omniReturnURL;
		var url=baseUrl+params;
		if(rootConfig.isDeviceMobile)
		{
			var ref=window.open(url, '_blank','location=yes', 'toolbar=yes');
			ref.addEventListener('exit', 
							function(event) 
							{
								//$route.reload();
								$rootScope.$emit('mobilereAuthentication', { message: $scope.message });
							}
					); 
		}
		else
		{
			sessionStorage.setItem('reAuthentication',"enabled");
			var form = document.createElement('form');
            form.method = 'post';
            form.action = url;
            document.body.appendChild(form);
            form.submit();
		}				
	};
	
	$scope.paymentSubmissionNavigation = function()
	{	
		var timeStamp = PersistenceMapping.getFormattedDate();
		var checkSum = CryptoJS.SHA512($rootScope.username+UserDetailsService.userDetilsModel.user.shaPassword+$rootScope.agentId+timeStamp).toString(CryptoJS.enc.Hex);
		var baseUrl = rootConfig.paymentSubmissionRexitURL+'?';
		var PMF;
		var submissionInd = "Y";
		if(rootConfig.isDeviceMobile)
		{
			PMF = "M";
		}
		else{
			PMF = "P";
		}
		var params = "USERID="+UserDetailsService.userDetilsModel.user.userId+
					 "&ACCODE"+$rootScope.agentId+
					 "&PMF="+PMF+
					 "&Password="+UserDetailsService.userDetilsModel.user.shaPassword+
					 "&DateTimeStamp="+timeStamp+
					 "&Checksum="+checkSum+
					 "&SUBMISSION_IND="+submissionInd+
					 "&RETURNURL="+rootConfig.omniReturnURL; 
		var url=baseUrl+params;
		if(rootConfig.isDeviceMobile)
		{
			var ref=window.open(url, '_blank','location=yes', 'toolbar=yes');
			ref.addEventListener('exit', 
							function(event) 
							{
								//$route.reload();
								$rootScope.$emit('mobilereAuthentication', { message: $scope.message });
							}
					); 
		}
		else
		{
			sessionStorage.setItem('reAuthentication',"enabled");
			var form = document.createElement('form');
            form.method = 'post';
            form.action = url;
            document.body.appendChild(form);
            form.submit();
		}				
	};
	
	$scope.cbcReportNavigation = function()
	{	var timeStamp = PersistenceMapping.getFormattedDate();
		var checkSum = CryptoJS.SHA512($rootScope.username+UserDetailsService.userDetilsModel.user.shaPassword+$rootScope.agentId+timeStamp).toString(CryptoJS.enc.Hex);
		var baseUrl = rootConfig.cbcReportRexitURL+'?';
		var PMF;
		var cbcInd = "Y";
		if(rootConfig.isDeviceMobile)
		{
			PMF = "M";
		}
		else{
			PMF = "P";
		}
		var params ="USERID="+UserDetailsService.userDetilsModel.user.userId+
					"&ACCODE"+$rootScope.agentId+
					"&PMF="+PMF+
					"&Password="+UserDetailsService.userDetilsModel.user.shaPassword+
					"&DateTimeStamp="+timeStamp+
					"&Checksum="+checkSum+
					"&CBC_IND="+cbcInd+
					"&RETURNURL="+rootConfig.omniReturnURL;		
		var url=baseUrl+params;		
		if(rootConfig.isDeviceMobile)
		{
			var ref=window.open(url, '_blank','location=yes', 'toolbar=yes');
			ref.addEventListener('exit', 
							function(event) 
							{
								$rootScope.$emit('mobilereAuthentication', { message: $scope.message });
								//$route.reload();
							}
					); 
		}
		else
		{
			sessionStorage.setItem('reAuthentication',"enabled");
			var form = document.createElement('form');
            form.method = 'post';
            form.action = url;
            document.body.appendChild(form);
            form.submit();
		}				
	};
	
		$scope.navigatetoSalesApp = function(){
		localStorage.usr_Det = JSON.stringify(UserDetailsService.getUserDetailsModel());
		sessionStorage.fromApp = "AgencyPortal";
		sessionStorage.role = angular.copy($rootScope.role);
		window.location.href = rootConfig.salesAppLink;
	}; 
    
	
	
	
	$scope.callClientBirthday =function(){	
	             $location.path('/relationship');
	}
}]);
