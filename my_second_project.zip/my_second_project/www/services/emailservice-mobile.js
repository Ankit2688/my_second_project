var EmailServiceUtility;
(function() {
	EmailServiceUtility = {
			sendEmail : function(emailObject, successCallback, errorCallback) {
				var self = this;
				try {
				      window.plugins.email.open(emailObject.toMailIds, emailObject.ccMailIds, emailObject.bccMailIds, emailObject.mailSubject,
				    		 					emailObject.emailBody, emailObject.emailAttachments, emailObject.emailIsHtml,
				    		 					emailObject.openWithApp, null, null);
					  successCallback();
				   } catch (exception) {
						if (errorCallback && typeof errorCallback == "function") {
							errorCallback(exception);
						} else {
							self._errorHandler(exception);
						}
				}
		},
        attachPhoto : function(successCallback, errorCallback) {
        FileSelectUtility.copyFile('photolibrary',function(url)
        {                   
         var name=url.substr(url.lastIndexOf('/')+1);                    
         var file_Details=[];
         file_Details.push({"fileName":name,destFolder:"Uploads"});
         LEFileUtils.prototype.readFileAsBase64(file_Details,function(dataURL){
         successCallback(dataURL,name);
         },function(error){
         	errorCallback(error);
         }
        );},function(error){errorCallback(error);});},
		/*Default failure callback if the error callback is not specified*/
		_errorHandler : function(error) {
			console.log('Error : ' + error.message + ' (Code ' + error.code
					+ ')');
		}
	};
	return EmailServiceUtility;
})();