﻿var dataLookupServiceUtility;
(function() {
	dataLookupServiceUtility = {
		getLookUpData : function(transactionObj, successCallback,
				errorCallback, options, $http) {
			var dataLookupServiceUrl = rootConfig.serviceBaseUrl
					+ "codeLookUpService/getLookUpData";
			var requestInfo = Request();
			transactionDataObj = {};
			transactionDataObj.typeName = transactionObj.type;
			if (transactionObj.code) {
				transactionDataObj.code = transactionObj.code;
			}
			if (localStorage[rootConfig.appName+'_'+rootConfig.majorVersion+'.'+rootConfig.minorVersion+'_locale']) {
				locale = localStorage[rootConfig.appName+'_'+rootConfig.majorVersion+'.'+rootConfig.minorVersion+'_locale'].split("_")
				transactionDataObj.language = locale[0];
				transactionDataObj.country = locale[1];
			} else {
				transactionDataObj.language = "en";
				transactionDataObj.country = "US";
			}
			transactionObj = {};
			transactionObj.TransactionData = transactionDataObj;
			requestInfo.Request.RequestPayload.Transactions
					.push(transactionObj)

			var request = {
				method : 'POST',
				url : dataLookupServiceUrl,
				headers : {
					'Content-Type' : "application/json; charset=utf-8",
					"Token" : options.headers.Token
				},
				data : requestInfo
			}

			$http(request)
					.success(
							function(data, status, headers, config) {
								result = data.Response.ResponsePayload.Transactions[0].TransactionData.lookUps;
								successCallback(result);
							}).error(function(data, status, headers, config) {
						errorCallback(data, status);
					});
		}
	};
	return dataLookupServiceUtility;
})();