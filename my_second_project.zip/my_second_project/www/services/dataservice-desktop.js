﻿//Implementation for life engage service save
var DbOperationsUtility;
(function() {
	DbOperationsUtility = {
		saveTransactions : function(transactionObj, successCallback,
				errorCallback,options, $http) {
			var saveUrl = rootConfig.serviceBaseUrl+rootConfig.servicePath+"saveGoalService/saveGoal"//?COMPANY_ID=100&APP_ID=14";
			//var saveUrl = "https://ipegservices.cognizant.com/Proxy/proxyService/mservice/services/WebService/BusinessSetGoalServiceRequest";
			var requestInfo = Request();
			requestInfo.Request.RequestPayload.Transactions
					.push(transactionObj);
			jQuery.support.cors = true;
				var request = {
				method : 'POST',
				url : saveUrl,
				headers : {
					'Content-Type' : "application/json; charset=utf-8",
					"Token" : options.Token
				},
				data : requestInfo
			}

			$http(request)
					.success(
							function(data, status, headers, config) {
								if (data.Response.ResponsePayload.Transactions[0].StatusData.StatusCode == "100") {
									successCallback(data.Response.ResponsePayload.Transactions[0]);
								} else {
									errorCallback(data.Response.ResponsePayload.Transactions[0].StatusData.StatusMessage);
								}
							}).error(function(data, status, headers, config) {
						errorCallback(data, status, resources.errorMessage);
					});
		},
		
		saveObservations: function (transactionObj, successCallback, errorCallback, options, $http) {
	            //showHideLoadingImage(true, "Uploading documents,please wait.. ");
	          //  var saveUrl = rootConfig.serviceBaseUrl + "lifeEngageService/save";
	           // var saveUrl = "https://sit-lifeengage.cognizant.com/mli-mService-platform-ep/services/mService/save";
			var saveUrl = rootConfig.serviceBaseUrl +rootConfig.servicePath+ "services/UsageReportService"//?COMPANY_ID=100&APP_ID=48";
	            var requestInfo = Request();
	            requestInfo.Request.RequestPayload.Transactions.push(transactionObj)
	            jQuery.support.cors = true;
	            console.log("request..."+angular.toJson(requestInfo));	            
				
				var request = {
					method : 'POST',
					url : saveUrl,
					headers : {
						'Content-Type' : "application/json; charset=utf-8",
						"Token" : options.Token
					},
					data : angular.toJson(requestInfo)
			    }
				
				$http(request).success(function(data, status, headers, config) {
				                if (status == 200){
								   successCallback(data);
								} else {
								   errorCallback(data, status);
								}								
								/* if (data.Response.ResponsePayload.Transactions[0].StatusData.StatusCode == "100") {
									successCallback(data.Response.ResponsePayload.Transactions[0]);
								} else {
									errorCallback(data.Response.ResponsePayload.Transactions[0].StatusData.StatusMessage);
								} */
							}).error(function(data, status, headers, config) {
						errorCallback(data, status, resources.saveTransactionsError);
					});	            
	        },
		searchTransactions : function(transactionObj, successCallback,
				errorCallback, options, $http) {
			var getUrl = rootConfig.serviceBaseUrl+rootConfig.servicePath;
			var requestInfo = Request();
			
			switch (transactionObj.Type) {

			case "MyEarnings":
				if (transactionObj.TransactionData.searchCriteria.type == "Policy Level Commissions") {
					getUrl = getUrl + "services/PolicyLevelCommissionService"//?COMPANY_ID=100&APP_ID=42";//"PolicyLevelCommissionRequest";
				}else if (transactionObj.TransactionData.searchCriteria.type == "ACSStatements") {
					getUrl = getUrl + "services/ACSService"//?COMPANY_ID=100&APP_ID=42";//"ACSServiceRequest";
				} else if (transactionObj.TransactionData.searchCriteria.type == "IncentiveStatements") {

					getUrl = getUrl + "services/IncentiveServiceRequest"//?COMPANY_ID=100&APP_ID=14";//"IncentiveServiceRequest";
				} else if (transactionObj.TransactionData.searchCriteria.type == "TDS Statements") {
					getUrl = getUrl + "services/TDSStatementService"//?COMPANY_ID=100&APP_ID=14";//"TDSStatementRequest";
				}
				break;
			case "PolicySearch":
				transactionObj.Type = "PolicyDetails";
				getUrl = getUrl + "services/PolicySearchRequest"//?COMPANY_ID=100&APP_ID=16";//"PolicySearchRequest";
				break;
			case "ProposalSearch":
				transactionObj.Type = "ProposalDetails";
				getUrl = getUrl + "services/ProposalSearchService"//?COMPANY_ID=100&APP_ID=14";//"ProposalSearchRequest";
				break;
			case "AgentCode":
				transactionObj.Type = "AgentCode";
				getUrl = getUrl + "userService/getAssociateId"//?COMPANY_ID=100&APP_ID=14";//"ProposalSearchRequest";
				break;

			}
			requestInfo.Request.RequestPayload.Transactions.push(transactionObj);
			
			var request = {
					method : 'POST',
					url : getUrl,
					headers : {
						'Content-Type' : "application/json; charset=utf-8",
						"Token" : options.Token
					},
					data : angular.toJson(requestInfo)
			    }
				
				$http(request).success(function(data, status, headers, config) {
								if (data.Response.ResponsePayload.Transactions != null) {
									successCallback(data.Response.ResponsePayload.Transactions);
								} else {
									successCallback(data.Response.ResponsePayload);
								}
							}).error(function(data, status, headers, config) {
						errorCallback(data, status, resources.saveTransactionsError);
					});	
		},
		getTransactions : function(transactionObj, successCallback,
				errorCallback, options, $http) {
			try {
				var getUrl = rootConfig.serviceBaseUrl+rootConfig.servicePath;

				var requestInfo = Request();
                
				// switch -- check the type and add the urls
				switch (transactionObj.Type) {
				
					case "Alerts":
						getUrl = getUrl +"services/ServiceAlert"//?COMPANY_ID=100&APP_ID=14";// "AlertServiceRequest";
						
						break;
				    case "MyBusiness":
					getUrl = getUrl +"services/MyBusiness"//?COMPANY_ID=100&APP_ID=14";// "MyBusinessServiceRequest";
						break;
				 case "MyGoals"	:
					getUrl = getUrl + "services/MyBusinessGetGoal"//?COMPANY_ID=100&APP_ID=14";//add set goal request
						break;
					case "MyEarnings":
					 
						
						getUrl=getUrl+"services/CompensationSchemeService"//?COMPANY_ID=100&APP_ID=14";//"CompensationSchemeRequest";
					    
				    
						break;
					case "PotentialToEarn"	:
						getUrl = getUrl + "services/PotentialToEarn"//?COMPANY_ID=100&APP_ID=14";//PotentialToEarnRequest";
						break;
					case "MyPerformanceOverview" :
						getUrl = getUrl + "services/MyPerformanceOverviewService"//?COMPANY_ID=100&APP_ID=14";//"MyPerformanceOverviewRequest";
						break;
					case "LeadsDashboard"	:
						getUrl = getUrl +"services/LeadsDashboardService"//?COMPANY_ID=100&APP_ID=14"; //"LeadsDashboardRequest";
						break;
				   case "RecruitmentDashboard"	:
						transactionObj.Type = "RecruitmentDashboard";
						getUrl = getUrl + "services/RecruitmentDashboardService"//?COMPANY_ID=100&APP_ID=14";//;"RecruitmentDashboardRequest";
						break;
					case "RnRSchemes"	:
						transactionObj.Type = "RnRSchemes";
						getUrl = getUrl + "services/RandRService"//?COMPANY_ID=100&APP_ID=14";//"RAndRRequest";
					break;
					case "PremiumCalendar"	:
						transactionObj.Type = "PremiumCalendar";
						getUrl = getUrl + "services/PremiumCalendarService"//?COMPANY_ID=100&APP_ID=14";//"RAndRRequest";
					break;
					case "HierarchyDetails"	:
					
						getUrl = getUrl + "services/HierarchyService"//?COMPANY_ID=100&APP_ID=14";//"HierarchyRequest";
						
					break;
					case "Product Name"	:					
						getUrl = getUrl + "services/ProductNameService"//?COMPANY_ID=100&APP_ID=17";//"ProductNameServiceRequest";//"HierarchyService?COMPANY_ID=100&APP_ID=14";//
						
					break;
					case "Plan Type":
				       getUrl = getUrl +"services/PlanTypeService"//?COMPANY_ID=100&APP_ID=17"; //"PlanTypeServiceRequest";//"HierarchyService?COMPANY_ID=100&APP_ID=14";//
						
					break;
					case "Proposal Status":					
						getUrl = getUrl + "services/ProposalStatusService"//?COMPANY_ID=100&APP_ID=17";//"ProposalStatusServiceRequest";//"HierarchyService?COMPANY_ID=100&APP_ID=14";//
						
					break;
					case "COI-NominatorName":					
						getUrl = getUrl + "services/COINominatorNameService"//?COMPANY_ID=100&APP_ID=17";//"COINominatorNameServiceRequest";//"HierarchyService?COMPANY_ID=100&APP_ID=14";//
						
					break;
					case "Premium Frequency":					
						getUrl = getUrl + "services/PremiumFrequencyService"//?COMPANY_ID=100&APP_ID=20";//"COINominatorNameServiceRequest";//"HierarchyService?COMPANY_ID=100&APP_ID=14";//
						
					break;
					case "Policy Status":					
						getUrl = getUrl + "services/PolicyStatusService"//?COMPANY_ID=100&APP_ID=20";//"COINominatorNameServiceRequest";//"HierarchyService?COMPANY_ID=100&APP_ID=14";//
						
					break;
					case "LoginPopUp":					
						getUrl = getUrl + "services/LognPopupService"//?COMPANY_ID=100&APP_ID=20";//"COINominatorNameServiceRequest";//"HierarchyService?COMPANY_ID=100&APP_ID=14";//
						
					break;
					case "ADMDashboard":					
						getUrl = getUrl + "services/ADMDashboardServiceRequest";//"ADMDashBoard?COMPANY_ID=100&APP_ID=35";//for eserve
					break;
				
			} 

				requestInfo.Request.RequestPayload.Transactions
						.push(transactionObj);
				jQuery.support.cors = true;
				
				var request = {
					method : 'POST',
					url : getUrl,
					headers : {
						'Content-Type' : "application/json; charset=utf-8",
						"Token" : options.Token
					},
					data : requestInfo
			    }
				
				$http(request).success(function(data, status, headers, config) {
								if (data.Response.ResponsePayload.Transactions != null) {
					                 successCallback(data.Response.ResponsePayload.Transactions);
				                } else {
					                 successCallback(data.Response.ResponsePayload);
								}
							}).error(function(data, status, headers, config) {
						errorCallback(data, status, resources.errorMessage);
					});
				

				/* callAjaxPost(getUrl, true, requestInfo, successCallback,
						errorCallback); */
			} catch (exception) {
				alert("error in  getTransactions: " + angular.toJson(exception)
						+ " :error in  getTransactions");
				errorCallback(resources.errorMessage);
			}
		}

	};
	return DbOperationsUtility;
})();

// Generic function for calling Ajax post
function callAjaxPost(url, isAsync, data, successCallback, errorCallback) {
	
	$.ajax({
		type : "POST",
		crossDomain : true,
		url : url,
		data : angular.toJson(data),
		contentType : "application/json;",
		dataType : "json",
		success : function(data, status) {

			try{
				if (data.Response.ResponsePayload.Transactions != null) {
					successCallback(data.Response.ResponsePayload.Transactions);
				} else
					successCallback(data.Response.ResponsePayload);
			}
			catch(exception){
				errorCallback(exception);
			}
		},
		error : function(data, status) {
			
			errorCallback("Error in ajax call");
		}
	});
}
