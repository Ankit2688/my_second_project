﻿//Implementation for life engage authService
var authServiceUtility;
(function() {
	authServiceUtility = {
		login : function(user, successCallback, errorCallback, $http) {
			jQuery.support.cors = true;
			var username = user.username;
			var password = user.password;			
			var loginServiceUrl = rootConfig.loginUrl;		
			
			var req = {
				method : 'POST',
				url : loginServiceUrl,
				headers : {
					'Content-Type' : "application/x-www-form-urlencoded; charset=utf-8"
				},
				transformRequest : function(obj) {
					var str = [];
					for ( var p in obj)
						str.push(encodeURIComponent(p) + "="
								+ encodeURIComponent(obj[p]));
					return str.join("&");
				},
				data : {
					username : username,
                    password : password,
                    j_auth_token : "on",
                    customerType : "AGENT"
				}
			}
			$http(req).success(function(data, status, headers, config) {
				successCallback(data,headers("TOKEN"));
			}).error(function(data, status) {
				errorCallback(data, status);
			});		
		},
		getUserDetails : function(user, successCallback, errorCallback) {

			jQuery.support.cors = true;
			var username = user.username;
			var data = {"information":{"display_name":username,"email_id":"","first_name":"Tom","last_name":"","app_role":"","member_of":["OrgPublicGroup"],"agent_cd":"123456","designation":"ADM"},"status":"SUCCESS"};
            successCallback(data);
		},

		getHierarchyDetails : function(transObj, successCallback, errorCallback, options, $http) {
			// jQuery.support.cors = true;
			// var username=user.username;

			var requestInfo = Request();
			requestInfo.Request.RequestPayload.Transactions.push(transObj);
			var url = rootConfig.serviceBaseUrl+rootConfig.servicePath+ "services/HierarchyService"//?COMPANY_ID=100&APP_ID=14";
			//;//"HierarchyRequest";
			
			
			var request = {
					method : 'POST',
					url : url,
					headers : {
						'Content-Type' : "application/json; charset=utf-8",
						"Token" : options.token
					},
					data : requestInfo
			    }
				
				$http(request).success(function(data, status, headers, config) {
								if (data.Response.ResponsePayload.Transactions != null) {
						             successCallback(data.Response.ResponsePayload.Transactions);
					            } else {
					                 successCallback(data.Response.ResponsePayload);
								}
							}).error(function(data, status, headers, config) {
						errorCallback(data, status, resources.errorMessage);
					});
			
			
			
			/*
			$.ajax({
				type : "POST",
				crossDomain : true,
				url : url,
				data : angular.toJson(requestInfo),
				contentType : "application/json;",
				dataType : "json",
				success : function(data, status) {
					if (data.Response.ResponsePayload.Transactions != null) {
						successCallback(data.Response.ResponsePayload.Transactions);
					} else
						successCallback(data.Response.ResponsePayload);
				},
				error : function(data, status) {
					errorCallback("Error in ajax call");
				}
			}); */

		},
		getSyncDriveAppRole: function(user,successCallback,errorCallback){
			var url =rootConfig.authenticationServiceBaseUrl+"authenticate?COMPANY_ID=100&APP_ID=41";
			var data ={"userName":user.username ,"password":user.password};
	$.ajax({
					type : "POST",
					headers : {
					"Authenticate|nwsAuthToken":"e03364fd-a8c6-7878-3d44-cff2a9d8e333"
				 },
					data : angular.toJson(data),
					crossDomain : true,
					async : true,
					timeout: 60000,
					url : url,
					contentType : "application/json",
					success : function(response) {
						if(response.username =='tom'){
							data = {"information":{"display_name":"Tom","email_id":"","first_name":"Tom","last_name":"","app_role":"","member_of":["OrgPublicGroup"],"agent_cd":"123456","designation":"XAG"},"status":"SUCCESS"};
							successCallback(data);
							}
                                                       else{
                                                              errorCallback();
							}
					},
					error : function(data, status) {
						if(data.username =='tom'){
							data = {"information":{"display_name":"Tom","email_id":"","first_name":"Tom","last_name":"","app_role":"","member_of":["OrgPublicGroup"],"agent_cd":"123456","designation":"XAG"},"status":"SUCCESS"};
							successCallback(data);
							}
							else{
								errorCallback();
							}
					}
				});
			
			
			
		},
		
		logout : function(successCallback, errorCallback) {
			//once the authentication service is up, remove the hardcoding
			//            $http.post('/logout').success(function(){
			//                success();
			//            }).error(error);
			successCallback();
		},
		authorize : function(accessLevel, role) {
			return false;
		},
		isLoggedIn : function($rootScope) {
			if ($rootScope.isAuthenticated)
				return true;
			else
				return false;
		}
	};

	return authServiceUtility;
})(); //Implementation for life engage authService
