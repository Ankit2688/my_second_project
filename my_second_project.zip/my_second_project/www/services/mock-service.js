
//$.mockjax({url:"hello.php",proxy:'sample.json',responseTime:0,dataType:'json'});

$.mockjax(function(settings) {
	
////////////////console.log("inside mock service");
	if ( settings.url == 'eServe/getTransactions' ) {
		var data  = JSON.parse(settings.data);
		var type = data.Request.RequestPayload.Transactions[0].Type;
		if(type=="Alerts")
		{
			return {dataType: 'json',proxy: 'mockdata/mServiceAlertsResponse.json'};
		}
		else if(type =="HierarchyDetails")
		{
			return {dataType: 'json',proxy: 'mockdata/mServiceHierarchyResponse.json'};
		}
		else if(type =="LoginPopUp")
		{
			return {dataType: 'json',proxy: 'mockdata/mServiceLoginPopupResponse.json'};
		}
		else if(type =="DashBoard")
		{
			return {dataType: 'json',proxy: 'mockdata/mServicePotentialToEarnResponse.json'};
		}else if(type =="AgentDashboard")
		{
			return {dataType: 'json',proxy: 'mockdata/mServiceGLIDashboard.json'};
		}else if(type =="MyPerformanceOverview")
		{
			
			return {dataType: 'json',proxy: 'mockdata/mServiceMyPerformanceOverviewResponse.json'};
		}
		else if(type =="MyBusiness")
		{
			return {dataType: 'json',proxy: 'mockdata/mServiceMyBusinessResponse.json'};
		}
		else if(type =="MyGoals")
		{
			return {dataType: 'json',proxy: 'mockdata/mServiceMyBusinessGetGoalResponse.json'};
		}
		else if (type =="MyEarnings")
		{
			return {dataType: 'json',proxy :'mockdata/mServiceMyEarningsResponse.json'};
		}
		else if (type =="PotentialToEarn")
		{
			return {dataType: 'json',proxy :'mockdata/mServicePotentialToEarnResponse.json'};
		}
		
		else if (type =="Product Name")
		{
			return {dataType: 'json',proxy :'mockdata/mServiceProductNameResponse.json'};
		}
		else if (type =="Plan Type")
		{
			return {dataType: 'json',proxy :'mockdata/mServicePlanTypeResponse.json'};
		}
		else if (type =="Proposal Status")
		{
			return {dataType: 'json',proxy :'mockdata/mServiceProposalStatusResponse.json'};
		}
		else if (type =="LeadsDashboard")
		{
			
			return {dataType: 'json',proxy :'mockdata/mServiceLeadsDashboardResponse.json'};
		}
		else if (type =="PolicySearch")
		{
			
			return {dataType: 'json',proxy :'mockdata/mServicePolicySearchResponse.json'};
		}
		else if (type =="ProposalSearch")
		{
			
			return {dataType: 'json',proxy :'mockdata/mServiceProposalSearchResponse.json'};
		}
		else if (type =="RecruitmentDashboard")
		{
			
			return {dataType: 'json',proxy :'mockdata/mServiceRecruitmentDashboardResponse.json'};
		}
		else if (type =="SetGoals")
		{
			
			return {dataType: 'json',proxy :'mockdata/mServiceMyBusinessSetGoalResponse.json'};
		}
		else if (type == "COINominatorName")
		{
			return {
				dataType : 'json',
				proxy : 'mockdata/mServiceCOINominatorNameResponse.json'
			};
		}
		else if (type =="PremiumCalendar")
		{
			
			return {dataType: 'json',proxy :'mockdata/mServicePremiumCalendarResponse.json'};
		}
		else if (type =="RnRSchemes")
		{
			
			return {dataType: 'json',proxy :'mockdata/mServiceRnRResponse.json'};
		}else if (type =="ADMDashboard")
		{
			
			return {dataType: 'json',proxy :'mockdata/mServiceADMDashboard.json'};
		}else
		{
			return {dataType: 'json',proxy: 'mockdata/mServiceAlertsResponse.json'};
		}
	}
	else if( settings.url == 'mService/postTransactions' )  
	{
		return true;
	}
	else if( settings.url == 'mService/loginRequests' )  
	{
		var data  = settings.data;
		if(data.j_username == "tom" && data.j_password == "cts"){
			return true;	
		}
		else{
			return false;
		}
	}
	else if( settings.url == 'mService/231434' ){
		return {dataType: 'json',proxy: 'mockdata/mServiceBusinessEmp1.json'};
		
	}
	else if( settings.url == 'mService/231435' ){
		return {dataType: 'json',proxy: 'mockdata/mServiceBusinessEmp2.json'};
		
	}
	else if ( settings.url == 'https://ipegservices.cognizant.com/Proxy/proxyService/mserviceuat/services/WebService/ProductName' ) {
		return {dataType: 'json',proxy :'mockdata/mServiceProductNameResponse.json'};
		
	}
	else if ( settings.url == 'https://ipegservices.cognizant.com/Proxy/proxyService/mserviceuat/services/WebService/PlanType' ) {
		return {dataType: 'json',proxy :'mockdata/mServicePlanTypeResponse.json'};
		
	}
	else if ( settings.url == 'https://ipegservices.cognizant.com/Proxy/proxyService/mserviceuat/services/WebService/ProposalStatus' ) {
		return {dataType: 'json',proxy :'mockdata/mServiceProposalStatusResponse.json'};
		
	}
	else if ( settings.url == 'https://ipegservices.cognizant.com/Proxy/proxyService/mservice/services/WebService/BusinessSetGoalServiceRequest' ) {
		return {dataType: 'json',proxy: 'mockdata/mServiceMyBusinessSetGoalResponse.json'};
		
	}
	else{
		return false;
	}
	
});
