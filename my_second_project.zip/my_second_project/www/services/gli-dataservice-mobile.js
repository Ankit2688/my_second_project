/*
*GLI specific service change
*/
(function() {
    DbOperationsUtility['searchTransactions'] = function(transactionObj, successCallback,
   		errorCallback,header) {
		var token = header.Token;
   		var getUrl = rootConfig.serviceBaseUrl+rootConfig.servicePath;
   		var requestInfo = Request();
   	switch (transactionObj.Type) {
   	case "premiumCalendar":
   		getUrl = getUrl + "policyService/getPremiumCalendar";
   		break;
   	case "CreatePassword":
       		getUrl = getUrl + "userService/createPassword";
       		break;
   	case "CreateSecurityQuestion":
        getUrl = getUrl + "userService/createSecurityOptions";
        break;
	case "AgentDashboard":
   		getUrl = getUrl + "policyService/retrieveAgentDashboard";
   		break;
	case "clientInformation":
		getUrl = getUrl + "userService/retrieveClientInformation";
   		break;
   	case "policyDueRenewalSearch":
   		getUrl = getUrl + "policyService/policiesRemarkHistoryRenewalStatusSearch";
   		break;
   	case "clientLoggedSearch":
   		getUrl = getUrl + "policyService/getClaimsLogged";
   		break;
   	case "actionTaken":
   		getUrl = getUrl + "policyService/updateRenewalRemarksInformation";
   		break;
   	case "majorclass":
   		getUrl = getUrl + "policyService/retrieveMasterData";
   		break;
	case "contracttype":
   		getUrl = getUrl + "policyService/retrieveMasterData";
   		break;
	case "transactiontype":
   		getUrl = getUrl + "policyService/retrieveMasterData";
   		break;
	case "AgentCode":
		getUrl = getUrl + "userService/getAssociateId";
		break;
	case "BranchCode":
        getUrl = getUrl + "userService/getAllBranchDetails ";
        break;
	case "SOA":
		getUrl = getUrl + "policyService/getSOAList";
		break;
	case "ClaimsAlert":
   		getUrl = getUrl + "policyService/claimsAlert";
   		break;
   	case "claimInquiry":
        getUrl = getUrl + "policyService/clientLoggedSearch";
        break;
   	case "policySearch":
    	getUrl = getUrl + "policyService/policySearch";
    	break;
   	case "customerStatus":
    	getUrl = getUrl + "policyService/customerStatus";
    	break;
    case "claimstatus":
        getUrl = getUrl + "policyService/retrieveMasterData";
        break;
	case "RenewalListing":
    	getUrl = getUrl + "policyService/renewalListing";
    	break;
	case "Performance":
    	getUrl = getUrl + "policyService/agentPerformance";
    	break;
	case "CPDHoursTracking":
    	getUrl = getUrl + "policyService/getAgentCpdHours";
    	break;
	case "CPDTrainingCalendar":
    	getUrl = getUrl + "policyService/agentCPDTrainingCalendar";
    	break;
    case "relationshipSearch":
		getUrl = getUrl + "policyService/getClientBirthdayInfo";
		break;
	case "AgentDetails":
		getUrl = getUrl + "policyService/getAgentDetails";
		break;
	case "getContractTypesByMajorClass":
		getUrl = getUrl + "policyService/getContractTypesByMajorClass";
		break;
    case "Change Password":
		getUrl = getUrl + "userService/updatePassword";
		break;
	case "retrieveCpdBranchList":
        getUrl = getUrl + "policyService/retrieveCpdBranchList";
		break;        
	default:break;
   	}
   	requestInfo.Request.RequestPayload.Transactions.push(transactionObj);
   	jQuery.support.cors = true;
   	$.ajax({
   				type : "POST",
   				crossDomain : true,
   				url : getUrl,
   				headers: {
   					"Token": token,
   					"SOURCE": 200
   			    },
   				data : angular.toJson(requestInfo),
   				contentType : "application/json; charset=utf-8",
   				dataType : "json",
   				success : function(data, status) {
   					try{
   						if ((data.STATUS)&& (data.STATUS == 'E')) {

   						    errorCallback("Error in ajax call"+data.STATUS);
   						}
   						else
   						{
   						    if (data.Response.ResponsePayload.Transactions !== null)
   						    {
   							successCallback(data.Response.ResponsePayload.Transactions);
   						    }
   						    else{
								successCallback(data.Response.ResponsePayload);
							}
   						}
   					}
   				catch(error){
   				var data =
   				errorCallback("Error in ajax call"+error);
   				}
   				},
   				error : function(data, status) {
   						errorCallback(data.status);
   				}
   			});
   };
   DbOperationsUtility['getTransactions'] = function(transactionObj, successCallback,
					errorCallback) {
	var getUrl = rootConfig.serviceBaseUrl+rootConfig.servicePath;
	var requestInfo = Request();
	switch (transactionObj.Type) {
	case "UserDetails":
    	getUrl = getUrl + "userService/register";
    	break;
    case "ValidateSecretQuestion":
    	getUrl = getUrl + "userService/validateSecurityQuestion";
    	break;
    case "RetrieveSecretQuestion":
    	getUrl = getUrl + "userService/getSecurityQuestion";
    	break;
	default:break;
	}
	requestInfo.Request.RequestPayload.Transactions.push(transactionObj);
	jQuery.support.cors = true;
	$.ajax({
				type : "POST",
				crossDomain : true,
				url : getUrl,
				headers: {
					"SOURCE": 200
			    },
				data : angular.toJson(requestInfo),
				contentType : "application/json; charset=utf-8",
				dataType : "json",
				success : function(data, status) {
					try{
						if ((data.STATUS)&& (data.STATUS == 'E')) {

						    errorCallback("Error in ajax call"+data.STATUS);
						}
						else
						{
						    if (data.Response.ResponsePayload.Transactions !== null)
						    {
							successCallback(data.Response.ResponsePayload.Transactions);
						    }
						    else{
								successCallback(data.Response.ResponsePayload);
							}
						}
					}
				catch(error){
				var data =
				errorCallback("Error in ajax call"+error);
				}
				},
				error : function(data, status) {
						errorCallback(data.status);
				}
			});
};
DbOperationsUtility['saveObservations'] = function (transactionObj, successCallback, errorCallback, options, $http) {
	            //showHideLoadingImage(true, "Uploading documents,please wait.. ");
	          //  var saveUrl = rootConfig.serviceBaseUrl + "lifeEngageService/save";
	           // var saveUrl = "https://sit-lifeengage.cognizant.com/mli-mService-platform-ep/services/mService/save";
			var saveUrl = rootConfig.serviceBaseUrl + "SyncService/saveObservation"//?COMPANY_ID=100&APP_ID=48";
	            var requestInfo = Request();
				var userDetilsModel = JSON.parse(sessionStorage.userDetails);
	            requestInfo.Request.RequestPayload.Transactions.push(transactionObj)
	            jQuery.support.cors = true;
	            console.log("request..."+angular.toJson(requestInfo));

				var request = {
					method : 'POST',
					url : saveUrl,
					headers : {
						'Content-Type' : "application/json; charset=utf-8",
						"Token" : userDetilsModel.options.headers.Token
					},
					data : angular.toJson(requestInfo)
			    }

				$http(request).success(function(data, status, headers, config) {
				                if (status == 200){
								   successCallback(data);
								} else {
								   errorCallback(data, status);
								}
								/* if (data.Response.ResponsePayload.Transactions[0].StatusData.StatusCode == "100") {
									successCallback(data.Response.ResponsePayload.Transactions[0]);
								} else {
									errorCallback(data.Response.ResponsePayload.Transactions[0].StatusData.StatusMessage);
								} */
							}).error(function(data, status, headers, config) {
						errorCallback(data, status, resources.saveTransactionsError);
					});
	        };

    var _dbOperations = {
		_db : null,
		_dbInit : function(cb) {
			var self = this;
			self._db = window.sqlitePlugin.openDatabase("eServiceDB","1.0", "eServiceDB", -1,function(db){
            self._db = db;
            var tblTransactionQuery = "CREATE TABLE IF NOT EXISTS Transactions (Id INTEGER PRIMARY KEY ,Key1 TEXT NOT NULL,Key2 TEXT NOT NULL,Key3 TEXT NOT NULL,Key4 TEXT,Key5 TEXT,Key6 TEXT,Key7 TEXT,Key8 TEXT,Key9 TEXT,Key10 TEXT,Type TEXT,TransactionData TEXT, Key11 text, Key12  text, TransTrackingID text, agentId text,Key13 TEXT,Key14 TEXT,Key15 TEXT,Key16 TEXT,Key17 TEXT,Key18 TEXT,Key19 TEXT,Key20 TEXT,Key21 TEXT,Key22 TEXT,Key23 TEXT,Key24 TEXT,Key25 TEXT,Key26 TEXT,Key27 TEXT,Key28 TEXT,Key29 TEXT,Key30 TEXT)"
			self._executeSql(tblTransactionQuery);
			var tblSyncStatusQuery = "CREATE TABLE IF NOT EXISTS SyncStatus (Id INTEGER PRIMARY KEY,RecordId INTEGER,SynAttemptTS TEXT,SyncResponseStatus TEXT,SyncResponseStatusDesc TEXT,SyncResponseTS TEXT)";
			self._executeSql(tblSyncStatusQuery);
			var tblAgentQuery = "CREATE TABLE IF NOT EXISTS AGENT (Id INTEGER PRIMARY KEY,agentCode TEXT,agentDesc TEXT,agentName TEXT,designation TEXT,userId TEXT,employeeType TEXT,supervisorCode TEXT,office TEXT,unit TEXT,agentGroup TEXT,yearsofExperience TEXT,businessSourced TEXT,customerServicing TEXT,licenseNumber TEXT,agentLicensestartdate TEXT,agentLicenseExpDate TEXT,emailId TEXT,mobileNumber TEXT,channelId TEXT)";
            self._executeSql(tblAgentQuery);
	        self._createDBSync();
	        cb();
	        });
		},
        _getIdExitingInDB: function (tableName, idName, listIdToCheck,
            successCallback, errorCallback) {
            if (listIdToCheck.length === 0) {
                successCallback([]);
                return;
            }
            var self = this;
            var SQL = 'SELECT ' + idName + ' FROM ' + tableName + ' WHERE ' + idName + ' IN ("' + self._arrayToString(listIdToCheck, '","') + '")';
            self._executeSql(SQL, function (ids) {
                var data = _dbOperations._getRecordsArray(ids);
                var idsInDb = [];
                for (var i = 0; i < data.length; ++i) {
                    idsInDb[data[i][idName]] = true;
                }
                successCallback(idsInDb);
            }, errorCallback);
        },
        _syncNow: function (type, progressIndicator, successCallback,
                errorCallback,saveBandwidth,options) {
                DBSYNC.syncNow(type, progressIndicator, function (result) {
                    if (result.syncOK === true) {
                        //Synchronized successfully
                                               successCallback(result);
                    }
                }, errorCallback,saveBandwidth,options);
            },
        _refreshNow: function (transObj, progressIndicator, successCallback,errorCallback,options) {
            DBSYNC.refreshNow(transObj, progressIndicator, function (response) {
                successCallback(response);
            },errorCallback,options);
        },
        _createDBSync: function () {
            var self = this;
            var saveUrl = rootConfig.serviceBaseUrl+rootConfig.servicePath+ "lifeEngageService/save";
            TABLES_TO_SYNC = [{
                tableName: 'Transactions',
                idName: 'Id'
            }];
            var syncInfo;
            DBSYNC.initSync(TABLES_TO_SYNC, self._db, {
            	  UserName: "agent name",
                  CreationDate: "09-25-2013",
                  CreationTime: "12:15:54-04:00",
                  SourceInfoName: "tablet",
                  RequestorToken: "",
                  UserEmail: "test@gmail.com",
                  LastSyncDateTime: "09-25-2013 23:15:45"
            }, saveUrl, function () {
            });
        },
		_closeDB : function(dbName, successCallback, errorCallback) {
			try {
				if (self._db != null) {
					self._db.close(dbName);
					if (successCallback && typeof successCallback == "function") {
						successCallback();
					} else {
						self._defaultCallBack();
					}
				}
			} catch (e) {
				errorCallback(e);
			}
		},
		_executeSql : function(sql, successCallback, errorCallback) {
			var self = this;
				try {
				if (self._db == null) {
					self._dbInit(function(){
                        self._getTransactionAndExecuteSql(sql, successCallback, errorCallback);
                    });
                }else{
                    self._getTransactionAndExecuteSql(sql, successCallback, errorCallback);
                }
            } catch (e) {
                errorCallback(e);
            }
        },
		_getTransactionAndExecuteSql : function(sql, successCallback, errorCallback){
            var self = this;
            self._db.transaction(function(tx) {
                tx.executeSql(sql, [], function(tx, results) {
                    if (successCallback && typeof successCallback == "function") {
                        successCallback(results);
                    } else {
                        self._defaultCallBack(tx, results);
                    }
                }, function(tx, e) {
                    if (errorCallback && typeof errorCallback == "function") {
                        errorCallback(e);
                    } else {
                        self._errorHandler(tx, results);
                    }
                });
            });
        },
        _buildInsertScript : function(tableName, trasactionData) {
			var members = this._getAttributesList(trasactionData);
			var values = this._getMembersValue(trasactionData, members);
			if (members.length === 0) {
				throw 'buildInsertSQL : Error, try to insert an empty object in the table '
						+ tableName;
			}
			var sql = "INSERT INTO " + tableName + " (";
			sql += this._arrayToString(members, ',');
			sql += ") VALUES (";
			sql += this._arrayToString(values, ',');
			sql += ")";
			return sql;
		},
			_buildInsertOrUpdateScript: function(tableName, columnName, transactionData) {
            var members = this._getAttributesList(transactionData);
            var values = this._getMembersValue(transactionData, members);
            if (members.length === 0) {
                throw 'buildInsertSQL : Error, try to insert an empty object in the table ' + tableName;
            }
            var sql = "INSERT OR REPLACE INTO " + tableName + " (ID, ";
            sql += this._arrayToString(members, ',');
            sql += ") VALUES (";
            sql += "(SELECT ID FROM " + tableName + "  WHERE  " + columnName + "='" + transactionData[columnName] + "'),";
            sql += this._arrayToString(values, ',');
            sql += ")";
            console.log("_buildInsertOrUpdateScript" + sql);
            return sql;

        },
		_buildUpdateScript : function(tableName, trasactionData) {
			var self = this;
			var sql = "UPDATE " + tableName + " SET ";
			var members = self._getAttributesList(trasactionData);
			if (members.length === 0) {
				throw 'buildUpdateSQL : Error, try to insert an empty object in the table '
						+ tableName;
			}
			var values = self._getMembersValue(trasactionData, members);
			var memLength = members.length;
			for ( var i = 0; i < memLength; i++) {
				sql += members[i] + " = " + values[i];
				if (i < memLength - 1) {
					sql += ', ';
				}
			}
			return sql;
		},
		_buildFetchScript : function(selectCol, tableName, dataObj) {
			var self = this;
			var sql = "SELECT " + selectCol + " FROM " + tableName;
			if (!jQuery.isEmptyObject(dataObj)) {
				sql += " WHERE ";
				var members = self._getAttributesList(dataObj);
				if (members.length === 0) {
					throw 'buildUpdateSQL : Error, try to insert an empty object in the table '
							+ tableName;
				}
				var values = self._getMembersValue(dataObj, members);
				var memLength = members.length;
				for (var i = 0; i < memLength; i++) {
                                         if(members[i]=="filter"){
                                                sql +=dataObj.filter;
                                         }else{
                                                sql += members[i] + " = " + values[i];
                                         }
                                         if (i < memLength - 1) {
                                                sql += " AND ";
                                         }
                                  }
			}
			return sql;
		},
		_buildDeleteScript : function(tableName, whereClause) {
			var self = this;
			var sql = 'DELETE FROM ' + tableName + ' WHERE ' + whereClause;
			return sql;
		},
		_getRecordsArray : function(results) {
			var resultsArray = [];
			if (results.rows.length == 0) {
			} else {
				for ( var i = 0; i < results.rows.length; i++) {
					resultsArray.push(results.rows.item(i));
				}
			}
			return resultsArray;
		},
		_getMembersValue : function(obj, members) {
			var valueArray = [];
			for ( var i = 0; i < members.length; i++) {
				if (members[i].toUpperCase() == "ID") {
					valueArray.push(obj[members[i]]);
				} else if (members[i].toUpperCase() == "DOCUMENTOBJECT") {
					valueArray
							.push("'" + JSON.stringify(obj[members[i]]) + "'");
				} else {
					valueArray.push("'" + obj[members[i]] + "'");
				}
			}
			return valueArray;
		},
		_getAttributesList : function(obj) {
			var memberArray = [];
			for ( var elm in obj) {
				if (typeof this[elm] === 'function' && !obj.hasOwnProperty(elm)) {
					continue;
				}
				memberArray.push(elm);
			}
			return memberArray;
		},
		_arrayToString : function(array, separator) {
			var result = '';
			for ( var i = 0; i < array.length; i++) {
				result += array[i];
				if (i < array.length - 1) {
					result += separator;
				}
			}
			return result;
		},
		_defaultCallBack : function(transaction, results) {
		},
		_errorHandler : function(transaction, error) {
		}
	};
    return DbOperationsUtility;
})();