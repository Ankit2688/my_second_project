﻿//Implementation for life engage authService
var authServiceUtility;
(function() {
	authServiceUtility = {
		login : function(user, successCallback, errorCallback, $http) {
							//jQuery.support.cors = true;
							var username = user.username;
							var password = user.password;			
							var loginServiceUrl = rootConfig.loginUrl;
							var req = {
								method : 'POST',
								url : loginServiceUrl,
								headers : {
									'Content-Type' : "application/x-www-form-urlencoded; charset=utf-8"
							},
							transformRequest : function(obj) {
								var str = [];
								for ( var p in obj)
									str.push(encodeURIComponent(p) + "="
											+ encodeURIComponent(obj[p]));
								return str.join("&");
							},
							data : {
								username : username,
                                password : password,
                                j_auth_token : "on",
                                customerType : "AGENT"
							}
						}
						$http(req).success(function(data, status, headers, config) {
							successCallback(data,headers("TOKEN"));
						}).error(function(data, status) {
							errorCallback(data, status);
						});

        },
        fetchKey : function(user, successCallback, errorCallback, $http) {

            var requestInfo = Request();
            var loginServiceUrl = rootConfig.encryptionUrl;
            var req = {
                method : 'POST',
                crossDomain : true,
                url : loginServiceUrl,
                headers : {
                    'Content-Type' : "application/json; charset=utf-8"
                },
                data : requestInfo
            }

            $http(req).success(function(data, status, headers, config) {
                successCallback(data.Response.ResponsePayload.Transactions[0].TransactionData);
            }).error(function(data, status) {
                errorCallback(data, status);
            });
            /*data ={}
            data.StatusData = {}
            data.StatusData.Status = "SUCCESS";
            data.encryptionKey = "MIICzjCCAjegAwIBAgIJAOFqovQuVUgKMA0GCSqGSIb3DQEBBQUAME8xCzAJBgNVBAYTAlVTMQswCQYDVQQIEwJDQTEWMBQGA1UEBxMNTW91bnRhaW4gVmlldzEbMBkGA1UEChMSQW5kcm9pZCBUZXN0IENhc2VzMB4XDTEyMDgxNDE2NTU0NFoXDTIyMDgxMjE2NTU0NFowTzELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAkNBMRYwFAYDVQQHEw1Nb3VudGFpbiBWaWV3MRswGQYDVQQKExJBbmRyb2lkIFRlc3QgQ2FzZXMwgZ8wDQYJKoZIhvcNAQEBBQADgY0AMIGJAoGBAKNyq9DkrS/n4nkHNj0MjUKaCjNks82y1zpCBndFKenLt0rW7q0BkZsMWaED+vBafE/3jTYPH0V9GzGhNQsA7Xq2yE6phkx7mVdBEu9rvD1g8pkaze1WpOU2nyQf3IlAyJmSq0q1YUVi/6NFZa/2JzBRDg7reQy+swpvKQbcL2tRAgMBAAGjgbEwga4wHQYDVR0OBBYEFDMF7v5vYMf5qdJzXI9toi+Xjl1RMH8GA1UdIwR4MHaAFDMF7v5vYMf5qdJzXI9toi+Xjl1RoVOkUTBPMQswCQYDVQQGEwJVUzELMAkGA1UECBMCQ0ExFjAUBgNVBAcTDU1vdW50YWluIFZpZXcxGzAZBgNVBAoTEkFuZHJvaWQgVGVzdCBDYXNlc4IJAOFqovQuVUgKMAwGA1UdEwQFMAMBAf8wDQYJKoZIhvcNAQEFBQADgYEAjDBC+usaJuvaVjLynaUk2DraMKaLRv7+2/Hm4Xwb53cAoRwZF3Ow8J3zT7a8x0eFKkqhpVj1xRpRsQSA7jrsL+H9WOvtgp44oyR19z7CxSfrb3tQ2kPcOwtveI+wZuESh1+Xe8oUeffobHLbkWUXVOB0HaxHBBLgw2YZBS5+8WE=";
            successCallback(data);*/
        },
        getUserDetails   : function(user, successCallback, errorCallback) {

            jQuery.support.cors = true;
            var username = user.username;
            var data = {"information":{"display_name":username,"email_id":"","first_name":"Tom","last_name":"","app_role":"","member_of":["OrgPublicGroup"],"agent_cd":"123456","designation":"ADM"},"status":"SUCCESS"};
            successCallback(data);

        },

		getHierarchyDetails : function(transObj, successCallback, errorCallback, options, $http) {
			// jQuery.support.cors = true;
			// var username=user.username;

			var requestInfo = Request();
			requestInfo.Request.RequestPayload.Transactions.push(transObj);
			var url = rootConfig.serviceBaseUrl +rootConfig.servicePath+ "services/HierarchyService"//?COMPANY_ID=100&APP_ID=14";
			//;//"HierarchyRequest";
			
			var request = {
					method : 'POST',
					url : url,
					headers : {
						'Content-Type' : "application/json; charset=utf-8",
						"Token" : options.token
					},
					data : requestInfo
			    }
				
				$http(request).success(function(data, status, headers, config) {
								if (data.Response.ResponsePayload.Transactions != null) {
						             successCallback(data.Response.ResponsePayload.Transactions);
					            } else {
					                 successCallback(data.Response.ResponsePayload);
								}
							}).error(function(data, status, headers, config) {
						errorCallback(data, status, resources.errorMessage);
					});
					
			/*		
			$.ajax({
				type : "POST",
				crossDomain : true,
				url : url,
				data : angular.toJson(requestInfo),
				contentType : "application/json;",
				dataType : "json",
				success : function(data, status) {
					if (data.Response.ResponsePayload.Transactions != null) {
						successCallback(data.Response.ResponsePayload.Transactions);
					} else
						successCallback(data.Response.ResponsePayload);
				},
				error : function(data, status) {
					////////////////////console.log("rror in auth service..."+angular.toJson(data)+"ststus..."+status);
					errorCallback("Error in ajax call");
				}
			});
			*/

		},
		getSyncDriveAppRole: function(user,successCallback,errorCallback){
			var url = rootConfig.serviceBaseUrl +rootConfig.servicePath+"authenticate"//?COMPANY_ID=100&APP_ID=41";
			var data ={"userName":user.username ,"password":user.password};
	$.ajax({
					type : "POST",
					headers : {
					"Authenticate|nwsAuthToken": "e03364fd-a8c6-7878-3d44-cff2a9d8e333"
				 },
					data : angular.toJson(data),
					crossDomain : true,
					async : true,
					url : url,
					contentType : "application/json",
					success : function(response) {
						//alert("success-----"+angular.toJson(response));
						successCallback(response);
					},
					error : function(data, status) {
						//alert("error----"+angular.toJson(data));
						errorCallback();
					}
				});
			
			
			
		},
		logout : function(successCallback, errorCallback) {
			//once the authentication service is up, remove the hardcoding
			//            $http.post('/logout').success(function(){
			//                success();
			//            }).error(error);
			successCallback();
		},
		authorize : function(accessLevel, role) {
			return false;
		},
		isLoggedIn : function($rootScope) {
			if ($rootScope.isAuthenticated)
				return true;
			else
				return false;
		}
	};

	return authServiceUtility;
})(); 