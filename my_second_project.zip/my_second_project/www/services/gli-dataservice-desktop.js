
(function() {
    DbOperationsUtility['searchTransactions'] = function(transactionObj, successCallback,
   		errorCallback,header) {
		var token = header.Token;
   		var getUrl = rootConfig.serviceBaseUrl+rootConfig.servicePath;
   	var requestInfo = Request();
   	switch (transactionObj.Type) {
   	case "premiumCalendar":
   		getUrl = getUrl + "policyService/getPremiumCalendar";
   		break;
   	case "CreatePassword":
       		getUrl = getUrl + "userService/createPassword";
       		break;
   	case "CreateSecurityQuestion":
        getUrl = getUrl + "userService/createSecurityOptions";
        break;
	case "AgentDashboard":
   		getUrl = getUrl + "policyService/retrieveAgentDashboard";
   		break;
	case "clientInformation":
		getUrl = getUrl + "userService/retrieveClientInformation";
   		break;
   	case "policyDueRenewalSearch":
   		getUrl = getUrl + "policyService/policiesRemarkHistoryRenewalStatusSearch";
   		break;
   	case "clientLoggedSearch":
   		getUrl = getUrl + "policyService/getClaimsLogged";
   		break;
   	case "actionTaken":
   		getUrl = getUrl + "policyService/updateRenewalRemarksInformation";
   		break;
	case "majorclass":
   		getUrl = getUrl + "policyService/retrieveMasterData";
   		break;
	case "contracttype":
   		getUrl = getUrl + "policyService/retrieveMasterData";
   		break;
	case "transactiontype":
   		getUrl = getUrl + "policyService/retrieveMasterData";
   		break;
   	case "AgentCode":
		getUrl = getUrl + "userService/getAssociateId";
		break;
	case "BranchCode":
    	getUrl = getUrl + "userService/getAllBranchDetails ";
    	break;
	case "SOA":
		getUrl = getUrl + "policyService/getSOAList";
		break;
   	case "ClaimsAlert":
   		getUrl = getUrl + "policyService/claimsAlert";
   		break;
   	case "claimInquiry":
    	getUrl = getUrl + "policyService/clientLoggedSearch";
    	break;
	case "policySearch":
    	getUrl = getUrl + "policyService/policySearch";
    	break;
	case "customerStatus":
    	getUrl = getUrl + "policyService/customerStatus";
    	break;
    case "claimstatus":
       	getUrl = getUrl + "policyService/retrieveMasterData";
       	break;
	case "RenewalListing":
    	getUrl = getUrl + "policyService/renewalListing";
    	break;
	case "Performance":
    	getUrl = getUrl + "policyService/agentPerformance";
    	break;
	case "CPDHoursTracking":
    	getUrl = getUrl + "policyService/getAgentCpdHours";
    	break;
	case "CPDTrainingCalendar":
    	getUrl = getUrl + "policyService/agentCPDTrainingCalendar";
    	break;
    case "relationshipSearch":
		getUrl = getUrl + "policyService/getClientBirthdayInfo";
		break;
	case "AgentDetails":
		getUrl = getUrl + "policyService/getAgentDetails";
		break;
	case "getContractTypesByMajorClass":
		getUrl = getUrl + "policyService/getContractTypesByMajorClass";
		break;
    case "Change Password":
		getUrl = getUrl + "userService/updatePassword";
		break;
	case "retrieveCpdBranchList":
    		getUrl = getUrl + "policyService/retrieveCpdBranchList";
		break;
	default:break;
   	}
   	requestInfo.Request.RequestPayload.Transactions.push(transactionObj);
   	jQuery.support.cors = true;
   	$.ajax({
   				type : "POST",
   				crossDomain : true,
   				url : getUrl,
   				headers: {
   					"Token": token,
   					"SOURCE": 100
   			    },
   				data : angular.toJson(requestInfo),
   				contentType : "application/json; charset=utf-8",
   				dataType : "json",
   				success : function(data, status) {
   					try{
   						if ((data.STATUS)&& (data.STATUS == 'E')) {

   						    errorCallback("Error in ajax call"+data.STATUS);
   						}
   						else
   						{
   						    if (data.Response.ResponsePayload.Transactions !== null)
   						    {
								successCallback(data.Response.ResponsePayload.Transactions);
   						    }
   						    else{
								successCallback(data.Response.ResponsePayload);
							}
   						}
   					}
   				catch(error){
   				var data =
   				errorCallback("Error in ajax call"+error);
   				}
   				},
   				error : function(data, status) {
   						errorCallback(data.status);
   				}
   			});
   };
   DbOperationsUtility['getTransactions'] = function(transactionObj, successCallback,
      		errorCallback) {
      	var getUrl = rootConfig.serviceBaseUrl+rootConfig.servicePath;
      	var requestInfo = Request();
      	switch (transactionObj.Type) {
      	case "UserDetails":
      		getUrl = getUrl + "userService/register";
      		break;
		case "ValidateSecretQuestion":
        	getUrl = getUrl + "userService/validateSecurityQuestion";
        	break;
        case "RetrieveSecretQuestion":
        	getUrl = getUrl + "userService/getSecurityQuestion";
        	break;
		default:break;
      	}
      	requestInfo.Request.RequestPayload.Transactions.push(transactionObj);
      	jQuery.support.cors = true;
      	$.ajax({
      				type : "POST",
      				crossDomain : true,
      				url : getUrl,
      				headers: {
      					"SOURCE": 100
      			    },
      				data : angular.toJson(requestInfo),
      				contentType : "application/json; charset=utf-8",
      				dataType : "json",
      				success : function(data, status) {
      					try{
      						if ((data.STATUS)&& (data.STATUS == 'E')) {

      						    errorCallback("Error in ajax call"+data.STATUS);
      						}
      						else
      						{
      						    if (data.Response.ResponsePayload.Transactions !== null)
      						    {
									successCallback(data.Response.ResponsePayload.Transactions);
      						    }
      						    else{
									successCallback(data.Response.ResponsePayload);
								}
      						}
      					}
      				catch(error){
      				var data =
      				errorCallback("Error in ajax call"+error);
      				}
      				},
      				error : function(data, status) {
      						errorCallback(data.status);
      				}
      			});
      };
      DbOperationsUtility['saveObservations'] = function (transactionObj, successCallback, errorCallback, options, $http) {
      	            //showHideLoadingImage(true, "Uploading documents,please wait.. ");
      	          //  var saveUrl = rootConfig.serviceBaseUrl + "lifeEngageService/save";
      	           // var saveUrl = "https://sit-lifeengage.cognizant.com/mli-mService-platform-ep/services/mService/save";
      			var saveUrl = rootConfig.serviceBaseUrl + "SyncService/saveObservation"//?COMPANY_ID=100&APP_ID=48";
      	            var requestInfo = Request();
					var userDetilsModel = JSON.parse(sessionStorage.userDetails);
      	            requestInfo.Request.RequestPayload.Transactions.push(transactionObj)
      	            jQuery.support.cors = true;
      	            console.log("request..."+angular.toJson(requestInfo));

      				var request = {
      					method : 'POST',
      					url : saveUrl,
      					headers : {
      						'Content-Type' : "application/json; charset=utf-8",
      						"Token" : userDetilsModel.options.headers.Token
      					},
      					data : angular.toJson(requestInfo)
      			    }

      				$http(request).success(function(data, status, headers, config) {
      				                if (status == 200){
      								   successCallback(data);
      								} else {
      								   errorCallback(data, status);
      								}
      								/* if (data.Response.ResponsePayload.Transactions[0].StatusData.StatusCode == "100") {
      									successCallback(data.Response.ResponsePayload.Transactions[0]);
      								} else {
      									errorCallback(data.Response.ResponsePayload.Transactions[0].StatusData.StatusMessage);
      								} */
      							}).error(function(data, status, headers, config) {
      						errorCallback(data, status, resources.saveTransactionsError);
      					});
      	        };
     return DbOperationsUtility;
   })();