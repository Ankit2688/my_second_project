var loginUtility;
(function(){
	loginUtility={
			saveToken : function(userdetailsService,successCallback,errorCallback){
				
				successCallback();
			},
			
			fetchToken :function(userId,successCallback,errorCallback){
				//alert("success");
				successCallback();
			},
			checkAgentIdExistingInDb: function (user, successCallback, errorCallback) {
				try {
					successCallback();
				} catch (exception) {
					errorCallback(exception);
				}
			}
	};
	
	return loginUtility;
		})();
	