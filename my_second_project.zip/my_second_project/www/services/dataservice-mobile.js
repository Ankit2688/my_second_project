var DbOperationsUtility;
var status = navigator.onLine ? "ONLINE" : "OFFLINE";
//var status1 = window.navigator.onLine ? "ONLINE" : "OFFLINE";
(function() {
	
	DbOperationsUtility = {
		
		openDatabase : function(dbName) {
		},
		exportDataToExcel: function (transactionData,successCallback, errorCallback) {
			
            var self = this;
          //  //////////////console.log("exportDataToExcel.."+angular.toJson(transactionData));
            window.plugins.exportExcel.exportData(transactionData,successCallback, errorCallback);
        },
		getTransactions : function(transactionObj, successCallback, errorCallback) {		 		
			try {
				var self = this;
				var dataObj = {};
				if (transactionObj.Key1 != null && transactionObj.Key1 != "") {
					dataObj.Key1 = transactionObj.Key1;
				} 
				if (transactionObj.Key6 != null && transactionObj.Key6 != "") {
					dataObj.Key6 = transactionObj.Key6;
				} else if (transactionObj.Key8 != null	&& transactionObj.Key8 != "") {
					dataObj.Key8 = transactionObj.Key8;
				} else if (transactionObj.Id != null && transactionObj.Id != "") {
					dataObj.Id = transactionObj.Id;
				}
				if (transactionObj.Type != null && transactionObj.Type != "") {
					dataObj.Type = transactionObj.Type;
				}
				if (transactionObj.filter != null && transactionObj.filter != "") {
					dataObj.filter = transactionObj.filter;
				}
			
				var fields='*';
				switch(transactionObj.Key10)
				{
					//this wil help to select custom fields
					case "Custom":
					{
						if(transactionObj.fields!=null && transactionObj.fields!=""){
							fields=transactionObj.fields;
						}
						else{
							fields=rootConfig.transactionTableBasicFields;
						}
						break;
					}
					//Selects all feilds except the transaction data
					case "BasicDetails":
					{
						fields=rootConfig.transactionTableBasicFields;
						break;
					}
					//Selects entire fields
					case "FullDetails":
					{
						fields=" * ";
						break;
					}
				}	
				////////////////console.log("dataOBJ>>>>>>>>>>>>>>>>>>>"+angular.toJson(dataObj));
				sql=_dbOperations._buildFetchScript(fields,"Transactions",dataObj);	
				
				_dbOperations._executeSql(sql, function(results) {			
					var data = _dbOperations._getRecordsArray(results);					
									 
				  $.each(data, function(i, obj) {
						var formattedData = JSON.parse(unescape(obj.TransactionData));
						
						obj.TransactionData = formattedData;
					});
					  successCallback(data)
			
					}, function(error) {
					errorCallback(error);
				});
			} catch (exception) {
				errorCallback(exception);
			}
		},
		searchTransactions: function (transactionObj, successCallback, errorCallback, options, $http) {
			var getUrl = rootConfig.serviceBaseUrl+rootConfig.servicePath ;
			var requestInfo = Request();
			switch (transactionObj.Type) {

			case "MyEarnings":
				if (transactionObj.TransactionData.searchCriteria.type == "Policy Level Commissions") {
					getUrl = getUrl + "services/PolicyLevelCommissionService"//?COMPANY_ID=100&APP_ID=42";//"PolicyLevelCommissionRequest";////
				}else if (transactionObj.TransactionData.searchCriteria.type == "ACSStatements") {
					getUrl = getUrl + "services/ACSService"//?COMPANY_ID=100&APP_ID=42";//"ACSServiceRequest";////
				} else if (transactionObj.TransactionData.searchCriteria.type == "IncentiveStatements") {

					getUrl = getUrl + "IncentiveServiceRequest"//?COMPANY_ID=100&APP_ID=14";//"IncentiveServiceRequest";////
				} else if (transactionObj.TransactionData.searchCriteria.type == "TDS Statements") {
					getUrl = getUrl +"services/TDSStatementService"//?COMPANY_ID=100&APP_ID=14";//"TDSStatementRequest";// //
				}
				break;
			case "PolicySearch":
				transactionObj.Type = "PolicyDetails";
				getUrl = getUrl +"services/PolicySearchRequest"//?COMPANY_ID=100&APP_ID=16";//"PolicySearchRequest";// //
				break;
			case "ProposalSearch":
				transactionObj.Type = "ProposalDetails";
				getUrl = getUrl +"services/ProposalSearchService"//?COMPANY_ID=100&APP_ID=14";//"ProposalSearchRequest";// //
				break;
			case "AgentCode":
				transactionObj.Type = "AgentCode";
				getUrl = getUrl + "userService/getAssociateId"//?COMPANY_ID=100&APP_ID=14";//"ProposalSearchRequest";
				break;

			}
			requestInfo.Request.RequestPayload.Transactions.push(transactionObj);   
			
			var request = {
					method : 'POST',
					url : getUrl,
					headers : {
						'Content-Type' : "application/json; charset=utf-8",
						"Token" :options.Token
					},
					data : angular.toJson(requestInfo)
			    }
				
				$http(request).success(function(data, status, headers, config) {
								if (data.Response.ResponsePayload.Transactions != null) {
					                 successCallback(data.Response.ResponsePayload.Transactions);
				                } else {
					                 successCallback(data.Response.ResponsePayload);
								}
							}).error(function(data, status, headers, config) {
						errorCallback(data, status, resources.errorMessage);
					});
		
		},
		saveTransactions : function(transactionData, successCallback,errorCallback) {
			try {
			
				var self = this;
				if (transactionData.Id != null && transactionData.Id != 0) {
					sql = _dbOperations._buildUpdateScript("Transactions",transactionData);
					sql += " WHERE 	Id = " + transactionData["Id"];
				} else {
					sql = _dbOperations._buildInsertScript("Transactions",transactionData);
				}
				
				_dbOperations._executeSql(sql, function(data) {
					var transId = (data.insertId == null) ? transactionData.Id: data.insertId;
				
					self.insertStatusRec(transId, successCallback,errorCallback);
				}, function(error) {
					errorCallback(error);
				});
			} catch (exception) {
				errorCallback(exception);
			}
		},
		
		
		deleteTransactions : function(whereClause, successCallback,errorCallback) {
			try {
			
				var self = this;
			
				sql =_dbOperations._buildDeleteScript("Transactions",whereClause);
				
				_dbOperations._executeSql(sql, function(data) {
					successCallback();
				}, function(error) {
					errorCallback(error);
				});
			} catch (exception) {
				errorCallback(exception);
			}
		},
		saveAgentProfile: function(transactionObj, successCallback,
            errorCallback) {
            var self = this;
            var achievementDetails = [];
            var agentDetails = transactionObj.AgentDetails;
            achievementDetails = transactionObj.Achievements;
            self.saveOrUpdateAgentDetails(agentDetails,
               successCallback,
                errorCallback);

        },
		      saveOrUpdateAgentDetails: function(transactionData, successCallback,
            errorCallback) {
            try {
                delete transactionData.group;
                sql = _dbOperations._buildInsertOrUpdateScript("AGENT", "agentCode",
                    transactionData);
                _dbOperations._executeSql(sql, function(data) {
                    successCallback();
                }, function(error) {
                    errorCallback(error);
                });
            } catch (exception) {
                errorCallback(exception);
            }
        },
		 isAchievementExistsForAgent: function(agentId, successCallback, errorCallback) {
            try {
                var isExists = false;
                var dataObj = {};
                dataObj.agentId = agentId;
                var sql = _dbOperations._buildFetchScript("Id", "ACHIEVEMENT",
                    dataObj);
                console.log(sql);
                _dbOperations._executeSql(sql, function(results) {
                    var data = _dbOperations._getRecordsArray(results);
                    if (data.length > 0) {
                        isExists = true;
                    }
                    successCallback(isExists);
                }, function(error) {
                    errorCallback(error);
                });
            } catch (exception) {
                errorCallback(exception);
            }
        },
		 saveOrUpdateAchievements: function(transactionData, isExists, agentId, successCallback,
            errorCallback) {
            var self = this;
            $.each(transactionData, function(i, obj) {
                obj.agentId = agentId;
            });
            if (isExists) {
                var whereClause = "agentId='" + agentId +"'";
                self.deleteFromTable("ACHIEVEMENT", whereClause,
                    function() {
                        self.saveAchievements(transactionData, agentId, successCallback,
                            errorCallback);
                    }, errorCallback)
            } else {
                self.saveAchievements(transactionData, agentId, successCallback,
                    errorCallback);
            }


        },
		  saveAchievements: function(transactionData, agentId, successCallback,
            errorCallback) {
            try {
                sql = _dbOperations._buildBatchInsertScript("ACHIEVEMENT",
                    transactionData);
                console.log("achievemnt query" + sql);
                _dbOperations._executeSql(sql, function(data) {
                    successCallback();
                }, function(error) {
                    errorCallback(error);
                });
            } catch (exception) {
                errorCallback(exception);
            }
        },
		 insertStatusRec: function (transId, successCallback, errorCallback) {
	            try {
	                var self = this;
	                var statusData = {
	                    RecordId: transId,
	                    SyncResponseStatus: "Saved"
	                };
	                _dbOperations._getIdExitingInDB("SyncStatus", "RecordId", [transId], function (idInStatusTbl) {
	                    if (idInStatusTbl[transId]) {
	                        sql = _dbOperations._buildUpdateScript(
	                            "SyncStatus", statusData);
	                        sql += " WHERE 	RecordId = " + transId;
	                    } else {
	                        sql = _dbOperations._buildInsertScript(
	                            "SyncStatus", statusData);
	                    }
	                    _dbOperations._executeSql(sql, function (data) {
	                        successCallback(transId);
	                    }, function (error) {
	                        errorCallback(error);
	                    });
	                }, errorCallback);
	            } catch (exception) {
	                errorCallback(exception);
	            }
	        },
	        syncDataToServer: function (transactionObj, successCallback,
	                errorCallback,saveBandwidth,options,useroptions) {
	                try {
	                       	var self = this;
	                     
	                    //var serviceUrl = rootConfig.serviceBaseUrl+rootConfig.servicePath+"MyBusinessSetGoal?COMPANY_ID=100&APP_ID=14";  		
	                       	var serviceUrl = getSyncToServiceUrl(transactionObj.Type);	   
	                       	
	                       
	    				var options = {
	    					url : serviceUrl,
							headers : {
							      "Token" : useroptions.Token,
								  "source" : "200"
							}
	    				};
	    				////////////////console.log("inside dataservice-mobile...serviceUrl"+serviceUrl);
	                    var recordType = transactionObj.Type;
	                    _dbOperations._dbInit();
	                    _dbOperations._syncNow(recordType, self._syncProgress,
	                        function (result) {
	                    	
	                            if (result.syncOK === true) {
	                            	
	                            	
	                                //Synchronized successfully
	                                successCallback(result);
	                            }
	                        }, errorCallback,saveBandwidth,options);

	                } catch (exception) {
	                	
	                    errorCallback(exception);
	                }
	            },
				
	    retrieveLoggedInAgentIds : function(successCallback,errorCallback) {
        	try {
        		sql = _dbOperations._buildFetchScript("userId", "UserDetails");
        		_dbOperations._executeSql(sql, function(results) {
        			var data = _dbOperations._getRecordsArray(results);
        			successCallback(data);
        		}, function(error) {
        			errorCallback(error);
        		});
        	} catch (error) {
        		errorCallback(error);
        	}
        },

		retrieveAgentDetails: function(transactionObj, successCallback,
            errorCallback) {
            try {
                var self = this;
                var dataObj = {};
                dataObj.agentCode = transactionObj.Key1;
                sql = _dbOperations._buildFetchScript("*",
                    "AGENT", dataObj);
                console.log(sql);
                _dbOperations._executeSql(sql, function(results) {

                    console.log(results);
                    var data = _dbOperations._getRecordsArray(results);
                    successCallback(data);
                }, function(error) {
                    errorCallback(error);
                });
            } catch (exception) {
                errorCallback(exception);
            }
        },
	            _syncProgress: function (message, percent, msgKey) {
	               
	            },
	            syncData: function (transactionObj, successCallback, errorCallback, useroptions, $http) {
	                try {
	                	var self = this;
	    			
	    				var serviceUrl =  getServiceUrl(transactionObj.Type);	               
	    				var options = {
	    					"url" : serviceUrl,
							headers : {
							      "Token" : useroptions.Token,
								  "source" : "200"
							}
	    				};
	                
	                    var requestInfo = Request();
	                    requestInfo.Request.RequestPayload.Transactions.push(transactionObj);
	                    var dataObj = {};
	                    dataObj.type = transactionObj.Type;
	                    sql = _dbOperations._buildFetchScript("last_sync", "sync_info", dataObj);
	                    _dbOperations
	                        ._executeSql(
	                            sql,
	                            function (results) {
	                                var data = _dbOperations._getRecordsArray(results);
	                                var lastSyncDate;
	                                if (data.length == 0) {
	                                    lastSyncDate = 0;
	                                } else {
	                                    lastSyncDate = data[0]["last_sync"];
	                                }
	                              
	                                requestInfo.Request.RequestInfo.LastSyncDate = lastSyncDate == 0 ? "" : lastSyncDate;
	                              
	                                _dbOperations._refreshNow(requestInfo, self._syncProgress,
	                                    function (result) {
	                                		
	                                        if (result.syncOK === true) {
	                                            //Synchronized successfully
	                                        	
	                                            successCallback();
	                                        }
	                                    },errorCallback,options);
	                            }, function (error) {
	                            	
	                                errorCallback(error);
	                            });

	                } catch (exception) {
	                    errorCallback(exception);
	                }
	            },
	            
		closeDatabase : function(dbName, successCallback, errorCallback) {
			try {
				_dbOperations._closeDB(dbName, function(data) {
					successCallback(data);
				}, function(error) {
					errorCallback(error);
				});
			} catch (exception) {
				errorCallback(exception);
			}
		}
				
		
	};  
		
	var _dbOperations = {
		_db : null,
		_dbInit : function(cb) {
			
			var self = this;
			self._db = window.sqlitePlugin.openDatabase("eServiceDB","1.0", "eServiceDB", -1,function(db){
            self._db = db;
            var tblTransactionQuery = "CREATE TABLE IF NOT EXISTS Transactions (Id INTEGER PRIMARY KEY ,Key1 TEXT NOT NULL,Key2 TEXT NOT NULL,Key3 TEXT NOT NULL,Key4 TEXT,Key5 TEXT,Key6 TEXT,Key7 TEXT,Key8 TEXT,Key9 TEXT,Key10 TEXT,Type TEXT,TransactionData TEXT, Key11 text, Key12  text, TransTrackingID text, agentId text,Key13 TEXT,Key14 TEXT,Key15 TEXT,Key16 TEXT,Key17 TEXT,Key18 TEXT,Key19 TEXT,Key20 TEXT,Key21 TEXT,Key22 TEXT,Key23 TEXT,Key24 TEXT,Key25 TEXT,Key26 TEXT,Key27 TEXT,Key28 TEXT,Key29 TEXT,Key30 TEXT)"
			self._executeSql(tblTransactionQuery);
			var tblSyncStatusQuery = "CREATE TABLE IF NOT EXISTS SyncStatus (Id INTEGER PRIMARY KEY,RecordId INTEGER,SynAttemptTS TEXT,SyncResponseStatus TEXT,SyncResponseStatusDesc TEXT,SyncResponseTS TEXT)";
			self._executeSql(tblSyncStatusQuery);
			var tblAgentQuery = "CREATE TABLE IF NOT EXISTS AGENT (Id INTEGER PRIMARY KEY,agentCode TEXT,agentDesc TEXT,agentName TEXT,designation TEXT,userId TEXT,employeeType TEXT,supervisorCode TEXT,office TEXT,unit TEXT,agentGroup TEXT,yearsofExperience TEXT,businessSourced TEXT,customerServicing TEXT,licenseNumber TEXT,agentLicensestartdate TEXT,agentLicenseExpDate TEXT,emailId TEXT,mobileNumber TEXT,channelId TEXT)";
            self._executeSql(tblAgentQuery);
	        self._createDBSync();
	        cb();
	        });
		},
        _getIdExitingInDB: function (tableName, idName, listIdToCheck,
            successCallback, errorCallback) {
            if (listIdToCheck.length === 0) {
                successCallback([]);
                return;
            }
            var self = this;
            var SQL = 'SELECT ' + idName + ' FROM ' + tableName + ' WHERE ' + idName + ' IN ("' + self._arrayToString(listIdToCheck, '","') + '")';
            self._executeSql(SQL, function (ids) {
                var data = _dbOperations._getRecordsArray(ids);
                var idsInDb = [];
                for (var i = 0; i < data.length; ++i) {
                    idsInDb[data[i][idName]] = true;
                }
                successCallback(idsInDb);
            }, errorCallback);
        },
        _syncNow: function (type, progressIndicator, successCallback,
                errorCallback,saveBandwidth,options) {
        
        
                DBSYNC.syncNow(type, progressIndicator, function (result) {
                    if (result.syncOK === true) {
                        //Synchronized successfully
                                               successCallback(result);
                    }
                }, errorCallback,saveBandwidth,options);
            },
        
        
        _refreshNow: function (transObj, progressIndicator, successCallback,errorCallback,options) {
        	
            DBSYNC.refreshNow(transObj, progressIndicator, function (response) {
               
                successCallback(response);
            },errorCallback,options);
        },
        _createDBSync: function () {
        
            var self = this;
            var saveUrl = rootConfig.serviceBaseUrl+rootConfig.servicePath+ "lifeEngageService/save";
            TABLES_TO_SYNC = [{
                tableName: 'Transactions',
                idName: 'Id'
            }];
            var syncInfo;
            DBSYNC.initSync(TABLES_TO_SYNC, self._db, {
            	  UserName: "agent name",
                  CreationDate: "09-25-2013",
                  CreationTime: "12:15:54-04:00",
                  SourceInfoName: "tablet",
                  RequestorToken: "",
                  UserEmail: "test@gmail.com",
                  LastSyncDateTime: "09-25-2013 23:15:45"
            }, saveUrl, function () {
                
            });
        },		
		_closeDB : function(dbName, successCallback, errorCallback) {
			try {
				if (self._db != null) {
					self._db.close(dbName);
					if (successCallback && typeof successCallback == "function") {
						successCallback();
					} else {
						self._defaultCallBack();
					}
				}
			} catch (e) {
				////////////////console.log("ERROR: " + e.message);
				errorCallback(e);
			}
		},
		_executeSql : function(sql, successCallback, errorCallback) {
			var self = this;
				try {
				if (self._db == null) {
					self._dbInit(function(){
                        self._getTransactionAndExecuteSql(sql, successCallback, errorCallback);
                    });
                }else{
                    self._getTransactionAndExecuteSql(sql, successCallback, errorCallback);
                }

            } catch (e) {
                errorCallback(e);
            }

        },
		_getTransactionAndExecuteSql : function(sql, successCallback, errorCallback){
            var self = this;
            self._db.transaction(function(tx) {
                tx.executeSql(sql, [], function(tx, results) {
                    if (successCallback && typeof successCallback == "function") {
                        successCallback(results);
                    } else {
                        self._defaultCallBack(tx, results);
                    }
                }, function(tx, e) {
                    if (errorCallback && typeof errorCallback == "function") {
                        errorCallback(e);
                    } else {
                        self._errorHandler(tx, results);
                    }
                });
            });
        },
        _buildInsertScript : function(tableName, trasactionData) {
			var members = this._getAttributesList(trasactionData);
			var values = this._getMembersValue(trasactionData, members);
			if (members.length === 0) {
				throw 'buildInsertSQL : Error, try to insert an empty object in the table '
						+ tableName;
			}
			var sql = "INSERT INTO " + tableName + " (";
			sql += this._arrayToString(members, ',');
			sql += ") VALUES (";
			sql += this._arrayToString(values, ',');
			sql += ")";
			return sql;

		},
			_buildInsertOrUpdateScript: function(tableName, columnName, transactionData) {
            var members = this._getAttributesList(transactionData);
            var values = this._getMembersValue(transactionData, members);
            if (members.length === 0) {
                throw 'buildInsertSQL : Error, try to insert an empty object in the table ' + tableName;
            }
            var sql = "INSERT OR REPLACE INTO " + tableName + " (ID, ";
            sql += this._arrayToString(members, ',');
            sql += ") VALUES (";
            sql += "(SELECT ID FROM " + tableName + "  WHERE  " + columnName + "='" + transactionData[columnName] + "'),";
            sql += this._arrayToString(values, ',');
            sql += ")";
            console.log("_buildInsertOrUpdateScript" + sql);
            return sql;

        },
		_buildUpdateScript : function(tableName, trasactionData) {
			var self = this;
			var sql = "UPDATE " + tableName + " SET ";
			var members = self._getAttributesList(trasactionData);
			if (members.length === 0) {
				throw 'buildUpdateSQL : Error, try to insert an empty object in the table '
						+ tableName;
			}
			var values = self._getMembersValue(trasactionData, members);

			var memLength = members.length;
			for ( var i = 0; i < memLength; i++) {
				
				sql += members[i] + " = " + values[i];
				if (i < memLength - 1) {
					sql += ', ';
				}
			}

			return sql;
		},
		_buildFetchScript : function(selectCol, tableName, dataObj) {
			var self = this;
			var sql = "SELECT " + selectCol + " FROM " + tableName;
			//if(dataObj.filter==null && dataObj.filter!="All"){
			if (!jQuery.isEmptyObject(dataObj)) {
				sql += " WHERE ";
				var members = self._getAttributesList(dataObj);
			    ////////////////console.log("members,,,,,,,,,>>>>>>>>"+angular.toJson(members));
				if (members.length === 0) {
					throw 'buildUpdateSQL : Error, try to insert an empty object in the table '
							+ tableName;
				}
				var values = self._getMembersValue(dataObj, members);
				var memLength = members.length;
				for (var i = 0; i < memLength; i++) {
                                         if(members[i]=="filter"){
                                                sql +=dataObj.filter;
                                         }else{
                                                sql += members[i] + " = " + values[i];
                                         }
                                         
                                         if (i < memLength - 1) {
                                                sql += " AND ";
                                         }
                                  }

			}
			return sql;
		},
		_buildDeleteScript : function(tableName, whereClause) {
			var self = this;
			var sql = 'DELETE FROM ' + tableName + ' WHERE ' + whereClause;
			return sql;
		},
		_getRecordsArray : function(results) {
			
			var resultsArray = [];
			if (results.rows.length == 0) {
				
			} else {
				for ( var i = 0; i < results.rows.length; i++) {
					resultsArray.push(results.rows.item(i));
				}
			}
			return resultsArray;
		},
		_getMembersValue : function(obj, members) {
			var valueArray = [];
			for ( var i = 0; i < members.length; i++) {
				if (members[i].toUpperCase() == "ID") {
					valueArray.push(obj[members[i]]);
				} else if (members[i].toUpperCase() == "DOCUMENTOBJECT") {
					valueArray
							.push("'" + JSON.stringify(obj[members[i]]) + "'");
				} else {
					valueArray.push("'" + obj[members[i]] + "'");
				}
			}
			return valueArray;
		},
		_getAttributesList : function(obj) {
			var memberArray = [];
			for ( var elm in obj) {
				if (typeof this[elm] === 'function' && !obj.hasOwnProperty(elm)) {
					continue;
				}
				memberArray.push(elm);
			}
			return memberArray;
		},
		_arrayToString : function(array, separator) {
			var result = '';
			for ( var i = 0; i < array.length; i++) {
				result += array[i];
				if (i < array.length - 1) {
					result += separator;
				}
			}
			return result;
		},
		_defaultCallBack : function(transaction, results) {
			
		},
		_errorHandler : function(transaction, error) {
			
		}

	};
	return DbOperationsUtility;
})();

