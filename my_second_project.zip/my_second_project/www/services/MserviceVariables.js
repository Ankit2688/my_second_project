angular.module('lifeEngage.MserviceVariables', []).factory(
		"MserviceVariables",
		function($http) {
			var MserviceVariables = {
				"mserviceModel" : "",
				"getMserviceModel" : function() {
					if (!MserviceVariables.mserviceModel) {

						return new MserviceObject();
					} else {
						var mserviceMod = JSON
								.stringify(MserviceVariables.mserviceModel);
						return JSON.parse(mserviceMod);
					}
				},
				"setMserviceModel" : function(value) {
					MserviceVariables.mserviceModel = value;

				}
				/*,"setGoals" : [ {
					"month" : "",
					"year" : "",
					"business" : [ {
						"noOfPolicies" : "",
						"myGoalsPremium" : "",
						"myCommissions" : "",
						"myGoalsEarnings" : "",
						"myOtherEarnings" : "",
						"commissionPercentage" : "",
						"myTotalEarnings" : ""
					} ]

				} ]*/
			}
			return MserviceVariables;
		});
