var agentServiceUtility;
(function(){
	agentServiceUtility = {
			retrieveAgentProfileOnline : function(transactionObj, successCallback, errorCallback, options, $http) {
		try {
				var getUrl = rootConfig.serviceBaseUrl + "agentProfileService/retrieveAgentProfile";
				var requestInfo = Request();
			
				requestInfo.Request.RequestPayload.Transactions
						.push(transactionObj);
			var request = {
				method : 'POST',
				url : getUrl,
				headers : {
					'Content-Type' : "application/json; charset=utf-8",
					"Token" : options.headers.Token
				},
				data : requestInfo
			}

				$http(request).success(function(data, status, headers, config) {
				if (data.Response.ResponsePayload.Transactions)
					successCallback(data.Response.ResponsePayload.Transactions[0].TransactionData);
				else
					successCallback(data.Response.ResponsePayload);
			}).error(function(data, status, headers, config) {
				errorCallback(data, status, resources.errorMessage);
			});

			} catch (exception) {
				alert("error in  getListings: " + angular.toJson(exception)
						+ " :error in  getListings");
				errorCallback(exception);
			}
		},
		retrieveAgentProfileOffline : function(transactionObj, successCallback, errorCallback, options, $http) {
			try {
				DbOperationsUtility.retrieveAgentDetails(transactionObj, successCallback,
			            errorCallback);
			} catch (exception) {
					alert("error in  getListings: " + angular.toJson(exception)
							+ " :error in  getListings");
					errorCallback(exception);
				}
			
		}
		
		
	};
	
	return agentServiceUtility;
		})();
		


	