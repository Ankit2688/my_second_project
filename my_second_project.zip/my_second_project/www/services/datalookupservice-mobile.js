﻿var dataLookupServiceUtility;
(function () {
    dataLookupServiceUtility = {
        getLookUpData: function (transactionObj, successCallback, errorCallback, options) {
            transactionObj.carrierId = 1;
			transactionObj.language = "en";
			transactionObj.country = "US";
            LEDataLookUpService.getLookUpData(transactionObj, successCallback, errorCallback);
        }
	};
    return dataLookupServiceUtility;
})();