(function () {

    // Dynamically loading device specific cordova and SQLLite script files.
    // Found the solution from here.
    // http://stackoverflow.com/questions/6783144/issue-with-dynamically-loaded-phonegap-js

	if ((navigator.userAgent.indexOf("Android") > 0 || navigator.userAgent.indexOf("iPhone") > 0 || navigator.userAgent.indexOf("iPad") > 0 || navigator.userAgent.indexOf("iPod") > 0) && (rootConfig.isDeviceMobile)) {
		loadScript('services/dataservice-mobile.js');
		loadScript('services/gli-dataservice-mobile.js');
    	loadScript('services/athenticationservice-mobile.js');
    	loadScript('services/loginservice-mobile.js');
		loadScript('services/agentservice-mobile.js');
		loadScript('services/documentservice-mobile.js');
		loadScript('services/emailservice-mobile.js');
		loadScript('services/platforminfoservice-mobile.js');
		loadScript('services/datalookupservice-mobile.js');
		//loadScript('lib/vendor/phonegap/Toast.js'); clear duobt


    }else{
    	loadScript('services/dataservice-desktop.js');
    	loadScript('services/gli-dataservice-desktop.js');
    	loadScript('services/athenticationservice-desktop.js');
    	loadScript('services/loginservice-desktop.js');
		loadScript('services/agentservice-desktop.js');
		loadScript('services/documentservice-desktop.js');
		loadScript('services/emailservice-desktop.js');
		loadScript('services/platforminfoservice-desktop.js');
		loadScript('services/datalookupservice-desktop.js');
    }


 function loadScript(url) {
 // synchronous load by @Sean Kinsey
 // http://stackoverflow.com/a/2880147/813951
 var xhrObj = new XMLHttpRequest();
 xhrObj.open('GET', url, false);
 xhrObj.send('');
 var scriptTag = document.createElement('script');
 scriptTag.text = xhrObj.responseText;
 document.getElementsByTagName('head')[0].appendChild(scriptTag);
 }

})();
