mServiceApp.constant('commonConfig', function(){return{
   
   	"STORAGE" :{
                "LOCALE" : "locale",
                "DEFAULT_LANGAUGE" : "defaultLanguage",
                "AGENT_ID" : "agentId",
                "AUTHENTICATED_USER":"authenticateduser",
				"DEVICE_USER_ID":"DeviceUserID"
   	           },
   	"STATUS" : {
				"CLEAR_FILTER" : "clearFilter",
				"IS_DEVICE_ONLINE" : "isDeviceOnline",
				"SAVED" : "Saved",
				"SYNCED" : "Synced",
				"FAILED" : "Syncing failed ",
				"LAST_SYNC_ON" : "Last synced on : ",
				"NOT_AUTHENTICATED" : "not authenticated",
				"SUCCESS" : "SUCCESS"
			 },

	"LOCATION" : {
					"DASHBOARD" : "dashboard",
					"ALERTS" : "alerts",
					"SELF_SERVICE" : "selfService",
					"CUSTOMER_SERVICE" : "customerService"
	             },
	"PAGE_DETAILS" : { 
					"LOGIN" : "loginDetails",
					"INITIAL_LOGIN" :"intialLoginDetails",
					"LAST_SYNCED" :"lastSyncDetails",
					"ADM" : "admDetails",
					"MCONTENTROLES" :"mContentRoles",
					"AA" :"aaDetails",
					"AGENT" :"agtDetails",
					"VERSION" :"dbVersion"
					
	            },
	"PAGE_NAME" : {
					"ALERTS" : "Alerts",
                   	"CUSTOMER_SERVICE" : "Customer Service",
					"DASH_BOARD" :"DashBoard",
					"CPD_HOURS_TRACKING" :"CPD Hours Tracking",
					"LOGIN_PAGE" : "Login Page",
					"POLICY_DUE_FOR_RENEWAL" : "Policy Due For Renewal",
					"IMP_COMMUNICATIONS" :"Important Communications",
					"RELATIONSHIP_MANAGEMENT" : "Relationship Management",
					"POLICY_SEARCH" : "Policy Search",
					"PREMIUM_CALENDAR" : "Premium Calendar",
					"CLAIM_INQUIRY" : "Claim Inquiry",
					"CLAIM_RECORDS" : "Claim Records",
					"CUSTOMER_CONTACT" : "Customer Contact",
					"SOA" : "SOA",
					"ACCOUNT_INFO" : "Account Information",
					"GUIDES" : "Guides",
					"PRODUCTS" : "Products",
					"FORMS" : "Forms",
					"RENEWAL_SUMMARY" : "Renewal Summary",
					"REPAIRERS_WORKSHOPS" : "Repairers & Workshops",
					"HOSPITALS_CLINICS" : "Hospitals & Clinics",
					"CHANGE_PASSWORD" : "Change Password",
					"PRIVACY_POLICY" : "Privacy Policy",
					"DISCLAIMER" : "Disclaimer",
					"PERFORMANCE" : "Performance",
					"LOCATION" : "Location",
					"RESET_PASSWORD" : "Reset Password",
					"CHANGE_TEMPORARY_PASSWORD" : "Change Temporary Password",
					"SET_SECRET_QUESTION" : "Set Secret Question and Answer",
					"USER_REGISTRATION" : "New User Registration",
					"KNOWLEDGE_CENTER" :"Knowledge Center",
                    "MY_BUSINESS" :"Self Service - My Business",
                    "POTENTIAL_TO_EARN" : "Self Service - Potential to Earn",
                    "MY_EARNINGS" : "Self Service - My Earnings",
                    "REWARDS_RECOGNITION" : "Self Service - My rewards and recognition",
                    "SALESLEAD_DASHBOARD" : "Self Service - SalesLead Dashboard",
                    "RECRUITMENT_DASHBOARD" : "Self Service - Recruitment Dashboard",
                    "PERFORMANCE_DASHBOARD" : "Self Service - Performance Dashboard (ADM)"
				},
	"TRANSACTION_TYPE" : {
					"ALL" : "All",
					"OBSERVATION" : "Observation",
					"HIERARCHY_DETAILS" :"HierarchyDetails",
					"RNRSCHEMAS" :"RnRSchemes",
					"PLAN_TYPE" :"Plan Type",
					"MY_EARNINGS" :"MyEarnings",
					"POLICY_SEARCH" : "Product Name",
					"PREMIUM_AMOUNT" : "Premium Amount",
					"PREMIUM_FREQUENCY" : "Premium Frequency",
					"POLICY_STATUS" : "Policy Status",
					"PROPOSAL_STATUS" : "Proposal Status",
					"PERFORMANCE_OVERVIEW" : "MyPerformanceOverview",
					"LOGIN_POPUP" : "LoginPopUp",
					"RECRUITMENT_DASHBOARD" : "COI-NominatorName",
					"DASHBOARD" : "AgentDashboard"
				
				},
	"DATE_TYPE" : {
					"ISSUE_DATE" : "issuedate",
					"LAST_PAYMENT_DATE" : "lastPaymentDate",
					"DUE_DATE" : "duedate",
					"ALLOCATION_DATE" : "allocationDate"
				},
	"CHART_TYPE" : {
					"BARCHART" : "barChart",
					"PIECHART" : "pieChart"
				},
	"FILTER" : {
					"LAST_SEVEN" : "last7",
					"TODAY" : "today",
					"NEXT_SEVEN" : "next7",
					"MEETING" : "dueForRenewal7days",
					"YTD" : "ytd",
					"ALL" : "all",
					"LAST_THREE_MONTH" : "last3mnths",
					"LAST_MONTH" : "lastmonth",
					"THIS_MONTH" : "thismonth",
					"LAST_QUATER" : "lastQuarter",
					"THIS_WEEK" : "thisweek",
					"LAST_SIX_MONTHS" : "last6Months",
					"TOMORROW" : "tomorrow",
					"NEXT_MONTH" : "nextMonth",
					"ISSUANCE_PENDING" : "Issuance Pending",
					"CHEQUE_BOUNCE" : "Cheque Bounce",
					"PREMIUM_DUE" : "Premium Due"
				
				},
	"TIME_PERIOD" : {
					"LAST_SIX_MONTH" : "lastSixmonths",
					"LAST_THREE_MONTH" : "lastThreeMonths",
					"LAST_MONTH" : "lastMonth",
					"LAST_TWELVE_MONTH" : "last12Months",
					"LAST_YEAR" : "lastYear",
					"LAST_WEEK" : "lastWeek",
					"THIS_WEEK" : "thisWeek",
					"THIS_YEAR" : "thisYear",
					"THIS_QUATER" : "thisQuarter",
					"THIS_SIX_MONTH" : "thisSixMonths"
		
	},
	"SEARCH_OPTION" : {
	
					"MSIE" : "MSIE",
					"SAFARI" : "Safari",
					"PLAN_TYPE" : "Plan Type",
					"PROPOSAL_NUMBER" : "Proposal Number",
					"STATUS" : "Status",
					"PROPOSAL_RECEIVED_DATE" : "Proposal Received Date",
					"POLICY_STATUS" : "Policy Status",
					"PRODUCT_NAME" : "Product Name",
					"PREMIUM_FREQUENCY" : "Premium Frequency",
					"PREMIUM_AMOUNT" : "Premium Amount",
					"PREMIUM_DUE_DATE" : "Premium Due Date",
					"POLICY_ISSUE_DATE" : "Policy Issue Date",
					"MOBILE_NUMBER" : "Mobile Number",
					"CLIENT_ID" : "Client ID",
					"NAME" : "Name",
					"POLICY_NUMBER" : "Policy Number"
					
						},
	"MESSAGE" : {
							"SELF_SERVICE" : "Self Service",
							"CUSTOMER_SERVICE" : "Customer Service",
							"ALERTS" : "Alerts"
							
						},
	"MODULE_NAME" : {
					 "FEEDBACK" : "Feedback"
			
					},
	"TYPE" : {
		      "FEEDBACK":"Feedback"
			 },
	"DATA_WIPE_REASON" : {
          "ROOTED_DEVICE" : "RootedDevice",
          "UNAUTHORIZED_USER" : "UnAuthorizedUser",
          "BRUTE_FORCE_LOGIN" : "BruteForceLogin"
    }

}});  