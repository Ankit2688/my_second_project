﻿
//DataService for save,retrieve, sysn
angular.module('lifeEngage.dataService', []).factory("dataService", ['UserDetailsService',
						'$location',
						'$translate',
						'$rootScope',
						'$http', function (UserDetailsService, $location, $translate,
								$rootScope, $http) {
    var lifeEngage = new Object();

    lifeEngage.getTransactions = function (transactionObj, successCallback, errorCallback) {
	    var options = UserDetailsService.userDetilsModel.user;
        DbOperationsUtility.getTransactions(transactionObj, successCallback, function(data, status, message){
		    if(status=='401'){
				errorCallback();
			} else {
				errorCallback();
			}
		}, UserDetailsService.userDetilsModel.options.headers, $http);       
    };
    
    lifeEngage.saveTransactions = function (transactionObj, successCallback, errorCallback) {
    	
        DbOperationsUtility.saveTransactions(transactionObj, successCallback, errorCallback, UserDetailsService.userDetilsModel.options.headers, $http);       
    };
    
  lifeEngage.deleteTransactions = function (whereClause, successCallback, errorCallback) {
    	
        DbOperationsUtility.deleteTransactions(whereClause, successCallback, errorCallback);       
    };
    lifeEngage.saveObservations = function (transactionObj, successCallback, errorCallback) {
    	//var options = UserDetailsService.userDetilsModel.user;
	   if(UserDetailsService.userDetilsModel){
			var observeHeaders = UserDetailsService.userDetilsModel.options.headers;
	   }
	   DbOperationsUtility.saveObservations(transactionObj, successCallback, function(data, status){
		    if(status=='401'){
			    errorCallback();				
			} else {
				errorCallback();
			}
		}, observeHeaders, $http);              
    };
	lifeEngage.saveAgentProfile = function(
									transactionObj, successCallback,
									errorCallback) {
								DbOperationsUtility.saveAgentProfile(
										transactionObj, successCallback,
										errorCallback);
							};
	lifeEngage.retrieveAgentDetails = function(
    									transactionObj, successCallback,
    									errorCallback) {
    								DbOperationsUtility.retrieveAgentDetails(
    										transactionObj, successCallback,
    										errorCallback);
    							};
	lifeEngage.syncDataFromServer=function(type,successCallback,errorCallback){
	    var options = UserDetailsService.userDetilsModel.user;
		DbOperationsUtility.syncData(type,successCallback,function(data){
		    if(status=='401'){
				errorCallback();
			} else {
				errorCallback();
			}
		}, UserDetailsService.userDetilsModel.options.headers, $http); 
	};
	
	lifeEngage.syncDataToServer=function(type,successCallback,errorCallback,saveBandwidth,options){	   
		DbOperationsUtility.syncDataToServer(type,successCallback,errorCallback,saveBandwidth,options,UserDetailsService.userDetilsModel.options.headers);
	};
	lifeEngage.exportDataToExcel = function(transactionObj,successCallback, errorCallback){
		DbOperationsUtility.exportDataToExcel(transactionObj,successCallback, errorCallback);
	};

	lifeEngage.searchTransactions = function (transactionObj, successCallback, errorCallback){
	    //var options = UserDetailsService.userDetilsModel.user;
		 if(UserDetailsService.userDetilsModel){
				var searchHeaders = UserDetailsService.userDetilsModel.options.headers;
		   }else{
				var userDetilsModel = JSON.parse(sessionStorage.userDetails);
				var searchHeaders = userDetilsModel.options.headers;
				transactionObj.Key2 = userDetilsModel.user.userId;
		   }
		DbOperationsUtility.searchTransactions(transactionObj, successCallback, function(data, status){
		    if(status=='401'){
				errorCallback();
			} else {
				errorCallback();
			}
		}, searchHeaders, $http);
	};

	lifeEngage.retrieveLoggedInAgentIds=function(successCallback,errorCallback){
        DbOperationsUtility.retrieveLoggedInAgentIds(successCallback,errorCallback);
    };
    return lifeEngage;

}  ]);

