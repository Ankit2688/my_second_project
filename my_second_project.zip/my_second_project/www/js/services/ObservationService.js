angular.module('lifeEngage.ObservationService',[]).service("ObservationService", function ($http,PersistenceMapping,dataService) {  
	
	return {


	 store: function (data,scope) {
	    	var observationObject = ObservationObject();
	    	var transactionObj;
			observationObject.Observation.Page.Context = data.context;
			observationObject.Observation.Page.PageDesc = data.pageDesc;
			observationObject.Observation.CreatedOn = data.createdOn;
			observationObject.Observation.ModifiedOn = data.modifiedOn;
			observationObject.Observation.Customer = data.customer;
			observationObject.Observation.Email = data.email;
			observationObject.Observation.Agent = data.agent;			
			observationObject.Observation.SubOrdinateId = data.subOrdinateId;			
			observationObject.Observation.DeviceId = data.deviceId;
			observationObject.Observation.SubModule = data.subModule;
			observationObject.Observation.Module = data.module;
			observationObject.Observation.LoggedDate = data.loggedDate;
			observationObject.Observation.LoggedTime = data.loggedTime;
	        // Only insert is availabe for observation.
			PersistenceMapping.clearTransactionKeys();
			
			PersistenceMapping.Type  = "Observation";
			
			if(rootConfig.isDeviceMobile){
                      transactionObj =  PersistenceMapping.mapScopeToOfflinePersistance(observationObject);	
                      dataService.saveTransactions(transactionObj,function(data){},function(data){});
			}
			
			else{
				transactionObj =  PersistenceMapping.mapScopeToPersistence(observationObject);
				dataService.saveObservations(transactionObj,function(data){},function(data){});
			}
			

			
	    }
	}
	
});