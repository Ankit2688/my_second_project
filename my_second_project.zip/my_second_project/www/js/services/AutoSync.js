angular
		.module('lifeEngage.AutoSync', [])
		.factory(
				"AutoSync",
				function() {

					var AutoSync = {
						"SyncData" : function(dataService, $rootScope,
								appDataShareService, debounce, $scope,$timeout,PersistenceMapping,commonConfig) {
							
							
							var i = -1;
							var j = -1;
							var isSyncFailed = false;
							var appDataShareService = appDataShareService;
							$rootScope.isAutoSyncCompleted =  false;
							var deleteType =commonConfig().TRANSACTION_TYPE.OBSERVATION;
							var syncDataToServer = function() {
								
								alert("inside sync data to server..");
						
								$rootScope.lastSyncedDate ="";
								$rootScope.syncLabel = "Syncing Data";								
							
								if (j == (rootConfig.sycnToArray.length - 1)) {
									j = -1;
									var whereClause = "Type='" + deleteType + "'";
									dataService.deleteTransactions(whereClause,function(){
									
									},deleteOperationError);		
									syncDataFromServer();
									
								} else {
									
									j++;
									type = rootConfig.sycnToArray[j];			
									$rootScope.syncMessage = "Syncing " + (type.replace(/([A-Z]+)/g, ",$1").replace(/,/g , " "))+ " to server. please wait..";			
									var transactionObj = $scope.mapScopeToPersistance(type);			
									dataService.syncDataToServer(transactionObj,
											syncDataToServer, operationError,
											true, $rootScope);
								}
								
                            }

							$scope.$watch('appDataShareService', debounce(
									syncDataToServer,
									rootConfig.autoSyncTimeDelay), true);

							var syncDataFromServer = function() {
								if (i == (rootConfig.sycnArray.length - 1)) {
									i = -1;
									syncSuccessCallBack();
								} else {
									
									i++;
									var type = rootConfig.sycnArray[i];
									
									var transactionObj = mapScopeToPersistance(type);
									if (type == "MyEarnings") {
										transactionObj.TransactionData = {
											"searchCriteria" : {
												"type" : "compensation Schemes"
											}
										};
									}
									dataService.syncDataFromServer(
											transactionObj, syncDataFromServer,
											operationError);
								}
							}

							var mapScopeToPersistance = function(type) {
								

								var updatedDate = new Date();
								var formattedDate = Number(updatedDate.getMonth() + 1) + "-"
										+ updatedDate.getDate() + "-" + updatedDate.getFullYear();
                               
								
								PersistenceMapping.clearTransactionKeys();
                                
								if(type == commonConfig().TRANSACTION_TYPE.OBSERVATION){
									
									
									PersistenceMapping.Key11 = appDataShareService.selectedUser.userId;
									PersistenceMapping.Key13 = formattedDate;
									PersistenceMapping.Key14 = formattedDate;
									
									

									
								}else{
									
									PersistenceMapping.Key1 = appDataShareService.selectedUser.userId;
									PersistenceMapping.Key4 = formattedDate;
									PersistenceMapping.Key5 = formattedDate;
									
									if(type == commonConfig().TRANSACTION_TYPE.HIERARCHY_DETAILS){
											
										PersistenceMapping.TransactionData = {};
									}
									else{
										PersistenceMapping.TransTrackingID = "";	
									}
								}
								 PersistenceMapping.Type = type;
								var transactionObj =  PersistenceMapping.mapScopeToPersistence({});
								return transactionObj;
								
								
							
							}

							var operationError = function(message) {

								isSyncFailed = true;
								if (i == (rootConfig.sycnArray.length - 1)) {
									$rootScope.isAutoSyncCompleted =  true;
									$rootScope.syncLabel = "Syncing failed ";
									$scope.$apply();
																											
									$timeout(function(){
										if($rootScope.lastSuccessSyncDate == ""){											
											$rootScope.syncLabel = "Syncing failed "											
										}
										else{
											$rootScope.syncLabel = "Last synced on : ";	
											$rootScope.lastSyncedDate = $rootScope.lastSuccessSyncDate;											
										}
										
								  }, 3000);
									var lastSyncDetails = {'syncLabel': $rootScope.syncLabel, 'lastSyncedDate': $rootScope.lastSyncedDate};
									localStorage.setItem(getUniqueAppNamePattern(commonConfig().STORAGE.LAST_SYNCED), JSON.stringify(lastSyncDetails));
									i = -1;

								}
								else{
									syncDataFromServer();
								}
								$scope.$apply();							
							}

							
							 var deleteOperationError =  function(message){
								console.log("error while deleting transactions");
							}
							var syncSuccessCallBack = function() {

                                  if(isSyncFailed){									
									$timeout(function(){
										$rootScope.syncLabel = "Syncing failed "}, 30000);
									if($rootScope.lastSuccessSyncDate == ""){
										$rootScope.syncLabel = "Syncing failed "
									}
									else{
										$rootScope.syncLabel = "Last synced on : ";	
										$rootScope.lastSyncedDate = $rootScope.lastSuccessSyncDate;
									}									
																}
								else{									
									$rootScope.lastSyncedDate = Date.now();//"Last synched on : ";
									$rootScope.syncLabel = "Last synced on : ";
								}
								$rootScope.isAutoSyncCompleted =  true;
								var lastSyncDetails = {'syncLabel': $rootScope.syncLabel, 'lastSyncedDate': $rootScope.lastSyncedDate};
								localStorage.setItem(getUniqueAppNamePattern(commonConfig().STORAGE.LAST_SYNCED), JSON.stringify(lastSyncDetails));
								$scope.$apply();								
							}
						}
					}
					return AutoSync;
				});
