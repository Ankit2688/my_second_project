//DataService for save,retrieve, sysn
angular
		.module('lifeEngage.UtilityService', [])
		.factory(
				"UtilityService",
				function($http, PersistenceMapping, $rootScope,commonConfig) {
					var utilityService = new Object();

					var disableProgressTab = false;

					utilityService.initiateThemeChange = function(theme) {
						switch (theme) {

						case 'MainTheme':
							$('link[href="css/abc-theme/css/styles.css"]')
									.attr('href',
											'css/main-theme/css/styles.css');
							$rootScope.theme = "mainTheme";

							break;
						case 'ABCTHEME':
							$('link[href="css/main-theme/css/styles.css"]')
									.attr('href',
											'css/abc-theme/css/styles.css');
							$rootScope.theme = "abcTheme";
							break;

						default:
							break;
						// Do nothing
						}
					};
					
						utilityService.InitializeErrorDisplay = function($scope,
							$rootScope, $translate) {
						$scope.showErrorCount = true;
						$scope.updateErrorCountWhileAddOrRemove = function(id) {
							$rootScope.updateErrorCount(id);
						};
						$scope.focusErrorField = function(errorMessage) {
							$scope.isPopupDisplayed = false;
							$('#' + errorMessage).focus();
						};
						$rootScope.showErrorPopup = function(id, e) {
							if ($scope.isPopupDisplayed) {
								$scope.isPopupDisplayed = false;
							} else {
								$scope.errorMessages = [];
								$scope.isPopupDisplayed = true;
								var i = 0;

								var id1 = Array.prototype.slice
										.call(document
												.querySelector('#' + id)
												.querySelectorAll(
														".trueRequired:not([class*='ng-hide'])"));
								var id2 = Array.prototype.slice
										.call(document
												.querySelector('#' + id)
												.querySelectorAll(
														".truePattern:not([class*='ng-hide'])"));
								id1 = id1.concat(id2);
								id1
										.forEach(function(elemen) {
											var error = {};
											error.message = translateMessages(
													$translate,
													elemen
															.getAttribute('errormessage'));
											error.key = elemen
													.getAttribute('errorkey');
											$scope.errorMessages.push(error);
										});
								var id3 = Array.prototype.slice
										.call(document
												.querySelector('#' + id)
												.querySelectorAll(
														".trueValid:not([class*='ng-hide'])"));
								id3
										.forEach(function(elemen) {
											var error = {};
											var messageTemp = translateMessages(
													$translate,
													elemen
															.getAttribute('errormessage'));
											var maxLength = translateMessages(
													$translate,
													elemen
															.getAttribute('maxlength'));
											var minLength = translateMessages(
													$translate,
													elemen
															.getAttribute('minlength'));
											/*var unit = elemen
													.getAttribute('unit');
											var unitModel = unit.replace(
													/FNAObject/g,
													"$scope.FNAObject");*/
											var min;
											var max;
											/*if (eval(unitModel) != "NA") {
												min = Number(minLength)
														/ Number($scope.unitList[eval(unitModel)]);
												max = Number(maxLength)
														/ Number($scope.unitList[eval(unitModel)]);
												error.message = messageTemp
														+ ' ' + min + ' and'
														+ ' ' + max
														+ eval(unitModel);
											} else {*/
												min = Number(minLength) + 1;
												max = maxLength;
												error.message = messageTemp
														+ ' ' + min + ' and'
														+ ' ' + max;
											//}
											error.key = elemen
													.getAttribute('errorkey');
											$scope.errorMessages.push(error);

										});
								if ($scope.dynamicErrorMessages
										&& $scope.dynamicErrorMessages.length > 0) {
									for ( var i = 0; i < $scope.dynamicErrorMessages.length; i++) {
										$scope.errorMessages
												.push($scope.dynamicErrorMessages[i]);
									}
								}
								if ($scope.dynamicErrorMessagesFund
										&& $scope.dynamicErrorMessagesFund.length > 0) {
									for ( var i = 0; i < $scope.dynamicErrorMessagesFund.length; i++) {
										$scope.errorMessages
												.push($scope.dynamicErrorMessagesFund[i]);
									}
								}
							}
						};
						$rootScope.updateErrorCount = function(id,
								isExplicitCall) {
							var id1 = Array.prototype.slice
									.call(document
											.querySelector('#' + id)
											.querySelectorAll(
													".trueRequired:not([class*='ng-hide'])"));
							var id2 = Array.prototype.slice
									.call(document
											.querySelector('#' + id)
											.querySelectorAll(
													".truePattern:not([class*='ng-hide'])"));
							var id3 = Array.prototype.slice
									.call(document
											.querySelector('#' + id)
											.querySelectorAll(
													".trueValid:not([class*='ng-hide'])"));
							if ($scope.dynamicErrorCountFund != null
									&& $scope.dynamicErrorCount != null) {
								$scope.errorCount = id1.length + id2.length
										+ id3.length
										+ $scope.dynamicErrorCountFund
										+ $scope.dynamicErrorCount;
							} else if ($scope.dynamicErrorCount != null
									|| $scope.dynamicErrorCount != undefined) {
								$scope.errorCount = id1.length + id2.length
										+ id3.length + $scope.dynamicErrorCount;
							} else if ($scope.dynamicErrorCountFund != null) {
								$scope.errorCount = id1.length + id2.length
										+ id3.length
										+ $scope.dynamicErrorCountFund;
							} else {
								$scope.errorCount = id1.length + id2.length
										+ id3.length;
							}
							if ($scope.isPopupDisplayed) {
								if (isExplicitCall) {
									$scope.isPopupDisplayed = $scope.isPopupDisplayed;
								} else {
									$scope.isPopupDisplayed = false;
								}
							}
						};
					};
					
					
					/*Methods to replace eval - start*/
					utilityService.evaluateString = function(value, $scope) {
					    var val;

					    var variableValue = $scope;
					    if (value.indexOf('.') != -1) {
					        val = value.split('.');
					        if (val[0] == '$scope' || val[0] == 'scope') {
					            val.shift();
					        }
					        for (var i in val) {
								if(typeof variableValue != 'undefined'){
									if (val[i].indexOf('[') != -1) {
										var indexValue = val[i].substring(val[i].indexOf('[') + 1, val[i].indexOf(']'));
										var arrayObject = val[i].split('[');
										if (variableValue[arrayObject[0]].hasOwnProperty(indexValue)) {
											variableValue = variableValue[arrayObject[0]][indexValue];
										} else if (!$.isNumeric(value) && typeof $scope[indexValue] != 'undefined') {
											var indexEval = $scope[indexValue];
											variableValue = variableValue[arrayObject[0]][indexEval];
										} else {
											variableValue = variableValue[arrayObject[0]][indexValue];
										}

									} else {
										variableValue = variableValue[val[i]];
									}
								}
					        }
					    } else {
					        variableValue = value;
					    }
					    return variableValue;
					};
				
					utilityService.evaluateModelValueFromString = function($scope, modelName, start, end, init) {
					    var variableName = modelName;
					    var evaluatedData;
					    var chk = false;
					    while (modelName.indexOf('[', start) != -1) {
					        start = modelName.indexOf('[', start);
					        end = modelName.indexOf(']', end + 1);
					        var value = modelName.substring(start, end + 1);
					        var startingCount = (value.match(/\[/g) || []).length;
					        var closingCount = (value.match(/\]/g) || []).length;
					        variableName = value;
					        if (startingCount == closingCount) {
					            variableName = variableName.substring(1, variableName.length - 1);
					            returnedData = utilityService.evaluateModelValueFromString($scope, variableName, 0, 0, false);
					            modelName = modelName.substring(0, start + 1) + String(returnedData) + modelName.substring(end, modelName.length + 1);
					            variableName = modelName;
					            start = modelName.indexOf(']', start);
					            end = start + 1;

					        } else {
					            variableName = utilityService.evaluateModelValueFromString($scope, modelName, start, end, init);
					            evaluatedData = variableName;
					            chk = true;
					            break;
					        }
					    }

					    if (init) {
					        evaluatedData = variableName;
					    } else {
					        if (!chk) {
					            evaluatedData = utilityService.evaluateString(variableName, $scope);
					        }
					    }

					    return evaluatedData;
					};
					//Method to evaluate value from model(model name is passed as string)
					utilityService.evaluateModel = function($scope,model){
						var modelArray = model.split('.');
						if(modelArray.length == 1 || ((modelArray[0] == '$scope' || modelArray[0] == 'scope') &&  modelArray.shift().length == 1)){
							return $scope[modelArray[0]];
						} else {
							return utilityService.evaluateModelValueFromString($scope,model,0,0,false);
						}
					};
					//Method to assign value to model (model name is passed as string)
					utilityService.bindModel = function($scope, model, value) {
					    var variable = utilityService.evaluateModelValueFromString($scope, model, 0, 0, true);
					    var _lastIndex = variable.lastIndexOf('.');
					    var parentModel;
					    var remain_parentModel;
					    if (typeof variable != 'undefined' && _lastIndex > 0) {
					        parentModel = variable.substring(0, _lastIndex);
					        parentModel = utilityService.evaluateModelValueFromString($scope, parentModel, 0, 0, false);
					        remain_parentModel = variable.substring(_lastIndex + 1, variable.length);
					        if (remain_parentModel.indexOf('[') != -1) {
					            var indexValue = remain_parentModel.substring(remain_parentModel.indexOf('[') + 1, remain_parentModel.indexOf(']'));
					            var arrayObject = remain_parentModel.split('[');
					            if (parentModel[arrayObject[0]].hasOwnProperty(indexValue)) {
					                parentModel[arrayObject[0]][indexValue] = value;
					            } else if (!$.isNumeric(value) && typeof $scope[indexValue] != 'undefined') {
					                parentModel[arrayObject[0]][$scope[indexValue]] = value;
					            } else {
					                parentModel[arrayObject[0]][indexValue] = value;
					            }

					        } else {
					            parentModel[remain_parentModel] = value;
					        }
					    } else {
					    	if(typeof variable != 'undefined' && $scope[variable]){
					    		$scope[variable] = value;
					    	}
					    	
					    }
					};
					/*Methods to replace eval - end*/
					
					return utilityService;

				});


