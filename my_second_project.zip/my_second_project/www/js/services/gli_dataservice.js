/*
*GLI specific dataservices
*/
angular.module('lifeEngage.gli_dataservice', []).factory("gli_dataservice", ['UserDetailsService',
						'$location',
						'$translate',
						'$rootScope',
						'dataService',
						'$http', function (UserDetailsService, $location, $translate,
								$rootScope, dataService, $http) {

   dataService['getTransactions'] = function (transactionObj, successCallback, errorCallback) {
            DbOperationsUtility.getTransactions(transactionObj, successCallback, function(data, status, message){
    		    if(status=='401'){
    				errorCallback();
    			} else {
    				errorCallback();
    			}
    		}, $http);
        };

    return dataService;

}  ]);