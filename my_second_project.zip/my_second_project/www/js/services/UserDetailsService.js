angular.module('lifeEngage.UserDetailsService',[]).service("UserDetailsService",function($http) {
            var UserDetailsService = {
                "userDetilsModel" : "",
                "getUserDetailsModel" : function() {
                    if (!UserDetailsService.userDetilsModel) {
                        userDetailsObj = new UserDetailsObject();
                        if (rootConfig.isDeviceMobile) {
                            userDetailsObj.options.headers.source = "200";
                        } else {
                            userDetailsObj.options.headers.source = "100";
                        }
                        return userDetailsObj;
                    } else {
                        var userDetilsModelObj = JSON
                                .stringify(UserDetailsService.userDetilsModel);
                        return JSON.parse(userDetilsModelObj);
                    }
                },
                "setUserDetailsModel" : function(value) {
                    UserDetailsService.userDetilsModel = value;
                }
            };
            return UserDetailsService;

        });