/*
 * Services for mapping the keys of the transaction Object from service and to the service
 */
angular.module('lifeEngage.PersistenceMapping',[]).factory("PersistenceMapping", function ($http,$rootScope,commonConfig,UserDetailsService) {

    var PersistenceMapping = {
            //"Id":"",
    		"Key1"  : "",
    		"Key2"  : "",
    		"Key3"  : "",
    		"Key4"  : "",
    		"Key5"  : "",
    		"Key6"  : "",
    		"Key7"  : "",
    		"Key8"  : "",
     		"Key9"  : "",
    		"Key10" : "",
    		"Key11" : "",
    		"Key12" : "",
    		"Key13" : "",
    		"Key14" : "",
    		"Key15" : "",
    		"Key16" : "",
    		"Key17" : "",
    		"Key18" : "",
    		"Key19" : "",
    		"Key20" : "",
    		"Key21" : "",
    		"Key22" : "",
    		"Key23" : "",
    		"Key24" : "",
    		"Key25" : "",
            "Key26" : "",
    		"Key27" : "",
    		"Key28" : "",
    		"Key29" : "",
    		"Key30" : "",
    		"Type"  : "",
    		"TransactionId"   : "",
    		"TransTrackingID" : "",
    		"filter" : "",
    		"transactionData" : {},
    		"dataIdentifyFlag" : true,
    		"mapScopeToPersistence" : function(data) {
    			var transactionData = angular.copy(data);
    			var formattedDate =  getFormattedDate();
    			var transactionObj = {};
    			 if (rootConfig.isDeviceMobile && PersistenceMapping.Type =="SetGoals" ) {
			            transactionObj.Id = $rootScope.transactionId != null && $rootScope.transactionId != 0 ? $rootScope.transactionId : null;
			           if(PersistenceMapping.dataIdentifyFlag){
			            	transactionObj.TransactionData = angular.toJson(transactionData);
			            }else{
			            	transactionObj.TransactionData = transactionData;
			            }
			        } else {
			            transactionObj.TransTrackingID = PersistenceMapping.TransTrackingID;
			            transactionObj.TransactionData = transactionData;
			        }
    			 	transactionObj.Type  = PersistenceMapping.Type;
    			 	//transactionObj.Id  = PersistenceMapping.Id;
    				transactionObj.Key1  = PersistenceMapping.Key1;
    				transactionObj.Key2  = PersistenceMapping.Key2;
    				transactionObj.Key3  = PersistenceMapping.Key3;
    				transactionObj.Key4  = PersistenceMapping.Key4;
    				transactionObj.Key5  = PersistenceMapping.Key5;
    				transactionObj.Key6  = PersistenceMapping.Key6;
    				transactionObj.Key7  = PersistenceMapping.Key7;
    				transactionObj.Key8  = PersistenceMapping.Key8;
    				transactionObj.Key9  = PersistenceMapping.Key9;
    				transactionObj.Key10 = PersistenceMapping.Key10;
                    if(transactionData && transactionData.Observation && transactionData.Observation.Agent){
    				transactionObj.Key11 = transactionData.Observation.Agent; //AgentId is hardcoded
                    }
    				transactionObj.Key12 = PersistenceMapping.Key12;
    				if(PersistenceMapping.Type =="Observation"){
    					transactionObj.Key13 = formattedDate;
    					delete transactionObj.Id;
    				}
    			    transactionObj.Key14 = formattedDate;
    				transactionObj.Key15 = PersistenceMapping.Key15;
    				transactionObj.Key16 = PersistenceMapping.Key16;
    				transactionObj.Key17 = PersistenceMapping.Key17;
    				transactionObj.Key18 = PersistenceMapping.Key18;
    				transactionObj.Key19 = PersistenceMapping.Key19;
    				transactionObj.Key20 = PersistenceMapping.Key20;
    				transactionObj.Key21 = PersistenceMapping.Key21;
    				transactionObj.Key22 = PersistenceMapping.Key22;
    				transactionObj.Key23 = PersistenceMapping.Key23;
    				transactionObj.Key24 = PersistenceMapping.Key24;
    				transactionObj.Key25 = PersistenceMapping.Key25;
                    transactionObj.Key26 = PersistenceMapping.Key26;
    			    transactionObj.Key27 = PersistenceMapping.Key27;
    			    transactionObj.Key28 = PersistenceMapping.Key28;
    			    transactionObj.Key29 = UserDetailsService.userDetilsModel.user.rexitLoginId;
    			    transactionObj.Key30 = PersistenceMapping.Key30;

    			    return transactionObj;
    		},
    		"clearTransactionKeys"  : function(){

    			PersistenceMapping.Key1  = "",
    			PersistenceMapping.Key2  = "",
    			PersistenceMapping.Key3  = "",
    			PersistenceMapping.Key4  = "",
    			PersistenceMapping.Key5  = "",
    			PersistenceMapping.Key6  = "",
    			PersistenceMapping.Key7  = "",
    			PersistenceMapping.Key8  = "",
    			PersistenceMapping.Key9  = "",
    			PersistenceMapping.Key10 = "",
    			PersistenceMapping.Key11 = "",
    			PersistenceMapping.Key12 = "",
    			PersistenceMapping.Key13 = "",
    			PersistenceMapping.Key14 = "",
    			PersistenceMapping.Key15 = "",
    			PersistenceMapping.Key16 = "",
    			PersistenceMapping.Key17 = "",
    			PersistenceMapping.Key18 = "",
    			PersistenceMapping.Key19 = "",
    			PersistenceMapping.Key20 = "",
    			PersistenceMapping.Key21 = "",
    			PersistenceMapping.Key22 = "",
    			PersistenceMapping.Key23 = "",
    			PersistenceMapping.Key24 = "",
    			PersistenceMapping.Key25 = "",
                PersistenceMapping.Key26 = "",
    			PersistenceMapping.Key27 = "",
    			PersistenceMapping.Key28 = "",
    			PersistenceMapping.Key29 = "",
    			PersistenceMapping.Key30 = "",
    			PersistenceMapping.Type = "",
    			PersistenceMapping.TransactionId  = "",
    			PersistenceMapping.TransTrackingID = "",
    			PersistenceMapping.filter = "",
    			PersistenceMapping.dataIdentifyFlag = true
    		},
			
			"getFormattedDate" : function() {
							now = new Date();
							year = "" + now.getFullYear();
							month = "" + (now.getMonth() + 1);
							if (month.length == 1) {
								month = "0" + month;
							}
							day = "" + now.getDate();
							if (day.length == 1) {
								day = "0" + day;
							}
							hour = "" + now.getHours();
							if (hour.length == 1) {
								hour = "0" + hour;
							}
							minute = "" + now.getMinutes();
							if (minute.length == 1) {
								minute = "0" + minute;
							}
							second = "" + now.getSeconds();
							if (second.length == 1) {
								second = "0" + second;
							}
							return year + "-" + month + "-" + day + " " + hour
									+ ":" + minute + ":" + second;
						},
    		
    		"mapScopeToOfflinePersistance" : function(data) {
    			var transactionData = angular.copy(data);
    			var updatedDate = new Date();
    			var formattedDate = getFormattedDate();
    			var transactionObj = {};
    			transactionObj.Id = "";
    			transactionObj.Key1 = transactionData.Observation.Agent;
    			transactionObj.Key2 = PersistenceMapping.Key2;
    			transactionObj.Key3 = PersistenceMapping.Key3;
    			transactionObj.Key4 = formattedDate;
    			transactionObj.Key5 = formattedDate;
    			transactionObj.Key6 = PersistenceMapping.Key6;
    			transactionObj.Key7 = commonConfig().STATUS.SAVED;
    			transactionObj.Key8 = PersistenceMapping.Key8;
    			transactionObj.Key9 = PersistenceMapping.Key9;
    			transactionObj.Key10 = "FullDetails";
    			transactionObj.Type =  PersistenceMapping.Type;
    			transactionObj.TransTrackingID = "";
                transactionObj.Key11 =  PersistenceMapping.Key11;
    			transactionObj.Key12 =  PersistenceMapping.Key12;
    			transactionObj.Key13 =  PersistenceMapping.Key13;
    			transactionObj.Key14 =  PersistenceMapping.Key14;
    			transactionObj.Key15 =  PersistenceMapping.Key15;
    			transactionObj.Key16 =  PersistenceMapping.Key16;
    			transactionObj.Key17 =  PersistenceMapping.Key17;
    			transactionObj.Key18 =  PersistenceMapping.Key18;
    			transactionObj.Key19 =  PersistenceMapping.Key19;
    			transactionObj.Key20 =  PersistenceMapping.Key20;
    			transactionObj.Key21 =  PersistenceMapping.Key21;
    			transactionObj.Key22 =  PersistenceMapping.Key22;
    			transactionObj.Key23 =  PersistenceMapping.Key23;
    			transactionObj.Key24 =  PersistenceMapping.Key24;
    			transactionObj.Key25 =  PersistenceMapping.Key25;
                transactionObj.Key26 =  PersistenceMapping.Key26;
    			transactionObj.Key27 =  PersistenceMapping.Key27;
    			transactionObj.Key28 =  PersistenceMapping.Key28;
    			transactionObj.Key29 =  PersistenceMapping.Key29;
    			transactionObj.Key30 =  PersistenceMapping.Key30;
    			if (rootConfig.isDeviceMobile) {
    			transactionObj.Id = null;//$rootScope.transactionId != null
    						//&& $rootScope.transactionId != 0 ? $rootScope.transactionId
    						//: null;
    				transactionObj.TransactionData = angular.toJson(transactionData);
    			} else {
    				transactionObj.TransTrackingID = "";
    				transactionObj.TransactionData = transactionData;
    			}
    			return transactionObj;
    		}
    }
	 return PersistenceMapping;
});
