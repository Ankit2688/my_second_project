//var debounce = angular.module('lifeEngage.debounce', []);angular.module('lifeEngage.AutoSync',[]).factory("AutoSync", function () {
//Returns a function, that, as long as it continues to be invoked, will not
//be triggered. The function will be called after it stops being called for
//N milliseconds. If `immediate` is passed, trigger the function on the
//leading edge, instead of the trailing.

angular.module('lifeEngage.debounce',[]).factory('debounce', ['$timeout','$q', function($timeout, $q) {
	  // The service is actually this function, which we call with the func
	  // that should be debounced and how long to wait in between calls
	  return function debounce(func, wait, immediate) {
	    var timeout;
	    // Create a deferred object that will be resolved when we need to
	    // actually call the func
	    var deferred = $q.defer();
	  
	   
	    return function () {
	   
	      var context = this, args = arguments;
	  	
	      var later = function() {
	        timeout = null;
	        if(!immediate) {
	          deferred.resolve(func.apply(context, args));
	          deferred = $q.defer();
	        }
	      };
	      var callNow = immediate && !timeout;
	      if ( timeout ) {
	        $timeout.cancel(timeout);
	      }
	      timeout = $timeout(later, wait);
	      if (callNow) {
	        deferred.resolve(func.apply(context,args));
	        deferred = $q.defer();
	      }
	      return deferred.promise;
	    };
	  };
	}]);