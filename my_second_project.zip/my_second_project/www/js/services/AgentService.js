﻿//DataService for agentprofile
angular
		.module('lifeEngage.AgentService', [])
		.factory(
				"AgentService",
				[
						'UserDetailsService',
						'$http',
						function(UserDetailsService, $http) {
							var agentService = new Object();
							try {
								agentService.retrieveAgentProfileOnline = function(transactionObj, successCallback,
										errorCallback) {
									agentServiceUtility.retrieveAgentProfileOnline(transactionObj, successCallback,
											errorCallback, UserDetailsService.getUserDetailsModel().options, $http);
								};
									
									agentService.retrieveAgentProfileOffline = function(transactionObj, successCallback,
											errorCallback) {
										agentServiceUtility.retrieveAgentProfileOffline(transactionObj, successCallback,
												errorCallback, UserDetailsService.getUserDetailsModel().options, $http);
											
								};
								} catch (e) {
								alert(e);
							}
							return agentService;
						} ]);