﻿

//DataService for save,retrieve, sysn
angular.module('lifeEngage.authService', []).factory("authService",['UserDetailsService','$location','$translate','$rootScope','$http', function (UserDetailsService, $location, $translate, $rootScope, $http) {
    var authService = new Object();

    authService.login = function (user, successCallback, errorCallback) {
        authServiceUtility.login(user, successCallback, errorCallback, $http);       
    };
    authService.getUserDetails = function (user, successCallback, errorCallback) {
        authServiceUtility.getUserDetails(user, successCallback, errorCallback);       
    };
     authService.getHierarchyDetails = function (transObj, successCallback, errorCallback) {
	    var options = UserDetailsService.user;	 
        authServiceUtility.getHierarchyDetails(transObj, successCallback, function(data){
		    if(status=='401'){
				errorCallback();
			} else {
				errorCallback();
			}
		}, UserDetailsService.userDetilsModel.user, $http);            
    };
    authService.logout = function (user, successCallback, errorCallback) {
        authServiceUtility.logout(user, successCallback, errorCallback);
    };

    authService.isLoggedIn = function (user) {
       return authServiceUtility.isLoggedIn(user);
    };
    authService.authorize = function (accessLevel, role) {
       return authServiceUtility.authorize(accessLevel, role);
    };
    authService.getSyncDriveAppRole = function (user,successCallback,errorCallback) {
       return authServiceUtility.getSyncDriveAppRole(user,successCallback,errorCallback);
    };
    authService.fetchKey = function(user,successCallback,errorCallback) {
       return authServiceUtility.fetchKey(user,successCallback,errorCallback,$http);
    };
    return authService;

}]);

