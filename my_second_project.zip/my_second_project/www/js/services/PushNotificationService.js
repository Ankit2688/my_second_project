var PushNotificationService;
(function() {
 PushNotificationService = {
 registerdevice : function(transactionObj, successcallback, errorcallback) {
 var getUrl = rootConfig.registerDeviceUrl;
 var requestInfo = Request();
 requestInfo.Request.RequestPayload.Transactions
     .push(transactionObj);
 $.ajax({
        type : "POST",
        crossDomain : true,
        url : getUrl,
        data : angular.toJson(requestInfo),
        contentType : "application/json; charset=utf-8",
        dataType : "json",
        success : function(data, status) {
        successcallback("Push Notification Success :----- " + data.Response.ResponsePayload.Transactions);
        },
        error : function(error) {
        errorcallback("Push Notification Error :----- "
                      + angular.toJson(error));
        }
        });
 
 },
 unRegisterdevice : function(request, successcallback, errorcallback) {
 var getUrl = rootConfig.serviceBaseUrl+"mServiceRegisterDevice?DeviceUserID="+DeviceUserID+"&MobileAppBundleID="+request.MobileAppBundleID;
 //http://54.251.248.74:4090/mServiceRegisterDevice?DeviceUserID="+DeviceUserID+"&MobileAppBundleID="+request.MobileAppBundleID;
 $.ajax({
        type : "DELETE",
        crossDomain : true,
        url : getUrl,
        data : angular.toJson(request),
        contentType : "application/json",
        dataType : "json",
        success : function(data, status) {
        successcallback("Push Notification UnRegister Success :----- " + data.message);
        },
        error : function(error) {
        errorcallback("Push Notification UnRegister Error :----- " + angular.toJson(error));
        }
        });
 }
 }
 return PushNotificationService;
 })();
