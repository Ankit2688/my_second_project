angular.module('lifeEngage.GLI_ObservationService',[]).service("GLI_ObservationService", function ($http,PersistenceMapping,dataService) {
	
	return {


	 store: function (data,scope) {
	    	var observationObject = ObservationObject();
	    	var transactionObj;
			observationObject.Observation.Page.Context = data.context;
			observationObject.Observation.Page.PageDesc = data.pageDesc;
			observationObject.Observation.CreatedOn = data.createdOn;
			observationObject.Observation.ModifiedOn = data.modifiedOn;
			observationObject.Observation.Customer = data.customer;
			observationObject.Observation.Email = data.email;
			observationObject.Observation.Agent = data.agent;			
			observationObject.Observation.SubOrdinateId = data.subOrdinateId;			
			observationObject.Observation.DeviceId = data.deviceId;
			observationObject.Observation.DeviceInfo = data.deviceInfo;
			observationObject.Observation.SubModule = data.subModule;
			observationObject.Observation.Module = data.module;
			observationObject.Observation.LoggedDate = data.loggedDate;
			observationObject.Observation.LoggedTime = data.loggedTime;
	        // Only insert is availabe for observation.
			PersistenceMapping.clearTransactionKeys();
			
			PersistenceMapping.Type  = "Observation";
			var formattedDate = getFormattedDate();
            var formattedTime = getFormattedTime();
				transactionObj =  PersistenceMapping.mapScopeToPersistence(observationObject);
				transactionObj.Key13 = formattedDate + " " + formattedTime;
				transactionObj.Key14 = formattedDate + " " + formattedTime;
				dataService.saveObservations(transactionObj,function(data){},function(data){});
	    }
	}
	
});