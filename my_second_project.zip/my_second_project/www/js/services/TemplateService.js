//TemplateService for compiling HTML templates
angular.module('lifeEngage.TemplateService', []).factory("TemplateService",['$http', function($http) {
	var templateService = new Object();
	templateService.createHtmlTemplate = function(templateName, JSONObject, successCallback, errorCallback) {
			if (rootConfig.isPrecomiledTemplate) {
					var compiledTemplate = Handlebars.templates['lePreCompiledEmailTemplate'];
					var compiledOutput = compiledTemplate(JSONObject);
					successCallback(compiledOutput);
			} else {
				$.get( templateName , function(respData) {
					 var template = Handlebars.compile(respData);
					 var compiledOutput = template(JSONObject);
					 successCallback(compiledOutput);
				 });
				}
	};
	return templateService;
}]);