/*
Name:baseCtrl
CreatedDate:17/03/2014 
Description:parent controller.
*/
mServiceApp.controller('BaseCtrl',['$rootScope', '$scope','dataService','type','userId','PersistenceMapping',function($rootScope, $scope,dataService,type,userId,PersistenceMapping) {
	
//function BaseCtrl($scope,$rootScope,dataService,type,userId) {
	var _this = this;
	this.Type = type;
	this.UserId = userId;
	 
    this.getTransactions = function(successCallback, errorCallback,transactionObj) {	 
		 
	 
		if (!(transactionObj && typeof transactionObj != "function")) {
		 
           transactionObj = this.mapScopeToPersistance();
        }
        if (!(successCallback && typeof successCallback == "function")) {
            successCallback = $scope.onSaveSuccess;
        }
        if (!(errorCallback && typeof errorCallback == "function")) {
            errorCallback = $scope.onSaveError;
        }
	 
        //Call the angular service for getTransactions.
        //For offline it will invoke the getTransactions implemented in dataservice-mobile.js
        //For online it will invoke the getTransactions implemented in dataservice-desktop.js
        dataService.getTransactions(transactionObj, successCallback, errorCallback);
	};
	
	/**
	 * For Creating the transaction object by assigning the scope variable to transactionObj
	 * Key1 = agentId or userId
	 * Key2 = ssoID
	 * Key3 - Key10 = For future extension
	 * Type = Module Type
	 */
    this.mapScopeToPersistance = function () {
	var newDate = new Date();
        
	    PersistenceMapping.clearTransactionKeys();
        PersistenceMapping.Key1 = this.UserId != null ? this.UserId : "1";
       /* PersistenceMapping.Key2 = "12345";
        PersistenceMapping.Key5 = "Agent";*/
        PersistenceMapping.Key10 = "FullDetails";
        PersistenceMapping.Type = _this.Type;
        var transactionObj =  PersistenceMapping.mapScopeToPersistence({});
        return transactionObj;
    };
    
 
    //For mapping service out put to scope variables
    this.mapPersistenceToScope = function (dbObject) {
    	
        $rootScope.customerId = dbObject[0].Key1;
        $rootScope.agentId = dbObject[0].Key2;
        if (rootConfig.isDeviceMobile) {
		    $rootScope.transactionId = dbObject[0].Id;             
        }        
    };
}]);