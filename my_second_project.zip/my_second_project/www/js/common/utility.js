$(document).ready(function() {
	if (!rootConfig.isDeviceMobile){
		if(window.matchMedia('(max-width: 800px)').matches){
			$('body').attr('id','mobile-touch-device');
		}
		else{
			$('body').attr('id','');
		}
		
	}
	$(window).resize(function(){
		updateResponsiveDesign();
	});

	function updateResponsiveDesign(){
		if (!rootConfig.isDeviceMobile){
			var chkOpen = $('.slider_menu').hasClass("isOpen");    
			$('.slider_menu').removeClass("isOpen bx_shadow");
			$('#fade').css("display","none");  
			$("body").removeClass("hide_scroll"); 
			$('.subList').removeClass("show");
			$('.dropdownLink').removeClass("open");
			
			if(window.matchMedia('(max-width: 800px)').matches){
				$('body').attr('id','mobile-touch-device');
				$('.slider_menu').css('left','-275px');
			}
			else{
				$('body').attr('id','');
				$('.slider_menu').animate({left:'0px'},300);                             
				
			}
			
		}
	};
	if (rootConfig.isDeviceMobile){
		$('body').addClass('device-mobile-tab');

		if (/webOS|iPhone|iPad/i.test(navigator.userAgent)) {
			$('body').addClass('ios');
			$(document).on('focus', 'input:not([type="radio"]):not([type="checkbox"])', function() {
				$('.navbar-fixed-top').removeClass('animated fadeInCustom');
				$('.navbar-fixed-top').css('position', 'absolute');
				$('.sync-time').removeClass('animated fadeInCustom');
				$('.sync-time').css('position', 'static');					
			});		
			$(document).on('blur', 'input:not([type="radio"]):not([type="checkbox"])', function() {
				$('.navbar-fixed-top').addClass('animated fadeInCustom');
				$('.navbar-fixed-top').css('position', 'fixed');
				$('.sync-time').addClass('animated fadeInCustom');
				$('.sync-time').css('position', 'fixed');					
				setTimeout(function() {				
					window.scrollTo(document.body.scrollLeft, document.body.scrollTop);
				}, 0);
			});
			
			$(document).on('focus', 'textarea', function() {
				$('.navbar-fixed-top').removeClass('animated fadeInCustom');
				$('.navbar-fixed-top').css('position', 'absolute');		
				$('.sync-time').removeClass('animated fadeInCustom');
				$('.sync-time').css('position', 'static');						
			});
			$(document).on('blur', 'textarea', function() {
					$('.navbar-fixed-top').addClass('animated fadeInCustom');
					$('.navbar-fixed-top').css('position', 'fixed');	
					$('.sync-time').addClass('animated fadeInCustom');
					$('.sync-time').css('position', 'fixed');					
			setTimeout(function() {			
					window.scrollTo(document.body.scrollLeft, document.body.scrollTop);
				}, 0);
			});
			
			$(document).on('focus', 'select', function() {
				$('.navbar-fixed-top').removeClass('animated fadeInCustom');
				$('.navbar-fixed-top').css('position', 'absolute');
				$('.sync-time').removeClass('animated fadeInCustom');
				$('.sync-time').css('position', 'static');	
				$('.main-footer').removeClass('animated fadeInCustom');
				$('.main-footer').css('position', 'static');						
			});
			$(document).on('blur', 'select', function() {
					$('.navbar-fixed-top').addClass('animated fadeInCustom');
					$('.navbar-fixed-top').css('position', 'fixed');	
					$('.sync-time').addClass('animated fadeInCustom');
					$('.sync-time').css('position', 'fixed');	
					$('.main-footer').addClass('animated fadeInCustom');
					$('.main-footer').css('position', 'fixed');					
			setTimeout(function() {			
					window.scrollTo(document.body.scrollLeft, document.body.scrollTop);
				}, 0);
			});
		}
		
		//Android
		
		$(document).on('focus', 'input:not([type="radio"]):not([type="checkbox"])', function() {
				$('.main-footer').removeClass('animated fadeInCustom');
				$('.main-footer').css('position', 'static');					
			});		
			$(document).on('blur', 'input:not([type="radio"]):not([type="checkbox"])', function() {
				$('.main-footer').addClass('animated fadeInCustom');
				$('.main-footer').css('position', 'fixed');						
				setTimeout(function() {				
					window.scrollTo(document.body.scrollLeft, document.body.scrollTop);
				}, 0);
			});
			
			$(document).on('focus', 'textarea', function() {
				$('.main-footer').removeClass('animated fadeInCustom');
				$('.main-footer').css('position', 'static');					
			});
			$(document).on('blur', 'textarea', function() {
					$('.main-footer').addClass('animated fadeInCustom');
					$('.main-footer').css('position', 'fixed');						
			setTimeout(function() {			
					window.scrollTo(document.body.scrollLeft, document.body.scrollTop);
				}, 0);
			});
	}
});


function Request() {
	return {
		"Request" : {
			"RequestInfo" : {
				"UserName" : "agent name",
				"CreationDate" : "09-25-2013",
				"CreationTime" : "12:15:54-04:00",
				"RequestorToken" : "",
				"UserEmail" : "test@gmail.com"
			},
			"RequestPayload" : {
				"Transactions" : []
			}
		}
	};
}

function getUniqueAppNamePattern(value) {
return rootConfig.appName+'_'+rootConfig.majorVersion+'.'+rootConfig.minorVersion+'_'+value;
}

function ObservationObject() {
    return {
   
    "Observation": {
        "Page": {
            "Context": "MSERVICING",
            "PageDesc": ""
        },
       
        "Email": "",
        "ModifiedOn":"",
		"CreatedOn":"",
		"Customer":"",
		"Agent": "",
        "LoggedDate": "",
        "Module": "",
        "DeviceId": "",
        "DeviceInfo": "",
        "SubModule": "",
        "SubOrdinateId": "",
        "LoggedTime": ""
    }
    };
}

function isFtureDate(date){
	now = getFormattedDate();
	if(now > date){
		return false;
	} else {
		return true;
	}
}

function isFutureDate(date){
	now = getFormattedDate();
	if(now >= date){
		return false;
	} else {
		return true;
	}
}
function LEDate(date) {
	if (date != undefined) {
		if ( typeof date != 'object') {
			if(typeof date == 'string' && date.length == 10){
			var dateString = date.split("-").join("/");
				var nowTZ = new Date(Date.parse(dateString));
			}else{
			var dateString = date.replace(' ', 'T');
			if(dateString.substr(dateString.length - 1)!='Z')
			dateString+='Z'
			var now = new Date(Date.parse(dateString));
				var nowTZ = new Date(now.getTime() + now.getTimezoneOffset()
						* 60000);
			}

		} else {
			nowTZ = date;
		}
	} else {
		nowTZ = new Date();
	}
	return nowTZ;
}
function isDateWithinSeven(date){
	now = getFormattedDate();
	dateDiff = Math.round((new Date(date) - new Date(now))/(1000*60*60*24));
	if(Math.abs(dateDiff) <= 7){
		return true;
	} else {
		return false;
	}
}

function isDateWithinSixty(date){
	now = getFormattedDate();
	dateDiff = Math.round((new Date(now) - new Date(date))/(1000*60*60*24));
	if(Math.abs(dateDiff) <= 60){
		return true;
	} else {
		return false;
	}
}


function isDateWithinSixtyFuture(date){
	now = getFormattedDate();
	dateDiff = Math.round((new Date(date) - new Date(now))/(1000*60*60*24));
	if(Math.abs(dateDiff) <= 60){
		return true;
	} else {
		return false;
	}
}

function validateDateRange(date, range){
	now = getFormattedDate();
	dateDiff = Math.round((new Date(now) - new Date(date))/(1000*60*60*24));
	if(Math.abs(dateDiff) <= range){
		return true;
	} else {
		return false;
	}
}

function isDateWithinSixtyPastFuture(date){
	now = getFormattedDate();
	if(date > now){
		dateDiff = Math.round((new Date(date) - new Date(now))/(1000*60*60*24));
	}
	else{
		dateDiff = Math.round((new Date(now) - new Date(date))/(1000*60*60*24));
	}
	if(Math.abs(dateDiff) <= 60){
		return true;
	}else{
		return false;
	}
}


function getDay(date){
    d = new Date(date);
    weekday = new Array(7);
    weekday[0] =  "Sun";
    weekday[1] = "Mon";
    weekday[2] = "Tue";
    weekday[3] = "Wed";
    weekday[4] = "Thu";
    weekday[5] = "Fri";
    weekday[6] = "Sat";

    n = weekday[d.getDay()];
    return n;
}
function getMonthFromDate(date){
    d = new Date(date);
    monthArray = new Array(12);
    monthArray[0] = "Jan";
    monthArray[1] = "Feb";
    monthArray[2] = "Mar";
    monthArray[3] = "Apr";
    monthArray[4] = "May";
    monthArray[5] = "Jun";
    monthArray[6] = "Jul";
    monthArray[7] = "Aug";
    monthArray[8] = "Sep";
    monthArray[9] = "Oct";
    monthArray[10] = "Nov";
    monthArray[11] = "Dec";

    n = monthArray[d.getMonth()];
    return n;
}

function getFormattedDate() {
    now = new Date();
    year = "" + now.getFullYear();
    month = "" + (now.getMonth() + 1);
    if (month.length == 1) {
        month = "0" + month;
    }
    day = "" + now.getDate();
    if (day.length == 1) {
        day = "0" + day;
    }
    return year + "-" + month + "-" + day;
}

function getFormattedDateFromDate(date) {
    now = date;
    year = "" + now.getFullYear();
    month = "" + (now.getMonth() + 1);
    if (month.length == 1) {
        month = "0" + month;
    }
    day = "" + now.getDate();
    if (day.length == 1) {
        day = "0" + day;
    }
    return year + "-" + month + "-" + day;
}


function getFormattedTime() {
    now = new Date();
    hour = "" + now.getHours();
    if (hour.length == 1) {
        hour = "0" + hour;
    }
    minute = "" + now.getMinutes();
    if (minute.length == 1) {
        minute = "0" + minute;
    }
    second = "" + now.getSeconds();
    if (second.length == 1) {
        second = "0" + second;
    }
    return  hour + ":" + minute + ":" + second;
}

function loginPopup(data){
	
	
	if (data[0] != undefined) {
		if (data[0].TransactionData != null) {
			
			var popupData = [];
			popupData = {
				"popupData" : ""
			};
			popupData.popupData = data[0].TransactionData;
			
			
		}
	} 
	
	return popupData;
	
}
function UserDetailsObject() {
	return {
		"user" : {
			"userId" : "",
			"password" : "",
			"token" : "",
			"lastLoggedDate" : ""
		},
		"options" : {
			"headers" : {
				"Token" : "",
				"source" : ""
			}
		}
	}
}
function showSyncDriveContent(folderPath, agentID ,roles ,mServiceUrl) {	

	
	 var appRoles=[];
	 /*if(agentID==123456){
	    appRoles.push("mRecRole");
	    appRoles.push("mServiceRole");
	 }
	 else if(agentID==111441)
		appRoles.push("mServiceRole");
	 else if(agentID==407675)
			appRoles.push("mRecRole");
			else{
				appRoles=roles;
				
			}*/
appRoles=roles;
			
		if (/iPhone|iPad|iPod/i.test(navigator.userAgent)) // check for device --
			// ios
			{
				
	            
	          //  syncdrive://mServicing?password=admin&appname=mServicing&syndriveuserid=mRecruitAdmin&returnurlscheme=mServicing&agentId=104070&hash=e7184804b826eb21bbc297c97a036c82
				
				var plainkey = agentID + rootConfig.appNameforSD + rootConfig.hashKey;
				//var hash = CryptoJS.MD5(plainkey);
				var syncDrivePath = rootConfig.syncDrivePath ;//+ folderPath ;
	           var params = "?password=admin&appname=" + rootConfig.appNameforSD+"&syndriveuserid=mRecruitAdmin" + "&returnurlscheme=" + rootConfig.appNameforSD + "&agentId=" + agentID;

	          //  console.log("syncDrivePath===="+syncDrivePath);
				
				cordova
						.exec(syncDriveSuccessCallback, syncDriveErrorCallback,
								"SyncDrive", "isSyncDriveAvailable", [ syncDrivePath , plainkey,params]);

			} else if (/Android/i.test(navigator.userAgent)) // for android
	{

		var extras = {};
		extras["folderPath"] = folderPath; // for SD
	    extras["agentId"] = agentID;
		extras["appname"] = rootConfig.appNameforSD;
        extras["password"] = "admin";
        extras["syndriveuserid"]= "mRecruitmentAdmin";
        extras["mContentRoles"]= appRoles;//TODO call the service
		
		
		var plainkey = agentID + rootConfig.appNameforSD + rootConfig.hashKey;// "mServicing" + "M@xl1f*mR*c";//TODO 
		//var hash = CryptoJS.MD5(plainkey);
	   // extras["hash"] = hash;
		extras["plainkey"] = plainkey;
		CDV.WEBINTENT.startActivity({
			action : '.android.common.mserviceIntent',
			extras : extras
		}, function() {
			// console.log("********* Success");
		}, function(message) {
			//alert(message);
			 $("#sd_not_sub").html(message);
			   $('#dvShowDecisionBoxSDNotInstall').modal('show');

		});
	} else {
		// alert('Desktop version not done!!' + extras.filePath);	
		var plainkey = agentID + rootConfig.appNameforSD + rootConfig.hashKey;// "mServicing" + "M@xl1f*mR*c";//TODO 
		//var hash = CryptoJS.MD5(plainkey);
				 var sdForm = $("#knowledge");
                           /*
				var sdForm = jQuery('<form>', {
					'action' : 'https://syncdrive.cognizant.com/mRecSample/knowledgeCenter',
					'target' : '_top',
					'method' : 'post'
				})
*/

				sdForm .append(jQuery('<input>', {
					'name' : 'appName',
					'value' : rootConfig.appNameforSD,
					'type' : 'hidden'
				})).append(jQuery('<input>', {
					'name' : 'syncDriveUserID',
					'value' : rootConfig.syndriveuserid,
					'type' : 'hidden'
				})).append(jQuery('<input>', {
					'name' : 'agentID',
					'value' : agentID,
					'type' : 'hidden'
				})).append(jQuery('<input>', {
					'name' : 'hash',
					'value' : hash,
					'type' : 'hidden'
				})).append(jQuery('<input>', {
					'name' : 'returnUrl',
					'value' : mServiceUrl,
					'type' : 'hidden'
				})).append(jQuery('<input>', {
					'type' : 'submit',
					 'value' : "Submit"
				}));
				
				/*
				 append(jQuery('<input>', {
					'name' : 'mContentRoles',
					'value' : appRoles[0],
					'type' : 'hidden'
				})).append(jQuery('<input>', {
					'name' : 'mContentRoles',
					'value' : appRoles[1],
					'type' : 'hidden'
				}))*/
				
				for(var i=0; i<appRoles.length;i++){
					sdForm.append(jQuery('<input>', {
					'name' : 'mContentRoles',
					'value' : appRoles[i],
					'type' : 'hidden'
				}));
				}
sdForm.trigger('submit');
				//sdForm.submit();


			}

		function syncDriveSuccessCallback(params) {
			//console.log("syncDriveSuccessCallback"+angular.toJson(params));
			if (params) {
				if (params.isAvailable) {
					var message = rootConfig.syncDrivePath + folderPath
							+ params.esyncParams+"&mContentRoles="+appRoles;
	               // console.log("message---++++++++++"+message);
	                //alert("----"+message);
					window.location = message;
				} else {
                  // alert("mContentManager is not installed. Please download and install from the AppStore");
				   $("#sd_not_sub").html("mContentManager is not installed. Please download and install from the AppStore.");
				   $('#dvShowDecisionBoxSDNotInstall').modal('show');
				}
			} else {

			}
		}

	function syncDriveErrorCallback(params) {
		// console.log("error"+angular.toJson(params));

	}

}

/*
 * Request used in mserve
function PushNotificationRequest(){
	
	return {
		  "MobileAppBundleID": "",
		  "DeviceType": "",
		  "DeviceUserID": "",
		  "PushMsgRegisteredID": "",
		  "TruJunctionAPPName": "",
		  "UserGroup": "",
		  "DEVICE_ID": ""
		};
}*/

function PushNotificationRegisterRequest(){
	
	return {
		"registerDeviceRequest":{
			"MobileAppBundleID" : "",
			"DeviceType" : "",
			"DeviceUserID" : "",
			"PushMsgRegisteredID" : "",
			"UserGroup" : "",
			"Device_ID" : "",
			"Application_Name" : ""
			}
	};
}


function hidePopUps() {
    var chkOpen = $('.slider_menu').hasClass("isOpen");       
    if(chkOpen){                      
	$('.slider_menu').animate({left:'-275px'},300); 
	$('.slider_menu').removeClass("isOpen bx_shadow");
	$('#fade').css("display","none");  
	$("body").removeClass("hide_scroll");                                  
    }
    $('.action_popup').css("display","none");
    $('.common_model_container').css("display","none");

}
function getServiceUrl(type) {
	
	var getUrl = rootConfig.serviceBaseUrl+rootConfig.servicePath;
	switch (type) {

	case "Alerts":
		getUrl = getUrl +"services/ServiceAlert"//?COMPANY_ID=100&APP_ID=14";//"AlertServiceRequest";//"ServiceAlert?COMPANY_ID=100&APP_ID=14";//
		
		break;
    case "MyBusiness":
	getUrl = getUrl +"services/MyBusiness"//?COMPANY_ID=100&APP_ID=14";//"MyBusinessServiceRequest";//"MyBusiness?COMPANY_ID=100&APP_ID=14";//
		break;
   case "MyGoals"	:
	getUrl = getUrl + "services/MyBusinessGetGoal"//?COMPANY_ID=100&APP_ID=14";//"BusinessGetGoalServiceRequest";//add set goal request
		break;
	case "MyEarnings":
	 
		getUrl=getUrl+"services/CompensationSchemeService"//?COMPANY_ID=100&APP_ID=14";//"CompensationSchemeRequest";//"CompensationSchemeService?COMPANY_ID=100&APP_ID=14";//;
	 
    
		break;
	case "PotentialToEarn":
		getUrl = getUrl +"services/PotentialToEarn"//?COMPANY_ID=100&APP_ID=14";//"PotentialToEarnRequest";
		break;
	case "MyPerformanceOverview":
		getUrl = getUrl + "services/MyPerformanceOverviewService"//?COMPANY_ID=100&APP_ID=14";//"MyPerformanceOverviewRequest";//"MyPerformanceOverviewService?COMPANY_ID=100&APP_ID=14";//
		break;
	case "LeadsDashboard":
		getUrl = getUrl +"services/LeadsDashboardService"//?COMPANY_ID=100&APP_ID=14";//"LeadsDashboardRequest";//"LeadsDashboardService?COMPANY_ID=100&APP_ID=14"; //
		break;
   case "RecruitmentDashboard":
	
		getUrl = getUrl + "services/RecruitmentDashboardService"//?COMPANY_ID=100&APP_ID=14";//"RecruitmentDashboardRequest";//"RecruitmentDashboardService?COMPANY_ID=100&APP_ID=14";//;
		break;
	case "RnRSchemes":
	
		getUrl = getUrl + "services/RandRService"//?COMPANY_ID=100&APP_ID=14";//"RAndRRequest";//"RandRService?COMPANY_ID=100&APP_ID=14";//
	break;
	case "PremiumCalendar":					
		getUrl = getUrl + "services/PremiumCalendarService"//?COMPANY_ID=100&APP_ID=14";//"PremiumCalendarRequest";//"HierarchyService?COMPANY_ID=100&APP_ID=14";//
		
	break;
	
	case "HierarchyDetails":
	
		getUrl = getUrl + "services/HierarchyService"//?COMPANY_ID=100&APP_ID=14";//"HierarchyRequest";//"HierarchyService?COMPANY_ID=100&APP_ID=14";//
		
	break;
	case "Product Name"	:					
		getUrl = getUrl + "services/ProductNameService"//?COMPANY_ID=100&APP_ID=17";//"ProductNameServiceRequest";//"HierarchyService?COMPANY_ID=100&APP_ID=14";//
		
	break;
	case "Plan Type":
       getUrl = getUrl +"services/PlanTypeService"//?COMPANY_ID=100&APP_ID=17"; //"PlanTypeServiceRequest";//"HierarchyService?COMPANY_ID=100&APP_ID=14";//
		
	break;
	case "Proposal Status":					
		getUrl = getUrl + "services/ProposalStatusService"//?COMPANY_ID=100&APP_ID=17";//"ProposalStatusServiceRequest";//"HierarchyService?COMPANY_ID=100&APP_ID=14";//
		
	break;
	case "COI-NominatorName":					
		getUrl = getUrl + "services/COINominatorNameService"//?COMPANY_ID=100&APP_ID=17";//"COINominatorNameServiceRequest";//"HierarchyService?COMPANY_ID=100&APP_ID=14";//
		
	break;
	case "Premium Frequency":					
		getUrl = getUrl + "services/PremiumFrequencyService"//?COMPANY_ID=100&APP_ID=20";//"COINominatorNameServiceRequest";//"HierarchyService?COMPANY_ID=100&APP_ID=14";//
		
	break;
	case "Policy Status":					
		getUrl = getUrl + "services/PolicyStatusService"//?COMPANY_ID=100&APP_ID=20";//"COINominatorNameServiceRequest";//"HierarchyService?COMPANY_ID=100&APP_ID=14";//
		
	break;
	case "PushNotification" :
		//getUrl = getUrl + registerDevice" ;//hard coded for now
		getUrl = "http://54.251.248.74:4080/mServicePushNotifications";
		break;
	case "LoginPopUp":
		getUrl +="services/LognPopupService"//?COMPANY_ID=100&APP_ID=20";
	break;	
	case "ADMDashboard":					
		getUrl = getUrl + "services/ADMDashboardServiceRequest";//"ADMDashBoard?COMPANY_ID=100&APP_ID=35";//for eserve
	break;
	
	}
	
	return getUrl;
}



function getSyncToServiceUrl(type) {
	
	//var getUrl = rootConfig.serviceBaseUrl+rootConfig.servicePath;
	var getUrl = "";
	
	switch (type) {

	
   case "MyGoals"	:
	getUrl = rootConfig.serviceBaseUrl+rootConfig.servicePath;
	getUrl = getUrl + "saveGoalService/MyBusinessSetGoal"//?COMPANY_ID=100&APP_ID=14";//"BusinessGetGoalServiceRequest";//add set goal request
		break;
   
   case "Observation" :
	 getUrl = "https://sit-lifeengage.cognizant.com/mli-mService-platform-ep/services/mService/save";
		break;
	}
	
	return getUrl;
}

function MserviceObject() {
	return {
		"goal" : []
	};

}
// Generic function to handle the anugular translate services
/*function translateMessages($translate, message, additionalInfo) {
	if (jQuery.isEmptyObject(message))
		return message;
	else
		return (jQuery.isEmptyObject(additionalInfo)) ? $translate(message)
				: $translate(message) + " " + additionalInfo;
}*/


function translateMessages($translate, message, additionalInfo) {
	if (!jQuery.isEmptyObject(message) && !jQuery.isEmptyObject($translate)
			&& !jQuery.isEmptyObject(additionalInfo)) {
		// hack:Need to research on how we can inject data in between the
		// traslated message.
		return $translate(message) + " " + additionalInfo;
	} else if (!jQuery.isEmptyObject(message)
			&& !jQuery.isEmptyObject($translate)) {
		return $translate(message);
	} else {
		return message;
	}
}

var loadingImageArray=[];
// Show hide the loading images across all ajax requests
function showHideLoadingImage(isShow, loadingMessage, $translate,callingFrom) {
	if (isShow) {
		if (!(rootConfig.isDeviceMobile)) {
			if(callingFrom!=undefined)
			loadingImageArray.push(callingFrom);
		}
	
		var dynamic_height = $(window).height();
		/*
		 * if (dynamic_height < 700) { dynamic_height = 700; }
		 */
		$('#page_loader').show();
		$('#page_loader_overlay').show();
		$('#page_loader').find('#loadImage').css("display", "inline");
		$('#page_loader').find('span.loadingMessage').css("display", "inline");
		$('#page_loader').css('height', dynamic_height).fadeIn(300);
		if (navigator.userAgent.search("MSIE") >= 0) {
	
			$('#page_loader span.loadingMessage').html(loadingMessage);	
		}
		else
		{
			$('#page_loader span.loadingMessage').html(
			translateMessages($translate, loadingMessage));
		}
	} else {
	// console.log("--arrayb4-"+loadingImageArray);
	if (!(rootConfig.isDeviceMobile)) {
		if(callingFrom!=undefined)
		loadingImageArray.pop(callingFrom);
	}
	//var index = loadingImageArray.indexOf(callingFrom);
//loadingImageArray.splice(index, 1);
	 // console.log(callingFrom+"--removed - current = "+loadingImageArray);
	   if(loadingImageArray.length==0){
			$('#page_loader').hide();
			$('#page_loader_overlay').hide();
		}
	}
	displayPopUp();

	//alert("--"+loadingMessage);
	
	
}

// Show popups
function displayPopUp() {
	var flag = $('#page_loader').css("display");
	if (flag == "block") {
		var top = ($(window).height() - $('.modal_container').height()) / 2;
		var left = ($(window).width() - $('.modal_container').width()) / 2;
		$('.modal_container').css({
			'top' : top ,
			'left' : left
		});
		/*$('.modal_container').css({
			'top' : top + $(document).scrollTop(),
			'left' : left
		});*/
		$("body").removeClass("display_modal").addClass("display_modal");
	} else {
		$("body").removeClass("display_modal");
	}

}
// NotifyMessages
function NotifyMessages(isError, message, $translate, additionalInfo) {
	if (isError) {
		$('#notifyIcon').removeClass("success_icon info_icon");
		$('#notifyIcon').addClass("error_icon info_icon");
		$("#notifyMsgContent").removeClass("success_alert_content");
		$("#notifyMsgContent").addClass("error_alert_content");
	} else {
		$('#notifyIcon').removeClass("error_icon info_icon");
		$('#notifyIcon').addClass("success_icon info_icon");
		$("#notifyMsgContent").removeClass("error_alert_content");
		$("#notifyMsgContent").addClass("success_alert_content");
	}
	$("#notifyMsgContent").html(
			translateMessages($translate, message, additionalInfo));
	$('#notifyMsg').show().delay(1000).fadeOut('slow');

}

function changeStringToDate(dateString,dateFormat)
{
 
	if(dateString instanceof Date)
	{
		return dateString;
	    
	}
	else
	{
		return(parseDate(dateString,dateFormat));	
	}
}
function convertDateFromISO(s){
	
	if ((s == "") ||(s == 0)) {
		return s
	}
	else
	{
		s = s.split(/\D/);
		return new Date(s[0], s[1]-1, s[2], s[3], s[4], s[5], s[6]);
		
	}
  
}

function dateFromISO(s) {
	  s = s.split(/\D/);
	  return new Date(Date.UTC(s[0], --s[1]||'', s[2]||'', s[3]||'', s[4]||'', s[5]||'', s[6]||''))
	}


function getIntegerFromString(amountString)
{

    if (typeof amountString == 'string' || amountString instanceof String)
	//if (isNumber(amountString))
	{
		var amount =  parseFloat(amountString ? amountString.replace(/,/g, ""):'');
		return amount;
	}
	else
	{
		if(amountString == ""){
			var data = parseFloat("0.00");
			return parseFloat("0.00");
		}
		else{
			 return amountString;
		}
	   
	}
	
}
function isNumber(n)
{
  return !isNaN(parseFloat(n)) && isFinite(n);
}
function getBrowserVersion()
{
   var rv = -1; 
   if (navigator.appName == 'Microsoft Internet Explorer')
   {
      var ua = navigator.userAgent;
      var re  = new RegExp("MSIE ([0-9]{1,}[\.0-9]{0,})");
      if (re.exec(ua) != null)
         rv = parseFloat( RegExp.$1 );
   }
   return rv;
}

function tConvert (time) 
{
	if((time.indexOf("PM") > -1) || (time.indexOf("PM") > -1))
	{
		return time;
	}
	else
	{
		var H = +time.substr(0, 2);
		var h = (H % 12) || 12;
		var ampm = H < 12 ? " AM" : " PM";
		time = h + time.substr(2, 3) + ampm;
		return time;
	}
}
function dateFilter(arrayRef, expression,scope){ 

             var filtered = [];
             var type;
             if (scope.$root.isRelationshipManagement)
             {
	       //TODO:Take this string from constants for comparision 
               type = "RelationshipManagement";
             }
           
             else
             {
               type = "";
             }
             
                switch (scope.$root.selectedAlertFilter)
                {
                                case "last7":
                                                filtered = getDataBetweenDates(arrayRef,scope.$root.selectedAlertFilter,type);
                                                break;
                                
                                case "today":
                                                filtered = getDataBetweenDates(arrayRef,scope.$root.selectedAlertFilter,type);
                                                break;
                                
                                case "next7":
                                                filtered = getDataBetweenDates(arrayRef,scope.$root.selectedAlertFilter,type);
                                                break;
                                default:
                                    break;            
                }
                if (scope.$root.isImportantCommunication)
                {
                	var version = getBrowserVersion();
                	 if(filtered.length != 0){
                    
                     	scope.$root.types = [];
                     	scope.$root.types.push("All");
                     	 for(var i = 0; i < arrayRef.length; i++)
                          {
                     		if(arrayRef[i].type != undefined){
                     			if (version > -1 && version <= 8.0) {
                         			
                         			if(($.inArray(arrayRef[i].type,scope.$root.types)) == -1){
                            			 scope.$root.types.push(arrayRef[i].type);
                            		}                        		

                				} else {
                					
                					if(((scope.$root.types).indexOf(arrayRef[i].type)) == -1){
                            			 scope.$root.types.push(arrayRef[i].type);
                            		}
                            		
                				}
                     		}
                     		
                          }
                     	
                     }
                     else{
                    	
                     	scope.$root.types = [];
                     }
                	 
                }
               
                return filtered;
   		
}
function getDataBetweenDates(arrayRef,identify,type)
{
   var filtered = [];
               var splitDate;
               var dateFromServer = "";
               var currentArray=[];
               
               for(var i = 0; i < arrayRef.length; i++)
               {
            	   currentArray = angular.copy(arrayRef[i]);
                     dateFromServer =  arrayRef[i].date;
                     arrayRef[i].date = angular.copy(dateFromServer);
               if(dateFromServer != "" && dateFromServer){
            	    if (type=="RelationshipManagement")//get the current year for relationshipmanagement
                    {
                       var currentDate =  new Date();
                       dateFromServer.setYear(currentDate.getUTCFullYear());
                    }
                     var startDate = new Date();
                     var stopDate = new Date();
                     var today = new Date();
                     startDate.setHours(23);
                     startDate.setMinutes(59);
                     startDate.setSeconds(59);                                
                     stopDate.setHours(23);
                     stopDate.setMinutes(59);
                     stopDate.setSeconds(59);
                     switch (identify)
                     {
                                     case "last7":
                                     startDate.setDate(startDate.getDate() - 1);
                                     stopDate.setDate(stopDate.getDate() - 8);
      
                                     if (dateFromServer <= startDate && dateFromServer >= stopDate)
                                     {
                                                     filtered.push(currentArray);
                                     }
                                     break;
                     
                                     case "today":
                                     //var today = new Date();
                                     if (dateFromServer!="") {
                                    
                                     if(today.getDate() == dateFromServer.getDate() && today.getMonth() == dateFromServer.getMonth())
                                     {
                                                     filtered.push(currentArray);
                                                     
                                     }
                                     }
                                     break;
                     
                                     case "next7":
                                     startDate.setDate(startDate.getDate());
                                     stopDate.setDate(stopDate.getDate() + 7);
                                     if(dateFromServer >= startDate && dateFromServer <= stopDate)
                                     {
                                                     filtered.push(currentArray);
                                     }
                     } 
               }
                          
                }
                return arrayRef;
}
function MserviceObject() {
	return {
		"goal": [
                 
                 {
                  "month": "4",
                  "year": "",
                  "business": [
                      {
                          "noOfPolicies": "",
                          "myGoalsPremium": "",
                          "myCommissions": "",
                          "myGoalsEarnings": "",
                          "myOtherEarnings": "",
                          "commissionPercentage": "",
                          "myTotalEarnings": ""
                      }
                  ]
              },
              {
                  "month": "5",
                  "year": "",
                  "business": [
                      {
                         "noOfPolicies": "",
                          "myGoalsPremium": "",
                          "myCommissions": "",
                          "myGoalsEarnings": "",
                          "myOtherEarnings": "",
                          "commissionPercentage": "",
                          "myTotalEarnings": ""
                      }
                  ]
              },
              {
                  "month": "6",
                  "year": "",
                  "business": [
                      {
                         "noOfPolicies": "",
                          "myGoalsPremium": "",
                          "myCommissions": "",
                          "myGoalsEarnings": "",
                          "myOtherEarnings": "",
                          "commissionPercentage": "",
                          "myTotalEarnings": ""
                      }
                  ]
              },
              {
                  "month": "7",
                  "year": "",
                  "business": [
                      {
                         "noOfPolicies": "",
                          "myGoalsPremium": "",
                          "myCommissions": "",
                          "myGoalsEarnings": "",
                          "myOtherEarnings": "",
                          "commissionPercentage": "",
                          "myTotalEarnings": ""
                      }
                  ]
              },
              {
                  "month": "8",
                  "year": "",
                  "business": [
                      {
                         "noOfPolicies": "",
                          "myGoalsPremium": "",
                          "myCommissions": "",
                          "myGoalsEarnings": "",
                          "myOtherEarnings": "",
                          "commissionPercentage": "",
                          "myTotalEarnings": ""
                      }
                  ]
              },
              {
                  "month": "9",
                  "year": "",
                  "business": [
                      {
                          "noOfPolicies": "",
                          "myGoalsPremium": "",
                          "myCommissions": "",
                          "myGoalsEarnings": "",
                          "myOtherEarnings": "",
                          "commissionPercentage": "",
                          "myTotalEarnings": ""
                      }
                  ]
              }, {
                  "month": "10",
                  "year": "",
                  "business": [
                      {
                          "noOfPolicies": "",
                          "myGoalsPremium": "",
                          "myCommissions": "",
                          "myGoalsEarnings": "",
                          "myOtherEarnings": "",
                          "commissionPercentage": "",
                          "myTotalEarnings": ""
                      }
                  ]
              }, {
                  "month": "11",
                  "year": "",
                  "business": [
                      {
                          "noOfPolicies": "",
                          "myGoalsPremium": "",
                          "myCommissions": "",
                          "myGoalsEarnings": "",
                          "myOtherEarnings": "",
                          "commissionPercentage": "",
                          "myTotalEarnings": ""
                      }
                  ]
              }, {
                  "month": "12",
                  "year": "",
                  "business": [
                      {
                          "noOfPolicies": "",
                          "myGoalsPremium": "",
                          "myCommissions": "",
                          "myGoalsEarnings": "",
                          "myOtherEarnings": "",
                          "commissionPercentage": "",
                          "myTotalEarnings": ""
                      }
                  ]
              }, {
                  "month": "1",
                  "year": "",
                  "business": [
                      {
                          "noOfPolicies": "",
                          "myGoalsPremium": "",
                          "myCommissions": "",
                          "myGoalsEarnings": "",
                          "myOtherEarnings": "",
                          "commissionPercentage": "",
                          "myTotalEarnings": ""
                      }
                  ]
              }, {
                  "month": "2",
                  "year": "",
                  "business": [
                      {
                          "noOfPolicies": "",
                          "myGoalsPremium": "",
                          "myCommissions": "",
                          "myGoalsEarnings": "",
                          "myOtherEarnings": "",
                          "commissionPercentage": "",
                          "myTotalEarnings": ""
                      }
                  ]
              }, {
                  "month": "3",
                  "year": "",
                  "business": [
                      {
                          "noOfPolicies": "",
                          "myGoalsPremium": "",
                          "myCommissions": "",
                          "myGoalsEarnings": "",
                          "myOtherEarnings": "",
                          "commissionPercentage": "",
                          "myTotalEarnings": ""
                      }
                  ]
              }
          ]
	};

}
function checkConnection() {
	if (rootConfig.isOfflineDesktop) {
		if (navigator.onLine) {
			return true;
		} else {
			return false;
		}
	} else {
		var networkState = navigator.network.connection.type;
		var states = {};
		states[Connection.UNKNOWN] = 'Unknown connection';
		states[Connection.ETHERNET] = 'Ethernet connection';
		states[Connection.WIFI] = 'WiFi connection';
		states[Connection.CELL_2G] = 'Cell 2G connection';
		states[Connection.CELL_3G] = 'Cell 3G connection';
		states[Connection.CELL_4G] = 'Cell 4G connection';
		states[Connection.NONE] = 'No network connection';
		if (states[networkState] == 'No network connection') {
			return false;
		} else {
			return true;
		}
	}
}
function EmailObject() {
	return {
		"toMailIds" : [],
		"ccMailIds" : [],
		"bccMailIds" : [],
		"mailSubject" : "",
		"emailAttachments" : [],
		"emailIsHtml" : true,
		"openWithApp" : null,
		"emailBody" : ""
	};
}

function FeedbackIssueModelObject() {
	return {
		"templateID" : "",
		"composeHeader" : "",
		"type" : "",
		"moduleTitle" : "Module Name",
		"screenTitle" : "Screen Name",
		"descriptionTitle" : "Description",
		"contactNumberTitle" : "Contact Number",
		"deviceInformation" : "Device Information:",
		"deviceUUID" : "Device UUID",
		"uuid" : "",
		"deviceVersion" : "Version",
		"version" : "",
		"devicePlatform" : "Platform",
		"deviceVersionModel" : "Model",
		"model" : "",
		"deviceManufacturer" : "Manufacturer",
		"manufacturer" : "",
		"emailFooter" : "",
		"attachDeviceTemplate" : "No",
		"browserInformation" : "Browser Information",
		"browserName" : "Browser Name",
		"browserVersion" : "Browser Version",
		"language" : "Browser Language",
		"platform" : "Platform",
		"agentDetails" : "Agent Details",
		"agentCodeTitle" : "Agent Code",
		"agentCode" : "",
		"agentNameTitle" : "Agent Name",
		"agentName" : "",
		"deviceInfo" : {
			"uuid" : "",
			"version" : "",
			"platform" : "",
			"model" : ""
		},
		"browserInfo" : {
			"browserName" : "",
			"majorVersion" : "",
			"fullVersion" : "",
			"language" : "",
			"platform" : ""
		}
	};
}

function downloadPdfFromRemote(downloadUrl, file) {
	if(!file){
		file = '';
	}
    var isAndroid = navigator.userAgent.indexOf("Android") > 0 ? true : false;
    if(isAndroid) {
        window.plugins.toast.showLongBottom('PDF file downloading to Internal Storage/' +rootConfig.androidDownloadsFolderName + '/', function(a){}, function(b){})
    }
    else {
        showHideLoadingImage(true, 'Downloading PDF', null, "Forms");
    }
    window.plugins.LEFileUtils.getApplicationPath(function (path) {
        if(isAndroid) {
            path='file:///storage/emulated/0/'+rootConfig.androidDownloadsFolderName;
            if (downloadUrl.includes("./uijsons/")) {
                downloadUrl = "file:///android_asset/www/uijsons/" + downloadUrl.split("./uijsons/")[1];
//              downloadUrl = $location.path()+"/uijsons/";
            }
        }
        var uri = encodeURI(downloadUrl);
        var fileName=downloadUrl.split("/");
        var filePath;
        if(downloadUrl.indexOf("downloadContent?fileName=") > 0) {
            filePath=path+'/'+fileName[fileName.length - 1].split("?fileName=")[1];
        }
        else if(file!='') {
            filePath=path+'/'+file;
        }
        else if(downloadUrl.indexOf(".pdf") > 0) {
            filePath=path+'/'+ fileName[fileName.length - 1];
        }
        else {
            filePath=path+'/'+ fileName[fileName.length - 1]+".pdf";
        }
        downloadPdfAndStore(uri, filePath, isAndroid);
    });
}

function downloadPdfAndStore(uri, filePath, isAndroid) {
    var fileTransfer = new FileTransfer();
    var fileName=filePath.split("/");
    fileTransfer.download(uri, filePath,
       function(entry) {
           console.log("download complete: " + entry.fullPath);
           fileFullPath = "file://" + filePath;
           showHideLoadingImage(false);
           if(isAndroid) {
               window.plugins.toast.showLongBottom(fileName[fileName.length - 1] + ' downloaded to Internal  Storage/' +rootConfig.androidDownloadsFolderName + '/', function(a){}, function(b){});
           }
           else {
               cordova.exec(function () {}, function () {}, "PdfViewer", "showPdf", [fileFullPath]);
               showHideLoadingImage(false, null, null, "Forms");
           }
       },
       function(error) {
           window.plugins.toast.showLongBottom('Unable to download PDF..!', function(a){}, function(b){})
           console.log(error);
           showHideLoadingImage(false, null, null, "Forms");
       },
       true );
}

