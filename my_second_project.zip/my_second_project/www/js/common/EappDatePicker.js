function EappDatePicker() {
};

EappDatePicker.prototype.showDatePicker = function(success, error,format,defualtDate) {
    
    cordova.exec(success, error, "EappDatePicker", "showDatePicker",[format,defualtDate]);
};



/**
 * Load Plugin
 */

if(!window.plugins) {
    window.plugins = {};
}
if (!window.plugins.EappDatePicker) {
    window.plugins.EappDatePicker = new EappDatePicker();
}
