

//Dynamically inject the theme/css depends on the rootConfiguration
$(document).ready(function () {
   
    showHideLoadingImage(true, "Applying theme..please wait..");
    var dir = "css/" + rootConfig.themeName + "/css/";
    var fileextension = ".css";
    injectTheme(rootConfig.themeName)
    showHideLoadingImage(false, "");

//    $.ajax({
//        //This will retrieve the contents of the folder if the folder is configured as 'browsable'
//        url: dir,
//        success: function (data) {
//            //            $(data).find("a:contains(" + fileextension + ")").each(function () {
//            //                //var filename = this.href.replace(window.location.host, "").replace("http:///", "");
//            //                var filename = this.href.split("/")[this.href.split("/").length - 1];               
//            //                $("head").append($("<link rel='stylesheet' href=" + dir + filename + " type='text/css'/>"));
//            //            });
//            //if ($(data).find("a:contains(" + fileextension + ")").length <= 0) {
//            injectTheme(rootConfig.themeName);
//            //}
//            showHideLoadingImage(false, "");
//        },
//        error: function (data) {
//            injectDefaultTheme()
//            showHideLoadingImage(false, "");
//        }
 //   });


    $('.settings_btn').click(function () {
        $('#page_loader').empty();
        var dynamic_height = $('body').height();
        $('#page_loader').css('height', dynamic_height).fadeIn(300);
        showSwitcher();
        $('.switchThm').css("display", "block");
    });

    function showSwitcher() {
        var flag = $('#page_loader').css("display");
        if (flag == "block") {
            $('.switchThm').css("display", "block");
            var top = ($(window).height() - $('.switchThm').height()) / 2;
            var left = ($(window).width() - $('.switchThm').width()) / 2;
            $('.switchThm').css({ 'top': top + $(document).scrollTop(), 'left': left });
            $("body").removeClass("hide_scroll").addClass("hide_scroll");
        }
        else {
            $("body").removeClass("hide_scroll");
        }

    }

    $('#toAXA').click(function () {
        $('link[href="css/axa-theme/css/styles.css"]').attr('href', 'css/main-theme/css/styles.css');
        $('.switchThm').css("display", "none");
        $("body").removeClass("hide_scroll");
        $('#page_loader').css("display", "none");
    });

    $('#toEapp').click(function () {
        $('link[href="css/main-theme/css/styles.css"]').attr('href', 'css/axa-theme/css/styles.css');
        $('.switchThm').css("display", "none");
        $("body").removeClass("hide_scroll");
        $('#page_loader').css("display", "none");
    });

});

function injectTheme(folderName) {
    $("head").append($("<link href='css/" + folderName + "/css/jslider.css' rel='stylesheet' type='text/css' />"));
    $("head").append($("<link href='css/" + folderName + "/css/styles.css' rel='stylesheet' type='text/css' />"));
    
}



 