var filters = angular.module('lifeEngage.formatter', []);
filters.
filter('formatter', function () {
  
    return function (s) {
        s = String(s).replace( /\d{1,3}(?=(\d{3})+(?!\d))/g , "$&,");
        return s;
    };
});

filters.
filter('NameFormatter', function () {
  
    return function (a) {		
	a = String(a).replace(/ \(([^)]+)\)/m,"");
	return a;
    };
});



filters.
filter('vehicle', function () {
  
    return function (policyNum,inputVal) {		
		 if(inputVal.vehicleNumber == "")
			{
			var policyNum =inputVal.policyNumber ;
			}
		else
			{
			var policyNum=inputVal.vehicleNumber;
			}	
        return policyNum;
    };
});
filters.
filter('DateTimeFormatting', function () {
  
    return function (updatedDateValue,inputVal) {		
		var value =  inputVal.remarkUpdatedDate;
		var valueData =[];
		valueData=value.split(" ");
		var dateData = [];
		dateData= valueData[0].split("-");
		var newDate = dateData[2]+"/"+dateData[1]+"/"+dateData[0];
		var timeData = [];
		timeData = valueData[1].split(":");
		if(timeData[0] >='12')
		{
			var pwd = "PM";
		}
		else
		{
			var pwd = "AM";
		}
		var newTime = timeData[0]+":"+timeData[1]+" "+pwd;
		var updatedDateValue = newDate +"  " + newTime; 
        return updatedDateValue;
    };
});