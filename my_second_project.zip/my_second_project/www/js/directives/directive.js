  
var lifeEngageChart = angular.module('lifeEngage.chart', []);

var plotArrayBar=[];
var plotArrayLine =[];
var plotArrayPie=[];

lifeEngageChart.directive('uiChart', function () {
    return {
    	restrict: 'E',
    	replace: true,
    	link: function (scope, elem, attrs) {
    	
    	var renderChart = function () {  
    	var data = scope[attrs.ngModel];
    	var legend_array = scope[attrs.label];
    		
    	var chartId = attrs.id;
    	var isDashboard = attrs.dashboard;
    	var type = attrs.type;
    	var xaxisLabel = attrs.xaxis;
    	var yaxisLabel = attrs.yaxis;
    	var lineTicks= attrs.ticks;
    	var isStacked = attrs.stacked;
    	var tickInt1=attrs.tickint;
    	var labels=attrs.labelname;

    	if(attrs.labelname != undefined){
    	    labels= JSON.parse(attrs.labelname);
    	}
    	
    	if (data!=undefined) {
    	if(type == "pieChart") {
    		

     	   
     	   var disData=[];
     	   for(var i=0;i<data.length;i++){
     	   	if(data[i][1]==0){
     	   		data[i] = ["", 0];
     	   	}
     	   	  disData.push(data[i]);
     	   }
     	   $("#"+chartId).children().remove();
     	    var total = 0;
     	    $(disData).map(function(){total += this[1];})// if(this[1]!=0)
			
			myLabels = $.makeArray($(disData).map(function(){ 
				if(this[1] == 0){
					return ""
				}else{
					return Math.round(this[1]/total*100) +"%<br/>"+ Math.round(this[1]).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
				}
			}));//Math.floor(this[1]/total*1000)/10
     	    myLegendLabels = $.makeArray($(disData).map(function(){ return this[0] }));
         	    if(attrs.ongraphclick != undefined)
         	    {
         	    	
         	    	if(plotArrayPie.length>4){
				           for (var i = 0; i < plotArrayPie.length; i++)
				        	   plotArrayPie[i].destroy();
				     } 
         	    	 var  plotPie = $.jqplot (chartId, [disData], {  
         		    seriesDefaults: {shadow: true, renderer: jQuery.jqplot.PieRenderer, rendererOptions: { showDataLabels: true ,dataLabels: myLabels,dataLabelThreshold: 0, sliceMargin: 1,shadowAlpha:0}},
         		      seriesColors:["#f18a4a","#838383","#ffa132","#b3713f","#bd5403","#ffcfab","#da762a","#bd5403","#f8a86d","#6b2f01"],
         		    legend: { show:false, 
         			      location: 's',
						  placement:'outside',
         		              showSwatch: true,
         		              labels:myLegendLabels,
         	 			      showLabels: true
         		            }, 
         		    grid: { borderWidth: 0.0,
         			    drawGridLines: false, 
         			    background: '#FFFFFF',
         			    shadow: false     						
         			   }
         			   
         		    });
					if(plotArrayPie.length ==2){
						plotArrayPie =[];
					}
         	    plotArrayPie.push(plotPie);
         		var legendTable = $($('.jqplot-table-legend')[0]);    
         	    legendTable.css('display','block');
         	    legendTable.css('z-index',100);
         	    legendTable.css('min-width','100px');
         	    legendTable.css('max-height','180px');
         	    legendTable.css('overflow-y','auto');
         	    }
         	    else
         	    {
         		
         		
         	    	 var  plotPie = $.jqplot (chartId, [disData], {  
         		    seriesDefaults: {shadow: true, renderer: jQuery.jqplot.PieRenderer, rendererOptions: { showDataLabels: true,
         		    dataLabels: myLabels, dataLabelThreshold: 0,highlightMouseOver :false,sliceMargin: 1,shadowAlpha:0}},
         		     seriesColors:[  "#f18a4a","#838383","#ffa132","#b3713f","#bd5403","#ffcfab","#da762a","#bd5403","#f8a86d","#6b2f01"],
         		    legend: { show:false, 
         			      location: 's',
         			      showSwatch: true,
						  placement:'outside',
         			      labels:myLegendLabels,
     	 			      showLabels: true
         			    }, 
         		    grid: { borderWidth: 0.0,
         			    drawGridLines: false, 
         			    background: '#FFFFFF',
         			    shadow: false     						
         			   }
         		    });
					if(plotArrayPie.length ==2){
						plotArrayPie =[];
					}
         	    	plotArrayPie.push(plotPie);
         	        var legendTable = $($('.jqplot-table-legend')[0]);    
         		    legendTable.css('display','block');
         		    legendTable.css('z-index',100);
         		    legendTable.css('min-width','100px');
         		    legendTable.css('max-height','180px');
         		    legendTable.css('overflow-y','auto'); 
         	    }
     	   	
     	    
     	
     	    $("#"+chartId).bind('jqplotDataClick', function(ev, seriesIndex, pointIndex, disData) {
     		if(attrs.ongraphclick != undefined){
     		    scope[attrs.ongraphclick](disData[0]);
     		}
     	    });
     	$(window).bind('resize', function(event, ui) {    
			if (plotArrayPie.length!= 0) {
				
				plotArrayPie[0].replot();
				plotArrayPie[1].replot();
			}
		});
    	}
    	
    	
    	else if(type == "linechart") {
    		////console.log("data..."+angular.toJson(data));
    	    if(attrs.ticks != undefined){
    	    lineTicks= JSON.parse(attrs.ticks);
    		}	
    	    var labelname ;
    	    //note:  if we replaced the pointLabel with ticks it will display the ticks in points
    	    if(attrs.labelname != undefined){
    		labelname= JSON.parse(attrs.labelname);
    		}
    	    var jqData = [];
    	    if(scope.multigraphflag== undefined || !scope.multigraphflag){
    		jqData.push(data);
    	    }
    	    else
    	    {
    		jqData = data;
    	    }						
    	    
    	    
    	    $("#"+chartId).html('');		 
    	    var plotLine= $.jqplot(chartId,jqData, {  
    		title: "",
    		axes:
    		{
    		    xaxis:
    		    {
    			renderer: $.jqplot.CategoryAxisRenderer,
    			ticks : lineTicks,
    			rendererOptions: {drawBaseline: true},
    			tickOptions:{
    			showGridline: false}
    		    },
    		    yaxis:
    		    {
    			labelRenderer: $.jqplot.CanvasAxisLabelRenderer,
    			showTicks : false,
    			rendererOptions: {drawBaseline: true},
    			tickOptions : {
    			showGridline: false}
    		    }
    		},
    		grid:
    		{
    		    shadow:false,
    		    background: '#FFFFFF',
    		    drawBorder: false,
    		    borderColor:'black'
    		},
    		seriesDefaults:
    		{
    		    rendererOptions:
    		    {
    			smooth: true
    		    },
    		    pointLabels:
    		    {
    			show:true,
    			location : 's'
    		    } 
    		},
    		series:[{
    			color: ' #3b9617',
    			lineWidth:1, 
    			markerOptions: { style:"filledCircle" },
    			pointLabels: {show: true, stackedValue: false, location:'w'}
    			},
    			{
    			color:  '#ff7031',
    			lineWidth:1, 
    			markerOptions: { style:"filledCircle" },
    			pointLabels: {show: true, stackedValue: false, location:'e', labels:labelname}
    			}],
    			legend:
    			{ 
    			    show:true, 
    			    location: 'n', 
    			    placement: 'outside',
    			    labels:legend_array,
    			    border: '0 solid'
    			}
    			});
    	    plotArrayLine.push(plotLine);
    		}
    	 	  	  
    	  
    	else if(type == "barChart")
    	{
    	
    		var ticks="";
	    if(attrs.ticks != undefined){		 
			ticks=scope[attrs.ticks];			 
	    }
	    if (scope[attrs.ticks].length==0)
	    {		    
	    ticks=[' '];
	    }
	    var barsWidth = 40;
	  
	    if(isStacked != undefined){
	    
    		barsWidth = 25;
    	}
	    var viewPortWidth = $(window).width();
	    var viewPortHeight = $(window).height();
		var chartHeight;
		
		chartHeight = viewPortHeight - 455;
		if(chartHeight<183){
			chartHeight = 183;
		}
		$('#dvPerformanceOverview').height(chartHeight);
	    if(viewPortWidth<800)
	    {	    	
            if(viewPortWidth<400){
	    		barsWidth = 15;
	    	}else{
	    		 barsWidth = 30;
	    	}
        }
			
	    $("#"+chartId).children().remove();
	    
	    var colorSeriesarray = [];
	 
	    var arr2 = ["#000000", "#3893cd", "#3893cd", "#3893cd","#3893cd","#3893cd","#3893cd","#3893cd","#3893cd", "#3893cd","#3893cd","#3893cd"];
    		/* var arr1 = ["#ADBCDB", "#74B7D9", "#FFD966","#C16579","#CC99CC","#666699","#FF9999","#99CC99", "#669999","#CC9966","#CCCC66","#666666","#7BCECF"]; */
    		var arr1 = ["#f18a4a", "#A81B38", "#f18a4a","#A81B38","#f18a4a","#A81B38","#f18a4a","#A81B38", "#f18a4a","#A81B38","#f18a4a","#A81B38","#f18a4a"];
    		var arr3 = ["#ffa132", "#ffa132", "#ffa132", "#ffa132","#ffa132","#ffa132","#ffa132","#ffa132","#ffa132", "#ffa132","#ffa132","#ffa132"];
		colorSeriesarray.push({'seriesColors' : arr1},{'seriesColors' : arr2},{'seriesColors' : arr3});
	 var maxValue = 0;
						//find max value
						for (var i = 0; i < data.length; i++) {
							for (var j = 0; j < data[i].length; j++) {
								var temp = data[i][j];
								if (parseInt(temp) > maxValue)
									maxValue = parseInt(temp);
							}
						}

						if (maxValue < 10)
    							dynamicTicks = [0, 2, 4, 6, 8, 10];
    						else if (maxValue >= 10 && maxValue <25)// To make graph pretty for small values
    							dynamicTicks = [0,5,10,15,20,25];
						//setting deafult ticks
						else {
							var len = Math.ceil(Math.log(maxValue + 1) / Math.LN10);
							var dynamicTicks = [];
							for (var j = 0; j <= (maxValue / Math.pow(10, len - 1)) + 2; j++) {
								if (len)
									dynamicTicks.push(j * Math.pow(10, len - 1));
								//push the ticks for graph (~maxValue + 2 no. of ticks)
							}
						}

						if(plotArrayBar.length>4){
					           for (var i = 0; i < plotArrayBar.length; i++)
								plotArrayBar[i].destroy();
					     } 

		 $("#"+chartId).innerHTML="";	
		 var rendererDetails;
		 if(attrs.ongraphclick != undefined || attrs.onstackedgraphclick != undefined){
			 rendererDetails = {barPadding:0, barMargin :0, barDirection : 'vertical' , barWidth :barsWidth, fillToZero :true, varyBarColor : true};
		 }
		 else{
			 rendererDetails = {barPadding:0, barMargin :0, barDirection : 'vertical' , barWidth :barsWidth, fillToZero :true, varyBarColor : true,highlightMouseOver :false};
		 }
	var chartTickAngle =0;
	if(data.length>8){
		chartTickAngle = -30;
	}
	var plotBar =$.jqplot(chartId,data,{title: ' ',height:chartHeight,
	    seriesDefaults: { renderer: $.jqplot.BarRenderer,pointLabels: { show: true ,stackedValue: false,location:'n', ypadding: 1,edgeTolerance: -30},rendererOptions:rendererDetails}, 
	    
        legend :{ show :false, location : 'e' , placement : 'outside'},
  
    series: colorSeriesarray,
        axes :
    { 
            xaxis :
	{
                renderer: $.jqplot.CategoryAxisRenderer,
                ticks :ticks,
                rendererOptions: {drawBaseline: true},
				tickRenderer: $.jqplot.CanvasAxisTickRenderer ,
				tickOptions: {
				  fontSize: '8pt',
				  angle: chartTickAngle,
				  showGridline: false
				}
            },
            yaxis:
	{
               ticks:dynamicTicks,
                rendererOptions: {drawBaseline: false},
            
	            tickOptions: {formatString: '%d',labelPosition: 'middle', 
                showGridline: false ,show: false
            },
	labelRenderer: $.jqplot.CanvasAxisLabelRenderer,
	labelOptions:{
            fontSize: '10pt'
	},
	label:yaxisLabel
	}
        },
   // seriesColors : colorSeriesarray,
    
    
             grid :{ borderWidth :0, shadow :false, drawGridLines: false,  gridLineColor: '#cccccc', background: '#FFFFFF'}
        });		
	
	
	if(plotArrayBar.length ==1){
		plotArrayBar = [];
	}
	plotArrayBar.push(plotBar);	
	
$(window).bind('resize', function(event, ui) {    
    if (plotArrayBar.length!= 0) {
	    var viewPortWidth = $(window).width();
	    var viewPortHeight = $(window).height();
		var chartHeight;
		
		chartHeight = viewPortHeight - 455;
		if(chartHeight<183){
			chartHeight = 183;
		}
        plotArrayBar[0].replot();
    }
});
/*$(".jqplot-point-label").click(function(event){
	// console.log(event.target.className);    
		var cellClassArray = event.target.className.split(" ");
		var pointCountArray = cellClassArray[cellClassArray.length-1].split("-");
		var seriesCountArray = cellClassArray[cellClassArray.length-2].split("-");
		var pointCount = parseInt(pointCountArray[pointCountArray.length-1]);              
		var seriesCount = parseInt(seriesCountArray[seriesCountArray.length-1]);
	 //   console.log(pointCount,seriesCount);                                                                                    
		
		if(attrs.ongraphclick != undefined)
		  scope[attrs.ongraphclick](pointCount+1);
		if (attrs.onstackedgraphclick != undefined)
			scope[attrs.onstackedgraphclick](seriesCount,pointCount); 


});*/
			  
	    $("#"+chartId).bind('jqplotDataClick', function(ev, seriesIndex, pointIndex, data)
	    {
		if(attrs.ongraphclick != undefined)
		{			    
		
		    scope[attrs.ongraphclick](data[0]);
		}
		else if (attrs.onstackedgraphclick != undefined)
		{
		    scope[attrs.onstackedgraphclick](seriesIndex,pointIndex,data);
		}
	    });		 
	    }
    	
    	else if(type == "comparisonChart")
    	{
    	    $("#"+chartId).jqplot( data, { 
    		title: '', 
    		seriesDefaults: {
    		    showMarker:false,
    		    pointLabels: {
    		    show: true,
    		    edgeTolerance: 5
    		    }},
    		axesDefaults: {
    		    showTicks: true,
    		    showTickMarks: true       
    		    },
    		legend: { show:true, 
    		    location: 's', 
    		    placement: 'outside'
    		    }
    	    });
    	}
    	
    	    $("#"+chartId).bind("jqplotClick", function(ev, gridpos, datapos, neighbor) {
    		if (neighbor) {
    		}
    	    });
    	    
    	}
        };
    	
        scope.$watch(attrs.ngModel, function () {
            renderChart();
        }, true);
        
        scope.$watch(attrs.ticks, function () {
            renderChart();
        }, true);
    	
        }
    	
        };
});
  
mServiceApp
		.directive(
				'lepopup',
				function() {
					return {
						restrict : 'E',
						templateUrl : 'template/lePopUp.html',
						scope : {
							control : '='
						},
						replace : true, // Replace with the template below
						// transclude: true, // we want to insert custom content
						// inside the directive
						link : function(scope, element, attrs) {
							scope.control.message = "";
							scope.control.show = false;
							scope.control.showWarning = function(header,
									message, button1Name, button1Function,
									button2Name, button2Function, closeFunction,errorPopupHeader) {
								scope.control.icon = "warning";
								scope.control.setProperties(header, message,
										button1Name, button1Function,
										closeFunction,errorPopupHeader);
								scope.control.setButton2Properties(button2Name,
										button2Function);
								scope.control.button3Show = false;
								scope.control.textAreaShow = false;
								scope.refresh();
							};

							scope.control.showQuestion = function(header,
									message, button1Name, button1Function,
									button2Name, button2Function, button3Name,
									button3Function, closeFunction) {
								scope.control.textAreaShow = false;
								scope.control.icon = "question";
								scope.control.setProperties(header, message,
										button1Name, button1Function,
										closeFunction);
								scope.control.setButton2Properties(button2Name,
										button2Function);
								scope.control.setButton3Properties(button3Name,
										button3Function);
								scope.refresh();

							};
							scope.control.showError = function(header, message,
									button1Name, button1Function, closeFunction) {
								scope.control.icon = "error";
								scope.control.setProperties(header, message,
										button1Name, button1Function,
										closeFunction);
								scope.control.button2Show = false;
								scope.control.button3Show = false;
								scope.control.textAreaShow = false;
								scope.refresh();

							};
							scope.control.showInformation = function(header,
									message, button1Name, button1Function,
									button2Name, button2Function, closeFunction) {
								scope.control.icon = "information";
								scope.control.setProperties(header, message,
										button1Name, button1Function,
										closeFunction);
								if (typeof button2Name == 'undefined') {
									scope.control.button2Show = false;
									scope.control.button3Show = false;
									scope.control.textAreaShow = false;
								} else {
									scope.control.textAreaShow = false;
									scope.control.setButton3Properties(
											button2Name, button2Function);
								}
								scope.refresh();

							};
							scope.control.showSuccess = function(header,
									message, button1Name, button1Function,
									button2Name, button2Function, closeFunction) {
								scope.control.icon = "success";
								scope.control.setProperties(header, message,
										button1Name, button1Function,
										closeFunction);
								if (typeof button2Name == 'undefined') {
									scope.control.button2Show = false;
									scope.control.button3Show = false;
									scope.control.textAreaShow = false;
								} else {
									scope.control.textAreaShow = false;
									scope.control.setButton3Properties(
											button2Name, button2Function);
								}

								scope.refresh();

							};
							scope.control.showBlockingPopUp = function(header,
									message) {
								scope.control.icon = "error";
								scope.control.blockingPopup = true;
								scope.control.setProperties(header, message);
								scope.control.button2Show = false;
								scope.control.button3Show = false;
								scope.control.textAreaShow = false;
								scope.refresh();

							};
							scope.control.setProperties = function(header,
									message, button1Name, button1Function,
									closeFunction,errorPopupHeader) {
								if (typeof button1Name == 'undefined') {
									button1Name = "OK";
								}
								if (typeof button1Function == 'undefined') {
									button1Function = scope.control.hideModal;
								}
								if (typeof closeFunction == 'undefined') {
									closeFunction = button1Function;
								}
								//emptying the scope's message variable,to fix bug 5285
								scope.control.message = "";
								scope.control.listDetails = [];
								scope.control.isDisplayList = false;
								scope.control.header = header;
								if (message instanceof Array) {// If an array
									// came as
									// argument,
									// First item
									// will be taken
									// as mesage and
									// others will
									// be listed
									// below.
									if(errorPopupHeader)
									{
									scope.control.message = message[0];
									message.shift();
									}
									if (message.length > 0) {
										scope.control.listDetails = message;
										scope.control.isDisplayList = true;
									}
								} else {
									scope.control.message = message;
								}
								scope.control.button1Label = button1Name;
								scope.control.show = true;

								scope.control.callBackPositive = function() {
									scope.control.message = "";
									scope.control.show = false;
									button1Function();

								};
								scope.control.closeFunction = function() {
									scope.control.message = "";
									scope.control.show = false;
									closeFunction();

								};

							};

							scope.control.setButton2Properties = function(
									button2Name, button2Function) {
								if (typeof button2Name == 'undefined') {
									scope.control.button2Show = false;
								} else {
									scope.control.button2Label = button2Name;
									scope.control.button2Show = true;
									if (typeof button2Function == 'undefined') {
										scope.control.callBackNegative = scope.control.hideModal;
									} else {
										scope.control.callBackNegative = function() {
											scope.control.show = false;
											button2Function();
										};
									}
								}
							};
							scope.control.setButton3Properties = function(
									button3Name, button3Function) {
								if (typeof button3Name == 'undefined'
										|| button3Name == '') {
									scope.control.button3Show = false;
								} else {
									scope.control.button3Label = button3Name;
									scope.control.button3Show = true;
									if (typeof button3Function == 'undefined'
											|| button3Name == '') {
										scope.control.showDetails = scope.control.hideModal;
									} else {
										scope.control.showDetails = function() {

											scope.control.details = button3Function();
											if (scope.control.textAreaShow) {
												scope.control.textAreaShow = false;
											} else {
												scope.control.textAreaShow = true;
											}
										};
									}
								}
							};
							scope.control.hideModal = function() {
								scope.control.show = false;
							};
							scope.$on('$destroy', function() {
								element.remove();
							});
						}
					};
				});
				
	/* lookupDdlDirective have a succescallback facility, attrs.success.
	* To enable it use the below attributes in the uijson
	*	"successTrue":true,
	*	"success":"directiveSuccess()", here directiveSuccess is the successcallback function.
	*/
mServiceApp.directive('lookupDdlDirective', function(UtilityService) {
	return {
		restrict : 'A',
		require : 'ngModel',
		link : function(scope, element, attrs) {
		    scope.initialize = true;
			element.bind("keyup", function() {
                              element.triggerHandler("change");
                            });
			attrs.$observe('observeattr', function(value) {
				scope.populateDependentLookupDate(attrs.childType,
						attrs.childName, UtilityService.evaluateModel(scope, attrs.ngModel),
						attrs.grandChildren,attrs.childModel,scope.initialize,attrs.success);
			scope.initialize = false;
			});
			attrs.$observe('observetype', function(value) {
				scope.populateIndependentLookupDate(attrs.observetype,attrs.observearrayname,attrs.filterobj,attrs.selectindex,attrs.index,attrs.ngModel,attrs.setDefault,attrs.dropdowntype,attrs.success);
			});
			scope.$on('$destroy', function() {
				element.remove();
			});
		},
		controller : function($scope, DataLookupService,$location,$rootScope,$translate) {
			$scope.populateIndependentLookupDate = function(type, fieldName,filterObj,selectedRequirementIndex,$index,model,setDefault,dropDownType,successCallback) {
				if (!$scope[fieldName] || $scope[fieldName].length == 0) {
					$scope[fieldName] = [ {
						"key" : "",
						"value" : "loading ...."
					} ];
					var options = {};
					options.type = type;
					DataLookupService.getLookUpData(options, function(data) {
						angular.forEach(data, function (obj,index) {
							obj.value +=" ";
						});
						$scope[fieldName] = data;
						if(setDefault){
                                         for ( var i = 0; i < data.length; i++) {
                                            if(data[i].isDefault==1){
                                               UtilityService.bindModel($scope,model,data[i].code);
                                               break;
                                            }
                                         }
                                      }
						if(filterObj){
							UtilityService.bindModel($scope,"$scope."+model,$scope[fieldName][0].code);
						}
						if($scope[fieldName].length ==1 && dropDownType=="docUpload"){
							UtilityService.bindModel($scope,"$scope."+model,$scope[fieldName][0].code);
						}
						$scope.refresh();
						if(successCallback){
							$scope[successCallback]();
						}
					}, function(errorData,status) {
							if (status == '401') {
								$rootScope.lePopupCtrl.showError(translateMessages($translate, "lifeEngage"),
								translateMessages($translate, "general.validToken"),translateMessages($translate, "fna.ok"),
								function(){
									$location.path('/login');
									$rootScope.refresh();
									$rootScope.showHideLoadingImage(false);
								});
							}
						$scope[fieldName] = [];
					});
				}
			},$scope.setValuetoScope=function(model,value){
                        var _lastIndex=model.lastIndexOf(".");
                        if(_lastIndex>0){
                               var parentModel=model.substring(0,_lastIndex);
                               var scopeVar=$scope.getValue(parentModel);
                                      var remain_parentModel =model.substring(_lastIndex+1,model.length);
                               scopeVar[remain_parentModel]=value;
                        }else{
                        	 $scope.model=value;
                        }
                  },$scope.getValue = function(model) {
                        if ($scope.isVariableExists(model)) {
                            var m=$scope.evaluateString(model);   
                        	return m;
                        }
				},$scope.isVariableExists = function(variable) {
                	    var modelData=variable;
                        variable = variable.split('.');
                        var obj = $scope[variable.shift()];
                        for(a in variable) {
                        	if(variable[a].indexOf('[')>=0){
                        		var length=variable[a].indexOf('[');
                        		if(variable[a].indexOf(']')==(length+2)){
                        			var flag=true;
                            		break;
                        		}
                        	}
                        }
                        while (obj && variable.length)
                               obj = obj[variable.shift()];
                        if(flag==true){
							return modelData;
						}
                        else{
                        	return obj;
						}
                  }
				$scope.evaluateString = function(value) {
					var val;
                    var variableValue = $scope;
                    val = value.split('.');
                    if(value.indexOf('$scope') != -1){
                        val = val.shift();
                    }
					for(var i in val){
                        variableValue = variableValue[val[i]];
                    }
                    console.log(variableValue);
                    return variableValue;
                };
			$scope.populateDependentLookupDate = function(type, fieldName,
					parentCode, grandChildren,childModel,initialize,successCallback) {
				if (parentCode && parentCode.trim() != "") {
					$scope[fieldName] = [ {
						"key" : "",
						"value" : "loading ...."
					} ];
					var options = {};
					options.type = type;
					options.code = parentCode;
					DataLookupService.getLookUpData(options, function(data) {
						$scope[fieldName] = data;
						 if(childModel && initialize == false)
							 UtilityService.bindModel($scope,"$scope."+childModel ,data[0].code);
						 $scope.refresh();
						if(successCallback){
							$scope[successCallback]();
						}
					}, function(errorData,status) {
						if (status == '401') {
							$rootScope.lePopupCtrl.showError(translateMessages($translate, "lifeEngage"),
							translateMessages($translate, "general.validToken"),translateMessages($translate, "fna.ok"),
							function(){
								$location.path('/login');
								$rootScope.refresh();
								$rootScope.showHideLoadingImage(false);
							});
						} else {
							$scope[fieldName] = [];
						}
					});
					if (grandChildren != "" && grandChildren != undefined) {
						var grandChildrens = grandChildren.split(",");
						for ( var i = 0; i < grandChildrens.length; i++) {
							$scope[grandChildrens[i]] = [];
						}
					}
				} else {
					$scope[fieldName] = [];
					if (grandChildren != "" && grandChildren != undefined) {
						var grandChildrens = grandChildren.split(",");
						for ( var i = 0; i < grandChildrens.length; i++) {
							$scope[grandChildrens[i]] = [];
						}
					}
				}
			}, $scope.getValue = function(model) {
				    var m=$scope.evaluateString(model);
					return m;
			}, $scope.isVariableExists = function(variable) {
				variable = variable.split('.');
				var obj = $scope[variable.shift()];
				while (obj && variable.length)
					obj = obj[variable.shift()];
				return obj;
			},
			$scope.getFilterResult = function(data,filterObj) {
				 var filterData=[];
				 var filterArray = UtilityService.evaluateModel($scope,filterObj);
				 if(typeof filterArray == 'undefined' || filterArray.length==0){
					filterData =  data;
				 }
				 else{
					 for(var i=0; i<data.length;i++){
						if($.inArray(data[i].code, filterArray)!=-1){
							filterData.push(data[i]);
						}
					 }
				 }
				return filterData;
			};
			$scope.$on('$destroy', function() {
				if(typeof element!="undefined")
					element.remove();
			});
		}
	};
});				
				
mServiceApp.directive('filelistBind', function (UtilityService) {
    return function (scope, elm, attrs) {
        elm.bind('change', function (evt) {
        	var evaluatedVal = JSON.parse(evt.target.attributes.isimage.value);
            var isImage = evaluatedVal;
            var isPhoto = evaluatedVal;
            scope.$apply(function () {
                scope.browseFile(isImage,isPhoto, evt.target.files[0]);



            });
        });
    };
});


/* custom popup for Action popup - updated by Anoj */  
var servDirectives = angular.module('serv.directives', []);
servDirectives.directive('actionpopup', function ($compile) {
    return {
        restrict: 'E',
        // include smart table controller to use its API if needed
        //require: '^smartTable',
		scope:true,		
        template: '<span class="only-mob-tab-inline-block"><a class="call-action"></a></span>',
        replace: true,
        link: function (scope, element, attrs, ctrl) {
        	var mobNumber;
        	 attrs.$observe('number', function(value) {         		  
     			mobNumber = value;
     			
     			if(mobNumber == undefined){
     				
     				  // can use scope.dataRow, scope.column, scope.formatedValue, and
     				// ctrl API
    				scope.mobNumber = scope.dataRow.contactNumber;
    				scope.emailId = scope.dataRow.emailId;
    			}
    			else{
    				scope.mobNumber = mobNumber; 
    			}
     			
    			scope.showPopup = function(){
    				// var thisObj = $(this);
    				var individualOffset = findOffset(element);
    				var topVal = individualOffset[0];
    				var leftval = individualOffset[1];
					var arrowClass = individualOffset[2];
    				showPopupModal(".common_model_container",".action_popup",topVal,leftval,arrowClass);
    			}

    			function findOffset(thisObj){
					var x =30;
					var y =  -95;
					var arrowClass="arrow";
    				var cordinateVal = $(thisObj).offset();
    				var scrollTopVal = $('body').scrollTop();
    				var scrollLeftVal = $('body').scrollLeft();
					var fixedTop = (cordinateVal.top - scrollTopVal);
					var fixedLeft = (cordinateVal.left - scrollLeftVal );
					if($(window).height()/2<fixedTop){
						x = -135;
						arrowClass="arrow-bottom ";
					}
					if($(window).width()/2>fixedLeft){
						y = -10;
						arrowClass=arrowClass+" arrow-left";
					}
					else{
						arrowClass=arrowClass+" arrow-right";
					}

    			   var topVal = fixedTop + x + "px";
    				var leftVal = fixedLeft + y  + "px";
    				return [topVal,leftVal,arrowClass];
    			}
    			function showPopupModal(modalPopupOverlay,modalCOntainer,top,left,arrowClass){
    			
    			var html = "<div class='"+arrowClass+"'></div>" +
    							"<ul>"+
    							  "<li><a class='sms'  data-toggle='modal' data-target='#actionPopupSharePopupModal'> Message </a></li>"+
    							  "<li class='mob-tab-only'><a class='call' target='_self' href='tel:"+scope.mobNumber+"'> Call </a></li>"+
    							  "<li><button type='button' class='cust-btn cust-default-btn orange open-native-contact-list'> Search </button></li>"+
    							 							  
    							"</ul>";
    				var disp = $(modalPopupOverlay).css("display"); 
    				if(disp == "none"){
    					$(modalPopupOverlay).css("display","block");
    					$('body').addClass('no-overflow');
    					$(modalCOntainer).css(
    							   {
    								   "display": "block",
    								   "top" : top,
    								   "left" : left
    							   });
    						$compile(html)(scope);					 
    						$(modalCOntainer).html("");
    						$(modalCOntainer).append(html);
     						
    					}
    					
    				$(modalCOntainer).off('click').click(function(e){
				        if($(e.target).hasClass('open-native-contact-list')){
                         	 navigator.contacts.pickContact(function(contact) {
								document.location.href = 'tel:'+contact.phoneNumbers[0].value;
							 }, function() {console.log("Error")});
                         }
						 if (/webOS|iPhone|iPad/i.test(navigator.userAgent)) {
							 if($(e.target).hasClass('call')){
								document.location.href = 'tel:'+scope.mobNumber;
							 }
						 }
    					$(this).css("display","none");
    					$(modalPopupOverlay).css("display","none");
						$('body').removeClass('no-overflow');
    				});
    				 $(modalPopupOverlay).click(function(){
    					$(this).css("display","none");
    					$(modalCOntainer).css("display","none");
						$('body').removeClass('no-overflow');
    				});
    			}
         	  });
          
        }
    };
});

/* To calculate the window height and add the corresponding height to the login container 
to make the footer at the bottom of the window*/ 
servDirectives.directive('loginParent', function () {
    return {
        restrict: 'A',
        replace: true,
        link: function (scope, element, attrs, ctrl) {
			var viewPortHeight = $(window).height();
			var id = $('body').attr('id');
			if(id=="mobile-touch-device"){
				$(element).height(viewPortHeight);
			}
			else{
				$(element).height(viewPortHeight-120);
				
				$( window ).resize(function() {
					// do stuff here to handle the viewport changes	
					viewPortHeight = $(window).height();
					$(element).height(viewPortHeight-120);			
				});
				
			}
        }
    };
});



/*  To calculate and set the height for right panel in dashboard based on window height*/
servDirectives.directive('dashboardAlertHeight', function () {
    return {
        restrict: 'A',
        replace: true,
        link: function (scope, element, attrs) {
			rightPanelHeight = ($(window).height())-100;
			if($(window).width()>800){
				$('#mobile-touch-device #right-panel').height(rightPanelHeight);   
			}			
		}
    };
});


servDirectives.directive('tableScroll1', function () {
    return {
        restrict: 'A',
        replace: true,
        link: function (scope, element, attrs) {
		
			var headObj = JSON.parse(attrs.columns);
			var columnCount = headObj.length;
			
			
			
			function setParentWidth(columnCount,element,headObj){
			
				var totTblWidth=0;	
				for (x=0; x<headObj.length; x++) {
					if (!(typeof headObj[x].cellClass === "undefined")) {
						var cellWidthArray = headObj[x].cellClass.split("_");
						var cellWidth = parseInt(cellWidthArray[cellWidthArray.length-1]);
						if(cellWidth==0 || isNaN(cellWidth)){
							cellWidth = 150;
						}
					}
					else{
						cellWidth = 150;
					}
					totTblWidth = totTblWidth + cellWidth+10 ;
				}
								
				var parentWidth = $(element).parent().parent().width();
				if(parentWidth==0){ /* fix added for smart tables inside modal*/
					parentWidth = (($(window).width()*0.90)-(30));
				}
				$(element).children('.smart-outer').width(parentWidth);
				
				if(totTblWidth<=parentWidth)
				{
					$(element).find('table').width(parentWidth);
				}
				else{    
					/* added 20 for table row td padding */
					$(element).find('table').width(totTblWidth+20);
				}
				
				$(element).find('table').addClass(totTblWidth.toString());
				$(element).find('table').addClass(columnCount.toString());
				
				
			}
			
			setParentWidth(columnCount,element,headObj);
			
			// $( window ).resize(function() {
				// // do stuff here to handle the orientation changes
				// setParentWidth(columnCount,element,headObj);
				
			// });
		}
    };
});

servDirectives.directive('tblColMap', function () {
    return {
        restrict: 'A',
        replace: true,
        link: function (scope, element, attrs) {
		
			function setColumnWidth(element,attrs){
			
				if (!(typeof scope.column.cellClass === "undefined")) {
					var cellWidthArray =scope.column.cellClass.split("_");
					var cellWidth = parseInt(cellWidthArray[cellWidthArray.length-1]);
					if(cellWidth==0 || isNaN(cellWidth)){
						cellWidth = 150;
					}
				}
				else{
					cellWidth = 150;
				}


				var parentWidth = $(element).parents('table').width();
				
				var tblWidthArray =$(element).parents('table').attr('class').split(" ");
				var calTblWidth = parseInt(tblWidthArray[tblWidthArray.length-2]);
				var calColCount = parseInt(tblWidthArray[tblWidthArray.length-1]);
				
				/* $(element).parents('td').css("min-width",parentWidth-21); */

				if(calTblWidth>=parentWidth){
					$(element).width(cellWidth);
				}
				else{
					var balanceWidth = parentWidth-calTblWidth;
					var padWidth = balanceWidth/calColCount;
					$(element).width(cellWidth+padWidth-7);	
				}
			
			}
			setColumnWidth(element,attrs);
			
			
			// $( window ).resize(function() {
				// // do stuff here to handle the orientation changes
				// setColumnWidth(element,attrs);
				
			// });	

		}
    };
});



servDirectives.directive('tblHeadMap', function () {
    return {
        restrict: 'A',
        replace: true,
        link: function (scope, element, attrs) {
		
			function setColumnWidth(element,attrs){
			
				if (!(typeof scope.column.cellClass === "undefined")) {
					var cellWidthArray =scope.column.cellClass.split("_");
					var cellWidth = parseFloat(cellWidthArray[cellWidthArray.length-1]);
					if(cellWidth==0 || isNaN(cellWidth)){
						cellWidth = 150;
					}
				}
				else{ 
					cellWidth = 150;
				}				
				var parentWidth = $(element).parents('table').width();
				
				
				var tblWidthArray =$(element).parents('table').attr('class').split(" ");
				var calTblWidth = parseInt(tblWidthArray[tblWidthArray.length-2]);
				var calColCount = parseInt(tblWidthArray[tblWidthArray.length-1]);
				
				/* $(element).parents('td').css("min-width",parentWidth-21); */
				
				
				if(calTblWidth>=parentWidth){
					$(element).width(cellWidth*(scope.column.columnNo));
				}
				else{
					var balanceWidth = parentWidth-calTblWidth;
					var padWidth = balanceWidth/calColCount;
					$(element).width((cellWidth+padWidth-1)*(scope.column.columnNo));	
				}
			
			}
			setColumnWidth(element,attrs);
			
		}
    };
});



servDirectives.directive('paintui', function () {
    return {
        restrict: 'E',		
		scope:true,		
		template: '<div class="dvLEPaintUI"></div>',
        replace: true,		
        link: function (scope, element, attrs, ctrl) {
	    
		    if (attrs.viewid) {			
			scope.$parent.onPartialLoaded(element,scope,attrs.viewid);
		    }
		    else
		    {
			
			scope.$parent.onPartialLoaded(element,scope);
		    }
		}
		
	 };
});


servDirectives.directive('collapseFinder', function () {
    return {
        restrict: 'A',
        replace: true,
        link: function (scope, element, attrs) {
			$(element).on('hidden', function () {
			   $(element).prev().find('a').addClass("collapsed");
			});
		}
    };
});


servDirectives.directive('datePicker', function (dateFilter, $filter, $parse,UtilityService) {
	
	   return {
	        restrict: 'A',
			replace: true,	
			require: 'ngModel',
	        link: function (scope, element, attrs,ngModelCtrl) {	
				var elem = document.createElement('input');
				elem.setAttribute('type', 'date');
				var id_elmnt = attrs['id'];
				var elmType = '#' + element[0].id;
				var ngModelVal = $parse(attrs.ngModel);
				function getAndroidVersion(ua) {
				    var ua = ua || navigator.userAgent; 
				    var match = ua.match(/Android\s([0-9\.]*)/);
				    return match ? match[1] : false;
				};

				var version = parseFloat(getAndroidVersion());
//In IE
			    if (!rootConfig.isDeviceMobile) {
					element.attr('type', 'text');
						$('.custDate').datepicker({
							format : 'yyyy-mm-dd',
							autoclose : true
						})
						.focus(function() {
							$(this).prop("autocomplete", "off");
							return false;
						});
						$(elmType).on('show',function(ev){
							$(this).data({date: $(this).val()});
							$(this).datepicker('update');
							$('#datepickerOverlay').show();
						});
						$(elmType)
								.on(
										'changeDate',
										function(ev) {
											var id_elmnt_Model = attrs['ngModel'];
											var selected_date = $(
													'#' + id_elmnt)
													.val();

											var modelObject = id_elmnt_Model
													.substring(
															0,
															id_elmnt_Model
																	.lastIndexOf('.'));
											var modelVariable = id_elmnt_Model
													.substring(id_elmnt_Model
															.lastIndexOf('.') + 1);
											if (modelObject.length > 0) {
												modelObject = "."
														+ modelObject;
											}
											if(typeof selected_date !="undefined"){
												//eval('scope' + modelObject)[modelVariable] = selected_date;
												UtilityService.bindModel(scope,id_elmnt_Model,selected_date);
											}else{
											
												//eval('scope' + modelObject)[modelVariable] =eval('scope' + modelObject)[modelVariable];
												var dateValue = UtilityService.evaluateModel(scope,id_elmnt_Model);
												UtilityService.bindModel(scope,id_elmnt_Model,dateValue);
											}
											if (attrs.customBlur) {
												scope[customBlur]();
											}
											$('#datepickerOverlay').hide();
											scope.refresh();
										});
			   }
			    // Chrome, Devices
				else{
					$(element).attr('type','date');
					$(element).addClass('native');

					
					
					if (navigator.userAgent.indexOf("Android")> 0){
			            $(element).click(function(event) {
		                       
			            	if(version< 4.4){
			            		element.preventDefault();	
			            	}
			            	else{
			            		event.preventDefault();
			            	}
		                         
		                       
		                         var selectedObject = $(this);
		                       
		                         var FORMAT_KEY = "datepickerformat";
		                         var OPEN_KEY = "datepickeropen";
		                         
		                         var YES = "YES";
		                         var NO = "NO";
		                         
		                        //read the element attribute to know datepicker is already open or not
		                         var isOpen = $(selectedObject).attr(OPEN_KEY);
		                      
		                         //read the custom format specified as element attribute
		                         var format = $(selectedObject).attr(FORMAT_KEY);
		                         
		                         //if no format specified set the default
		                         if(!format || format.length == 0)
		                              format = "yyyy-MM-dd";
                                       $(selectedObject).attr(OPEN_KEY,YES);
		                               window.plugins.EappDatePicker.showDatePicker(function(data) { $(selectedObject).val(data.SelectedDate); $(selectedObject).trigger('input'); $(selectedObject).attr(OPEN_KEY,NO); },function(err) {$(selectedObject).attr(OPEN_KEY,NO);},format,$(selectedObject).val());
		                         });
					}
	    
				}
					if (ngModelVal) {
						ngModelCtrl.$formatters.push(function(val) {
							var returnValue;
							if(typeof val =="undefined" || val ==""){
							    returnValue =""
							}else{
								if (!rootConfig.isDeviceMobile){
									returnValue = val;
								}else{
									now = new Date(val);
                                    year = "" + now.getFullYear();
                                    month = "" + (now.getMonth() + 1);
                                    if (month.length == 1) {
                                    	month = "0" + month;
                                    }
                                    day = "" + now.getDate();
                                    if (day.length == 1) {
                                    	day = "0" + day;
                                    }
                                    returnValue = year + "-" + month + "-" + day;
								}
							}
						return returnValue;
						scope.refresh();
						});
						ngModelCtrl.$parsers.push(function(val) {
							if (val != null && typeof val != "undefined" && val !="") {
									var now, month, day;
									now = new Date(val);
									year = "" + now.getFullYear();
									month = "" + (now.getMonth() + 1);
									if (month.length == 1) {
										month = "0" + month;
									}
									day = "" + now.getDate();
									if (day.length == 1) {
										day = "0" + day;
									}
									return year + "-" + month + "-" + day;
							} else {
								return "";
							}

						});
					}
					scope.$on('$destroy', function() {
						if(typeof elm !="undefined"){
							elm.remove();
						}
					});
}
			
		 };
});

servDirectives.directive('linkInjector', function () {
    return {
		 restrict: "A",
	        replace: true,
            link: function (scope, element, attrs) {    
          	  attrs.$observe('linkInjector', function(value) {         		  
          		  $(element).parent().prev().find('.pdfdata').attr('href', value);         
          	  });         
        }
    }
});




servDirectives
.directive(
		'validateInput',['$translate', 
		function($translate) {
			return {
				restrict : "A",
				replace : true,
				scope : true,
				require : 'ngModel',
				link : function(scope, element, attrs, ctrl, ngModel) {
					var searchField;
					var searchValue;
				
					var policyNumberPattern = "^(\\d{9})$";
					var namePattern = "^([a-zA-Z ]*)$";
				
					var mobileNumberPattern = "^(\\d{10})$";
					var clientIdPattern = "^[a-zA-Z0-9]*$";
					var premiumAmountPattern = "^-?\\d*\\.\\d{2}$";
					var proposalNumberPattern = "^(\\d{9})$";
                    var isMobile = attrs.device;
					function validatePattern(value, pattern) {
						var pattern = new RegExp(pattern);
						if (!pattern.test(value)) {
							return false;
						} else {
							return true;
						}
					}
					function validateInput() {
					
					 if(searchField == undefined){
						searchField = attrs.field; 
					}
				
						if(searchField != undefined  && searchValue != undefined){
							
							if(isMobile != undefined){
								scope.$parent.$parent.policyNumberValidationMessage = "";
								scope.$parent.policyNumberValidationMessage = "";
								scope.$parent.mobileNumberValidationMessage = "";
								scope.$parent.nameValidationMessage = "";
								scope.$parent.cilentIdValidationMessage = "";
								scope.$parent.proposalNumberValidationMessage="";
								scope.$parent.premiumAmountValidationMessage="";
								
							}
							
						
							if ((searchField.replace(/ +/g, "")) == "PolicyNumberCommissions") {
								if( searchValue == ""){
									 scope.$parent.$parent.policyNumberValidationMessage = "";
								}
								else{
									if (!validatePattern(searchValue,
											policyNumberPattern)) {
										scope.$parent.$parent.policyNumberValidationMessage = translateMessages($translate, "policyNumberValidationErrorMessage");
										
									} else {
									   scope.$parent.$parent.policyNumberValidationMessage = "";
									}	
								}
								
							}
							else if ((searchField.replace(/ +/g, "")) == "PolicyNumber") {
								if(searchValue == ""){
									scope.$parent.policyNumberValidationMessage = "";
								}
								else{
									if (!validatePattern(searchValue,
											policyNumberPattern)) {
										scope.$parent.policyNumberValidationMessage = translateMessages($translate, "policyNumberValidationErrorMessage");
									} else {
										scope.$parent.policyNumberValidationMessage = "";
									}	
								}
								
							} else if ((searchField.replace(/ +/g, "")) == "MobileNumber") {
								if(searchValue == ""){
									scope.$parent.mobileNumberValidationMessage = "";
								}
								else{
									if (!validatePattern(searchValue,
											mobileNumberPattern)) {
										scope.$parent.mobileNumberValidationMessage = translateMessages($translate, "mobileNumberValidationErrorMessage");
										
									} else {
										scope.$parent.mobileNumberValidationMessage = "";
									}	
								}
								
							} else if ((searchField.replace(/ +/g, "")) == "Name") {
														
                                 if(searchValue == ""){
                                	      scope.$parent.nameValidationMessage = "";
								}
								else{
									if (!validatePattern(searchValue,
											namePattern)) {
										scope.$parent.nameValidationMessage = translateMessages($translate, "namePatternValidationErrorMessage");
										
									} else {
										scope.$parent.nameValidationMessage = "";
									}
								}
								
							} 
							else if ((searchField.replace(/ +/g, "")) == "LastName") {
								
                                if(searchValue == ""){
                               	      scope.$parent.lastNameValidationMessage = "";
								}
								else{
									if (!validatePattern(searchValue,
											namePattern)) {
										if(scope.$parent.nameValidationMessage == ""){
											scope.$parent.lastNameValidationMessage = translateMessages($translate, "namePatternValidationErrorMessage");
										}
										
									} else {
										scope.$parent.lastNameValidationMessage = "";
									}
								}
								
							} 
							else if ((searchField.replace(/ +/g, "")) == "ClientID") {
							
								
                                 if(searchValue == ""){
                                	 scope.$parent.cilentIdValidationMessage = "";
								}
								else{
									if (!validatePattern(searchValue,
											clientIdPattern)) {
										scope.$parent.cilentIdValidationMessage = translateMessages($translate, "clientIdPatternValidationErrorMessage");
									} else {
										scope.$parent.cilentIdValidationMessage = "";
									}
								}
								
								
								
							
							} else if ((searchField.replace(/ +/g, "")) == "PremiumAmount") {
								
                                 if(searchValue == ""){
                                	 scope.$parent.premiumAmountValidationMessage = "";
								}
								else{
								    if (scope.premiumAmountValidation(searchValue)) {
									scope.$parent.premiumAmountValidationMessage = "";
								    }
								    else
								    {
									if (!validatePattern(searchValue,
											premiumAmountPattern)) {
										//alert("searchValue=="+searchValue);
										scope.$parent.premiumAmountValidationMessage = translateMessages($translate, "premiumAmountValidationErrorMessage");
									} else {
										scope.$parent.premiumAmountValidationMessage = "";
									}
								    }
								}
								
								
							} else if ((searchField.replace(/ +/g, "")) == "ProposalNumber") {
								
                                  if(searchValue == ""){
                                	  scope.$parent.proposalNumberValidationMessage = "";
								}
								else{
									if (!validatePattern(searchValue,
											proposalNumberPattern)) {
										scope.$parent.proposalNumberValidationMessage = translateMessages($translate, "proposalNumberValidationErrorMessage");
									} else {
										scope.$parent.proposalNumberValidationMessage = "";
									}
								}
								
								
							}
					
						}
					}
					scope.premiumAmountValidation = function(number)
					{
						if(!isNumber(number))
							return false;
					    var pieces = number.split(".");
					    if (pieces[1])
					    {
						if (pieces[1].length > 0)
						{
						    if (pieces[1] == '0' || pieces[1] == '00')
						    {
							 return true;
						    }
						    else
						    {
							return false;
						    }
						}
						else
						{
						    return true;						
						}	
					    }
					    return true;
					}

					scope.$watch(attrs.ngModel, function(value) {
						searchValue = value;
						validateInput();
					});

					scope.$watch(attrs.field, function(value) {
						searchField = value;
						
						if(searchField == "Policy Issue Date" || searchField == "Premium Due Date" || searchField == "Proposal Received Date" ){
							scope.$parent.isDateField = true;
						}
						else{
							scope.$parent.isDateField = false;
						}
						
						validateInput();
					});

				}
			}
		}
		]);



/*  To calculate and set the min-height for data-container based on window height*/
servDirectives.directive('viewPortHeight', function () {
    return {
		 restrict: "A",
	        replace: true,
            link: function (scope, element, attrs) {  
				var viewPortHeight = $(window).height();
				// for desktop
				$(element).css('min-height', viewPortHeight-154+'px');  
				// for tab/mobile				
				$('#mobile-touch-device #data-cont').css('min-height', viewPortHeight-215+'px');
        }
    }
});

/*  To calculate and set the max-height for map-filter container based on window height*/
servDirectives.directive('viewPortHeightMap', function () {
    return {
		 restrict: "A",
	        replace: true,
            link: function (scope, element, attrs) {  
				var viewPortHeight = $(window).height();
				// for desktop
                $(element).css('max-height', viewPortHeight-160+'px');
				// for tab/mobile
                $('#mobile-touch-device .mapWrapper .content-section .filter-box').css('max-height', viewPortHeight-215+'px');
        }
    }
});

/*  To hide/show calendar modal on click */
servDirectives.directive('calendarModalActions', function () {
    return {
		 restrict: "A",
		replace: true,
		link: function (scope, element, attrs) {  
			$(element).on('click', function () {
				$(element).toggleClass("open");
				$(element).parents(".premium-calendar-description").toggleClass("high-index");
				$('#calStat').toggleClass("hide");
				/*$('body').toggleClass("hide_scroll");*/
				$('.common_model_overlay').toggle();
			});
		}
    }
});

/*  IE8 fix to identify checkbox checked and apply CSS */
/*servDirectives.directive('identifyChecked', function () {
    return {
		 restrict: "A",
		replace: true,
		link: function (scope, element, attrs) { 
			$(element).on( "click", function(){
				if($(element).prop("checked")){
					$( element).next( "label" ).addClass("css-checkbox-checked");
				}
				else{
					$( element).next( "label" ).removeClass("css-checkbox-checked");
				}
				
			});		
		}
    }
});*/

servDirectives.directive('premiumCalendarActions', function () {
    return {
		 restrict: "A",
		replace: true,
		link: function (scope, element, attrs) {  
			$(element).on('click', function () {
				$(".modal-backdrop").remove();
				//$(element).parents(".premium-calendar-description").toggleClass("high-index");
				//$('#calStat').toggleClass("hide");
				//$('body').toggleClass("hide_scroll");
				//$('.common_model_container').toggle();
			});
		}
    }
});

/*  enable padding for smart table outer div to hold the pagination and hide if there is no pagination */
servDirectives.directive('enablePane', function () {
    return {
		 restrict: "A",
		replace: true,
		link: function (scope, element, attrs) {  
			scope.$watch(attrs.page, function(value) {
				if(value){
					$( element ).closest( ".paintui-outer" ).removeClass("padding0");
					$( element ).closest( ".dvLEPaintUI" ).removeClass("paddingbottom0");
				}
				else{
					$( element ).closest( ".paintui-outer" ).addClass("padding0");
					$( element ).closest( ".dvLEPaintUI" ).addClass("paddingbottom0");
				}
			});
		}
    }
});

servDirectives.directive('startupPopup', function () {
    return {
		 restrict: "A",
		replace: true,
		link: function (scope, element, attrs) {  
			if($(window).width()>800){
			    var windowHeight = $(window).height();
				if(windowHeight<670){
				    var popupHeight = windowHeight-50;
                    var popupWidth =  popupHeight*(550/630);	
                    var marginTop = popupHeight/2; 					
                    var marginLeft = popupWidth/2; 					
					$(element).css({
						'max-height' : popupHeight+'px' ,
						'max-width' : popupWidth+'px',
						'margin-top' : "-"+ marginTop +'px',
						'margin-left' : "-"+marginLeft+'px'
					});	
				}
			}				
		}
    }
});


servDirectives
.directive(
		'buildGoals',
		function($translate) {
			return {
				restrict : "A",
				replace : true,
				scope : true,
				require : 'ngModel',
				link : function(scope, element, attrs, ctrl, ngModel) {

					var noOfPoliciesPattern = "^\\d+$";
					var commisionPercentIntegerPattern = "^\\d{0,3}$";
					
					var otherPayoutPattern = "^-?\\d*\\.\\d{0,2}$";
					var isPolicyValid = true;
					var isCommissionPercentValid = true;
					var isOtherPayoutValid = true;
					var isMyGoalsValid = true;
					var isNumeberValid =  true;
					var isAmountValid =  true;
					var isPayoutValid =  true;
					var commisionPercentDecimalPattern = "^-?\\d*\\.\\d{0,2}$";

					function validateInput(value,fieldPattern) {
						var pattern = new RegExp(fieldPattern);
						if (!pattern.test(value)) {
							return false;
						} else {
							return true;
						}
					}
					function getBetweenDates(inputMonth, inputYear,currentMonth,currentYear,
							startMonthCount, monthsCount) {
						var now = new Date();
						var preDateStart = new Date(currentYear,
								currentMonth - startMonthCount, 31);
						var preDateEnd = new Date(currentYear,
								currentMonth- monthsCount, 1);
						now.setMonth((inputMonth) - 1);
						now.setUTCFullYear(inputYear);
						if (now < preDateStart && now > preDateEnd) {
							return true;
						} else {
							return false;
						}

					}
					scope.$watch(attrs.ngModel,function(value) {

						var monthArray = [ "Jan","Feb", "Mar", "Apr","May", "Jun", "Jul","Aug", "Sep", "Oct","Nov", "Dec" ];
						var policyDate = scope.$parent.$parent.$parent.dateListTemp[attrs.index].policyMonth;
						var version = getBrowserVersion();
						var monthSplit = policyDate.split("-")[0];
						var monthIndex;
						if (version > -1 && version <= 8.0) {
							monthIndex = ($.inArray(monthSplit, monthArray))+1;
						}

						else {
							monthIndex = (monthArray.indexOf(policyDate.split("-")[0]))+1;
						}
						
						var year = policyDate
								.split("-")[1];
						var isUpdate = false;
						var totalCommissionValue = 0;
						var totalPremiumAmount = 0;
						
						if(value != undefined && value != ""){
							switch (attrs.key) {
							case "No of Policies":
									if(value != ""){
										isPolicyValid = validateInput(value,noOfPoliciesPattern);
										if(value <= 0){
											isPolicyValid =  false;
										}
											if(value.length <= 5 ){
												isNumeberValid =  true;
											}
											else{
												isNumeberValid =  false;
											}

										
										if(!isPolicyValid){
											scope.$parent.$parent.$parent.noOfPoliciesValidationMessage = translateMessages($translate, "myBusiness.enterPositiveNoOfPolicies");
										}
										else if(!isNumeberValid){
											scope.$parent.$parent.$parent.noOfPoliciesValidationMessage =translateMessages($translate, "myBusiness.entermaxNoOfPolicies");
										}
										else{
											scope.$parent.$parent.$parent.noOfPoliciesValidationMessage = "";
										}
									}
									else{
										scope.$parent.$parent.$parent.noOfPoliciesValidationMessage = "";
									}
								break;
							case "Commission %":
								if(value != ""){
									
									
									if((1/value)===-Infinity || value < 0){
										isCommissionPercentValid = false;
									}
								else if(validateInput(value.replace(/,/g,""),
											commisionPercentDecimalPattern) || validateInput(value.replace(/,/g,""),
													commisionPercentIntegerPattern)){
										isCommissionPercentValid = true;
									}
									
									else{
										isCommissionPercentValid = false;
									}
										
									if(!isCommissionPercentValid){
										scope.$parent.$parent.$parent.commissionPercentValidationMessage =translateMessages($translate, "myBusiness.enterPositiveCommision"); 
									}
									else{
										scope.$parent.$parent.$parent.commissionPercentValidationMessage = "";
									}
								}
								else{
									scope.$parent.$parent.$parent.commissionPercentValidationMessage = "";
								}
							break;
								
								
							case "My Goals\n(MFYP In Rs)":
								if(value != ""){
									var result  = ((value.replace(/,/g,"")) / 1000);
									isMyGoalsValid = validateInput(result,noOfPoliciesPattern);
									
									if(result===0 || (1/result)===-Infinity || result <= 0 ){
										isMyGoalsValid =  false;
									}
									if((value.replace(/,/g,"")).length <= 10 ){
										isAmountValid =  true;
										
									}
									else{
										isAmountValid =  false;
									}
									if(!isAmountValid){
										scope.$parent.$parent.$parent.myGoalsValidationMessage = translateMessages($translate, "myBusiness.enterMaxMyGoals");
									}
									else if(!isMyGoalsValid){
										scope.$parent.$parent.$parent.myGoalsValidationMessage =translateMessages($translate, "myBusiness.enterPositiveMyGoals"); 
									}
									else{
										scope.$parent.$parent.$parent.myGoalsValidationMessage = "";
									}
								}
								else{
									scope.$parent.$parent.$parent.myGoalsValidationMessage = "";
								}
								break;

							case "Other payout\n(In Rs)":
								if(value != ""){
									
									if((1/value)===-Infinity || value < 0){
										isOtherPayoutValid = false;
									}else{
										if(validateInput(value.replace(/,/g,""),
												otherPayoutPattern) || validateInput(value.replace(/,/g,""),
														noOfPoliciesPattern)){
											isOtherPayoutValid = true;
										}
										else{
											isOtherPayoutValid = false;
										}
										if((value.replace(/,/g,"")).length <= 10 ){
											isPayoutValid =  true;
										}
										else{
											isPayoutValid =  false;
										}
									}
									
									if(!isPayoutValid){
										scope.$parent.$parent.$parent.otherPayOutValidationMessage = translateMessages($translate, "myBusiness.enterMaxPayout");
									}
									else if(!isOtherPayoutValid){
										scope.$parent.$parent.$parent.otherPayOutValidationMessage = translateMessages($translate, "myBusiness.enterPositivePayout");
									}
									else{
										scope.$parent.$parent.$parent.otherPayOutValidationMessage = "";
									}	
								}
								else{
									scope.$parent.$parent.$parent.otherPayOutValidationMessage = "";
								}
								break;
								
							 default:
								isPolicyValid = true;
								isCommissionPercentValid = true;
								isOtherPayoutValid = true;
								isMyGoalsValid = true;
							
							}

						}	
						
						else if(value == undefined || value == ""){
							
							switch (attrs.key) {
							
							case "No of Policies":
								isPolicyValid = true;
								scope.$parent.$parent.$parent.noOfPoliciesValidationMessage = "";
								break;
							
							case "Commission %":
								 isCommissionPercentValid = true;
								 scope.$parent.$parent.$parent.commissionPercentValidationMessage = "";
							break;
								
								
							case "My Goals\n(MFYP In Rs)":
								isMyGoalsValid = true;
								scope.$parent.$parent.$parent.myGoalsValidationMessage = "";
								break;

							case "Other payout\n(In Rs)":
								 isOtherPayoutValid = true;
								 scope.$parent.$parent.$parent.otherPayOutValidationMessage = "";
								break;
							
							}
							
							
						}
									if(isPolicyValid && isCommissionPercentValid && isOtherPayoutValid && isMyGoalsValid && isAmountValid && isPayoutValid && isNumeberValid){															
											for ( var i = 0; i < scope.$parent.$parent.$parent.goalDetails.length; i++) {

																if ((scope.$parent.$parent.$parent.goalDetails[i].month == monthIndex)
																		&& (scope.$parent.$parent.$parent.goalDetails[i].year == year)) {

																	switch (attrs.key) {
																	case "No of Policies":
																		scope.$parent.$parent.$parent.goalDetails[i].business[0].noOfPolicies = value.toString();
																		
																		break;

																	case "My Goals\n(MFYP In Rs)":
																		
																		var roundvalue = (Math.round((value.replace(/,/g,"")) / 1000)) * 1000;
																		
																		scope.$parent.$parent.$parent.goalDetails[i].business[0].myGoalsPremium = roundvalue.toString();
																		
																		
																		
																		break;

																	case "Other payout\n(In Rs)":
																		scope.$parent.$parent.$parent.goalDetails[i].business[0].myOtherEarnings = value.toString();
																		
																		break;

																	case "Commission %":
																		scope.$parent.$parent.$parent.goalDetails[i].business[0].commissionPercentage = value.toString();
																		
																		break;
																	}

                                                             if(scope.$parent.$parent.$parent.goalDetails[i].business[0].myGoalsPremium != "" && scope.$parent.$parent.$parent.goalDetails[i].business[0].commissionPercentage != ""){
                                                            	 scope.$parent.$parent.$parent.goalDetails[i].business[0].myCommissions = ((parseFloat(scope.$parent.$parent.$parent.goalDetails[i].business[0].myGoalsPremium.replace(/,/g,"")) * (parseFloat(scope.$parent.$parent.$parent.goalDetails[i].business[0].commissionPercentage)))/100).toFixed(2); 
																	
                                                            	 scope.$parent.$parent.$parent.tableData[3].data[i] = scope.$parent.$parent.$parent.goalDetails[i].business[0].myCommissions;
                                                             }
                                                             else{
                                                            	 scope.$parent.$parent.$parent.goalDetails[i].business[0].myCommissions = "";
                                                            	 scope.$parent.$parent.$parent.tableData[3].data[i] = "";
                                                             }
																		
																	if((scope.$parent.$parent.$parent.goalDetails[i].business[0].myCommissions == "" && scope.$parent.$parent.$parent.goalDetails[i].business[0].myOtherEarnings == "")){
																		scope.$parent.$parent.$parent.goalDetails[i].business[0].myTotalEarnings = "";
																	}
																	else{
																		if(scope.$parent.$parent.$parent.goalDetails[i].business[0].myCommissions == ""){
																			scope.$parent.$parent.$parent.goalDetails[i].business[0].myTotalEarnings = parseFloat(scope.$parent.$parent.$parent.goalDetails[i].business[0].myOtherEarnings.replace(/,/g,""));
																		}
																		else if(scope.$parent.$parent.$parent.goalDetails[i].business[0].myOtherEarnings == ""){
																			scope.$parent.$parent.$parent.goalDetails[i].business[0].myTotalEarnings = parseFloat(scope.$parent.$parent.$parent.goalDetails[i].business[0].myCommissions.toString().replace(/,/g,""));
																		}
																		else{
																			if(scope.$parent.$parent.$parent.goalDetails[i].business[0].myOtherEarnings.replace(/,/g,"") == "."){
																				scope.$parent.$parent.$parent.goalDetails[i].business[0].myTotalEarnings = "";
																			}
																			else{
																				scope.$parent.$parent.$parent.goalDetails[i].business[0].myTotalEarnings = parseFloat(scope.$parent.$parent.$parent.goalDetails[i].business[0].myCommissions)+parseFloat(scope.$parent.$parent.$parent.goalDetails[i].business[0].myOtherEarnings.replace(/,/g,""));
																			}
																				
																			
																		}
																	}
                                                                scope.$parent.$parent.$parent.tableData[5].data[i] = scope.$parent.$parent.$parent.goalDetails[i].business[0].myTotalEarnings;		
																	
																	}
																																			
																}
	
														}											
});
				}
			}
		});




servDirectives
.directive('clickstream', function (ObservationService, $location,UserDetailsService,appDataShareService,commonConfig) {
    'use strict';
    return {
        restrict: 'E',
        link: function (scope, element, attrs) {
            /*Observation is not saved if user comes through QuickLinks button in home page*/
        var formattedDate = getFormattedDate();
        var formattedTime = getFormattedTime();
        var agentId = "";
    	var agentDetails = $.parseJSON(localStorage.getItem(getUniqueAppNamePattern(commonConfig().STORAGE.AGENT_ID)));
        if(agentDetails && agentDetails.Id){
			var agentId =  agentDetails.Id;
		}
   
        var subOrdinateId = "";
        var deviceId = "";
        deviceId = appDataShareService.deviceId;
       
        if(agentId !="" && agentId != appDataShareService.selectedUser.userId){
        	 subOrdinateId = appDataShareService.selectedUser.userId;
        }
       
        
       if(appDataShareService.isReloadIntiated){
    	   
    	   appDataShareService.isReloadIntiated =  false;
       }
       else{
    	 
    	   ObservationService.store({
         		
               pageDesc: "",
		        createdOn: "",
				customer: "",
				modifiedOn: "",
				email: "",
				agent: agentId,
				
				
				subOrdinateId:subOrdinateId,
				deviceId:deviceId,
				loggedDate:formattedDate,
				loggedTime:formattedTime,
				module:scope.selectedpage,
				subModule:scope.subModule
				},scope);

   } 
       }
       
    };
});
