

var gliServDirectives = angular.module('serv.gliServDirectives', []);

gliServDirectives.directive('alphanumericOnly', function(){
   return {
     require: 'ngModel',
     link: function(scope, element, attrs, modelCtrl) {
       modelCtrl.$parsers.push(function (inputValue) {
           // this next if is necessary for when using ng-required on your input.
           // In such cases, when a letter is typed first, this parser will be called
           // again, and the 2nd time, the value will be undefined
           if (inputValue == undefined){
				return '';
		   }
           var transformedInput = inputValue.replace(/[^a-zA-Z0-9 ]*$/, '');
           if (transformedInput!=inputValue) {
              modelCtrl.$setViewValue(transformedInput);
              modelCtrl.$render();
           }

           return transformedInput;
       });
     }
   };
});

gliServDirectives.directive('numbersOnly', function(){
   return {
     require: 'ngModel',
     link: function(scope, element, attrs, modelCtrl) {
       modelCtrl.$parsers.push(function (inputValue) {
           // this next if is necessary for when using ng-required on your input.
           // In such cases, when a letter is typed first, this parser will be called
           // again, and the 2nd time, the value will be undefined
    	   //restrict to maxlength explicitly
    	   var len;
    	   if(attrs.fieldlength){
    	   len = attrs.fieldlength;
    	   }

           if (inputValue == undefined){
			return '';
		   }
           var transformedInput = inputValue.replace(/[^0-9]/g, '');
		   if(inputValue.length>len){
           transformedInput = inputValue.substring(0,len);
		   }
           if (transformedInput!=inputValue) {
              modelCtrl.$setViewValue(transformedInput);
              modelCtrl.$render();
           }

           return transformedInput;
       });
     }
   };
});

gliServDirectives.directive('alphanumericWithSpecialcharecters', function(){
	   return {
	     require: 'ngModel',
	     link: function(scope, element, attrs, modelCtrl) {
	       modelCtrl.$parsers.push(function (inputValue) {
	           // this next if is necessary for when using ng-required on your input.
	           // In such cases, when a letter is typed first, this parser will be called
	           // again, and the 2nd time, the value will be undefined
	           if (inputValue == undefined){
				return '';
			   }
	           var transformedInput = inputValue.replace(/[^a-zA-Z0-9 @!#\$\^%&*()_+=\-\[\]\\\';,\.\/\{\}\|\":<>\?]*$/, '');
	           if (transformedInput!=inputValue) {
	              modelCtrl.$setViewValue(transformedInput);
	              modelCtrl.$render();
	           }

	           return transformedInput;
	       });
	     }
	   };
	});
gliServDirectives.directive('checkboxClickCondition', function(){
	   return {
		 restrict: 'A',
	     link: function(scope, element, attrs, modelCtrl) {
	    	 var remarkValue = attrs.value;
	    	 var currentScope = scope;
	    	 $(element).on('click', function (event) {
                 currentScope.$parent.$parent.dataRow.isActive = true;
					if(typeof currentScope.$parent.$parent.dataRow.comment !== 'undefined' && currentScope.$parent.$parent.dataRow.comment.length > 0){
                        event.preventDefault();
						$(this).parent().parent().parent().find('#confirmRemark').modal();
					}
					else{
						//currentScope.$parent.$parent.dataRow.isRemarksVisible = !currentScope.$parent.$parent.dataRow.isRemarksVisible;
					}
				});
	     }
	   };
	});
gliServDirectives.directive('moveToTop', function(){
   return {
	restrict:'A',
     link: function(scope, element, attrs) {
		var container = angular.element(document);
        var isExecuted = false; 
			container.on('scroll', function(e) {
				if (container.scrollTop() > 800) {
					$(element).addClass('show');
				} else {
					$(element).removeClass('show');
				}
                if((container.scrollTop() > (container.height() - (window.innerHeight + 100))) && !isExecuted) {
					scope.$emit("requestDataSet");
                    isExecuted = true;
                    setTimeout(function() {
						isExecuted = false;
                    }, 1500);
				}
			});
     }
   };
});

gliServDirectives.directive('gliOpenNativeApp', function(){
   return {
	restrict:'A',
     link: function(scope, element, attrs) {
        var appName = attrs.app;
        $(element).on('click', function() {
            $("#actionPopupSharePopupModal").modal('hide');
			if (/webOS|iPhone|iPad/i.test(navigator.userAgent)) {
					var options = {
					  message: 'Message', 
					  subject: null, 
					  files: null, 
					  url: null,
					  chooserTitle: null 
					}

					var onSuccess = function(result) {
					}

					var onError = function(msg) {
					}

					window.plugins.socialsharing.shareWithOptions(options, onSuccess, onError);
			}
			else{	
				switch(appName){
					case 'whatsapp':
						window.plugins.socialsharing.shareViaWhatsApp(null, null /* img */, null /* url */,
						function() {console.log('Application Opened');},
						function(errormsg){console.log(errormsg);}); 
						break;
					case 'gmail':
						window.plugins.socialsharing.shareVia('com.google.android.gm', '', null, null, null,
						function(){console.log('share ok');}, // success Callback
						function(msg) {alert('error: ' + msg);}); // Error Call Back
					default:break;
				}
			}
        });
     }
    };
});


gliServDirectives.directive('gliMaxLength', function(){
   return {
              restrict: 'A',
              require:'ngModel',
              scope:{ },
              link: function(scope, element, attrs, ngModelCtrl) {
                  ngModelCtrl.$parsers.push(function(value) {                      
                          var maxLength=attrs.maxlength;
                          if(value.length > maxLength)
                           {
                               var newVal=value.substring(0,maxLength);
                               $(element).val(newVal);
                               return newVal;
                           }
                           else
                           {
                           	    return value;
                           }                      
                  });
              }
      }
});
gliServDirectives.directive('updateHeightInfo', function(){
   return {
            restrict: 'A',
            link: function(scope, element, attrs) {
			var currentElement = element;
				scope.$watch(function(){return element.attr('class');},function(newValue){
					 if (newValue.match(/ng-hide/) == null) {
						var new_height =angular.element(currentElement).find('div.more-info-content-section').height();
						if(new_height == 0 || new_height == null || typeof(new_height)!= 'number'){
							new_height = 200;
						}
						angular.element(currentElement).find('div.height-wrapper').height(new_height+10);
					}       
				});
            }
      }
});


gliServDirectives
.directive('gliclickstream', function (GLI_ObservationService, $location,UserDetailsService,appDataShareService,commonConfig) {
    'use strict';
    return {
        restrict: 'E',
        link: function (scope, element, attrs) {
            /*Observation is not saved if user comes through QuickLinks button in home page*/
        var formattedDate = getFormattedDate();
        var formattedTime = getFormattedTime();
        var selectedpage = attrs.pageid;
        var deviceInfo = '';
        var agentDetails = sessionStorage.userDetails ? $.parseJSON(sessionStorage.userDetails) : "";
        var agentId = "";
		var rexitID = "";
        if(sessionStorage && sessionStorage.userDetails){
			agentId =  agentDetails.user.userId;
			rexitID = agentDetails.user.rexitLoginId;
		}
        var subOrdinateId = "";
        if(navigator.userAgent.indexOf("Android") > 0 && rootConfig.isDeviceMobile){
        	var deviceId = "Android";
        	if(window.device)
        	deviceInfo = JSON.stringify(window.device).replace(/"/g,'');
        } else if(rootConfig.isDeviceMobile && (navigator.userAgent.indexOf("iPhone") > 0 || navigator.userAgent.indexOf("iPad") > 0 || navigator.userAgent.indexOf("iPod") > 0)){
        	var deviceId = "iOS";
        	if(window.device)
        	deviceInfo = JSON.stringify(window.device).replace(/"/g,'');
        } else {
        	var deviceId = "Desktop"
        	if(window.device)
        	deviceInfo = navigator.userAgent;
        }

    	   GLI_ObservationService.store({

               pageDesc: "",
		        createdOn: "",
				customer: "",
				modifiedOn: "",
				email: "",
				agent: agentId,
				rexitID: rexitID,
				deviceInfo: deviceInfo,
				subOrdinateId:subOrdinateId,
				deviceId:deviceId,
				loggedDate:formattedDate + " " + formattedTime,
				loggedTime:formattedTime,
				module:selectedpage,
				subModule:""
				},scope);
       }

    };
});

gliServDirectives.directive('numbersWithDash', function(){
   return {
     require: 'ngModel',
     link: function(scope, element, attrs, modelCtrl) {
       modelCtrl.$parsers.push(function (inputValue) {
           // this next if is necessary for when using ng-required on your input.
           // In such cases, when a letter is typed first, this parser will be called
           // again, and the 2nd time, the value will be undefined
    	   //restrict to maxlength explicitly
    	   var len;
    	   if(attrs.fieldlength){
    	   len = attrs.fieldlength;
    	   }

           if (inputValue == undefined){
			return '';
		   }
           var transformedInput = inputValue.replace(/[^0-9\-]/g, '');
		   if(inputValue.length>len){
           transformedInput = inputValue.substring(0,len);
		   }
           if (transformedInput!=inputValue) {
              modelCtrl.$setViewValue(transformedInput);
              modelCtrl.$render();
           }

           return transformedInput;
       });
     }
   };
});
