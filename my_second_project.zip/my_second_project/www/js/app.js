var mServiceApp = angular.module('lifeEngage', ['ngRoute','ui.bootstrap','lifeEngage.dataService','lifeEngage.debounce','lifeEngage.AutoSync','pascalprecht.translate', 'lifeEngage.authService','lifeEngage.UserDetailsService','lifeEngage.ObservationService','lifeEngage.PersistenceMapping','lifeEngage.chart','lifeEngage.LoginService','lifeEngage.AgentService','lifeEngage.MserviceVariables','smartTable.table','serv.directives','ngCsv','ngSanitize','ngTable','constants', 'lifeEngage.formatter','lifeEngage.UtilityService','lifeEngage.DataLookupService','lifeEngage.DocumentService',
					'lifeEngage.EmailService','lifeEngage.TemplateService','lifeEngage.PlatformInfoService','lifeEngage.gli_dataservice','serv.gliServDirectives','dibari.angular-ellipsis','smoothScroll','ngIOS9UIWebViewPatch','lifeEngage.GLI_ObservationService','lifeEngage.DataWipeService'], function ($interpolateProvider) {
    $interpolateProvider.startSymbol('[[');
    $interpolateProvider.endSymbol(']]');
	});
mServiceApp.value('appDataShareService', {	
	 json: {},
	    loginPopupJson: {},
	    alertjson: {},
	    policysearchjson: {},
	    customerContactjson: {},
	    policyStatusJson: {policyStatus:["Active","Suspended","Terminated"]},
	    contractTypeJson: {contractType:["Advance Loss of Profit-Marine","Marine Certificate","Boiler & Pressure Vessel","Contractors' All Risks","Deterioration Of Stock","Electronic Equipment","Machinery Breakdown","M/Breakdown Loss Of Profit","Erection All Risk","Contractor Plant & Machinery","Crops (Growing Trees)","Fire","Motor-Private Car","Houseowner/Householder","Consequential Loss" ]},
	    majorClassJson: {majorClass:["Aviation","Bond","Engineering","Fire","Liability","Marine Cargo","Marine Hull","Medical","Miscellaneous","Motor Vehicle","Oil & Gas","Personal Accident","Workmen's Compensation"]},
	    proposalsearchjson: {},
	    premiumcalenderjson: {},
	    mybusinessjson: {},
	    myearningsjson : {},
	    mypotentialtoearnjson : {},
	    myrrjson: {},
	    premiumFrequencyJson: {},
	    productNameJson: {},
	    performanceJson:{},
	    pottentialJson:{},
	    dashBoardJson:{},
	    proposalStatusJson : {},
	    planTypeJson : {},
	    recruitmentdashboardjson :{},
	    admDashboardjson :{},
	    salesleadjson: {},
		alert:{selectedFilter:"today"},
		dashboard:{selectedFilter:"dueForRenewal7days"},
		authorizationToken:"abcd",
		alertBusinessOverview:{selectedFilter:"ytd"},
		potentialToEarn:{selectedFilter:"all"},
		leadSource:{selectedFilter:"lastYear"},
		salesDashboard:{selectedFilter:"today"},
		recruitmentDashboard:{selectedFilter:"today"},
		accordion:{index :"0",intialIndex:"0"},
		pushSubType:{subType :"Birthday"},
		refreshApp:true,
		isSwitchEnabled:false,
		user:{userName:"tom", userId:"1", reporties:[]},
		selectedUser:{userName:"tom", userId: "111441"},
		reporties:"",
		isSync:false,
		deviceId:"",
		mContentRoles:"not authenticated"
    }
  )

/*  routeProvider
* set the partial routing  
*/
mServiceApp.config(['$routeProvider', '$httpProvider', function ($routeProvider, $httpProvider) {
    $routeProvider.
      //Need to uncomment once the home page is done
      // when('/', { templateUrl: 'modules/eApp/partials/Home.html', controller: HomeController }).
      //remove this routing once the home page is done
		when('/', { templateUrl: 'modules/login/partials/login.html', controller: 'GLI_LoginCtrl', action: "Login.Login"}).
		when('/login', { templateUrl: 'modules/login/partials/login.html', controller: 'GLI_LoginCtrl',action: "Login.Login" }).
		when('/dashboard', { templateUrl: 'modules/dashboard/partials/dashboard.html', controller: 'GLI_DashBoardCtrl', action: "DashBoard.DashBoard"}).

		when('/customerService', { templateUrl: 'modules/customerservice/policyServicing/partials/policy-search.html', controller: 'GLI_PolicySearchCtrl'}).
		when('/customerService/claimsInquiry', { templateUrl: 'modules/customerservice/claimsInquiry/partials/claims-inquiry.html', controller: 'ClaimsInquery'}).
		when('/customerService/policySearch', { templateUrl: 'modules/customerservice/policyServicing/partials/policy-search.html', controller: 'GLI_PolicySearchCtrl'}).
		when('/customerService/policySearch/:pageName', { templateUrl: 'modules/customerservice/policyServicing/partials/policy-search.html', controller: 'GLI_PolicySearchCtrl'}).
		when('/customerService/proposalSearch', { templateUrl: 'modules/customerservice/policyServicing/partials/proposal-search.html', controller: 'ProposalSearchCtrl'}).
		when('/customerService/premiumCalendar', { templateUrl: 'modules/customerservice/premiumCalendar/partials/policy-renewal-calendar.html', controller: 'GLI_PolicyRenewalCalendarCtrl'}).
		when('/customerregistration', { templateUrl: 'modules/login/partials/registration.html', controller: 'CustomerRegistrationCtrl'}).
		when('/forgotpassword', { templateUrl: 'modules/login/partials/forgotpassword.html', controller: 'ForgotPasswordCtrl'}).
		when('/resetPassword', { templateUrl: 'modules/login/partials/resetPassword.html', controller: 'ForgotPasswordCtrl'}).
		when('/setSecretQuestion', { templateUrl: 'modules/login/partials/secret-qn-answer.html', controller: 'ForgotPasswordCtrl'}).
		when('/policyDueForRenewal', { templateUrl: 'modules/dashboard/partials/policy-due-for-renewal.html', controller: 'policyDueForRenewalController'}).
        when('/policyDueForRenewal/:defaultDays', { templateUrl: 'modules/dashboard/partials/policy-due-for-renewal.html', controller: 'policyDueForRenewalController'}).
        when('/claimsLogged', { templateUrl: 'modules/dashboard/partials/claims-logged.html', controller: 'ClaimsLoggedCtrl'}).
        when('/location', { templateUrl: 'modules/location/partials/location.html', controller: 'locationController'}).
        when('/performance', { templateUrl: 'modules/dashboard/partials/performance.html', controller: 'performanceCtrl'}).  
		when('/notification/claimAlerts', { templateUrl: 'modules/notification/partials/notification.html', controller: 'NotificationCtrl',action:"notification.claimAlerts"}).  
		when('/notification/cpdHrsTracking', { templateUrl: 'modules/notification/partials/notification.html', controller: 'NotificationCtrl',action:"notification.cpdHrsTracking"}).
		when('/notification/impCommunication', { templateUrl: 'modules/notification/partials/notification.html', controller: 'NotificationCtrl',action:"notification.impCommunication"}).
		when('/notification/relationship', { templateUrl: 'modules/notification/partials/notification.html', controller: 'NotificationCtrl', action:"notification.relationship"}).
        when('/relationship', { templateUrl: 'modules/notification/partials/relationship-management.html', controller: 'RelationshipManagementCtrl'}).
		when('/impCommunication', { templateUrl: 'modules/notification/partials/impCommunication.html', controller: 'ImpCommunicationCtrl'}).  	
		when('/claimAlerts', { templateUrl: 'modules/notification/partials/claimAlerts.html', controller: 'ClaimAlertsCtrl'}).      
		when('/cpdHrsTracking', { templateUrl: 'modules/notification/partials/CPDWorkingHrs.html', controller: 'CpdWorkingHrsCtrl'}).        
		when('/formDownloads/soa/:pageName', { templateUrl: 'modules/Forms/partials/soa.html', controller: 'SOACtrl'}).        
		when('/formDownloads/guides/:pageName', { templateUrl: 'modules/Forms/partials/guides.html', controller: 'GuidesCtrl'}).
        when('/formDownloads/forms/:pageName', { templateUrl: 'modules/Forms/partials/form.html', controller: 'GuidesCtrl'}).
        when('/formDownloads/products/:pageName', { templateUrl: 'modules/Forms/partials/products.html', controller: 'GuidesCtrl'}).
        when('/formDownloads/renewalSummary/:pageName', { templateUrl: 'modules/Forms/partials/renewal-summary.html', controller: 'RenewalSummaryCtrl'}).
        when('/formDownloads/piam/:pageName', { templateUrl: 'modules/Forms/partials/piam.html', controller: 'GuidesCtrl'}).
        when('/formDownloads/panelHospital/:pageName', { templateUrl: 'modules/Forms/partials/panel-hospitals.html', controller: 'GuidesCtrl'}).
        when('/customerService/customerContact', { templateUrl: 'modules/customerservice/customerContact/partials/customer-list.html', controller: 'customerContactCtrl'}).
		when('/accountInfo/:pageName', { templateUrl: 'modules/accountInfo/partial/accountInfo.html', controller: 'SOACtrl'}).		when('/settings/changePassword', { templateUrl: 'modules/settings/partials/change-password.html', controller: 'ChangePasswordCtrl'}).        otherwise({ redirectTo: '/login' });


    var interceptor = ['$location', '$q', function ($location, $q) {
        function success(response) {
            return response;
        }
        function error(response) {
            if (response.status === 401) {
                $location.path('/login');
                return $q.reject(response);
            }
            else {
                return $q.reject(response);
            };
        }
        return function (promise) {
            return promise.then(success, error);
        }
    } ];

    $httpProvider.interceptors.push(interceptor);
	
	if (rootConfig.isDeviceMobile) {
		$httpProvider.defaults.headers.post['source'] = "200";
	} else {
		$httpProvider.defaults.headers.post['source'] = "100";
	} 

} ])
.run(['$rootScope', '$location', 'authService', function ($rootScope, $location, authService) {

    $rootScope.$on("$routeChangeStart", function (event, next, current) {
      
        if (!authService.isLoggedIn($rootScope)) $location.path('/login');
          
         
    });
    
    $rootScope.moduleVariable="Customer";
	
	$rootScope.$on('$locationChangeSuccess', function() {
        $rootScope.actualLocation = $location.path();
    });        

   $rootScope.$watch(function () {return $location.path()}, function (newLocation, oldLocation) {
        if($rootScope.actualLocation === newLocation) {
			$('.modal:visible').not('#showGPSExpirymsg').not('#showExpirymsg').modal('hide');
			if(oldLocation.indexOf('guides/guide') >-1 && $('#showExpirymsg:visible').length == 0){
				$('.modal-backdrop.fade').remove();
			}
			if(oldLocation.indexOf('policySearch/Customer Contact') >-1 && newLocation.indexOf('/customerService/customerContact')>-1){
				$rootScope.$broadcast('backToCustomerContact');
			}
            if(oldLocation.indexOf('policyDueForRenewal/premiumCalendar') >-1 && newLocation.indexOf('customerService/premiumCalendar')>-1){
				$rootScope.$broadcast('backToPremiumCalendar');
			}
        }
    });
    $rootScope.$on('$locationChangeStart', function() {
                ga('set', 'page', $location.path());
                ga('send', 'pageview');
    });
} ]);


/*  translateProvider
* register supporting languages
*/

mServiceApp.config(['$translateProvider', function ($translateProvider) {
    // register english translation table
    $translateProvider.translations('en_EN', resources.en_EN);
    $translateProvider.preferredLanguage(rootConfig.defaultLanguage);
    // register thai translation table
    //Default set to english
    
	/*if (rootConfig.isDeviceMobile) {

    if (localStorage[getUniqueAppNamePattern(commonConfig().STORAGE.DEFAULT_LANGAUGE)] != "en_US")
    {
        $translateProvider.preferredLanguage("en_EN");
    } else {
        $translateProvider.preferredLanguage("en_EN");
    }

	} else {
		if(localStorage[getUniqueAppNamePattern(commonConfig().STORAGE.DEFAULT_LANGAUGE)] != undefined) {
			$translateProvider.preferredLanguage(localStorage[getUniqueAppNamePattern(commonConfig().STORAGE.DEFAULT_LANGAUGE)]);
		}
		else
			{
			$translateProvider.preferredLanguage(rootConfig.defaultLanguage);
			}
		
	}*/
	
	
} ]);

