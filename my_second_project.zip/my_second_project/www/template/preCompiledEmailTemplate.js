(function() {
	var template = Handlebars.template, templates = Handlebars.templates = Handlebars.templates
			|| {};
	templates['lePreCompiledEmailTemplate'] = template(function (Handlebars,depth0,helpers,partials,data) {
  helpers = helpers || Handlebars.helpers; data = data || {};
  var buffer = "", stack1, functionType="function", escapeExpression=this.escapeExpression, self=this;


  function program1(depth0,data) {
  
  var buffer = "", stack1, foundHelper;
  buffer += "\r\n\r\n			<U><h2>";
  foundHelper = helpers.composeHeader;
  if (foundHelper) { stack1 = foundHelper.call(depth0, {hash:{}}); }
  else { stack1 = depth0.composeHeader; stack1 = typeof stack1 === functionType ? stack1() : stack1; }
  buffer += escapeExpression(stack1) + " : -</h2></U>\r\n\r\n			";
  stack1 = depth0.type;
  stack1 = helpers.ifCond.call(depth0, stack1, "Issue", {hash:{},inverse:self.noop,fn:self.program(2, program2, data)});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n			\r\n				<p>- ";
  foundHelper = helpers.descriptionTitle;
  if (foundHelper) { stack1 = foundHelper.call(depth0, {hash:{}}); }
  else { stack1 = depth0.descriptionTitle; stack1 = typeof stack1 === functionType ? stack1() : stack1; }
  buffer += escapeExpression(stack1) + " : ";
  foundHelper = helpers.description;
  if (foundHelper) { stack1 = foundHelper.call(depth0, {hash:{}}); }
  else { stack1 = depth0.description; stack1 = typeof stack1 === functionType ? stack1() : stack1; }
  buffer += escapeExpression(stack1) + "</p>\r\n				<p>- ";
  foundHelper = helpers.contactNumberTitle;
  if (foundHelper) { stack1 = foundHelper.call(depth0, {hash:{}}); }
  else { stack1 = depth0.contactNumberTitle; stack1 = typeof stack1 === functionType ? stack1() : stack1; }
  buffer += escapeExpression(stack1) + " : ";
  foundHelper = helpers.contactNumber;
  if (foundHelper) { stack1 = foundHelper.call(depth0, {hash:{}}); }
  else { stack1 = depth0.contactNumber; stack1 = typeof stack1 === functionType ? stack1() : stack1; }
  buffer += escapeExpression(stack1) + "</p>\r\n				\r\n			<U><h2>";
  foundHelper = helpers.agentDetails;
  if (foundHelper) { stack1 = foundHelper.call(depth0, {hash:{}}); }
  else { stack1 = depth0.agentDetails; stack1 = typeof stack1 === functionType ? stack1() : stack1; }
  buffer += escapeExpression(stack1) + " : -</h2></U>\r\n			\r\n			<p>- ";
  foundHelper = helpers.agentCodeTitle;
  if (foundHelper) { stack1 = foundHelper.call(depth0, {hash:{}}); }
  else { stack1 = depth0.agentCodeTitle; stack1 = typeof stack1 === functionType ? stack1() : stack1; }
  buffer += escapeExpression(stack1) + " : ";
  foundHelper = helpers.agentCode;
  if (foundHelper) { stack1 = foundHelper.call(depth0, {hash:{}}); }
  else { stack1 = depth0.agentCode; stack1 = typeof stack1 === functionType ? stack1() : stack1; }
  buffer += escapeExpression(stack1) + "</p>\r\n			<p>- ";
  foundHelper = helpers.agentNameTitle;
  if (foundHelper) { stack1 = foundHelper.call(depth0, {hash:{}}); }
  else { stack1 = depth0.agentNameTitle; stack1 = typeof stack1 === functionType ? stack1() : stack1; }
  buffer += escapeExpression(stack1) + " : ";
  foundHelper = helpers.agentName;
  if (foundHelper) { stack1 = foundHelper.call(depth0, {hash:{}}); }
  else { stack1 = depth0.agentName; stack1 = typeof stack1 === functionType ? stack1() : stack1; }
  buffer += escapeExpression(stack1) + "</p>\r\n		\r\n			<br> \r\n			";
  foundHelper = helpers.emailFooter;
  if (foundHelper) { stack1 = foundHelper.call(depth0, {hash:{}}); }
  else { stack1 = depth0.emailFooter; stack1 = typeof stack1 === functionType ? stack1() : stack1; }
  buffer += escapeExpression(stack1) + " \r\n		\r\n ";
  return buffer;}
function program2(depth0,data) {
  
  var buffer = "", stack1, foundHelper;
  buffer += "\r\n				\r\n				<p>- ";
  foundHelper = helpers.moduleTitle;
  if (foundHelper) { stack1 = foundHelper.call(depth0, {hash:{}}); }
  else { stack1 = depth0.moduleTitle; stack1 = typeof stack1 === functionType ? stack1() : stack1; }
  buffer += escapeExpression(stack1) + " : ";
  foundHelper = helpers.moduleName;
  if (foundHelper) { stack1 = foundHelper.call(depth0, {hash:{}}); }
  else { stack1 = depth0.moduleName; stack1 = typeof stack1 === functionType ? stack1() : stack1; }
  buffer += escapeExpression(stack1) + "</p>\r\n				<p>- ";
  foundHelper = helpers.screenTitle;
  if (foundHelper) { stack1 = foundHelper.call(depth0, {hash:{}}); }
  else { stack1 = depth0.screenTitle; stack1 = typeof stack1 === functionType ? stack1() : stack1; }
  buffer += escapeExpression(stack1) + " : ";
  foundHelper = helpers.screenName;
  if (foundHelper) { stack1 = foundHelper.call(depth0, {hash:{}}); }
  else { stack1 = depth0.screenName; stack1 = typeof stack1 === functionType ? stack1() : stack1; }
  buffer += escapeExpression(stack1) + "</p>\r\n				\r\n			";
  return buffer;}

function program4(depth0,data) {
  
  var buffer = "", stack1, foundHelper;
  buffer += "\r\n		\r\n					  *********************************************\r\n					 \r\n					    	";
  foundHelper = helpers.deviceInformation;
  if (foundHelper) { stack1 = foundHelper.call(depth0, {hash:{}}); }
  else { stack1 = depth0.deviceInformation; stack1 = typeof stack1 === functionType ? stack1() : stack1; }
  buffer += escapeExpression(stack1) + " \r\n					 \r\n					  *********************************************\r\n					 \r\n					\r\n						";
  foundHelper = helpers.devicePlatform;
  if (foundHelper) { stack1 = foundHelper.call(depth0, {hash:{}}); }
  else { stack1 = depth0.devicePlatform; stack1 = typeof stack1 === functionType ? stack1() : stack1; }
  buffer += escapeExpression(stack1) + "     -   ";
  stack1 = depth0.deviceInfo;
  stack1 = stack1 == null || stack1 === false ? stack1 : stack1.platform;
  stack1 = typeof stack1 === functionType ? stack1() : stack1;
  buffer += escapeExpression(stack1) + "\r\n						\r\n						";
  foundHelper = helpers.deviceVersion;
  if (foundHelper) { stack1 = foundHelper.call(depth0, {hash:{}}); }
  else { stack1 = depth0.deviceVersion; stack1 = typeof stack1 === functionType ? stack1() : stack1; }
  buffer += escapeExpression(stack1) + "      -   ";
  stack1 = depth0.deviceInfo;
  stack1 = stack1 == null || stack1 === false ? stack1 : stack1.version;
  stack1 = typeof stack1 === functionType ? stack1() : stack1;
  buffer += escapeExpression(stack1) + "\r\n						\r\n						";
  foundHelper = helpers.deviceVersionModel;
  if (foundHelper) { stack1 = foundHelper.call(depth0, {hash:{}}); }
  else { stack1 = depth0.deviceVersionModel; stack1 = typeof stack1 === functionType ? stack1() : stack1; }
  buffer += escapeExpression(stack1) + " -   ";
  stack1 = depth0.deviceInfo;
  stack1 = stack1 == null || stack1 === false ? stack1 : stack1.model;
  stack1 = typeof stack1 === functionType ? stack1() : stack1;
  buffer += escapeExpression(stack1) + "\r\n						\r\n					 	";
  foundHelper = helpers.deviceUUID;
  if (foundHelper) { stack1 = foundHelper.call(depth0, {hash:{}}); }
  else { stack1 = depth0.deviceUUID; stack1 = typeof stack1 === functionType ? stack1() : stack1; }
  buffer += escapeExpression(stack1) + "         -   ";
  stack1 = depth0.deviceInfo;
  stack1 = stack1 == null || stack1 === false ? stack1 : stack1.uuid;
  stack1 = typeof stack1 === functionType ? stack1() : stack1;
  buffer += escapeExpression(stack1) + "\r\n					 \r\n					\r\n					  *********************************************\r\n";
  return buffer;}

function program6(depth0,data) {
  
  var buffer = "", stack1, foundHelper;
  buffer += "\r\n\r\n					  *********************************************\r\n					 \r\n					    	    ";
  foundHelper = helpers.browserInformation;
  if (foundHelper) { stack1 = foundHelper.call(depth0, {hash:{}}); }
  else { stack1 = depth0.browserInformation; stack1 = typeof stack1 === functionType ? stack1() : stack1; }
  buffer += escapeExpression(stack1) + " \r\n					 \r\n					  *********************************************\r\n					 \r\n					\r\n						";
  foundHelper = helpers.browserName;
  if (foundHelper) { stack1 = foundHelper.call(depth0, {hash:{}}); }
  else { stack1 = depth0.browserName; stack1 = typeof stack1 === functionType ? stack1() : stack1; }
  buffer += escapeExpression(stack1) + "     -   ";
  stack1 = depth0.browserInfo;
  stack1 = stack1 == null || stack1 === false ? stack1 : stack1.browserName;
  stack1 = typeof stack1 === functionType ? stack1() : stack1;
  buffer += escapeExpression(stack1) + "												\r\n						\r\n						";
  foundHelper = helpers.browserVersion;
  if (foundHelper) { stack1 = foundHelper.call(depth0, {hash:{}}); }
  else { stack1 = depth0.browserVersion; stack1 = typeof stack1 === functionType ? stack1() : stack1; }
  buffer += escapeExpression(stack1) + "  -   ";
  stack1 = depth0.browserInfo;
  stack1 = stack1 == null || stack1 === false ? stack1 : stack1.browserVersion;
  stack1 = typeof stack1 === functionType ? stack1() : stack1;
  buffer += escapeExpression(stack1) + "\r\n						\r\n						";
  foundHelper = helpers.language;
  if (foundHelper) { stack1 = foundHelper.call(depth0, {hash:{}}); }
  else { stack1 = depth0.language; stack1 = typeof stack1 === functionType ? stack1() : stack1; }
  buffer += escapeExpression(stack1) + " 		-	";
  stack1 = depth0.browserInfo;
  stack1 = stack1 == null || stack1 === false ? stack1 : stack1.language;
  stack1 = typeof stack1 === functionType ? stack1() : stack1;
  buffer += escapeExpression(stack1) + "\r\n						\r\n					 	";
  foundHelper = helpers.platform;
  if (foundHelper) { stack1 = foundHelper.call(depth0, {hash:{}}); }
  else { stack1 = depth0.platform; stack1 = typeof stack1 === functionType ? stack1() : stack1; }
  buffer += escapeExpression(stack1) + "        -   ";
  stack1 = depth0.browserInfo;
  stack1 = stack1 == null || stack1 === false ? stack1 : stack1.platform;
  stack1 = typeof stack1 === functionType ? stack1() : stack1;
  buffer += escapeExpression(stack1) + "\r\n					 \r\n					\r\n					  *********************************************\r\n					\r\n";
  return buffer;}

  buffer += "\r\n";
  stack1 = depth0.templateID;
  stack1 = helpers.ifCond.call(depth0, stack1, "emailTemplate", {hash:{},inverse:self.noop,fn:self.program(1, program1, data)});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n	\r\n";
  stack1 = depth0.templateID;
  stack1 = helpers.ifCond.call(depth0, stack1, "attachDeviceFileTemplate", {hash:{},inverse:self.noop,fn:self.program(4, program4, data)});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "	 	\r\n\r\n";
  stack1 = depth0.templateID;
  stack1 = helpers.ifCond.call(depth0, stack1, "attachBrowserFileTemplate", {hash:{},inverse:self.noop,fn:self.program(6, program6, data)});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n";
  return buffer;}
  
  );
})();